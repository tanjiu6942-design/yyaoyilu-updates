﻿import { SCREEN_WIDTH, SCREEN_HEIGHT, PIXEL_RATIO } from './render.js';
import SceneManager from './game/scene.js';
import { createMenuScene } from './game/scenes/MenuScene.js';
import { createMapScene } from './game/scenes/MapScene.js';
import { createBattleScene } from './game/scenes/BattleScene.js';
import { createEventScene } from './game/scenes/EventScene.js';
import { createRestScene } from './game/scenes/RestScene.js';
import { createShopScene } from './game/scenes/ShopScene.js';
import { loadCardTemplate, loadCardIcons } from './game/cardFrame.js';
import { soundManager } from './runtime/music.js';

export default class Main {
  constructor() {
    this.ctx = canvas.getContext('2d');

    // 高分屏适配：坐标系按逻辑像素缩放
    if (PIXEL_RATIO > 1) {
      this.ctx.scale(PIXEL_RATIO, PIXEL_RATIO);
    }

    this.width = SCREEN_WIDTH;
    this.height = SCREEN_HEIGHT;

    // 帧率统计（全局可配置，设置里可以开关）
    this.fps = 0;
    this.frameCount = 0;
    this.lastFpsTime = Date.now();
    if (typeof window !== 'undefined') {
      window.gameConfig = window.gameConfig || {};
      if (window.gameConfig.showFps === undefined) window.gameConfig.showFps = false;
    }

    // 显式将渲染帧率锁定到平台上限 60（省电/发热降频时也优先跑满）
    if (typeof wx !== 'undefined' && wx.setPreferredFramesPerSecond) {
      wx.setPreferredFramesPerSecond(60);
    }

    // 初始化场景管理器
    this.sceneManager = new SceneManager(this.ctx, this.width, this.height);

    // 注册所有六大核心场景
    this.sceneManager.registerScene('menu', createMenuScene(this.sceneManager));
    this.sceneManager.registerScene('map', createMapScene(this.sceneManager));
    this.sceneManager.registerScene('battle', createBattleScene(this.sceneManager));
    this.sceneManager.registerScene('event', createEventScene(this.sceneManager));
    this.sceneManager.registerScene('rest', createRestScene(this.sceneManager));
    this.sceneManager.registerScene('shop', createShopScene(this.sceneManager));

    // 切后台暂停 BGM，回前台恢复
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) soundManager.pauseForBackground();
      else soundManager.resumeFromBackground();
    });

    this.start();
  }

  start() {
    loadCardTemplate();
    loadCardIcons();
    this.sceneManager.enterScene('menu');
    this.loop();
  }

  loop() {
    this.sceneManager.update();
    this.sceneManager.render();

    // FPS 统计
    this.frameCount++;
    const now = Date.now();
    const elapsed = now - this.lastFpsTime;
    if (elapsed >= 1000) {
      this.fps = Math.round((this.frameCount * 1000) / elapsed);
      this.frameCount = 0;
      this.lastFpsTime = now;
    }

    // 显示 FPS
    if (typeof window !== 'undefined' && window.gameConfig && window.gameConfig.showFps) {
      this.ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      this.ctx.font = '12px monospace';
      this.ctx.textAlign = 'left';
      this.ctx.fillText('FPS: ' + this.fps, 10, 20);
    }

    requestAnimationFrame(this.loop.bind(this));
  }
}