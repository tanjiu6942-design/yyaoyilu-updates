/**
 * 游戏全局配置常量
 * 集中管理所有数值参数，便于平衡性调整和维护
 */

// ==================== 战斗核心参数 ====================
export const BATTLE = {
  // 手牌上限
  MAX_HAND_LIMIT: 7,
  
  // 五行相克映射（攻击方 -> 被克方）：金→木→土→水→火→金
  ELEMENT_ADVANTAGE_MAP: { 
    "金": "木", 
    "木": "土", 
    "土": "水", 
    "水": "火", 
    "火": "金", 
    "无": "无" 
  },

  // 五行相克倍率
  ELEMENT_ADVANTAGE_MULTIPLIER: 1.5,
  ELEMENT_DISADVANTAGE_MULTIPLIER: 0.75,

  // 印记触发阈值（全项目唯一真源，UI/教程/战斗均读取此值）
  MARK_TRIGGER_COUNT: 2,
  
  // 印记效果数值
  MARK_EFFECTS: {
    '金': { damageBonus: 8, description: '金印引爆：造成8点破甲真实伤害！' },
    '木': { healBonus: 6, description: '木印引爆：恢复6点生命值！' },
    '水': { freezeEnemy: true, description: '水印引爆：冻结目标，跳过下回合！' },
    '火': { doubleDamage: true, description: '火印引爆：本回合后续伤害翻倍！' },
    '土': { shieldBonus: 10, description: '土印引爆：获得10点不灭护盾！' }
  },
  
  // 最低伤害保底
  MIN_DAMAGE: 1,
  
  // 卡牌升级倍率
  UPGRADE_MULTIPLIER: 1.45,
  UPGRADE_BONUS_STAR_1: 2,
  UPGRADE_BONUS_STAR_2: 3,
  MAX_STAR_LEVEL: 2
};

// ==================== 角色属性 ====================
export const CHARACTERS_BASE = {
  DEFAULT_MAX_HP: 30,
  DEFAULT_MAX_ENERGY: 3,
  
  // 特殊角色修正
  TAOIST_COST_REDUCTION: 1,        // 游方道士符咒/法术卡消耗减少
  FOX_SPIRIT_EXTRA_DRAW: 1,         // 青丘狐仙额外抽牌数
  ZHONG_KUI_DAMAGE_BONUS: 2,        // 钟馗对妖邪伤害加成
  NEZHA_DEATH_THRESHOLD: 5          // 哪吒解锁所需死亡次数
};

// ==================== 经济系统 ====================
export const ECONOMY = {
  INITIAL_GOLD: 50,
  
  // 战斗奖励铜钱浮动范围
  REWARD_NORMAL_MIN: 20,
  REWARD_NORMAL_MAX: 25,
  REWARD_ELITE_MIN: 38,
  REWARD_ELITE_MAX: 45,
  REWARD_BOSS_MIN: 55,
  REWARD_BOSS_MAX: 65,

  // 聚宝盆加成系数 (20%)
  JUBAO_BONUS_RATE: 0.2,
  
  // 商店卡牌定价
  SHOP_FALLBACK_CARD_PRICE: 40,      // 补位兜底卡
  SHOP_PERMANENT_JINGXIN_PRICE: 25,  // 常驻破煞净心咒价格
  SHOP_CARD_NORMAL_MIN: 45,
  SHOP_CARD_NORMAL_MAX: 55,
  SHOP_CARD_POWERFUL_MIN: 60,
  SHOP_CARD_POWERFUL_MAX: 75,
  SHOP_CARD_LEGENDARY_MIN: 80,
  SHOP_CARD_LEGENDARY_MAX: 100,
  
  // 商店法宝/遗物按稀有度定价
  SHOP_RELIC_PRICES: {
    '普通': 70,
    '稀有': 85,
    '史诗': 95,
    '传说': 120
  },

  // 八卦炉卡牌进阶与强化定价
  SYNTHESIZE_COST: {
    STAR_0_TO_1: 20, // 0星升1星合成费
    STAR_1_TO_2: 30  // 1星升2星合成费
  },
  ENLIGHTEN_COST: {
    STAR_0_TO_1: 35, // 0星升1星点化费
    STAR_1_TO_2: 50  // 1星升2星点化费
  },
  // 升级成本综合范围（合成最低~点化最高）
  UPGRADE_COST_MIN: 20,
  UPGRADE_COST_MAX: 50,

  // 碎符与疗伤
  PURGE_CARD_COST: 25,             // 焚毁废牌
  MIN_DECK_LIMIT_FOR_PURGE: 5,     // 碎符最小保留牌库量
  HEAL_COST: 20,                   // 疗伤费用
  HEAL_HP_AMOUNT: 12,              // 疗伤恢复量
  
  // 刷新机制
  REFRESH_COST_BASE: 10,           // 刷新基础费用
  REFRESH_COST_INCREMENT: 5,       // 每次刷新递增费用
  
  // 单局最大持有遗物数
  MAX_RELICS_PER_RUN: 10
};

// 区间随机整数辅助函数
export function randomRangeInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ==================== 敌人数值 ====================
export const ENEMY_CONFIG = {
  // Boss 阶段转换阈值
  BOSS_ENRAGE_HP_PERCENT: 0.5,
  BOSS_ENRAGE_ATTACK_BONUS: 3,
  
  // 阴阳判官特殊机制
  JUDGE_TRUE_DAMAGE_TURNS: 3,
  JUDGE_TRUE_DAMAGE_VALUE: 15,
  JUDGE_BARRIER_DURATION: 1,
  JUDGE_CURSE_COUNT: 2,
  
  // 行为概率
  BEHAVIOR_PROBABILITY: {
    BALANCED_ATTACK_CHANCE: 0.5,
    DEFEND_SHIELD_CHANCE: 0.6,
    AGGRESSIVE_ATTACK_CHANCE: 0.8
  }
};

// ==================== UI 配置 ====================

// ==================== 卡牌布局常量 ====================
export const CARD_LAYOUT = {
  CARD_W: 94,
  CARD_H: 140,
  CARD_GAP: 10,
  TRAY_PADDING_X: 12,
};

export const UI_CONFIG = {
  ANIMATION_DURATION: {
    SHORT: 200,
    MEDIUM: 400,
    LONG: 800,
    CARD_PLAY: 300,
    DAMAGE_POPUP: 500
  },
  
  BUTTON: {
    MIN_WIDTH: 80,
    MIN_HEIGHT: 40,
    PADDING_H: 16,
    PADDING_V: 8,
    BORDER_RADIUS: 8,
    FONT_SIZE: 16
  },
  
  CARD: {
    WIDTH: 120,
    HEIGHT: 160,
    BORDER_RADIUS: 12,
    FONT_SIZE_NAME: 14,
    FONT_SIZE_DESC: 11,
    FONT_SIZE_COST: 18
  },
  
  PANEL: {
    PADDING: 20,
    BORDER_RADIUS: 16,
    SHADOW_BLUR: 10,
    TITLE_FONT_SIZE: 20,
    CONTENT_FONT_SIZE: 14
  }
};

// ==================== 存储键名（按数据生命周期分类） ====================
export const STORAGE_KEYS = {
  // 单局运行状态 —— RunManager 管理，场景间共享
  RUN: {
    STATE: 'yycontents_run',
  },
  // 元进度 —— 跨局持久化（成就、死亡计数、角色解锁、角色选择）
  META: {
    ACHIEVEMENTS: 'yycontents_achievements',
    DEATH_COUNT: 'yycontents_death_count',
    CHAR_NEZHA_UNLOCKED: 'yycontents_char_nezha_unlocked',
    CHAR_ZHONGKUI_UNLOCKED: 'yycontents_char_zhongkui_unlocked',
    CHAR_BAISUZHEN_UNLOCKED: 'yycontents_char_baisuzhen_unlocked',
    SELECTED_CHAR: 'yycontents_selected_char',
    DEFEATED_ENEMIES: 'yycontents_defeated_enemies',
  },
  // 剧情与教程标记
  TUTORIAL: {
    STORY_INTRO_DONE: 'yycontents_story_intro_done',
    PROLOGUE_DONE: 'yycontents_prologue_done',
    CH2_INTRO_DONE: 'yycontents_ch2_intro_done',
    CH3_INTRO_DONE: 'yycontents_ch3_intro_done',
    TUTORIAL_DONE: 'yycontents_tutorial_done',
    TUTORIAL_PROGRESS: 'yycontents_tutorial_progress',
  },
  // 用户设置
  SETTINGS: {
    BGM_MUTED: 'yycontents_bgm_muted',
    SFX_MUTED: 'yycontents_sfx_muted',
    SKIP_HAND_FULL_WARNING: 'yycontents_skip_hand_full_warning',
  },
  // 废弃键（保留兼容，不再使用）
  LEGACY: {
    SAVE_GAME: 'yycontents_save_data',
    SETTINGS_SOUND: 'yycontents_sound_enabled',
  }
};

// ==================== 成就配置 ====================
export const ACHIEVEMENT_CONFIG = {
  TOAST_DISPLAY_DURATION: 2500,
  RICH_GOLD_THRESHOLD: 150,
  KARMA_MAX: 10
};

// ==================== 地图生成 ====================
export const MAP_CONFIG = {
  NODE_TYPES: ['battle', 'elite', 'event', 'shop', 'rest', 'boss'],
  CHAPTER_NODE_RANGE: {
    CHAPTER_1: { min: 8, max: 12 },
    CHAPTER_2: { min: 10, max: 14 }
  },
  ELITE_SPAWN_RATE: 0.15,
  BOSS_POSITION: -1
};