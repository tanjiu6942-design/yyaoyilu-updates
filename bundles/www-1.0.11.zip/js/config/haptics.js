/**
 * 触感反馈（Haptics）工具库
 */

let lastVibrateTime = 0;

/**
 * 触发震动
 * @param {'light'|'medium'|'heavy'} type 震动强度
 * @param {number} minInterval 最小间隔（毫秒），防止高频重复触发
 */
export function triggerHaptic(type = 'light', minInterval = 60) {
  const now = Date.now();
  if (now - lastVibrateTime < minInterval) return;
  lastVibrateTime = now;

  try {
    if (typeof wx !== 'undefined' && wx.vibrateShort) {
      wx.vibrateShort({ type });
    }
  } catch (e) {
    // 忽略模拟器或不支持平台的异常
  }
}

export const hapticLight = () => triggerHaptic('light', 50);
export const hapticMedium = () => triggerHaptic('medium', 80);
export const hapticHeavy = () => triggerHaptic('heavy', 120);