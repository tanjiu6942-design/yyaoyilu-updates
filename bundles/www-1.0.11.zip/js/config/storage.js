﻿/**
 * 安全存储操作封装
 * 为所有 wx API 调用添加错误处理和降级方案
 */

import { STORAGE_KEYS, CHARACTERS_BASE } from './constants.js';

// 内存降级缓存（当 wx 存储 API 不可用时使用）
const _storageFallback = {};

/**
 * 安全读取存储数据
 * 内存缓存优先：当前会话内写入的数据即使 wx 持久化失败也能读到
 * @param {string} key - 存储键名
 * @param {*} defaultValue - 读取失败时的默认值
 * @returns {*} 存储的数据或默认值
 */
export function safeGetStorage(key, defaultValue = null) {
  // 1. 优先读内存缓存（保证当前会话内读写一致）
  if (key in _storageFallback) {
    return _storageFallback[key];
  }

  // 2. 尝试读 wx 持久化存储
  try {
    const data = wx.getStorageSync(key);
    if (data === '' || data === undefined || data === null) {
      return defaultValue;
    }
    
    // 尝试解析 JSON 字符串
    if (typeof data === 'string') {
      try {
        const parsed = JSON.parse(data);
        _storageFallback[key] = parsed; // 缓存到内存
        return parsed;
      } catch (parseError) {
        console.warn(`[Storage] JSON解析失败: ${key}`, parseError.message);
        _storageFallback[key] = data;
        return data;
      }
    }
    
    _storageFallback[key] = data;
    return data;
  } catch (error) {
    console.error(`[Storage] 读取失败: ${key}`, error);
    return defaultValue;
  }
}

/**
 * 清除内存降级缓存（仅供测试使用）
 */
export function _clearFallbackCache() {
  Object.keys(_storageFallback).forEach(key => delete _storageFallback[key]);
}

/**
 * 安全写入存储数据
 * 始终先写内存缓存，保证当前会话内立即可读；再尝试 wx 持久化
 * @param {string} key - 存储键名
 * @param {*} value - 要存储的数据
 * @returns {boolean} 是否持久化成功（内存写入始终成功）
 */
export function safeSetStorage(key, value) {
  // 始终先更新内存缓存（保证当前会话内读写一致）
  _storageFallback[key] = value;

  try {
    const dataToStore = (typeof value === 'object') ? JSON.stringify(value) : value;
    wx.setStorageSync(key, dataToStore);
    return true;
  } catch (error) {
    console.error(`[Storage] 写入失败: ${key}`, error);
    return false;
  }
}

/**
 * 安全移除存储数据
 * 始终先删内存缓存，再尝试 wx 持久化删除
 * @param {string} key - 存储键名
 * @returns {boolean} 是否持久化删除成功（内存删除始终成功）
 */
export function safeRemoveStorage(key) {
  // 始终先清除内存缓存
  delete _storageFallback[key];

  try {
    wx.removeStorageSync(key);
    return true;
  } catch (error) {
    console.error(`[Storage] 移除失败: ${key}`, error);
    return false;
  }
}

// ==================== 业务层存储接口 ====================

/**
 * 获取成就数据
 */
export function getAchievements() {
  return safeGetStorage(STORAGE_KEYS.META.ACHIEVEMENTS, {});
}

/**
 * 保存成就数据
 */
export function saveAchievements(achievements) {
  return safeSetStorage(STORAGE_KEYS.META.ACHIEVEMENTS, achievements);
}

/**
 * 获取死亡计数
 */
export function getDeathCount() {
  return safeGetStorage(STORAGE_KEYS.META.DEATH_COUNT, 0);
}

/**
 * 增加死亡计数并检查哪吒解锁条件
 */
export function incrementDeathCount() {
  try {
    let deaths = getDeathCount() + 1;
    saveDeathCount(deaths);
    
    if (deaths >= CHARACTERS_BASE.NEZHA_DEATH_THRESHOLD) {
      unlockNezha();
    }
    
    return deaths;
  } catch (error) {
    console.error('[Storage] 死亡计数更新失败', error);
    return getDeathCount();
  }
}

/**
 * 保存死亡计数
 */
export function saveDeathCount(count) {
  return safeSetStorage(STORAGE_KEYS.META.DEATH_COUNT, count);
}

/**
 * 解锁哪吒角色
 */
export function unlockNezha() {
  try {
    safeSetStorage(STORAGE_KEYS.META.CHAR_NEZHA_UNLOCKED, true);
    console.log('[Character] 哪吒已解锁！');
  } catch (error) {
    console.error('[Character] 解锁哪吒失败', error);
  }
}

/**
 * 解锁白素贞角色（善因果通关第二章）
 */
export function unlockBaiSuzhen() {
  try {
    safeSetStorage(STORAGE_KEYS.META.CHAR_BAISUZHEN_UNLOCKED, true);
    console.log('[Character] 白素贞已解锁！');
  } catch (error) {
    console.error('[Character] 解锁白素贞失败', error);
  }
}

/**
 * 检查角色是否解锁
 */
export function isCharacterUnlocked(characterId) {
  switch (characterId) {
    case 'nezha':
      return safeGetStorage(STORAGE_KEYS.META.CHAR_NEZHA_UNLOCKED, false);
    case 'zhong_kui':
      return safeGetStorage(STORAGE_KEYS.META.CHAR_ZHONGKUI_UNLOCKED, false);
    case 'bai_suzhen':
      return true; // 免费体验角色
    default:
      return true; // 默认角色始终解锁
  }
}

// ==================== 单局运行状态（RUN 分类，RunManager 管理） ====================

/**
 * 加载单局运行状态
 */
export function loadRun() {
  return safeGetStorage(STORAGE_KEYS.RUN.STATE, null);
}

/**
 * 保存单局运行状态
 */
export function saveRun(state) {
  if (!state) return false;
  return safeSetStorage(STORAGE_KEYS.RUN.STATE, state);
}

/**
 * 清除单局运行状态
 */
export function clearRun() {
  return safeRemoveStorage(STORAGE_KEYS.RUN.STATE);
}

/**
 * 彻底清除单局数据（含剧情、教程标记）
 */
export function wipeRunData() {
  try {
    safeRemoveStorage(STORAGE_KEYS.RUN.STATE);
    safeRemoveStorage(STORAGE_KEYS.TUTORIAL.STORY_INTRO_DONE);
    safeRemoveStorage(STORAGE_KEYS.TUTORIAL.PROLOGUE_DONE);
    safeRemoveStorage(STORAGE_KEYS.TUTORIAL.TUTORIAL_DONE);
  } catch (e) {
    console.error('[Storage] 清除单局数据失败', e);
  }
}

// ==================== 角色选择 ====================

export function getSelectedChar() {
  return safeGetStorage(STORAGE_KEYS.META.SELECTED_CHAR, 'taoist');
}

export function saveSelectedChar(charId) {
  return safeSetStorage(STORAGE_KEYS.META.SELECTED_CHAR, charId);
}

// ==================== 剧情与教程标记 ====================

export function isStoryIntroDone() {
  const val = safeGetStorage(STORAGE_KEYS.TUTORIAL.STORY_INTRO_DONE, false);
  return val === true || val === 'true';
}

export function setStoryIntroDone(done = true) {
  return safeSetStorage(STORAGE_KEYS.TUTORIAL.STORY_INTRO_DONE, done);
}

export function isPrologueDone() {
  const val = safeGetStorage(STORAGE_KEYS.TUTORIAL.PROLOGUE_DONE, false);
  return val === true || val === 'true';
}

export function setPrologueDone(done = true) {
  return safeSetStorage(STORAGE_KEYS.TUTORIAL.PROLOGUE_DONE, done);
}

export function isChapter2IntroDone() {
  const val = safeGetStorage(STORAGE_KEYS.TUTORIAL.CH2_INTRO_DONE, false);
  return val === true || val === 'true';
}

export function setChapter2IntroDone(done = true) {
  return safeSetStorage(STORAGE_KEYS.TUTORIAL.CH2_INTRO_DONE, done);
}

export function isChapter3IntroDone() {
  const val = safeGetStorage(STORAGE_KEYS.TUTORIAL.CH3_INTRO_DONE, false);
  return val === true || val === 'true';
}

export function setChapter3IntroDone(done = true) {
  return safeSetStorage(STORAGE_KEYS.TUTORIAL.CH3_INTRO_DONE, done);
}

export function isTutorialDone() {
  const val = safeGetStorage(STORAGE_KEYS.TUTORIAL.TUTORIAL_DONE, false);
  return val === true || val === 'true';
}

export function setTutorialDone(done = true) {
  return safeSetStorage(STORAGE_KEYS.TUTORIAL.TUTORIAL_DONE, done);
}

export function getTutorialProgress() {
  return safeGetStorage(STORAGE_KEYS.TUTORIAL.TUTORIAL_PROGRESS, {});
}

export function saveTutorialProgress(progress) {
  return safeSetStorage(STORAGE_KEYS.TUTORIAL.TUTORIAL_PROGRESS, progress);
}

// ==================== 音频设置 ====================

export function isBgmMuted() {
  const val = safeGetStorage(STORAGE_KEYS.SETTINGS.BGM_MUTED, false);
  return val === true || val === 'true';
}

export function setBgmMuted(muted) {
  return safeSetStorage(STORAGE_KEYS.SETTINGS.BGM_MUTED, muted);
}

export function isSfxMuted() {
  const val = safeGetStorage(STORAGE_KEYS.SETTINGS.SFX_MUTED, false);
  return val === true || val === 'true';
}

export function setSfxMuted(muted) {
  return safeSetStorage(STORAGE_KEYS.SETTINGS.SFX_MUTED, muted);
}

// ==================== 手牌满提示（SETTINGS 分类） ====================

export function isSkipHandFullWarning() {
  const val = safeGetStorage(STORAGE_KEYS.SETTINGS.SKIP_HAND_FULL_WARNING, false);
  return val === true || val === 'true';
}

export function setSkipHandFullWarning(skip = true) {
  return safeSetStorage(STORAGE_KEYS.SETTINGS.SKIP_HAND_FULL_WARNING, skip);
}

// ==================== 角色解锁（META 分类） ====================

export function unlockZhongKui() {
  return safeSetStorage(STORAGE_KEYS.META.CHAR_ZHONGKUI_UNLOCKED, true);
}

// ==================== META 聚合接口（跨局持久化数据统一读写） ====================

/**
 * 加载所有元进度数据（成就、死亡计数、角色解锁、角色选择）
 * @returns {Object} 聚合的元数据对象
 */
export function loadMeta() {
  return {
    achievements: safeGetStorage(STORAGE_KEYS.META.ACHIEVEMENTS, {}),
    deathCount: safeGetStorage(STORAGE_KEYS.META.DEATH_COUNT, 0),
    selectedChar: safeGetStorage(STORAGE_KEYS.META.SELECTED_CHAR, 'taoist'),
    unlocked: {
      nezha: safeGetStorage(STORAGE_KEYS.META.CHAR_NEZHA_UNLOCKED, false),
      zhongKui: safeGetStorage(STORAGE_KEYS.META.CHAR_ZHONGKUI_UNLOCKED, false),
    }
  };
}

/**
 * 保存元进度数据（只保存传入对象中存在的字段）
 * @param {Object} meta - 元数据对象，支持部分字段更新
 */
export function saveMeta(meta) {
  if (!meta || typeof meta !== 'object') return;
  if (meta.achievements !== undefined) safeSetStorage(STORAGE_KEYS.META.ACHIEVEMENTS, meta.achievements);
  if (meta.deathCount !== undefined) safeSetStorage(STORAGE_KEYS.META.DEATH_COUNT, meta.deathCount);
  if (meta.selectedChar !== undefined) safeSetStorage(STORAGE_KEYS.META.SELECTED_CHAR, meta.selectedChar);
  if (meta.unlocked) {
    if (meta.unlocked.nezha !== undefined) safeSetStorage(STORAGE_KEYS.META.CHAR_NEZHA_UNLOCKED, meta.unlocked.nezha);
    if (meta.unlocked.zhongKui !== undefined) safeSetStorage(STORAGE_KEYS.META.CHAR_ZHONGKUI_UNLOCKED, meta.unlocked.zhongKui);
  }
}
