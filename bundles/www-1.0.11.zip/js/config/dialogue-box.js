import { drawRoundedRect, drawScrollPanel, drawTextCentered, drawTextLeft, UI_COLORS } from '../game/scene.js';

export class DialogueController {
  constructor() {
    this.dialogueQueue = [];
    this.currentIndex = 0;
    this.isActive = false;
    this.onComplete = null;
  }

  start(dialogueList, onComplete = null) {
    if (!dialogueList || dialogueList.length === 0) return;
    this.dialogueQueue = dialogueList;
    this.currentIndex = 0;
    this.isActive = true;
    this.onComplete = onComplete;
  }

  next() {
    if (!this.isActive) return;
    this.currentIndex++;
    if (this.currentIndex >= this.dialogueQueue.length) {
      this.isActive = false;
      const callback = this.onComplete;
      this.onComplete = null;
      if (callback) callback();
    }
  }

  getCurrentLine() {
    return this.dialogueQueue[this.currentIndex] || null;
  }

  render(ctx, width, height) {
    if (!this.isActive) return;

    const line = this.getCurrentLine();
    if (!line) return;

    // 1. 全屏微暗遮罩
    ctx.fillStyle = 'rgba(10, 6, 2, 0.72)';
    ctx.fillRect(0, 0, width, height);

    // 2. 对话底框规格
    const panelW = Math.min(336, width - 24);
    const panelH = 150;
    const panelX = (width - panelW) / 2;
    const panelY = height - panelH - 32;

    drawScrollPanel(ctx, panelX, panelY, panelW, panelH, {
      fill: 'rgba(252, 246, 230, 0.98)',
      stroke: UI_COLORS.cinnabar,
      strokeWidth: 2
    });

    // 3. 身份徽章与名字标签
    const isLeft = line.side === 'left';
    const tagSize = 28;
    const tagX = isLeft ? panelX + 16 : panelX + panelW - 16 - tagSize;
    const tagY = panelY - 14;

    // 印章背景
    drawRoundedRect(ctx, tagX, tagY, tagSize, tagSize, 6, line.avatarColor || UI_COLORS.cinnabar, '#FFD700', 1.2);
    drawTextCentered(ctx, line.tag || '道', tagX + tagSize / 2, tagY + tagSize / 2, '#FFF8DD', 14, 'serif');

    // 说话人名称牌
    const nameX = isLeft ? tagX + tagSize + 8 : tagX - 10;
    ctx.font = 'bold 15px serif';
    ctx.fillStyle = UI_COLORS.ink;
    ctx.textAlign = isLeft ? 'left' : 'right';
    ctx.textBaseline = 'middle';
    ctx.fillText(line.speaker, nameX, tagY + tagSize / 2);

    // 4. 分隔金线
    ctx.strokeStyle = 'rgba(180, 130, 70, 0.3)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(panelX + 16, panelY + 22);
    ctx.lineTo(panelX + panelW - 16, panelY + 22);
    ctx.stroke();

    // 5. 对话正文换行渲染
    const textMarginX = panelX + 18;
    const textMarginY = panelY + 34;
    const maxTextW = panelW - 36;
    const lineHeight = 20;

    ctx.font = '13px serif';
    ctx.fillStyle = '#36261A';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    const text = line.text || '';
    let currentLine = '';
    let currentY = textMarginY;

    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const testLine = currentLine + char;
      if (ctx.measureText(testLine).width > maxTextW && currentLine !== '') {
        ctx.fillText(currentLine, textMarginX, currentY);
        currentLine = char;
        currentY += lineHeight;
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine) {
      ctx.fillText(currentLine, textMarginX, currentY);
    }

    // 6. 底部“轻触继续”呼吸提示
    const alpha = Math.abs(Math.sin(Date.now() / 350));
    ctx.fillStyle = `rgba(150, 42, 31, ${0.4 + 0.6 * alpha})`;
    ctx.font = '11px serif';
    ctx.textAlign = 'right';
    ctx.fillText('轻触继续 ▾', panelX + panelW - 16, panelY + panelH - 12);
  }
}