/**
 * js/config/ui-components.js
 * 公共 UI 组件库与高频渲染对象缓存系统
 */

import { UI_CONFIG, BATTLE } from './constants.js';
import { UI_COLORS, drawTextCentered, drawTextLeft } from '../game/scene.js';
import { CHARACTERS } from '../game/types.js';
import { isCurseCard } from '../game/effect-engine.js';
import { 
  drawCardTemplate, 
  isCardTemplateReady, 
  drawCardIcon, 
  getElementColor 
} from '../game/cardFrame.js';

// ==================== 高频渐变与颜色静态缓存 ====================
const GRADIENT_CACHE = new Map();

export function getCachedLinearGradient(ctx, key, x0, y0, x1, y1, colorStops) {
  let grad = GRADIENT_CACHE.get(key);
  if (!grad) {
    grad = ctx.createLinearGradient(x0, y0, x1, y1);
    colorStops.forEach(([pos, color]) => grad.addColorStop(pos, color));
    GRADIENT_CACHE.set(key, grad);
  }
  return grad;
}

export function getCachedRadialGradient(ctx, key, x0, y0, r0, x1, y1, r1, colorStops) {
  let grad = GRADIENT_CACHE.get(key);
  if (!grad) {
    grad = ctx.createRadialGradient(x0, y0, r0, x1, y1, r1);
    colorStops.forEach(([pos, color]) => grad.addColorStop(pos, color));
    GRADIENT_CACHE.set(key, grad);
  }
  return grad;
}

/**
 * 绘制基础圆角矩形
 */
export function drawRoundedRect(ctx, x, y, w, h, r, fillColor, strokeColor = null, strokeWidth = 1) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  
  if (fillColor) {
    ctx.fillStyle = fillColor;
    ctx.fill();
  }
  
  if (strokeColor) {
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = strokeWidth;
    ctx.stroke();
  }
}

/**
 * 墨金长卷/弹窗外框（集成静态渐变复用）
 */
export function drawInkGoldModal(ctx, x, y, w, h, options = {}) {
  if (!isFinite(x) || !isFinite(y) || !isFinite(w) || !isFinite(h) || w <= 0 || h <= 0) return;
  const isDialogue = options.isDialogue || false;

  ctx.save();
  ctx.shadowColor = 'rgba(212, 175, 55, 0.22)';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetY = 10;
  drawRoundedRect(ctx, x, y, w, h, 14, '#1A0E08', '#0D0704', 3);
  ctx.restore();

  const goldKey = `gold_${w}_${h}`;
  const goldGrad = getCachedLinearGradient(ctx, goldKey, 0, 0, w, h, [
    [0, '#E6C875'],
    [0.25, '#FFF6C2'],
    [0.5, '#C49838'],
    [0.75, '#FCE38A'],
    [1, '#8C6018']
  ]);
  drawRoundedRect(ctx, x + 2, y + 2, w - 4, h - 4, 12, null, goldGrad, 2);

  const paperKey = `paper_${w}_${h}`;
  const paperGrad = getCachedRadialGradient(ctx, paperKey, w / 2, h * 0.45, w * 0.15, w / 2, h * 0.5, w * 0.85, [
    [0, '#FFFDF8'],
    [0.35, '#F9EED9'],
    [0.75, '#EBD5AD'],
    [1, '#CFA968']
  ]);
  drawRoundedRect(ctx, x + 5, y + 5, w - 10, h - 10, 10, paperGrad, '#8F6126', 1.5);

  // 水印与纹理
  ctx.save();
  const centerX = x + w / 2;
  const centerY = isDialogue ? y + h / 2 : y + h * 0.52;
  const wmR = Math.min(w, h) * 0.32;

  ctx.strokeStyle = 'rgba(184, 134, 40, 0.075)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(centerX, centerY, wmR, 0, Math.PI * 2);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(centerX, centerY, wmR * 0.85, 0, Math.PI * 2);
  ctx.setLineDash([8, 6]);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();

  const innerMargin = 12;
  const ix = x + innerMargin;
  const iy = y + innerMargin;
  const iw = w - innerMargin * 2;
  const ih = h - innerMargin * 2;

  ctx.save();
  ctx.strokeStyle = 'rgba(150, 42, 31, 0.35)';
  ctx.lineWidth = 1;
  ctx.strokeRect(ix, iy, iw, ih);

  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 1.2;
  ctx.strokeRect(ix + 3, iy + 3, iw - 6, ih - 6);
  ctx.restore();
}

/**
 * 文本自动分行计算
 */
export function getWrappedLines(ctx, text, maxWidth, fontSize = 13, font = '"Songti SC", "SimSun", "STSong", serif') {
  ctx.font = `${fontSize}px ${font}`;
  const str = text ? String(text) : '';
  if (!str) return [];
  const lines = [];
  let line = '';
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    const testLine = line + char;
    if (ctx.measureText(testLine).width > maxWidth && line !== '') {
      lines.push(line);
      line = char;
    } else {
      line = testLine;
    }
  }
  if (line) lines.push(line);
  return lines;
}

export function wrapDetailText(ctx, text, x, y, maxWidth, lineHeight = 20, color = '#120904', fontSize = 13) {
  ctx.font = `500 ${fontSize}px "Songti SC", "SimSun", "STSong", serif`; 
  ctx.fillStyle = color || '#120904'; 
  ctx.textAlign = 'left'; 
  ctx.textBaseline = 'top';
  const lines = getWrappedLines(ctx, text, maxWidth, fontSize);
  lines.forEach((l, idx) => {
    ctx.fillText(l, x, y + idx * lineHeight);
  });
}

export function drawNameplate(ctx, config) {
  const {
    speaker = '',
    tag = '道',
    avatarColor = UI_COLORS.cinnabar,
    isLeft = true,
    panelX = 10,
    panelY = 0,
    panelW = 300
  } = config;

  ctx.font = 'bold 14px "Songti SC", "SimSun", serif';
  const nameWidth = ctx.measureText(speaker).width;
  const nameplateW = Math.max(114, nameWidth + 56);
  const nameplateH = 32;
  const nameplateX = isLeft ? panelX + 18 : panelX + panelW - 18 - nameplateW;
  const nameplateY = panelY - 16;

  drawRoundedRect(ctx, nameplateX + 2, nameplateY + 2, nameplateW, nameplateH, 16, UI_COLORS.shadow, null);
  drawRoundedRect(ctx, nameplateX, nameplateY, nameplateW, nameplateH, 16, 'rgba(28, 16, 10, 0.98)', '#D4AF37', 1.5);

  const badgeR = 12;
  const badgeX = isLeft ? nameplateX + 16 : nameplateX + nameplateW - 16;
  const badgeY = nameplateY + nameplateH / 2;
  drawRoundedRect(ctx, badgeX - badgeR, badgeY - badgeR, badgeR * 2, badgeR * 2, 5, avatarColor, '#FFD700', 1);
  drawTextCentered(ctx, tag, badgeX, badgeY, '#FFF8DD', 12, 'serif');

  const nameTextX = isLeft ? nameplateX + 36 : nameplateX + 14;
  ctx.fillStyle = '#FFF8DD';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText(speaker, nameTextX, nameplateY + nameplateH / 2);
}

// ==================== 统一抽取组件 1: 修真锦囊弹窗 ====================
export function renderBagModalComponent(ctx, width, height, runState, scrollY = 0) {
  ctx.fillStyle = 'rgba(10, 6, 2, 0.78)'; 
  ctx.fillRect(0, 0, width, height); 
  const panelW = Math.min(320, width - 36); 
  const panelH = Math.min(480, height - 80); 
  const panelX = (width - panelW) / 2; 
  const panelY = (height - panelH) / 2;
  
  drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: false }); 
  drawTextCentered(ctx, "修 真 锦 囊", width / 2, panelY + 28, UI_COLORS.cinnabar, 20, "serif");
  
  ctx.strokeStyle = '#D4AF37'; 
  ctx.lineWidth = 1; 
  ctx.beginPath(); 
  ctx.moveTo(panelX + 20, panelY + 46); 
  ctx.lineTo(panelX + panelW - 20, panelY + 46); 
  ctx.stroke();

  const clipY = panelY + 48;
  const clipH = panelH - 74;
  ctx.save();
  ctx.beginPath();
  ctx.rect(panelX + 4, clipY, panelW - 8, clipH);
  ctx.clip();
  
  let curY = clipY + 8 + scrollY;

  drawTextLeft(ctx, "【 道 体 资 产 】", panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
  curY += 16;
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, 34, 5, 'rgba(238, 226, 198, 0.75)', 'rgba(160, 120, 70, 0.3)', 1);
  drawTextLeft(ctx, `铜钱: ${runState ? runState.gold : 0} 文`, panelX + 28, curY + 17, "#C99A3A", 13, "serif"); 
  drawTextLeft(ctx, `因果善业: ${(runState?.karma || 0) > 0 ? '+' : ''}${runState?.karma || 0}`, panelX + 155, curY + 17, "#2B6B46", 13, "serif");
  curY += 44;

  const charConfig = CHARACTERS[runState?.characterId] || CHARACTERS.taoist;
  drawTextLeft(ctx, "【 道 统 传 承 】", panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
  curY += 16;
  const passiveText = `【${charConfig.name}】 被动：${charConfig.passive}`;
  const passiveLines = getWrappedLines(ctx, passiveText, panelW - 48, 11);
  const passiveBoxH = Math.max(34, 12 + passiveLines.length * 16);
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, passiveBoxH, 5, 'rgba(238, 226, 198, 0.75)', 'rgba(160, 120, 70, 0.3)', 1);
  ctx.font = '11px serif'; 
  ctx.fillStyle = '#2B6B46'; 
  ctx.textAlign = 'left'; 
  ctx.textBaseline = 'top';
  passiveLines.forEach((l, i) => {
    ctx.fillText(l, panelX + 24, curY + 8 + i * 16);
  });
  curY += passiveBoxH + 12;

  const allCards = runState?.allCards || [];
  const star2Cards = allCards.filter(c => c.star === 2);
  const star1Cards = allCards.filter(c => c.star === 1 || (c.isUpgraded && c.star !== 2));
  const shopBoughtCards = allCards.filter(c => c.price !== undefined || c.isPermanentSupply);
  
  drawTextLeft(ctx, `【 道 藏 牌 库 一 览 】 (共 ${allCards.length} 张)`, panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
  curY += 16;

  const star2Str = star2Cards.length > 0 ? star2Cards.map(c => c.name.replace(/\+*$/, '★★极')).join('、') : '暂无二星极品符箓';
  const star2Lines = getWrappedLines(ctx, star2Str, panelW - 48, 11);
  const star2BoxH = 22 + star2Lines.length * 16 + 6;
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, star2BoxH, 5, 'rgba(244, 235, 212, 0.88)', '#BA43AA', 1.2);
  ctx.font = '11px serif'; 
  ctx.fillStyle = '#5C1D54'; 
  ctx.fillText(`二星·极阶符箓 (${star2Cards.length}张):`, panelX + 24, curY + 6);
  star2Lines.forEach((l, i) => ctx.fillText(l, panelX + 24, curY + 22 + i * 16));
  curY += star2BoxH + 8;

  const star1Str = star1Cards.length > 0 ? star1Cards.map(c => c.name.replace(/\+*$/, '★')).join('、') : '暂无一星进阶符箓';
  const star1Lines = getWrappedLines(ctx, star1Str, panelW - 48, 11);
  const star1BoxH = 22 + star1Lines.length * 16 + 6;
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, star1BoxH, 5, 'rgba(244, 235, 212, 0.88)', '#2B6B46', 1.2);
  ctx.font = '11px serif'; 
  ctx.fillStyle = '#2B6B46'; 
  ctx.fillText(`一星·进阶符箓 (${star1Cards.length}张):`, panelX + 24, curY + 6);
  star1Lines.forEach((l, i) => ctx.fillText(l, panelX + 24, curY + 22 + i * 16));
  curY += star1BoxH + 8;

  const shopStr = shopBoughtCards.length > 0 ? shopBoughtCards.map(c => c.name).join('、') : '暂无';
  const shopLines = getWrappedLines(ctx, shopStr, panelW - 48, 11);
  const shopBoxH = 22 + shopLines.length * 16 + 6;
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, shopBoxH, 5, 'rgba(244, 235, 212, 0.88)', '#C99A3A', 1.2);
  ctx.font = '11px serif'; 
  ctx.fillStyle = '#8C6212'; 
  ctx.fillText(`货郎坊市购得 (${shopBoughtCards.length}张):`, panelX + 24, curY + 6);
  shopLines.forEach((l, i) => ctx.fillText(l, panelX + 24, curY + 22 + i * 16));
  curY += shopBoxH + 12;

  const relics = runState?.relics || []; 
  drawTextLeft(ctx, `【 已 纳 法 宝 】 (${relics.length} 件)`, panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
  curY += 16;
  
  if (relics.length === 0) { 
    drawTextCentered(ctx, "行囊空空，尚未寻得法宝机缘", width / 2, curY + 16, "#888888", 12, "serif"); 
    curY += 36;
  } else { 
    relics.forEach((relic) => { 
      const relicDesc = relic.description || relic.desc || '蕴含灵力的随身秘宝。';
      const relicLines = getWrappedLines(ctx, relicDesc, panelW - 52, 11);
      const relicBoxH = Math.max(46, 20 + relicLines.length * 15 + 6);
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, relicBoxH, 5, 'rgba(244, 235, 212, 0.9)', '#C99A3A', 1); 
      drawTextLeft(ctx, relic.name, panelX + 26, curY + 12, UI_COLORS.ink, 13, "serif"); 
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#543825'; 
      relicLines.forEach((l, i) => ctx.fillText(l, panelX + 26, curY + 24 + i * 15));
      curY += relicBoxH + 8; 
    }); 
  }

  const calculatedHeight = curY - (clipY + 8 + scrollY) + 12;
  ctx.restore();

  drawTextCentered(ctx, "— 上下滑动浏览 · 点击任意处收拢 —", width / 2, panelY + panelH - 14, "#8A6D4B", 11, "serif");
  return calculatedHeight;
}

// ==================== 统一抽取组件 2: 卡牌详情大图预览 ====================
export function renderCardPreviewModal(ctx, width, height, card, safeTopY, cardW, cardH) {
  if (!card) return;
  const logTop = safeTopY + 104;
  const trayY = height - cardH - 58 - 24;
  const logBottom = trayY - 44;
  const logLeft = 10;
  const logRight = width - 10;

  drawRoundedRect(ctx, logLeft, logTop, logRight - logLeft, logBottom - logTop, 8, "rgba(15, 10, 5, 0.92)", "rgba(200, 149, 56, 0.5)", 1.5);

  const scale = 1.8;
  const cW = cardW * scale;
  const cH = cardH * scale;
  const cx = width / 2;
  const cy = (logTop + logBottom) / 2 - 8;

  ctx.save();
  ctx.shadowColor = 'rgba(212, 175, 55, 0.5)';
  ctx.shadowBlur = 18;
  const glowR = Math.round(cW * 0.1);
  drawRoundedRect(ctx, cx - cW / 2, cy - cH / 2, cW, cH, glowR, 'rgba(212, 175, 55, 0.15)', 'rgba(212, 175, 55, 0.6)', 1.5);
  ctx.restore();

  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);
  ctx.translate(-cardW / 2, -cardH / 2);

  const drawX = 0, drawY = 0;
  const totalCost = card.cost + (card.dualElement ? 1 : 0);
  const isCurse = isCurseCard(card);

  if (isCardTemplateReady()) {
    drawCardTemplate(ctx, drawX, drawY, cardW, cardH, isCurse ? '无' : card.element);
  }
  if (isCurse && isCardTemplateReady()) {
    ctx.fillStyle = "rgba(20, 15, 10, 0.4)";
    ctx.fillRect(drawX, drawY, cardW, cardH);
  }

  drawCardIcon(ctx, drawX + cardW / 2, drawY + 36, 44, card.name);

  const costBg = isCurse ? "#504743" : "#C89538";
  drawRoundedRect(ctx, drawX + 9, drawY + 9, 16, 18, 4, costBg, "#FFF3CA", 1.2);
  drawTextCentered(ctx, String(totalCost), drawX + 17, drawY + 19, "#1F1408", 11, "serif");

  const elemColor = getElementColor(card.element);
  drawRoundedRect(ctx, drawX + cardW - 25, drawY + 9, 16, 16, 8, elemColor, "#FFF3CA", 1.2);
  drawTextCentered(ctx, card.element, drawX + cardW - 17, drawY + 17, "#1F1408", 10, "serif");

  drawTextCentered(ctx, card.name, drawX + cardW / 2, drawY + 70, "#F5E6C8", 13, "serif");

  const desc = card.description || '';
  const starCount = card.star !== undefined ? card.star : (card.isUpgraded ? 1 : 0);
  drawTextCentered(ctx, card.type || "普通", drawX + cardW / 2, drawY + 93, "#D4AF37", 9, "serif");
  
  const lines = getWrappedLines(ctx, desc, 82, 8.5);
  lines.slice(0, 3).forEach((l, idx) => {
    drawTextCentered(ctx, l, drawX + cardW / 2, drawY + 104 + idx * 10, "#D0C8B8", 8.5, "serif");
  });

  if (starCount > 0 && !isCurse) {
    drawTextCentered(ctx, starCount >= 2 ? '★★' : '★', drawX + cardW / 2, drawY + 136, "#FFD700", 9, "serif");
  }
  ctx.restore();

  if (!isCurse && card.element && BATTLE.MARK_EFFECTS[card.element]) {
    const effectDesc = BATTLE.MARK_EFFECTS[card.element].description;
    const triggerCount = BATTLE.MARK_TRIGGER_COUNT;
    const effectY = cy + cH / 2 + 16;
    ctx.save();
    ctx.font = 'bold 11px "Songti SC", "SimSun", serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#E8C870';
    ctx.fillText(`叠${triggerCount}张同属性符箓触发印记`, cx, effectY);
    ctx.fillStyle = '#FFD700';
    ctx.fillText(`【${card.element}印】${effectDesc}`, cx, effectY + 16);
    ctx.restore();
  }
}

// ==================== 统一抽取组件 3: 胜利结算弹窗 ====================
export function renderVictoryModalComponent(ctx, width, height, data, buttons) {
  if (!data) return;
  ctx.fillStyle = "rgba(10, 6, 2, 0.82)"; 
  ctx.fillRect(0, 0, width, height); 
  const panelW = Math.min(320, width - 36); 
  const panelH = 346; 
  const panelX = (width - panelW) / 2; 
  const panelY = (height - panelH) / 2;

  drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: true });
  drawTextCentered(ctx, "降 妖 功 成", width / 2, panelY + 32, UI_COLORS.cinnabar, 22, "serif"); 
  
  const subTitle = data.isFlawless ? "★ 气血毫发未损 · 触发【无伤完胜】★" : `斩除妖邪「${data.enemyName}」· 结算战利`; 
  drawTextCentered(ctx, subTitle, width / 2, panelY + 54, data.isFlawless ? "#9A731F" : "#6B4A2E", 11, "serif"); 
  
  ctx.strokeStyle = "rgba(180, 130, 70, 0.35)"; 
  ctx.lineWidth = 1; 
  ctx.beginPath(); 
  ctx.moveTo(panelX + 20, panelY + 68); 
  ctx.lineTo(panelX + panelW - 20, panelY + 68); 
  ctx.stroke();

  const itemX = panelX + 16; 
  const itemW = panelW - 32; 
  let curY = panelY + 80; 
  
  drawRoundedRect(ctx, itemX, curY, itemW, 44, 6, "rgba(244, 235, 212, 0.95)", data.isFlawless ? "#D4AF37" : "#C99A3A", data.isFlawless ? 2 : 1.2); 
  drawRoundedRect(ctx, itemX + 8, curY + 9, 26, 26, 13, "#9A731F", "#FFE599", 1); 
  drawTextCentered(ctx, "铜", itemX + 21, curY + 22, "#FFF8DD", 12, "serif"); 
  drawTextLeft(ctx, `本次获铜: +${data.totalGold}`, itemX + 42, curY + 22, UI_COLORS.ink, 14, "serif"); 
  
  if (data.isFlawless) { 
    drawRoundedRect(ctx, itemX + 138, curY + 11, 56, 22, 11, "#9A731F", "#FFE599", 1); 
    drawTextCentered(ctx, "无伤 ×2", itemX + 166, curY + 22, "#FFF8DD", 10, "serif"); 
  } 
  drawTextLeft(ctx, `总计: ${data.finalTotalGold}`, itemX + itemW - 76, curY + 22, "#C99A3A", 13, "serif"); 
  curY += 52;

  drawRoundedRect(ctx, itemX, curY, itemW, 44, 6, "rgba(244, 235, 212, 0.95)", "#2E6B46", 1.2); 
  drawRoundedRect(ctx, itemX + 8, curY + 9, 26, 26, 13, "#2B6B46", "#A3E4D7", 1); 
  drawTextCentered(ctx, "因", itemX + 21, curY + 22, "#FFF8DD", 12, "serif"); 
  drawTextLeft(ctx, `善业因果 +${data.karma}`, itemX + 42, curY + 22, UI_COLORS.ink, 14, "serif"); 
  curY += 52;
  
  if (data.isElite || data.isBoss) { 
    drawRoundedRect(ctx, itemX, curY, itemW, 44, 6, "rgba(244, 235, 212, 0.95)", "#BA43AA", 1.2); 
    drawRoundedRect(ctx, itemX + 8, curY + 9, 26, 26, 13, "#5C1D54", "#FFD6FA", 1); 
    drawTextCentered(ctx, "宝", itemX + 21, curY + 22, "#FFF8DD", 12, "serif"); 
    drawTextLeft(ctx, "感应到上古法宝现世！", itemX + 42, curY + 22, "#5C1D54", 13, "serif"); 
  } else { 
    drawRoundedRect(ctx, itemX, curY, itemW, 44, 6, "rgba(244, 235, 212, 0.95)", "#8C2A24", 1.2); 
    drawRoundedRect(ctx, itemX + 8, curY + 9, 26, 26, 13, UI_COLORS.cinnabar, "#FFD700", 1); 
    drawTextCentered(ctx, "血", itemX + 21, curY + 22, "#FFF8DD", 12, "serif"); 
    drawTextLeft(ctx, `道体气血 ${data.hp} / ${data.maxHp}`, itemX + 42, curY + 22, UI_COLORS.ink, 13, "serif"); 
  }

  if (buttons && buttons.length > 0) {
    const btn = buttons[0];
    drawRoundedRect(ctx, btn.x, btn.y, btn.w, btn.h, 19, btn.color || UI_COLORS.cinnabar, "#FFD700", 1.5); 
    drawTextCentered(ctx, btn.text, btn.x + btn.w / 2, btn.y + btn.h / 2, btn.textColor || "#FFF8DD", btn.fontSize || 16, "serif"); 
  }
}