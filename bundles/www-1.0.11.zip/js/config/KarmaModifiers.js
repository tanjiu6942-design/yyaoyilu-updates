/**
 * src/config/KarmaModifiers.js
 * 因果系统阶位与全局修饰器配置
 * 统一管理因果阈值、阶位枚举、世界回应参数（物价/伤害/遇敌率）及辅助计算函数
 */

// ==================== 因果阶位枚举 ====================
export const KARMA_TIERS = {
  RIGHTEOUS: 'righteous', // 善念 / 天道庇佑 (Karma >= 5)
  NEUTRAL: 'neutral',     // 中立 / 两不相涉 (-4 <= Karma <= 4)
  DEMONIC: 'demonic'      // 恶念 / 妖魔化身 (Karma <= -5)
};

// ==================== 因果阈值常量 ====================
export const KARMA_THRESHOLDS = {
  MAX: 10,
  MIN: -10,
  RIGHTEOUS_TRIGGER: 5,
  DEMONIC_TRIGGER: -5
};

// ==================== 全局修饰器配置表 ====================
export const KARMA_MODIFIERS = {
  [KARMA_TIERS.RIGHTEOUS]: {
    tier: KARMA_TIERS.RIGHTEOUS,
    tierName: '天道庇佑 (善念)',
    triggerDesc: '因果值 ≥ +5',
    shopPriceMultiplier: 0.85,    // 商人特惠：商店价格 -15%
    playerDamageMultiplier: 1.10, // 灵威浩荡：全伤害 +10%
    enemyDamageMultiplier: 1.00,  // 敌方伤害倍率（标准）
    eliteRateModifier: -0.15,     // 妖邪避退：精英怪生成率 -15%
    relicDropRateBonus: 0.10,     // 福缘加身：稀有掉落率 +10%
    enemyPoolBias: 'peaceful',    // 敌人池偏向：温和妖邪
    themeColor: '#4CAF50',        // UI 表现色（翠微绿/金光）
    worldStatusText: '【天道庇佑】妖邪避退，商贾敬重，灵威浩荡',
    description: '道法生辉，商贾敬重商品降价15%，自身攻击提升10%，妖邪避退精英遭遇率降低。'
  },
  [KARMA_TIERS.NEUTRAL]: {
    tier: KARMA_TIERS.NEUTRAL,
    tierName: '因果中立',
    triggerDesc: '-4 ~ +4',
    shopPriceMultiplier: 1.00,    // 标准价格
    playerDamageMultiplier: 1.00, // 基础伤害
    enemyDamageMultiplier: 1.00,
    eliteRateModifier: 0.00,
    relicDropRateBonus: 0.00,
    enemyPoolBias: 'normal',
    themeColor: '#DCDCDC',        // UI 表现色（素白/宣纸白）
    worldStatusText: '',
    description: '天道如常，两不相涉。'
  },
  [KARMA_TIERS.DEMONIC]: {
    tier: KARMA_TIERS.DEMONIC,
    tierName: '妖魔化身 (恶念)',
    triggerDesc: '因果值 ≤ -5',
    shopPriceMultiplier: 1.20,    // 商人敌意：商店价格 +20%
    playerDamageMultiplier: 1.15, // 煞气暴涌：全伤害 +15%
    enemyDamageMultiplier: 1.10,  // 凶煞戾气：敌人伤害 +10%
    eliteRateModifier: 0.15,      // 强敌涌现：精英怪生成率 +15%
    relicDropRateBonus: 0.05,     // 险中求贵：宝物掉落率 +5%
    enemyPoolBias: 'ferocious',   // 敌人池偏向：凶煞妖魔
    themeColor: '#9C27B0',        // UI 表现色（幽冥紫/暗红）
    worldStatusText: '【妖魔化身】煞气缠身，强敌窥伺，商贾戒备',
    description: '煞气缠身，自身攻击提升15%，商贾戒备价格上涨20%，强敌窥伺精英遭遇率提升15%。'
  }
};

/**
 * 根据因果数值计算当前所属阶位
 * @param {number} karma 当前因果值 (-10 ~ 10)
 * @returns {string} KARMA_TIERS 枚举值
 */
export function calculateKarmaTier(karma = 0) {
  if (karma >= KARMA_THRESHOLDS.RIGHTEOUS_TRIGGER) {
    return KARMA_TIERS.RIGHTEOUS;
  }
  if (karma <= KARMA_THRESHOLDS.DEMONIC_TRIGGER) {
    return KARMA_TIERS.DEMONIC;
  }
  return KARMA_TIERS.NEUTRAL;
}

/**
 * 根据因果值或阶位名称获取对应修饰器配置
 * @param {number|string} karmaOrTier 因果数值或阶位名称
 * @returns {object} 对应的修饰器配置对象
 */
export function getKarmaModifier(karmaOrTier) {
  const tier = typeof karmaOrTier === 'number' 
    ? calculateKarmaTier(karmaOrTier) 
    : karmaOrTier;

  return KARMA_MODIFIERS[tier] || KARMA_MODIFIERS[KARMA_TIERS.NEUTRAL];
}