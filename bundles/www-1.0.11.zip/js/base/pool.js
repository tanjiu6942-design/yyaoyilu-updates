/**
 * 高性能通用对象池
 * 适用于战斗飘字、粒子特效、卡牌动画对象等高频创建与回收场景
 */
export default class Pool {
  constructor() {
    this.pools = new Map();
  }

  /**
   * 注册对象池类型与生命周期钩子
   * @param {string} sign - 对象标识
   * @param {Function} createFn - 创建新实例的工厂函数
   * @param {Function} [resetFn] - 取出/回收时的状态重置函数 (item, ...args) => void
   * @param {number} [maxCapacity=60] - 对象池最大缓存容量
   */
  register(sign, createFn, resetFn = null, maxCapacity = 60) {
    this.pools.set(sign, {
      items: [],
      createFn,
      resetFn,
      maxCapacity
    });
  }

  /**
   * 从对象池获取实例
   * @param {string} sign - 对象标识
   * @param {...any} args - 传给 resetFn 或 createFn 的参数
   * @returns {any}
   */
  get(sign, ...args) {
    const pool = this.pools.get(sign);
    if (!pool) {
      console.warn(`[Pool] 尚未注册对象类型: ${sign}`);
      return null;
    }

    let item = pool.items.length > 0 ? pool.items.pop() : pool.createFn(...args);

    if (pool.resetFn) {
      pool.resetFn(item, ...args);
    }

    return item;
  }

  /**
   * 回收对象实例
   * @param {string} sign - 对象标识
   * @param {object} item - 待回收对象
   */
  recover(sign, item) {
    const pool = this.pools.get(sign);
    if (!pool || !item) return;

    if (pool.items.length < pool.maxCapacity) {
      pool.items.push(item);
    }
  }

  /**
   * 清空指定池或全部池
   * @param {string} [sign] - 对象标识，缺省则清空全部
   */
  clear(sign) {
    if (sign) {
      const pool = this.pools.get(sign);
      if (pool) pool.items = [];
    } else {
      this.pools.forEach((pool) => {
        pool.items = [];
      });
    }
  }
}

// 导出单例方便全局共享
export const globalPool = new Pool();