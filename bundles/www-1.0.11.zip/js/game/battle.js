import { 
  calculateElementDamage, 
  CARD_TEMPLATES, 
  createPlayer, 
  createEnemy,
  recordEnemyDefeat
} from './data.js';
import { CHARACTERS, generateCardId } from './types.js';
import { BATTLE, CHARACTERS_BASE } from '../config/constants.js';
import { incrementDeathCount } from '../config/storage.js';
import { executeCardEffects, hasRelic, applyCharacterCostPassive, isCurseCard } from './effect-engine.js';
import { MarkManager } from './battle/MarkManager.js';
import { BuildSystem } from './systems/BuildSystem.js';

function drawCards(player, count) {
  let drawn = 0;
  for (let i = 0; i < count; i++) {
    if (player.cards.length >= BATTLE.MAX_HAND_LIMIT) {
      break;
    }

    if (player.deck.length === 0) {
      if (player.discard.length === 0) break;
      player.deck = [...player.discard];
      player.discard = [];
      for (let j = player.deck.length - 1; j > 0; j--) {
        const k = Math.floor(Math.random() * (j + 1));
        [player.deck[j], player.deck[k]] = [player.deck[k], player.deck[j]];
      }
    }
    if (player.deck.length > 0) {
      player.cards.push(player.deck.pop());
      drawn++;
    }
  }
  return drawn;
}

function createCurseCard() {
  const curseTemplate = CARD_TEMPLATES.find(c => c.name === '索魂咒') || {
    name: "索魂咒", type: "诅咒", element: "无", cost: 1, value: 0, star: 0,
    description: "【负面诅咒】占用手牌，消耗1点灵气将其化解焚毁", effectType: "curse"
  };
  return { ...curseTemplate, id: generateCardId() };
}

function injectCurseToPlayer(player, count = 1) {
  let handCount = 0;
  let deckCount = 0;
  for (let i = 0; i < count; i++) {
    const curse = createCurseCard();
    if (player.cards.length < BATTLE.MAX_HAND_LIMIT) {
      player.cards.push(curse);
      handCount++;
    } else {
      player.deck.push(curse);
      deckCount++;
    }
  }
  return { handCount, deckCount };
}

export function recordPlayerDeath() {
  const deaths = incrementDeathCount();
  if (deaths >= CHARACTERS_BASE.NEZHA_DEATH_THRESHOLD) {
    CHARACTERS.nezha.unlocked = true;
  }
}

export function discardCard(battle, cardIndex) {
  const { player } = battle;
  if (!player || !player.cards) return battle;
  const card = player.cards[cardIndex];
  if (!card) return battle;

  if (isCurseCard(card)) {
    battle.log.push(`【${card.name}】附骨缠身无法弃置！需耗费1点灵气将其化解焚毁。`);
    return battle;
  }

  player.cards.splice(cardIndex, 1);
  player.discard.push(card);

  battle.log.push(`弃置了符箓【${card.name}】进入弃牌堆`);
  return battle;
}

export function decideEnemyIntent(enemy, turnCount, chapter = 1) {
  if (!enemy) return;
  const currentAtk = (enemy.attack || 4) + (enemy.attackBuff || 0);

  if (enemy.key === 'hei_shan_shan_xiao_wang') {
    if (enemy.hp <= enemy.maxHp * 0.5 && !enemy.enraged) {
      enemy.enraged = true;
      enemy.attackBuff = (enemy.attackBuff || 0) + 3;
      enemy.nextAction = '枯木狂暴';
      enemy.nextActionType = 'buff_enrage';
      enemy.nextActionValue = 3;
      enemy.intentDesc = '【狂暴】攻击力永久+3并蓄势！';
      return;
    }
  }

  if (enemy.key === 'yin_yang_pan_guan') {
    if (enemy.hp <= enemy.maxHp * 0.5 && !enemy.barrierTriggered) {
      enemy.barrierTriggered = true;
      enemy.nextAction = '生死冥界阵';
      enemy.nextActionType = 'invulnerable_barrier';
      enemy.nextActionValue = 2;
      enemy.intentDesc = '【冥界大阵】绝对免伤1回合，并向你塞入2张索魂咒！';
      return;
    }
    if (turnCount > 1 && turnCount % 3 === 0) {
      enemy.nextAction = '生死簿绝判';
      enemy.nextActionType = 'true_damage';
      enemy.nextActionValue = 15;
      enemy.intentDesc = '【生死簿】勾魂夺命！穿透所有护盾直接扣除15点生命！';
      return;
    }
  }

  // ==================== 第三章Boss：九尾狐·归墟之门 ====================
  if (enemy.key === 'jiu_wei_hu') {
    // 阶段2：HP ≤ 60%，混沌之兽形态
    if (enemy.hp <= enemy.maxHp * 0.6 && !enemy.phase2Triggered) {
      enemy.phase2Triggered = true;
      enemy.attackBuff = (enemy.attackBuff || 0) + 5;
      enemy.immuneToDebuff = true; // 混沌之兽形态免疫一切负面效果（冻结/定身）
      enemy.nextAction = '混沌之兽';
      enemy.nextActionType = 'buff_phase2';
      enemy.nextActionValue = 5;
      enemy.intentDesc = '【混沌之兽】九尾借用归墟之力！攻击力永久+5，免疫负面效果，每回合塞入1张索魂咒！';
      return;
    }
    // 阶段3：HP ≤ 30%，归墟之门形态
    if (enemy.hp <= enemy.maxHp * 0.3 && !enemy.phase3Triggered) {
      enemy.phase3Triggered = true;
      enemy.gateProgress = 0; // 开门进度条
      enemy.nextAction = '归墟之门';
      enemy.nextActionType = 'invulnerable_gate';
      enemy.nextActionValue = 1;
      enemy.intentDesc = '【归墟之门】绝对免伤1回合！开门仪式启动，5回合后门将完全开启！';
      return;
    }
    // 阶段3进行中：每回合进度+1，满4则玩家失败
    if (enemy.phase3Triggered && enemy.gateProgress !== undefined) {
      enemy.gateProgress++;
      if (enemy.gateProgress >= 4) {
        // 门完全开启，玩家失败（在resolveEnemyTurn中处理）
        enemy.nextAction = '门开';
        enemy.nextActionType = 'gate_complete';
        enemy.nextActionValue = 999;
        enemy.intentDesc = '【归墟之门完全开启】玄冥之力泄露，你被混沌吞噬！';
        return;
      }
      // 阶段3中每回合高伤攻击
      const gateDmg = currentAtk + 3;
      enemy.nextAction = '九尾天袭';
      enemy.nextActionType = 'attack_curse';
      enemy.nextActionValue = gateDmg;
      enemy.intentDesc = `【开门中 ${enemy.gateProgress}/5】九尾混沌攻击！造成 ${gateDmg} 伤害并塞入索魂咒！`;
      return;
    }
    // 阶段2中：每回合塞入诅咒
    if (enemy.phase2Triggered) {
      if (turnCount % 2 === 0) {
        enemy.nextAction = '混沌触手';
        enemy.nextActionType = 'attack_curse';
        enemy.nextActionValue = currentAtk;
        enemy.intentDesc = `混沌触手攻击！造成 ${currentAtk} 伤害并塞入1张索魂咒！`;
        return;
      }
    }
    // 阶段1：正常攻击
    if (turnCount % 3 === 0) {
      enemy.nextAction = '狐火燎原';
      enemy.nextActionType = 'attack';
      enemy.nextActionValue = currentAtk + 2;
      enemy.intentDesc = `九尾狐火燎原！造成 ${currentAtk + 2} 点伤害！`;
      return;
    }
  }

  if (enemy.key === 'hei_bai_wu_chang') {
    if (turnCount % 2 === 0) {
      enemy.nextAction = '锁魂幽冥盾';
      enemy.nextActionType = 'defend';
      enemy.nextActionValue = 12;
      enemy.intentDesc = '凝结幽冥阴盾 (护盾 +12)';
      return;
    }
  }

  if (enemy.key === 'niu_tou_a_bang') {
    if (turnCount % 3 === 0) {
      const heavyDmg = currentAtk + 6;
      enemy.nextAction = '开山巨劈';
      enemy.nextActionType = 'heavy_attack_curse';
      enemy.nextActionValue = heavyDmg;
      enemy.intentDesc = `蓄力重击！造成 ${heavyDmg} 点暴击伤害并附带索魂咒！`;
      return;
    }
  }

  if (enemy.key === 'you_ming_gui_huo') {
    if (turnCount % 2 === 0) {
      enemy.nextAction = '阴火封脉';
      enemy.nextActionType = 'debuff_energy';
      enemy.nextActionValue = currentAtk;
      enemy.intentDesc = `阴火噬脉 (造成 ${currentAtk} 伤，并封锁下回合1点灵气)`;
      return;
    }
  }

  if (enemy.key === 'gu_hun_ye_gui') {
    if (Math.random() < 0.35) {
      enemy.nextAction = '阴风扰魂';
      enemy.nextActionType = 'curse_insert';
      enemy.nextActionValue = currentAtk;
      enemy.intentDesc = `怨风扑面 (造成 ${currentAtk} 伤，并塞入1张索魂咒)`;
      return;
    }
  }

  // ==================== 第三章普通敌人与精英：专属技能 ====================
  if (enemy.key === 'gui_xu_yuan_hun' && turnCount % 3 === 0) {
    // 归墟怨魂：每3回合【万魂哭嚎】攻击并塞入索魂咒，其余回合走通用balanced
    enemy.nextAction = '万魂哭嚎';
    enemy.nextActionType = 'curse_insert';
    enemy.nextActionValue = currentAtk;
    enemy.intentDesc = `【万魂哭嚎】怨魂哀嚎扑击！造成 ${currentAtk} 伤害并塞入1张索魂咒！`;
    return;
  }

  if (enemy.key === 'shi_ling_can_ke' && turnCount % 3 === 0) {
    // 噬灵残壳：每3回合【混沌符咒】塞诅咒，其余走aggressive通用
    enemy.nextAction = '混沌符咒';
    enemy.nextActionType = 'curse_insert';
    enemy.nextActionValue = currentAtk;
    enemy.intentDesc = `【混沌符咒】残壳掷出污染符咒！造成 ${currentAtk} 伤害并塞入索魂咒！`;
    return;
  }

  if (enemy.key === 'hun_dun_you_hun' && turnCount % 3 === 0) {
    // 混沌游魂：每3回合【混沌侵蚀】攻击并封锁灵气，其余走aggressive通用
    enemy.nextAction = '混沌侵蚀';
    enemy.nextActionType = 'debuff_energy';
    enemy.nextActionValue = currentAtk;
    enemy.intentDesc = `【混沌侵蚀】幽蓝煞火侵脉！造成 ${currentAtk} 伤害，下回合灵气-1！`;
    return;
  }

  if (enemy.key === 'gui_xu_shi_kui') {
    // 归墟石傀：每3回合【大地震动】攻击塞诅咒，其余【归墟岩甲】+16盾
    if (turnCount % 3 === 0) {
      enemy.nextAction = '大地震动';
      enemy.nextActionType = 'curse_insert';
      enemy.nextActionValue = currentAtk;
      enemy.intentDesc = `【大地震动】石傀重踏！造成 ${currentAtk} 伤害并塞入索魂咒！`;
      return;
    }
    enemy.nextAction = '归墟岩甲';
    enemy.nextActionType = 'defend';
    enemy.nextActionValue = 16;
    enemy.intentDesc = '【归墟岩甲】石傀凝岩成甲 (护盾 +16)';
    return;
  }

  if (enemy.key === 'jiu_wei_shan_nian') {
    // 精英九尾善念残响：每3回合【九尾幻影】连击，偶数回合【善念护盾】，否则普通攻击
    if (turnCount % 3 === 0) {
      const dbl = currentAtk * 2;
      enemy.nextAction = '九尾幻影';
      enemy.nextActionType = 'heavy_attack';
      enemy.nextActionValue = dbl;
      enemy.intentDesc = `【九尾幻影】善念分化双身连击！造成 ${dbl} 点重击！`;
      return;
    }
    if (turnCount % 2 === 0) {
      enemy.nextAction = '善念护盾';
      enemy.nextActionType = 'defend';
      enemy.nextActionValue = 15;
      enemy.intentDesc = '【善念护盾】九尾善念凝盾 (护盾 +15)';
      return;
    }
    enemy.nextAction = '拂尘轻击';
    enemy.nextActionType = 'attack';
    enemy.nextActionValue = currentAtk;
    enemy.intentDesc = `善念残响轻击 (造成 ${currentAtk} 伤害)`;
    return;
  }

  const behavior = enemy.behavior || 'balanced';
  const rand = Math.random();

  if (behavior === 'defensive') {
    if (rand < 0.65) {
      const shieldVal = chapter === 2 ? 14 : (6 + Math.floor(Math.random() * 4));
      enemy.nextAction = chapter === 2 ? '铜皮纸铠' : '运功固守';
      enemy.nextActionType = 'defend';
      enemy.nextActionValue = shieldVal;
      enemy.intentDesc = `坚固防守 (获得 ${shieldVal} 点护盾)`;
    } else {
      enemy.nextAction = '伺机反击';
      enemy.nextActionType = 'attack';
      enemy.nextActionValue = currentAtk;
      enemy.intentDesc = `反击出招 (攻击 ${currentAtk} 点)`;
    }
  } else if (behavior === 'aggressive') {
    if (rand < 0.7) {
      enemy.nextAction = '凶煞扑杀';
      enemy.nextActionType = 'attack';
      enemy.nextActionValue = currentAtk;
      enemy.intentDesc = `狂暴扑杀 (攻击 ${currentAtk} 点)`;
    } else if (rand < 0.9) {
      const buffVal = chapter === 2 ? 3 : 2;
      enemy.nextAction = '煞气暴涌';
      enemy.nextActionType = 'buff_attack';
      enemy.nextActionValue = buffVal;
      enemy.intentDesc = `煞气暴涨 (攻击力永久 +${buffVal})`;
    } else {
      const shieldVal = chapter === 2 ? 8 : 5;
      enemy.nextAction = '妖雾遮体';
      enemy.nextActionType = 'defend';
      enemy.nextActionValue = shieldVal;
      enemy.intentDesc = `妖雾护体 (获得 ${shieldVal} 点护盾)`;
    }
  } else {
    if (rand < 0.5) {
      enemy.nextAction = '出招攻伐';
      enemy.nextActionType = 'attack';
      enemy.nextActionValue = currentAtk;
      enemy.intentDesc = `出招攻击 (造成 ${currentAtk} 点伤害)`;
    } else if (rand < 0.85) {
      const shieldVal = chapter === 2 ? (8 + Math.floor(Math.random() * 4)) : (5 + Math.floor(Math.random() * 3));
      enemy.nextAction = '聚气化盾';
      enemy.nextActionType = 'defend';
      enemy.nextActionValue = shieldVal;
      enemy.intentDesc = `聚气化盾 (获得 ${shieldVal} 点护盾)`;
    } else {
      enemy.nextAction = '吸纳阴煞';
      enemy.nextActionType = 'buff_attack';
      enemy.nextActionValue = chapter === 2 ? 2 : 1;
      enemy.intentDesc = `蓄势待发 (攻击力 +${chapter === 2 ? 2 : 1})`;
    }
  }
}

export function createBattleFromRun(runState, enemy) {
  const charConfig = CHARACTERS[runState.characterId] || CHARACTERS.taoist;
  const chapter = runState.chapter || 1;
  
  const initialEnergy = (runState.relics || []).some(r => r.id === 'relic_fuchen')
    ? charConfig.maxEnergy + 1 
    : charConfig.maxEnergy;

  let initialCards = (runState.allCards && runState.allCards.length > 0)
    ? JSON.parse(JSON.stringify(runState.allCards))
    : createPlayer(charConfig.id).deck;

  runState.allCards = initialCards;

  const player = {
    hp: runState.hp || charConfig.maxHp,
    maxHp: runState.maxHp || charConfig.maxHp,
    shield: 0,
    energy: initialEnergy,
    maxEnergy: initialEnergy,
    energyDebuff: 0,
    immune: false,
    nextDamageBonus: 0,
    cards: [],
    deck: JSON.parse(JSON.stringify(initialCards)),
    discard: [],
    relics: runState.relics || [],
    characterId: charConfig.id,
    hasRevived: false,
    // ★ 事件永久 buff 传入战斗：攻击加成、鸣冤浩气（对鬼差+2）
    attackBonus: (runState.buffs && runState.buffs.attackBonus) || 0,
    mingyuanHaoqi: !!(runState.buffs && runState.buffs.mingyuanHaoqi)
  };

  for (let i = player.deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [player.deck[i], player.deck[j]] = [player.deck[j], player.deck[i]];
  }

  if (hasRelic(player, 'relic_gongde')) {
    const karmaShield = Math.max(0, (runState.karma || 0) * 2);
    if (karmaShield > 0) player.shield += karmaShield;
  }

  const hasTianji = hasRelic(player, 'relic_tianji');
  const initialDrawCount = hasTianji ? 5 : 4;
  drawCards(player, initialDrawCount);
  applyCharacterCostPassive(player);

  const battleEnemy = JSON.parse(JSON.stringify(enemy));
  battleEnemy.invulnerableTurns = 0;
  battleEnemy.barrierTriggered = false;
  decideEnemyIntent(battleEnemy, 1, chapter);

  const tianjiStartLog = hasTianji ? ' (天机册生效：起手多纳 1 张符箓)' : '';
  const chapterEnvLog = chapter === 2 ? '★【九幽阴气】此界阴煞浓郁，每回合结束消散 30% 护盾！' : '';

  const logs = [
    `遭遇了【${battleEnemy.name}】，降妖之战开启！`,
    `起手纳 ${initialDrawCount} 张符箓${tianjiStartLog}`
  ];
  if (chapterEnvLog) logs.push(chapterEnvLog);

  // 初始化独立的 MarkManager 实例
  const markManager = new MarkManager(runState.elementMarks || null);

  // 初始化流派构筑系统：每场战斗全新创建，流派状态不跨战斗保留
  const buildSystem = new BuildSystem();

  const battle = {
    player,
    enemy: battleEnemy,
    chapter,
    phase: 'player_action',
    markManager,
    buildSystem,
    // 保持向后兼容：通过 getter/setter 代理到 markManager
    get elementMarks() {
      return this.markManager.getMarks();
    },
    set elementMarks(val) {
      if (val && typeof val === 'object') {
        this.markManager.marks = { ...val };
      }
    },
    get fireDoubleDamage() {
      return this.markManager.isFireDoubleDamage();
    },
    set fireDoubleDamage(val) {
      this.markManager.fireDoubleDamage = !!val;
    },
    turnCount: 1,
    log: logs
  };

  return battle;
}

export function createBattle(enemyIndex = 0) {
  const player = createPlayer('taoist');
  const enemy = createEnemy(enemyIndex);
  return createBattleFromRun({
    characterId: 'taoist',
    hp: player.hp,
    maxHp: player.maxHp,
    allCards: player.deck,
    relics: [],
    karma: 0,
    chapter: enemyIndex >= 6 ? 2 : 1
  }, enemy);
}

export function playCard(battle, cardIndex) {
  const { player, enemy } = battle;
  const card = player.cards[cardIndex];
  if (!card) return battle;

  let totalCost = card.cost + (card.dualElement ? 1 : 0);
  // ★ 遗物：枯木戒 - 血量低于50%时木系卡费用-1
  if (card.element === '木' && hasRelic(player, 'relic_kumu_jie') && player.hp <= player.maxHp * 0.5) {
    totalCost = Math.max(0, totalCost - 1);
  }
  // ★ 流派系统：寒渊流 - 水印引爆后下一张水牌费用减免
  if (card.element === '水' && battle.buildSystem) {
    const costResult = battle.buildSystem.applyWaterCostReduction(card);
    if (costResult.costReduction > 0) {
      totalCost = Math.max(0, totalCost - costResult.costReduction);
    }
  }
  if (player.energy < totalCost) return battle;

  player.energy -= totalCost;
  player.cards.splice(cardIndex, 1);

  if (isCurseCard(card)) {
    battle.log.push(`运功化解【${card.name}】，将其焚为青烟消散！`);
    return battle;
  }

  player.discard.push(card);

  let logMsg = `出招【${card.name}】: `;

  // ★ 数据驱动：执行卡牌声明的基础效果
  logMsg += executeCardEffects(battle, card);

  // 角色被动：狐仙使用木/水卡额外抽1牌
  if (player.characterId === 'fox_spirit' && (card.element === '木' || card.element === '水')) {
    drawCards(player, 1);
    applyCharacterCostPassive(player);
    logMsg += ` [狐仙灵动: 额外抽1牌]`;
  }

  // ★ 状态解耦：交给 MarkManager 自动结算印记累积与引爆
  const markResult = battle.markManager.processCardMark(card, battle);
  if (markResult.triggered) {
    logMsg += ` ★ ${markResult.desc}`;

    // ★ 流派系统：磐石流土印护盾加成
    if (card.element === '土' && markResult.detail && markResult.detail.shield) {
      const stoneResult = battle.buildSystem.applyStoneShieldBonus(markResult.detail.shield);
      if (stoneResult.shield > markResult.detail.shield) {
        const extraShield = stoneResult.shield - markResult.detail.shield;
        player.shield += extraShield;
        logMsg += stoneResult.log;
      }
    }

    // ★ 流派系统：印记引爆回调
    const buildLog = battle.buildSystem.onMarkDetonated(card.element, battle, markResult.detail);
    if (buildLog) logMsg += buildLog;

    // 寒渊流：水印引爆后额外抽牌
    if (card.element === '水') {
      const extraDraw = battle.buildSystem.consumeFrostExtraDraw();
      if (extraDraw > 0) {
        drawCards(player, extraDraw);
        applyCharacterCostPassive(player);
      }
    }
    // 青藤流：木印引爆后额外抽牌
    if (card.element === '木') {
      const extraDraw = battle.buildSystem.consumeVineExtraDraw();
      if (extraDraw > 0) {
        drawCards(player, extraDraw);
        applyCharacterCostPassive(player);
      }
    }

    // ★ 遗物效果：凝水玉 - 水印引爆额外抽牌
    if (card.element === '水' && markResult.detail && markResult.detail.extraDraw) {
      drawCards(player, markResult.detail.extraDraw);
      applyCharacterCostPassive(player);
      logMsg += ` [凝水玉: 额外抽${markResult.detail.extraDraw}牌]`;
    }
    // ★ 遗物效果：朱雀羽 - 火印引爆火伤+30%
    if (card.element === '火' && markResult.detail && markResult.detail.fireDamageBonus) {
      logMsg += ` [朱雀羽: 火伤+${Math.round(markResult.detail.fireDamageBonus * 100)}%]`;
    }
    // ★ 遗物效果：神木种子 - 木印治疗溢出转护盾
    if (card.element === '木' && markResult.detail && markResult.detail.overflowShield) {
      logMsg += ` [神木种子: 溢出转化${markResult.detail.overflowShield}护盾]`;
    }
    // ★ 遗物效果：玄冰佩 - 冻结+1回合
    if (card.element === '水' && markResult.detail && markResult.detail.extraFreeze) {
      logMsg += ` [玄冰佩: 冻结+${markResult.detail.extraFreeze}回合]`;
    }
  }

  // ★ 流派系统：出牌统计
  const cardPlayLog = battle.buildSystem.onCardPlayed(card, battle);
  if (cardPlayLog) logMsg += cardPlayLog;

  // ★ 印记层数显示：在出牌日志末尾添加当前属性印记层数
  if (card.element && card.element !== '无' && battle.markManager) {
    const marks = battle.markManager.getMarks();
    const currentMark = marks[card.element] || 0;
    if (currentMark > 0) {
      logMsg += ` 【${card.element}印 ${currentMark}层】`;
    }
  }

  battle.log.push(logMsg);

  if (enemy.hp <= 0) {
    if (enemy.key === 'jiu_wei_hu') {
      // 第三章终局：九尾由玩家的"最终选择"收束，伤害无法真正将她击杀，钳制到1血，
      // 交由场景弹出阶段三对话与最终选择，避免一击致死跳过结局选择
      enemy.hp = 1;
      battle.log.push(`【${enemy.name}】周身归墟之力翻涌，似有不可撼动之相！`);
    } else {
      battle.phase = 'battle_end';
      battle.win = true;
      battle.log.push(`降妖功成！【${enemy.name}】已被彻底诛灭！`);
      // 记录击败，解锁万妖异录详细信息
      if (enemy.key) recordEnemyDefeat(enemy.key);
    }
  }

  return battle;
}

export function resolveEnemyTurn(battle) {
  const { player, enemy, chapter } = battle;
  battle.phase = 'enemy_action';
  
  // 回合结束清理印记管理器的临时翻倍状态
  battle.markManager.onTurnEnd();

  if (enemy.burnTurns > 0) {
    let bDmg = enemy.burnDamage || 3;
    // ★ 炼妖壶碎片：灼烧伤害翻倍
    if (hasRelic(player, 'relic_lianyao_hu')) {
      bDmg *= 2;
    }
    if (enemy.invulnerableTurns <= 0) {
      enemy.hp = Math.max(0, enemy.hp - bDmg);
      battle.log.push(`烈焰灼烧！【${enemy.name}】受到 ${bDmg} 点真实伤害`);
    } else {
      battle.log.push(`【${enemy.name}】周身冥阵护体，免除烈焰灼烧！`);
    }
    enemy.burnTurns--;
    if (enemy.hp <= 0) {
      if (enemy.key === 'jiu_wei_hu') {
        // 同出牌逻辑：九尾无法被灼烧击杀，钳制到1血，最终由选择收束
        enemy.hp = 1;
        battle.log.push(`【${enemy.name}】周身归墟之力翻涌，烈火亦难伤其本源！`);
      } else {
        battle.phase = 'battle_end';
        battle.win = true;
        battle.log.push(`妖邪伏诛！【${enemy.name}】在烈火中化为飞灰！`);
        return battle;
      }
    }
  }

  if (enemy.skipTurn) {
    enemy.skipTurn = false;
    battle.log.push(`【${enemy.name}】被定身封印，本回合动弹不得！`);
    // ★ 玄冰佩：冻结额外回合
    if (enemy.frozenExtraTurns && enemy.frozenExtraTurns > 0) {
      enemy.frozenExtraTurns--;
      enemy.skipTurn = true;
    }
  } else {
    const actionType = enemy.nextActionType || 'attack';
    const actionVal = enemy.nextActionValue !== undefined ? enemy.nextActionValue : (enemy.attack || 4);

    if (actionType === 'attack' || actionType === 'heavy_attack' || actionType === 'heavy_attack_curse' || actionType === 'debuff_energy' || actionType === 'curse_insert' || actionType === 'attack_curse') {
      let actualAtk = actionVal;
      let shieldBroken = 0;
      if (player.shield > 0) {
        if (player.shield >= actualAtk) {
          player.shield -= actualAtk;
          actualAtk = 0;
          battle.log.push(`【${enemy.name}】使出【${enemy.nextAction}】，被你的护盾完全抵消！`);
        } else {
          shieldBroken = player.shield;
          actualAtk -= player.shield;
          player.shield = 0;
        }
      }
      // ★ 磐石流：护盾破碎反伤
      if (shieldBroken > 0) {
        const reflectLog = battle.buildSystem.onShieldBroken(battle, shieldBroken);
        if (reflectLog) battle.log.push(reflectLog);
      }
      if (actualAtk > 0) {
        player.hp -= actualAtk;
        const heavyTag = (actionType === 'heavy_attack' || actionType === 'heavy_attack_curse') ? '【暴击】' : '';
        battle.log.push(`【${enemy.name}】使出${heavyTag}【${enemy.nextAction}】！你受到了 ${actualAtk} 点肉身伤害！`);
      }

      if (actionType === 'heavy_attack_curse' || actionType === 'curse_insert' || actionType === 'attack_curse') {
        const { handCount } = injectCurseToPlayer(player, 1);
        if (handCount > 0) {
          battle.log.push(`★ 阴煞入体！【索魂咒】直接侵入手牌，挤占道法经脉！`);
        } else {
          battle.log.push(`★ 阴煞入体！手牌已满，【索魂咒】被强行注入抽牌堆顶！`);
        }
      }

      if (actionType === 'debuff_energy') {
        player.energyDebuff = 1;
        battle.log.push(`★【阴火封脉】经脉受阻！你下回合的可用灵气将减少 1 点！`);
      }
    } else if (actionType === 'defend') {
      enemy.shield = (enemy.shield || 0) + actionVal;
      battle.log.push(`【${enemy.name}】运转妖法【${enemy.nextAction}】，获得了 ${actionVal} 点妖气护盾！`);
    } else if (actionType === 'buff_attack') {
      enemy.attackBuff = (enemy.attackBuff || 0) + actionVal;
      battle.log.push(`【${enemy.name}】发动【${enemy.nextAction}】！攻击力永久提高 ${actionVal} 点！`);
    } else if (actionType === 'buff_enrage') {
      battle.log.push(`★【${enemy.name}】陷入【极度狂暴】！妖气滔天，攻击力提升 ${actionVal} 点！`);
    } else if (actionType === 'true_damage') {
      player.hp = Math.max(0, player.hp - actionVal);
      battle.log.push(`★【${enemy.name}】催动【生死簿】！勾魂夺命，穿透护盾直接扣除 ${actionVal} 点真实生命！`);
    } else if (actionType === 'invulnerable_barrier') {
      enemy.invulnerableTurns = 1;
      const { handCount, deckCount } = injectCurseToPlayer(player, 2);
      let curseDesc = '';
      if (handCount === 2) curseDesc = '将 2 张【索魂咒】直接打入手牌';
      else if (deckCount === 2) curseDesc = '将 2 张【索魂咒】强行注入抽牌堆顶';
      else curseDesc = '将 1 张【索魂咒】打入手牌、1 张注入牌堆顶';
      battle.log.push(`★【生死冥界阵】阴阳判官开启冥界免伤法阵（免疫伤害1回合），并${curseDesc}！`);
    } else if (actionType === 'buff_phase2') {
      // 九尾狐阶段2：混沌之兽
      battle.log.push(`★【混沌之兽】九尾狐借用归墟之力，全身被混沌之力包裹！攻击力永久+5，每回合塞入索魂咒！`);
    } else if (actionType === 'invulnerable_gate') {
      // 九尾狐阶段3：归墟之门
      enemy.invulnerableTurns = 1;
      battle.log.push(`★【归墟之门】九尾狐开启归墟封印之门！绝对免伤1回合，开门仪式启动（5回合后完全开启）！`);
    } else if (actionType === 'gate_complete') {
      // 归墟之门完全开启，玩家失败
      player.hp = 0;
      battle.log.push(`★【归墟之门完全开启】玄冥之力泄露，你被混沌之力吞噬……`);
    }
  }

  if (chapter === 2 && player.shield > 0) {
    const decay = Math.ceil(player.shield * 0.3);
    player.shield = Math.max(0, player.shield - decay);
    battle.log.push(`【九幽阴气】阴风呼啸，道体残留护盾被腐蚀消散了 ${decay} 点！`);
  }

  if (enemy.invulnerableTurns > 0) {
    enemy.invulnerableTurns--;
  }

  if (player.hp <= 0 && player.characterId === 'nezha' && !player.hasRevived) {
    player.hasRevived = true;
    player.hp = player.maxHp;
    battle.log.push(`★【莲花现化】哪吒三太子重生复活，道体气血回满！`);
  }

  if (player.hp <= 0) {
    player.hp = 0;
    battle.phase = 'battle_end';
    battle.win = false;
    recordPlayerDeath();
    battle.log.push(`道消身陨……你未能抵挡住幽冥深渊的凶煞戾气。`);
  }

  // ★ 流派系统：回合结束
  const turnEndLog = battle.buildSystem.onTurnEnd(battle);
  if (turnEndLog) battle.log.push(turnEndLog);

  return battle;
}

export function startPlayerTurn(battle) {
  const { player, enemy, chapter } = battle;
  battle.turnCount++;
  decideEnemyIntent(enemy, battle.turnCount, chapter);

  battle.phase = 'player_action';
  
  // 回合开始更新印记管理器状态
  battle.markManager.onTurnStart();

  // ★ 流派系统：回合开始
  const turnStartLog = battle.buildSystem.onTurnStart(battle);
  if (turnStartLog) battle.log.push(turnStartLog);

  const energyPenalty = player.energyDebuff || 0;
  if (player.characterId === 'bai_suzhen') {
    // ★ 白素贞：千年修为 - 剩余灵气无限继承，每回合恢复 maxEnergy
    player.energy = player.energy + player.maxEnergy - energyPenalty;
  } else {
    player.energy = Math.max(1, player.maxEnergy - energyPenalty);
  }
  player.energyDebuff = 0;

  if (hasRelic(player, 'relic_taiji')) player.shield += 2;
  if (hasRelic(player, 'relic_panshi')) player.shield += 3;

  const keptCount = player.cards.length;
  const hasTianji = hasRelic(player, 'relic_tianji');
  const drawCount = hasTianji ? 4 : 3;
  const actualDrawn = drawCards(player, drawCount);

  applyCharacterCostPassive(player);

  const tianjiTag = hasTianji ? ' [天机册+1]' : '';
  const penaltyTag = energyPenalty > 0 ? ` (经脉受阻: 灵气-${energyPenalty})` : '';
  const drawMsg = actualDrawn > 0 ? `新纳 ${actualDrawn} 张符箓${tianjiTag}` : `手牌已满7张（停止发牌）`;
  
  battle.log.push(`第 ${battle.turnCount} 回合：灵气恢复至 ${player.energy}/${player.maxEnergy}${penaltyTag}，保留 ${keptCount} 张，${drawMsg}`);

  return { battle, actualDrawn, keptCount };
}

export function endPlayerTurn(battle) {
  const b = resolveEnemyTurn(battle);
  if (b.phase === 'battle_end') return b;
  const { battle: nextBattle } = startPlayerTurn(b);
  return nextBattle;
}