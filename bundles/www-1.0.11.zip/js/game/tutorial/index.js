/**
 * 新手引导系统统一出口
 *
 * 使用方式：
 * import { TutorialManager, renderTutorial, isSkipButtonTapped, BATTLE_STEPS, ... } from '../tutorial/index.js';
 */

export { TutorialManager, TUTORIAL_TYPE } from './TutorialManager.js';
export { renderTutorial, renderOneShotHint, isSkipButtonTapped } from './renderer.js';
export {
  BATTLE_STEPS,
  MAP_STEPS,
  SHOP_STEPS,
  EVENT_STEPS,
  REST_STEPS,
  TUTORIAL_BATTLE_STEPS,
  ONE_SHOT_HINTS,
  ALL_TUTORIAL_STEPS
} from './steps.js';
