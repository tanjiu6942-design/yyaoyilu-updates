/**
 * TutorialRenderer —— 新手引导渲染层
 *
 * 负责渲染：
 * 1. 半透明遮罩 + 高亮挖空区域
 * 2. 墨金风格对话框
 * 3. 跳过按钮
 * 4. 进度指示器
 * 5. action 类型步骤的操作提示
 */

import {
  drawRoundedRect,
  drawTextCentered,
  drawSealButton,
  UI_COLORS
} from '../scene.js';
import { SAFE_TOP, TOP_BAR_Y, TOP_BAR_H, CAPSULE_LEFT } from '../../render.js';
import { TUTORIAL_TYPE } from './TutorialManager.js';

// 存储上一次渲染的跳过按钮位置，供点击检测使用
let _lastSkipBtnRect = null;

/**
 * 渲染完整的引导层
 * @param {CanvasRenderingContext2D} ctx
 * @param {Object} step - 当前步骤对象
 * @param {number} width - 屏幕宽度
 * @param {number} height - 屏幕高度
 * @param {number} currentIndex - 当前步骤索引
 * @param {number} totalCount - 总步骤数
 */
export function renderTutorial(ctx, step, width, height, currentIndex, totalCount) {
  if (!step) return;
  if (!isFinite(width) || !isFinite(height) || width <= 0 || height <= 0) return;

  // 1. 计算高亮区域
  let hl = null;
  if (step.highlight && typeof step.highlight === 'function') {
    try {
      hl = step.highlight(width, height);
    } catch (e) {
      hl = null;
    }
    // 校验高亮区域数值有效性
    if (hl && (!isFinite(hl.x) || !isFinite(hl.y) || !isFinite(hl.w) || !isFinite(hl.h))) {
      hl = null;
    }
  }

  // 2. 渲染高亮边框
  if (hl && hl.w > 0 && hl.h > 0) {
    const pulse = 0.5 + 0.5 * Math.sin(Date.now() / 200);
    ctx.save();
    ctx.shadowColor = '#FFD700';
    ctx.shadowBlur = 14 * pulse;
    drawRoundedRect(ctx, hl.x, hl.y, hl.w, hl.h, 8, null, '#FFD700', 2.5);
    ctx.restore();
  }

  // 3. 渲染对话框（内含跳过按钮）
  renderDialogBox(ctx, step, hl, width, height, currentIndex, totalCount);
}

/**
 * 文字换行：将长文本按最大宽度拆成多行
 */
function wrapTutorialText(ctx, text, maxWidth, fontSize) {
  if (!text) return [];
  ctx.font = `${fontSize}px "Songti SC", "SimSun", serif`;
  const lines = [];
  let current = '';
  for (const ch of text) {
    const test = current + ch;
    if (ctx.measureText(test).width > maxWidth && current.length > 0) {
      lines.push(current);
      current = ch;
    } else {
      current = test;
    }
  }
  if (current) lines.push(current);
  return lines;
}

/**
 * 渲染墨金风格对话框
 */
function renderDialogBox(ctx, step, hl, width, height, currentIndex, totalCount) {
  const safeTop = isFinite(SAFE_TOP) ? SAFE_TOP : 60;

  const dialogW = Math.min(348, width - 24);
  const textMaxW = dialogW - 56;
  const fontSize = 13;
  const lineH = 22;

  // 预先计算换行后的文本行数
  const lines1 = wrapTutorialText(ctx, step.text1 || '', textMaxW, fontSize);
  const lines2 = wrapTutorialText(ctx, step.text2 || '', textMaxW, fontSize);
  const totalTextLines = lines1.length + lines2.length;

  // 根据文本行数动态计算对话框高度
  const baseH = 82;
  const textAreaH = totalTextLines * lineH;
  const actionHintH = (step.type === TUTORIAL_TYPE.ACTION && step.actionHint) ? 24 : 0;
  let dialogH = baseH + textAreaH + actionHintH;
  dialogH = Math.max(dialogH, step.type === TUTORIAL_TYPE.ACTION ? 160 : 142);

  const dialogX = (width - dialogW) / 2;

  // 根据高亮位置决定对话框在上方还是下方；无高亮时统一放在顶部
  let dialogY = safeTop + 16;
  if (hl) {
    if (hl.y + hl.h / 2 < height / 2) {
      dialogY = Math.min(height - dialogH - 20, hl.y + hl.h + 20);
    } else {
      dialogY = Math.max(safeTop + 16, hl.y - dialogH - 20);
    }
  }
  // 限制在金色边框内（胶囊下方），避免遮挡微信原生胶囊
  dialogY = Math.max(dialogY, safeTop + 8);
  dialogY = Math.min(dialogY, height - dialogH - 16);

  // 防御性校验：确保所有尺寸为有限正数，避免 createLinearGradient 崩溃
  if (!isFinite(dialogW) || dialogW <= 0) dialogW = 300;
  if (!isFinite(dialogH) || dialogH <= 0) dialogH = 150;
  if (!isFinite(dialogX)) dialogX = (width - dialogW) / 2;
  if (!isFinite(dialogY)) dialogY = (height - dialogH) / 2;

  // 墨金框体
  drawInkGoldTutorialBox(ctx, dialogX, dialogY, dialogW, dialogH);

  // 标题
  ctx.save();
  ctx.font = 'bold 16px "Songti SC", "SimSun", serif';
  ctx.fillStyle = UI_COLORS.cinnabar;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(150, 42, 31, 0.3)';
  ctx.shadowBlur = 4;
  ctx.fillText(step.title || '【 新 手 引 路 】', width / 2, dialogY + 28);
  ctx.restore();

  // 分隔金线
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(dialogX + 32, dialogY + 44);
  ctx.lineTo(dialogX + dialogW - 32, dialogY + 44);
  ctx.stroke();

  // 正文（自动换行）
  let textY = dialogY + 60;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `${fontSize}px "Songti SC", "SimSun", serif`;

  for (const line of lines1) {
    ctx.fillStyle = '#120904';
    ctx.fillText(line, width / 2, textY);
    textY += lineH;
  }
  for (const line of lines2) {
    ctx.fillStyle = '#2B6B46';
    ctx.fillText(line, width / 2, textY);
    textY += lineH;
  }

  // action 类型的操作提示
  if (step.type === TUTORIAL_TYPE.ACTION && step.actionHint) {
    const alpha = 0.6 + 0.4 * Math.abs(Math.sin(Date.now() / 400));
    ctx.fillStyle = `rgba(150, 42, 31, ${alpha})`;
    ctx.font = 'bold 12px "Songti SC", "SimSun", serif';
    ctx.fillText(step.actionHint, width / 2, textY + 4);
    textY += 24;
  }

  // 跳过按钮：右上角，微信原生胶囊左边（与序章跳过按钮样式完全一致）
  const skipBtnW = 54;
  const skipBtnH = isFinite(TOP_BAR_H) ? TOP_BAR_H : 32;
  let skipBtnX = width - skipBtnW - 12;
  const skipBtnY = isFinite(TOP_BAR_Y) ? TOP_BAR_Y : 50;
  _lastSkipBtnRect = { x: skipBtnX, y: skipBtnY, w: skipBtnW, h: skipBtnH };

  // 使用 drawSealButton 绘制，和序章跳过按钮完全一致
  drawSealButton(ctx, {
    x: skipBtnX, y: skipBtnY, w: skipBtnW, h: skipBtnH,
    text: '跳过', fontSize: 13,
    color: 'rgba(38, 24, 14, 0.94)',
    strokeColor: '#D4AF37',
    textColor: '#FFF3CA'
  });

  // 底部区域：居中进度提示
  const bottomY = dialogY + dialogH - 24;
  if (step.type === TUTORIAL_TYPE.ACTION) {
    const alpha = 0.7 + 0.3 * Math.abs(Math.sin(Date.now() / 400));
    ctx.globalAlpha = alpha;
    ctx.fillStyle = '#962A1F';
    ctx.font = 'bold 12px "Songti SC", "SimSun", serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`执行操作继续 (${currentIndex + 1}/${totalCount})`, width / 2, bottomY);
    ctx.globalAlpha = 1;
  } else {
    const alpha = 0.7 + 0.3 * Math.abs(Math.sin(Date.now() / 360));
    ctx.globalAlpha = alpha;
    ctx.fillStyle = '#962A1F';
    ctx.font = 'bold 12px "Songti SC", "SimSun", serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`轻触继续 (${currentIndex + 1}/${totalCount})`, width / 2, bottomY);
    ctx.globalAlpha = 1;
  }
}

/**
 * 检测点击是否在跳过按钮上
 */
export function isSkipButtonTapped(x, y, width) {
  if (!_lastSkipBtnRect) return false;
  const r = _lastSkipBtnRect;
  return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h;
}

/**
 * 墨金风格教程框体（独立绘制，不依赖场景中的 drawInkGoldScrollModal）
 */
function drawInkGoldTutorialBox(ctx, x, y, w, h) {
  ctx.save();

  // 1. 金煞辉光投影
  ctx.shadowColor = 'rgba(212, 175, 55, 0.22)';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetY = 10;

  // 2. 最外层漆黑沉香重檀框
  drawRoundedRect(ctx, x, y, w, h, 14, '#1A0E08', '#0D0704', 3);
  ctx.restore();

  // 3. 多层次流金金属描边
  const goldGrad = ctx.createLinearGradient(x, y, x + w, y + h);
  goldGrad.addColorStop(0, '#E6C875');
  goldGrad.addColorStop(0.25, '#FFF6C2');
  goldGrad.addColorStop(0.5, '#C49838');
  goldGrad.addColorStop(0.75, '#FCE38A');
  goldGrad.addColorStop(1, '#8C6018');
  drawRoundedRect(ctx, x + 2, y + 2, w - 4, h - 4, 12, null, goldGrad, 2);

  // 4. 仿古泥金宣纸渐变底衬
  const paperGrad = ctx.createRadialGradient(
    x + w / 2, y + h * 0.45, w * 0.15,
    x + w / 2, y + h * 0.5, w * 0.85
  );
  paperGrad.addColorStop(0, '#FFFDF8');
  paperGrad.addColorStop(0.35, '#F9EED9');
  paperGrad.addColorStop(0.75, '#EBD5AD');
  paperGrad.addColorStop(1, '#CFA968');
  drawRoundedRect(ctx, x + 5, y + 5, w - 10, h - 10, 10, paperGrad, '#8F6126', 1.5);

  // 5. 宫廷暗纹暗印
  ctx.save();
  const centerX = x + w / 2;
  const centerY = y + h * 0.5;
  const wmR = Math.min(w, h) * 0.32;
  ctx.strokeStyle = 'rgba(184, 134, 40, 0.075)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(centerX, centerY, wmR, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(centerX, centerY, wmR * 0.85, 0, Math.PI * 2);
  ctx.setLineDash([8, 6]);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.beginPath();
  ctx.arc(centerX, centerY - wmR * 0.4, wmR * 0.4, Math.PI * 0.5, Math.PI * 1.5);
  ctx.arc(centerX, centerY + wmR * 0.4, wmR * 0.4, Math.PI * 1.5, Math.PI * 0.5);
  ctx.stroke();
  ctx.fillStyle = 'rgba(180, 120, 40, 0.04)';
  for (let i = 0; i < 28; i++) {
    const rx = x + 10 + ((i * 73 + 19) % (w - 20));
    const ry = y + 10 + ((i * 101 + 37) % (h - 20));
    ctx.beginPath();
    ctx.arc(rx, ry, (i % 3) + 1.2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // 6. 内侧双重朱砂与泥金框
  const innerMargin = 12;
  const ix = x + innerMargin;
  const iy = y + innerMargin;
  const iw = w - innerMargin * 2;
  const ih = h - innerMargin * 2;
  ctx.save();
  ctx.strokeStyle = 'rgba(150, 42, 31, 0.35)';
  ctx.lineWidth = 1;
  ctx.strokeRect(ix, iy, iw, ih);
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 1.2;
  ctx.strokeRect(ix + 3, iy + 3, iw - 6, ih - 6);

  // 7. 四角如意连珠祥云回纹
  const drawRoyalCorner = (cx, cy, dirX, dirY) => {
    ctx.save();
    ctx.strokeStyle = '#C99A3A';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(cx, cy + dirY * 18);
    ctx.lineTo(cx, cy);
    ctx.lineTo(cx + dirX * 18, cy);
    ctx.stroke();
    ctx.strokeStyle = '#EAD7A3';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(cx + dirX * 5, cy + dirY * 14);
    ctx.lineTo(cx + dirX * 5, cy + dirY * 5);
    ctx.lineTo(cx + dirX * 14, cy + dirY * 5);
    ctx.stroke();
    ctx.fillStyle = '#962A1F';
    ctx.beginPath();
    ctx.arc(cx + dirX * 7, cy + dirY * 7, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FFD700';
    ctx.fillRect(cx + dirX * 6, cy + dirY * 6, 2, 2);
    ctx.restore();
  };
  drawRoyalCorner(ix + 5, iy + 5, 1, 1);
  drawRoyalCorner(ix + iw - 5, iy + 5, -1, 1);
  drawRoyalCorner(ix + 5, iy + ih - 5, 1, -1);
  drawRoyalCorner(ix + iw - 5, iy + ih - 5, -1, -1);

  // 8. 顶部与底部中心如意云珠徽标
  const drawCenterRuyi = (midX, midY, isFlip) => {
    ctx.save();
    ctx.translate(midX, midY);
    if (isFlip) ctx.scale(1, -1);
    ctx.strokeStyle = '#C99A3A';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(-10, 0, 4, Math.PI * 0.5, Math.PI * 2);
    ctx.arc(0, -2, 6, Math.PI, 0);
    ctx.arc(10, 0, 4, Math.PI, Math.PI * 0.5);
    ctx.stroke();
    ctx.fillStyle = '#962A1F';
    ctx.beginPath();
    ctx.arc(0, -2, 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };
  drawCenterRuyi(ix + iw / 2, iy + 3, false);
  drawCenterRuyi(ix + iw / 2, iy + ih - 3, true);

  ctx.restore();
}

/**
 * 渲染一次性提示弹窗（用于首次遇到特定机制）
 * 与完整引导不同，这是一个居中的小弹窗，点击即消失
 */
export function renderOneShotHint(ctx, hint, width, height) {
  if (!hint) return;

  const panelW = Math.min(300, width - 40);
  const panelH = 142;
  const panelX = (width - panelW) / 2;
  const panelY = (height - panelH) / 2;

  // 半透明背景
  ctx.fillStyle = 'rgba(4, 2, 1, 0.7)';
  ctx.fillRect(0, 0, width, height);

  drawInkGoldTutorialBox(ctx, panelX, panelY, panelW, panelH);

  // 标题
  ctx.save();
  ctx.font = 'bold 15px "Songti SC", "SimSun", serif';
  ctx.fillStyle = UI_COLORS.cinnabar;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(hint.title || '提示', width / 2, panelY + 28);
  ctx.restore();

  // 分隔线
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(panelX + 24, panelY + 44);
  ctx.lineTo(panelX + panelW - 24, panelY + 44);
  ctx.stroke();

  // 正文
  drawTextCentered(ctx, hint.text1 || '', width / 2, panelY + 64, '#120904', 12, '"Songti SC", "SimSun", serif');
  drawTextCentered(ctx, hint.text2 || '', width / 2, panelY + 86, '#2B6B46', 12, '"Songti SC", "SimSun", serif');

  // 继续提示
  const alpha = Math.abs(Math.sin(Date.now() / 360));
  ctx.fillStyle = `rgba(150, 42, 31, ${0.65 + 0.35 * alpha})`;
  ctx.font = 'bold 11px "Songti SC", "SimSun", serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('— 轻触知晓 —', width / 2, panelY + panelH - 22);
}
