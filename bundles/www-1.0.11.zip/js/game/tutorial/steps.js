/**
 * 新手引导步骤配置
 *
 * 每个步骤字段说明：
 * - id: 唯一标识，用于持久化进度（格式：场景名_序号_简述）
 * - type: info（纯信息点击继续）/ highlight（高亮区域+点击）/ action（必须执行操作）
 * - title: 对话框标题
 * - text1, text2: 正文两行
 * - highlight: 函数 (width, height) => {x, y, w, h}，高亮区域坐标
 * - actionId: action 类型的操作标识，场景中调用 completeAction(actionId) 完成
 * - actionHint: action 类型的提示文字（显示在对话框底部）
 */

import { TUTORIAL_TYPE } from './TutorialManager.js';
import { SAFE_TOP, TOP_BAR_Y, TOP_BAR_H, CAPSULE_LEFT, SCREEN_WIDTH, SCREEN_HEIGHT } from '../../render.js';

// ==================== 战斗场景引导 ====================
// 注意：高亮坐标基于 BattleScene 的实际布局
// 敌人区中心: (width/2, SAFE_TOP+46)，尺寸约 196x104
// 玩家状态栏: y = HAND_Y - 58，高度 26
// 手牌区: y = height - CARD_H - 58
// 结束回合按钮: 底部

const BATTLE_CARD_H = 140;
const BATTLE_CARD_W = 94;
const BATTLE_CARD_GAP = 10;

// 教学关卡卡牌的位置计算（居中排列）
function getTutorialCardPos(width, height, cardIndex, cardCount = 2) {
  const totalWidth = cardCount * BATTLE_CARD_W + (cardCount - 1) * BATTLE_CARD_GAP;
  const startX = (width - totalWidth) / 2;
  const HAND_Y = height - BATTLE_CARD_H - 58;
  return {
    x: startX + cardIndex * (BATTLE_CARD_W + BATTLE_CARD_GAP),
    y: HAND_Y,
    w: BATTLE_CARD_W,
    h: BATTLE_CARD_H
  };
}

export const BATTLE_STEPS = [
  {
    id: 'battle_01_intro',
    type: TUTORIAL_TYPE.INFO,
    title: '降妖伏魔 · 入门',
    text1: '初入妖卷，道友莫慌。天地五行，生克有序。',
    text2: '且让老朽为你指点一二这降妖伏魔之玄法。',
    highlight: null
  },
  {
    id: 'battle_02_enemy',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【识妖】',
    text1: '上方乃是妖邪，标有气血与五行属性。',
    text2: '血条下方时刻展示其出招意图，知己知彼百战不殆。',
    highlight: (w, h) => ({
      x: w / 2 - 104,
      y: SAFE_TOP - 6,
      w: 208,
      h: 116
    })
  },
  {
    id: 'battle_03_status',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【道体】',
    text1: '此处展示你的气血、护盾与灵气。',
    text2: '打出符箓需消耗灵气，护盾可抵挡妖邪攻势。',
    highlight: (w, h) => ({
      x: 8,
      y: h - BATTLE_CARD_H - 58 - 36,
      w: w - 16,
      h: 32
    })
  },
  {
    id: 'battle_04_hand',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【符箓】',
    text1: '此为你的手牌（上限7张，每轮发2张）。',
    text2: '点击卡牌选中，上滑即可打出符箓攻伐妖邪！',
    highlight: (w, h) => ({
      x: 6,
      y: h - BATTLE_CARD_H - 82,
      w: w - 12,
      h: BATTLE_CARD_H + 30
    })
  },
  {
    id: 'battle_05_longpress',
    type: TUTORIAL_TYPE.INFO,
    title: '【观符】',
    text1: '点击手牌可放大符箓，详查技能与五行印记之效。',
    text2: '明晰五行法理，方能在激战中运筹帷幄。',
    highlight: null
  },
  {
    id: 'battle_06_elements',
    type: TUTORIAL_TYPE.INFO,
    title: '【五行相克】',
    text1: '金克木、木克土、土克水、水克火、火克金。',
    text2: '连出2张同属性符箓，即可引爆【五行印记】无上绝技！',
    highlight: null
  },
  {
    id: 'battle_07_play_card',
    type: TUTORIAL_TYPE.ACTION,
    title: '【出招】',
    text1: '是时候了！选中一张符箓，上滑将其打出。',
    text2: '亲手斩出你降妖路上的第一剑！',
    actionId: 'play_card',
    actionHint: '→ 请上滑一张手牌打出',
    highlight: (w, h) => ({
      x: 6,
      y: h - BATTLE_CARD_H - 82,
      w: w - 12,
      h: BATTLE_CARD_H + 30
    })
  },
  {
    id: 'battle_08_end_turn',
    type: TUTORIAL_TYPE.ACTION,
    title: '【结印】',
    text1: '灵气耗尽或无牌可出时，点击结束回合。',
    text2: '随后妖邪便会发难，切记提前运转法术叠盾防身！',
    actionId: 'end_turn',
    actionHint: '→ 请点击底部「结束回合」按钮',
    highlight: (w, h) => ({
      x: 12,
      y: h - 52,
      w: w - 24,
      h: 46
    })
  },
  {
    id: 'battle_09_bag',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【锦囊】',
    text1: '左上角为修真锦囊，随身携带。',
    text2: '内藏道统被动、上古法宝及盘缠，可随时查阅。',
    highlight: (w, h) => ({
      x: 8,
      y: TOP_BAR_Y - 2,
      w: 66,
      h: TOP_BAR_H + 4
    })
  },
  {
    id: 'battle_10_done',
    type: TUTORIAL_TYPE.INFO,
    title: '【道法初成】',
    text1: '基础法门已传授完毕，接下来便看道友自身修行了。',
    text2: '愿你手持五行符箓，荡尽这世间妖邪！',
    highlight: null
  }
];

// ==================== 地图场景引导 ====================
export const MAP_STEPS = [
  {
    id: 'map_01_intro',
    type: TUTORIAL_TYPE.INFO,
    title: '【妖域版图】',
    text1: '眼前乃是妖域迷阵，路径千变万化，每一次踏入皆不相同。',
    text2: '沿节点前行，斩妖除魔，直至章末魁首。',
    highlight: null
  },
  {
    id: 'map_02_nodes',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【节点类型】',
    text1: '不同图标代表不同遭遇：战斗、精英、事件、商店、休息。',
    text2: '发光的节点为当前可前往之处，点击即可踏入。',
    highlight: (w, h) => ({
      x: 4,
      y: SAFE_TOP,
      w: w - 8,
      h: h - SAFE_TOP - 4
    })
  },
  {
    id: 'map_03_path',
    type: TUTORIAL_TYPE.INFO,
    title: '【路径抉择】',
    text1: '每个节点可能连通多条前路，选择不同遭遇各异。',
    text2: '精英战斗凶险但法宝丰厚，商店可补强符箓，事件藏有因果机缘。',
    highlight: null
  },
  {
    id: 'map_03_karma',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【因果鉴】',
    text1: '右上角「因」字图标显示当前因果值。善念则商贾敬重、妖邪避退；恶念则煞气缠身、强敌窥伺。',
    text2: '长按此图标可查看当前因果阶位的全部增幅详情。',
    highlight: (w, h) => {
      const safeTopY = isFinite(TOP_BAR_Y) ? TOP_BAR_Y : 50;
      const safeTopH = isFinite(TOP_BAR_H) ? TOP_BAR_H : 32;
      const statusY = safeTopY + safeTopH + 8;
      const badgeW = (w - 24 - 12) / 3;
      const karmaX = 12 + badgeW * 2 + 12;
      return {
        x: karmaX - 4,
        y: statusY - 4,
        w: badgeW + 8,
        h: 34
      };
    }
  },
  {
    id: 'map_04_select',
    type: TUTORIAL_TYPE.ACTION,
    title: '【启程】',
    text1: '选择一个发光的节点，踏入你的第一场试炼吧。',
    text2: '建议先从普通战斗开始，熟悉五行斗法之法。',
    actionId: 'select_node',
    actionHint: '→ 请点击一个发光的节点',
    highlight: (w, h) => ({
      x: 4,
      y: SAFE_TOP,
      w: w - 8,
      h: h - SAFE_TOP - 4
    })
  }
];

// ==================== 商店场景引导 ====================
export const SHOP_STEPS = [
  {
    id: 'shop_01_intro',
    type: TUTORIAL_TYPE.INFO,
    title: '【坊市奇遇】',
    text1: '此乃山中货郎所设之秘宝阁，以铜钱换取机缘。',
    text2: '三大分区各有妙用，且听老朽一一道来。',
    highlight: null
  },
  {
    id: 'shop_02_tabs',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【三大分区】',
    text1: '神通阁购符箓，八卦炉强化卡牌，法宝阁收遗物。',
    text2: '顶部标签可切换分区，按需选购。',
    highlight: (w, h) => ({
      x: 12,
      y: SAFE_TOP + 4,
      w: w - 24,
      h: 34
    })
  },
  {
    id: 'shop_03_cards',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【神通阁】',
    text1: '此处售卖强力符箓，点击价格按钮即可购入。',
    text2: '购入的符箓将永久加入你的牌库，每场战斗皆可使用。',
    highlight: (w, h) => ({
      x: 10,
      y: SAFE_TOP + 74,
      w: w - 20,
      h: Math.min(200, h - SAFE_TOP - 120)
    })
  },
  {
    id: 'shop_04_furnace',
    type: TUTORIAL_TYPE.INFO,
    title: '【八卦炉】',
    text1: '两张同名同星符箓可合为更强的一星卡。',
    text2: '也可直接点化单卡强化，或焚毁废牌精简牌库。',
    highlight: null
  },
  {
    id: 'shop_05_relics',
    type: TUTORIAL_TYPE.INFO,
    title: '【法宝阁】',
    text1: '上古法宝效果各异，一旦收纳永久生效。',
    text2: '精英战斗也有几率掉落法宝，请谨慎抉择。',
    highlight: null
  },
  {
    id: 'shop_06_gold',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【铜钱】',
    text1: '顶部显示你当前持有的铜钱数量。',
    text2: '斩妖除魔可得铜钱，合理分配方能道行精进。',
    highlight: (w, h) => ({
      x: 120,
      y: TOP_BAR_Y,
      w: 100,
      h: TOP_BAR_H
    })
  },
  {
    id: 'shop_07_leave',
    type: TUTORIAL_TYPE.INFO,
    title: '【离店】',
    text1: '选购完毕后，点击左上角「离店」继续前行。',
    text2: '货郎只此一处，错过便需等下一处坊市了。',
    highlight: (w, h) => ({
      x: 8,
      y: TOP_BAR_Y - 2,
      w: 60,
      h: TOP_BAR_H + 4
    })
  }
];

// ==================== 事件场景引导 ====================
export const EVENT_STEPS = [
  {
    id: 'event_01_intro',
    type: TUTORIAL_TYPE.INFO,
    title: '【古道奇遇】',
    text1: '荒山野径之中，常有匪夷所思之事发生。',
    text2: '你的每一个抉择，都将影响因果与前路。',
    highlight: null
  },
  {
    id: 'event_02_story',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【情境铺叙】',
    text1: '上方画卷讲述当前遭遇的来龙去脉。',
    text2: '细读情境，方能做出最明智的抉择。',
    highlight: (w, h) => ({
      x: 8,
      y: 30,
      w: w - 16,
      h: h - 250
    })
  },
  {
    id: 'event_03_choices',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【因果抉择】',
    text1: '下方列出你的选择，每个选项标注了后果倾向。',
    text2: '善念积德，恶念招业，因果将影响法宝与结局。',
    highlight: (w, h) => ({
      x: 16,
      y: h - 200,
      w: w - 32,
      h: 150
    })
  },
  {
    id: 'event_04_choose',
    type: TUTORIAL_TYPE.ACTION,
    title: '【做出抉择】',
    text1: '仔细权衡后，点击一个选项做出你的选择。',
    text2: '一旦选定，因果便已种下，不可回头。',
    actionId: 'make_choice',
    actionHint: '→ 请点击一个选项做出抉择',
    highlight: (w, h) => ({
      x: 16,
      y: h - 200,
      w: w - 32,
      h: 150
    })
  }
];

// ==================== 休息场景引导 ====================
export const REST_STEPS = [
  {
    id: 'rest_01_intro',
    type: TUTORIAL_TYPE.INFO,
    title: '【残龛调息】',
    text1: '此地尚有一丝纯净天地灵气，可暂作歇息。',
    text2: '两种调息之法，各有裨益，请按需选择。',
    highlight: null
  },
  {
    id: 'rest_02_heal',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【吐纳调息】',
    text1: '吐纳天地灵气，可恢复三成最大气血。',
    text2: '激战之后气血亏空时，此为上上之选。',
    highlight: (w, h) => ({
      x: w / 2 - 85,
      y: h - 165,
      w: 170,
      h: 46
    })
  },
  {
    id: 'rest_03_karma',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【静心冥想】',
    text1: '面壁叩问本心，可增加1点善业因果。',
    text2: '因果圆满时，功德金莲等法宝将发挥更大威力。',
    highlight: (w, h) => ({
      x: w / 2 - 85,
      y: h - 105,
      w: 170,
      h: 46
    })
  },
  {
    id: 'rest_04_choose',
    type: TUTORIAL_TYPE.ACTION,
    title: '【选择调息之法】',
    text1: '根据当前状态选择一种调息方式。',
    text2: '调息完毕后即可启程继续前行。',
    actionId: 'do_rest',
    actionHint: '→ 请选择一种调息方式',
    highlight: (w, h) => ({
      x: w / 2 - 85,
      y: h - 165,
      w: 170,
      h: 106
    })
  }
];

// ==================== 一次性情境提示（非完整引导） ====================
// 用于首次遇到特定机制时的单条提示
export const ONE_SHOT_HINTS = {
  first_curse: {
    id: 'oneshot_first_curse',
    title: '【索魂咒】',
    text1: '妖邪的怨煞侵入了你的经脉！',
    text2: '此咒不可弃置，需消耗1点灵气将其化解焚毁。'
  },
  first_mark_trigger: {
    id: 'oneshot_first_mark',
    title: '【五行印记 · 引爆】',
    text1: '同属性符箓累积2层，印记引爆！',
    text2: '金印破甲、木印回血、水印冻结、火印翻倍、土印加盾！'
  },
  first_shield_break: {
    id: 'oneshot_shield_break',
    title: '【护盾机制】',
    text1: '护盾可抵挡伤害，但每回合开始时不会重置。',
    text2: '新获得的护盾将叠加在现有护盾之上，善加利用！'
  },
  first_relic_drop: {
    id: 'oneshot_first_relic',
    title: '【法宝现世】',
    text1: '斩除强敌，上古法宝感应到你的道行！',
    text2: '选择一件纳为己用，法宝效果将永久伴随本局修行。'
  },
  first_upgrade: {
    id: 'oneshot_first_upgrade',
    title: '【符箓强化】',
    text1: '符箓得以强化，星级提升！',
    text2: '星级越高威力越强，二星·极阶更是威力无穷。'
  }
};

// ==================== 全部步骤汇总（用于"重玩教程"） ====================
export const ALL_TUTORIAL_STEPS = {
  battle: BATTLE_STEPS,
  map: MAP_STEPS,
  shop: SHOP_STEPS,
  event: EVENT_STEPS,
  rest: REST_STEPS
};

// ==================== 新手教学关（独立固定关卡） ====================
export const TUTORIAL_BATTLE_STEPS = [
  {
    id: 'tut_01_welcome',
    type: TUTORIAL_TYPE.INFO,
    title: '【五行斗法 · 入门】',
    text1: '欢迎来到妖异录的世界，道友。',
    text2: '此关专为试炼而设，桃木傀儡不会真正伤你，且随我研习五行斗法之基。',
    highlight: null
  },
  {
    id: 'tut_02_enemy',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【识妖 · 桃木傀儡】',
    text1: '上方乃是你的对手——桃木傀儡，属性为【木】。',
    text2: '血条下方显示其出招意图，此傀儡只会笨拙挥击，造成3点伤害。',
    highlight: (w, h) => ({
      x: w / 2 - 104,
      y: SAFE_TOP - 6,
      w: 208,
      h: 116
    })
  },
  {
    id: 'tut_03_card_attack',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【符箓 · 御剑术】',
    text1: '左侧这张【御剑术】是攻击符箓，费用1点灵气。',
    text2: '效果：造成6点金系伤害，并附带1层【金印】。金克木，对木属性敌人伤害提升50%！',
    highlight: (w, h) => {
      const p = getTutorialCardPos(w, h, 0);
      return { x: p.x - 4, y: p.y - 4, w: p.w + 8, h: p.h + 8 };
    }
  },
  {
    id: 'tut_04_card_shield',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【符箓 · 金钟罩】',
    text1: '右侧这张【金钟罩】是防御符箓，费用2点灵气。',
    text2: '效果：获得12点护盾，可抵挡敌人攻击。护盾会叠加保留，善加利用可无伤通关！',
    highlight: (w, h) => {
      const p = getTutorialCardPos(w, h, 1);
      return { x: p.x - 4, y: p.y - 4, w: p.w + 8, h: p.h + 8 };
    }
  },
  {
    id: 'tut_05_energy',
    type: TUTORIAL_TYPE.HIGHLIGHT,
    title: '【灵气 · 出牌资源】',
    text1: '状态栏中的蓝色数字是你的【灵气】，每回合恢复至3点。',
    text2: '打出符箓需消耗对应费用的灵气，灵气用尽则无法继续出牌。',
    highlight: (w, h) => ({
      x: 8,
      y: h - 260,
      w: w - 16,
      h: 34
    })
  },
  {
    id: 'tut_06_how_to_play',
    type: TUTORIAL_TYPE.INFO,
    title: '【出招之法】',
    text1: '点击卡牌可选中并放大预览，再次点击或上滑即可打出。',
    text2: '也可直接按住卡牌向上拖拽，松手即打出符箓攻伐妖邪！',
    highlight: null
  },
  {
    id: 'tut_07_play_attack',
    type: TUTORIAL_TYPE.ACTION,
    title: '【初试锋芒】',
    text1: '是时候了！打出【御剑术】，感受金系剑气的威力！',
    text2: '金克木，这一剑将对桃木傀儡造成额外伤害。',
    actionId: 'play_card',
    actionHint: '→ 请打出【御剑术】',
    highlight: (w, h) => {
      const p = getTutorialCardPos(w, h, 0);
      return { x: p.x - 4, y: p.y - 4, w: p.w + 8, h: p.h + 8 };
    }
  },
  {
    id: 'tut_08_mark_explain',
    type: TUTORIAL_TYPE.INFO,
    title: '【五行印记 · 引爆】',
    text1: '看到了吗？打出金系卡牌后，敌人身上累积了【金印】！',
    text2: '同属性印记累积至2层时立即触发【印记引爆】！金印引爆：造成8点破甲真实伤害！（即连续打出2张同属性卡即可引爆）',
    highlight: null
  },
  {
    id: 'tut_09_elements',
    type: TUTORIAL_TYPE.INFO,
    title: '【五行印记 · 全解】',
    text1: '五行各有印记引爆之效：金印破甲真伤、木印恢复气血、水印冻结敌人、火印伤害翻倍、土印获得护盾。',
    text2: '合理搭配同属性卡牌，频繁触发印记引爆，是克敌制胜的关键！',
    highlight: null
  },
  {
    id: 'tut_09b_builds',
    type: TUTORIAL_TYPE.INFO,
    title: '【流派构筑 · 五行道统】',
    text1: '持续使用同属性卡牌可激活专属【流派】，获得强力增益！',
    text2: '金→锋锐流（破甲暴击）、火→烈煞流（烈焰爆发）、水→寒渊流（冻结抽牌）、木→青藤流（治疗续航）、土→磐石流（护盾反伤）。',
    highlight: null
  },
  {
    id: 'tut_09c_blade',
    type: TUTORIAL_TYPE.INFO,
    title: '【锋锐流 · 金之道统】',
    text1: '你手中的御剑术和金钟罩都是金系卡牌！',
    text2: '累积金印引爆即可激活【锋锐流】：破甲无视护盾、高等级暴击双倍伤害，一剑破万法！',
    highlight: null
  },
  {
    id: 'tut_10_play_shield',
    type: TUTORIAL_TYPE.ACTION,
    title: '【运转护盾】',
    text1: '现在打出【金钟罩】，获得12点护盾防身。',
    text2: '这是第2张金系卡牌，金印累积至2层将触发引爆，并激活【锋锐流】！',
    actionId: 'play_card',
    actionHint: '→ 请打出【金钟罩】',
    highlight: (w, h) => {
      const p = getTutorialCardPos(w, h, 0, 1);
      return { x: p.x - 4, y: p.y - 4, w: p.w + 8, h: p.h + 8 };
    }
  },
  {
    id: 'tut_10b_build_longpress',
    type: TUTORIAL_TYPE.INFO,
    title: '【流派详情 · 长按查看】',
    text1: '看到状态栏上方的【锋锐流 Lv1】标签了吗？',
    text2: '长按流派标签可查看详细效果与升级增益，随时掌握你的道统进度！',
    highlight: (w, h) => ({
      x: 8,
      y: h - 286,
      w: 160,
      h: 28
    })
  },
  {
    id: 'tut_11_end_turn',
    type: TUTORIAL_TYPE.ACTION,
    title: '【结印 · 结束回合】',
    text1: '灵气已尽，点击底部【结束回合】按钮。',
    text2: '随后桃木傀儡便会发难，看看你的护盾能否挡住它的攻击！',
    actionId: 'end_turn',
    actionHint: '→ 请点击「结束回合」',
    highlight: (w, h) => ({
      x: 12,
      y: h - 52,
      w: w - 24,
      h: 46
    })
  },
  {
    id: 'tut_12_done',
    type: TUTORIAL_TYPE.INFO,
    title: '【道法初成】',
    text1: '基础法门已传授完毕：卡牌、灵气、护盾、五行相克、印记引爆、流派构筑。',
    text2: '接下来便踏入真正的妖域，手持五行符箓，荡尽这世间妖邪！',
    highlight: null
  }
];
