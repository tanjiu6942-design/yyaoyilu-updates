/**
 * TutorialManager —— 新手引导系统核心状态机
 *
 * 设计原则：
 * 1. contextual（情境触发）：进入对应场景时自动检查未完成步骤
 * 2. 数据驱动：所有步骤配置在 steps.js 中，逻辑与数据分离
 * 3. 三种交互类型：info（点击继续）/ highlight（高亮+点击）/ action（必须执行指定操作）
 * 4. 细粒度持久化：每个步骤独立标记完成，而非一个全局 done 标志
 * 5. 可跳过：跳过当前引导组，但未触发的新系统仍会在首次遇到时提示
 */

import { getTutorialProgress, saveTutorialProgress } from '../../config/storage.js';

// 引导步骤类型
export const TUTORIAL_TYPE = {
  INFO: 'info',           // 纯信息，点击任意处继续
  HIGHLIGHT: 'highlight', // 高亮指定区域 + 点击继续
  ACTION: 'action'        // 必须执行指定操作（由场景调用 completeAction）才能继续
};

class TutorialManagerImpl {
  constructor() {
    this.progress = this.loadProgress();
    this.currentScene = null;
    this.currentStepIndex = -1;
    this.currentSteps = [];
    this.isActive = false;
    this.onStepChange = null;    // 步骤变化回调（场景用于重建 UI）
    this.onComplete = null;      // 当前场景引导全部完成回调
    this._actionLock = false;    // action 类型步骤的操作锁
  }

  // ==================== 持久化 ====================

  loadProgress() {
    const saved = getTutorialProgress();
    return saved && typeof saved === 'object' ? saved : {};
  }

  saveProgress() {
    saveTutorialProgress(this.progress);
  }

  isStepDone(stepId) {
    return this.progress[stepId] === true;
  }

  markStepDone(stepId) {
    this.progress[stepId] = true;
    this.saveProgress();
  }

  // 重置全部引导进度（用于"重玩教程"）
  resetAll() {
    this.progress = {};
    this.saveProgress();
    this.isActive = false;
    this.currentStepIndex = -1;
    this.currentSteps = [];
  }

  // 重置某个场景的引导
  resetScene(sceneName) {
    Object.keys(this.progress).forEach(key => {
      if (key.startsWith(sceneName + '_')) delete this.progress[key];
    });
    this.saveProgress();
  }

  // ==================== 场景进入/退出 ====================

  /**
   * 进入场景时调用，自动检查是否有未完成的引导步骤
   * @param {string} sceneName - 场景名（menu/map/battle/shop/event/rest）
   * @param {Array} steps - 该场景的引导步骤配置数组
   * @param {Object} callbacks - { onStepChange, onComplete }
   * @returns {boolean} 是否激活了引导
   */
  enterScene(sceneName, steps, callbacks = {}) {
    this.currentScene = sceneName;
    this.onStepChange = callbacks.onStepChange || null;
    this.onComplete = callbacks.onComplete || null;

    // 过滤出未完成的步骤
    const pendingSteps = (steps || []).filter(s => !this.isStepDone(s.id));

    if (pendingSteps.length === 0) {
      this.isActive = false;
      this.currentSteps = [];
      this.currentStepIndex = -1;
      return false;
    }

    this.currentSteps = pendingSteps;
    this.currentStepIndex = 0;
    this.isActive = true;
    this._actionLock = false;

    if (this.onStepChange) this.onStepChange(this.getCurrentStep());
    return true;
  }

  exitScene() {
    this.isActive = false;
    this.currentScene = null;
    this.currentSteps = [];
    this.currentStepIndex = -1;
    this.onStepChange = null;
    this.onComplete = null;
    this._actionLock = false;
  }

  // ==================== 步骤推进 ====================

  getCurrentStep() {
    if (!this.isActive || this.currentStepIndex < 0 || this.currentStepIndex >= this.currentSteps.length) {
      return null;
    }
    return this.currentSteps[this.currentStepIndex];
  }

  /**
   * 玩家点击屏幕（info/highlight 类型步骤用此推进）
   * @returns {boolean} 是否成功推进
   */
  advance() {
    if (!this.isActive) return false;
    const step = this.getCurrentStep();
    if (!step) return false;

    // action 类型步骤不允许点击推进，必须执行指定操作
    if (step.type === TUTORIAL_TYPE.ACTION && !this._actionLock) {
      return false;
    }

    return this._goNext();
  }

  /**
   * 场景中玩家执行了某个操作，调用此方法完成 action 类型步骤
   * @param {string} actionId - 操作标识，需与步骤的 actionId 匹配
   * @returns {boolean} 是否匹配并完成了当前步骤
   */
  completeAction(actionId) {
    if (!this.isActive) return false;
    const step = this.getCurrentStep();
    if (!step || step.type !== TUTORIAL_TYPE.ACTION) return false;
    if (step.actionId !== actionId) return false;

    this._actionLock = true;
    return this._goNext();
  }

  _goNext() {
    const step = this.getCurrentStep();
    if (!step) return false;

    // 标记当前步骤完成
    this.markStepDone(step.id);
    this._actionLock = false;

    this.currentStepIndex++;

    if (this.currentStepIndex >= this.currentSteps.length) {
      // 全部完成
      this.isActive = false;
      const cb = this.onComplete;
      this.onComplete = null;
      if (cb) cb();
      return true;
    }

    if (this.onStepChange) this.onStepChange(this.getCurrentStep());
    return true;
  }

  /**
   * 跳过当前场景剩余的所有引导步骤
   */
  skipAll() {
    if (!this.isActive) return;
    // 标记当前场景所有剩余步骤为完成
    for (let i = this.currentStepIndex; i < this.currentSteps.length; i++) {
      this.markStepDone(this.currentSteps[i].id);
    }
    this.isActive = false;
    const cb = this.onComplete;
    this.onComplete = null;
    if (cb) cb();
  }

  // ==================== 工具方法 ====================

  /**
   * 检查某个场景是否还有未完成的引导
   */
  hasPendingSteps(sceneName, steps) {
    return (steps || []).some(s => !this.isStepDone(s.id));
  }

  /**
   * 手动触发一个单步提示（用于 contextual 提示，如首次收到诅咒卡）
   * 不进入完整引导流程，只显示一次信息
   */
  showOneShot(stepId, stepConfig) {
    if (this.isStepDone(stepId)) return false;
    this.markStepDone(stepId);
    return stepConfig; // 由场景自行渲染
  }
}

// 单例
export const TutorialManager = new TutorialManagerImpl();
export default TutorialManager;
