import { 
  SCREEN_WIDTH, SCREEN_HEIGHT, SAFE_TOP, TOP_BAR_Y, TOP_BAR_H, CAPSULE_LEFT 
} from '../../render.js';
import { 
  drawParchmentBackground, drawScrollPanel, drawSealButton, drawRoundedRect, 
  drawTextCentered, drawTextLeft, drawTextRight, measureText, createButton, drawElementBadge, 
  getElementColor, UI_COLORS 
} from '../scene.js';
import { SPECIAL_SHOP_CARDS, CARD_TEMPLATES, getUpgradedCard, getCleanBaseName } from '../data.js';
import { RELIC_TEMPLATES, generateCardId, CHARACTERS } from '../types.js';
import { stepToNode } from '../map.js';
import { soundManager } from '../../runtime/music.js';
import { TutorialManager, renderTutorial, isSkipButtonTapped, SHOP_STEPS } from '../tutorial/index.js';
import { ECONOMY } from '../../config/constants.js';
import { runManager } from '../RunManager.js';
import { KarmaSystem } from '../systems/KarmaSystem.js';

const AFFORDABLE_BTN_COLOR = '#5C3A21';   
const UNAFFORDABLE_BTN_COLOR = '#9E2F24'; 

// ==================== 山路货郎 · 瞎眼柳半仙剧情对话 ====================
const SHOPKEEPER_DIALOGUES = [
  {
    speaker: '货郎 · 柳半仙',
    tag: '贾',
    side: 'right',
    avatarColor: '#8C6212',
    text: '“叮咚……叮咚……活人的铜钱，死人的冥币，在老瞎子眼里都是一个味道。”'
  },
  {
    speaker: '货郎 · 柳半仙',
    tag: '贾',
    side: 'right',
    avatarColor: '#8C6212',
    text: '“客官，您身上的道袍沾满了黑风山的死人血……要不要来一张咱这祖传的【净心咒】？包管洗得干干净净，连阎王爷都闻不出您的生人味儿！”'
  },
  {
    speaker: '货郎 · 柳半仙',
    tag: '贾',
    side: 'right',
    avatarColor: '#8C6212',
    text: '“嘿嘿，若是不嫌弃，老瞎子这口八卦炉还能帮您‘碎符化灵’……这符箓啊，多了是累赘，精纯才是大道！”'
  }
];

// ==================== 墨金重工华彩古典纹理引擎 ====================
function drawInkGoldScrollModal(ctx, x, y, w, h, isDialogue = false) {
  ctx.save();
  ctx.shadowColor = 'rgba(212, 175, 55, 0.22)';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 10;
  drawRoundedRect(ctx, x, y, w, h, 14, '#1A0E08', '#0D0704', 3);
  ctx.restore();

  const goldGrad = ctx.createLinearGradient(x, y, x + w, y + h);
  goldGrad.addColorStop(0, '#E6C875');
  goldGrad.addColorStop(0.25, '#FFF6C2');
  goldGrad.addColorStop(0.5, '#C49838');
  goldGrad.addColorStop(0.75, '#FCE38A');
  goldGrad.addColorStop(1, '#8C6018');
  drawRoundedRect(ctx, x + 2, y + 2, w - 4, h - 4, 12, null, goldGrad, 2);

  const paperGrad = ctx.createRadialGradient(
    x + w / 2, y + h * 0.45, w * 0.15,
    x + w / 2, y + h * 0.5, w * 0.85
  );
  paperGrad.addColorStop(0, '#FFFDF8');
  paperGrad.addColorStop(0.35, '#F9EED9');
  paperGrad.addColorStop(0.75, '#EBD5AD');
  paperGrad.addColorStop(1, '#CFA968');
  drawRoundedRect(ctx, x + 5, y + 5, w - 10, h - 10, 10, paperGrad, '#8F6126', 1.5);

  const innerMargin = 12;
  const ix = x + innerMargin;
  const iy = y + innerMargin;
  const iw = w - innerMargin * 2;
  const ih = h - innerMargin * 2;

  ctx.save();
  ctx.strokeStyle = 'rgba(150, 42, 31, 0.35)';
  ctx.lineWidth = 1;
  ctx.strokeRect(ix, iy, iw, ih);

  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 1.2;
  ctx.strokeRect(ix + 3, iy + 3, iw - 6, ih - 6);

  const drawRoyalCorner = (cx, cy, dirX, dirY) => {
    ctx.save();
    ctx.strokeStyle = '#C99A3A';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(cx, cy + dirY * 18);
    ctx.lineTo(cx, cy);
    ctx.lineTo(cx + dirX * 18, cy);
    ctx.stroke();

    ctx.fillStyle = '#962A1F';
    ctx.beginPath();
    ctx.arc(cx + dirX * 7, cy + dirY * 7, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  drawRoyalCorner(ix + 5, iy + 5, 1, 1);
  drawRoyalCorner(ix + iw - 5, iy + 5, -1, 1);
  drawRoyalCorner(ix + 5, iy + ih - 5, 1, -1);
  drawRoyalCorner(ix + iw - 5, iy + ih - 5, -1, -1);
  ctx.restore();
}

function getWrappedLines(ctx, text, maxWidth, fontSize) {
  ctx.font = `${fontSize}px "Songti SC", "SimSun", "STSong", serif`;
  const str = text ? String(text) : '';
  if (!str) return [];
  const lines = [];
  let line = '';
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    const testLine = line + char;
    if (ctx.measureText(testLine).width > maxWidth && line !== '') {
      lines.push(line);
      line = char;
    } else {
      line = testLine;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function wrapDetailText(ctx, text, x, y, maxWidth, lineHeight, color, fontSize) {
  ctx.font = `500 ${fontSize}px "Songti SC", "SimSun", "STSong", serif`; 
  ctx.fillStyle = color || '#120904'; 
  ctx.textAlign = 'left'; 
  ctx.textBaseline = 'top';
  const lines = getWrappedLines(ctx, text, maxWidth, fontSize);
  lines.forEach((l, idx) => {
    ctx.fillText(l, x, y + idx * lineHeight);
  });
}

export function createShopScene(manager) {
  return {
    manager, 
    runState: null, 
    tab: 'cards', 
    buttons: [], 
    shopCards: [], 
    shopRelics: [], 
    showLeaveModal: false, 
    showBag: false, 
    suppressNextTap: false,
    refreshCount: 0, 
    furnaceSubTab: 'craft',
    shopScrollY: 0, 
    isDragging: false, 
    touchStartY: 0, 
    lastTouchY: 0, 
    contentHeight: 0, 
    hasBoundTouch: false,
    furnaceItems: [],
    karmaSystem: new KarmaSystem(runManager),

    isDialogueActive: false,
    dialogueQueue: [],
    dialogueIndex: 0,
    dialogueOnComplete: null,

    bagScrollY: 0,
    isDraggingBag: false,
    bagTouchStartY: 0,
    bagLastTouchY: 0,
    bagContentHeight: 0,

    startDialogue(dialogueList, onComplete = null) {
      if (!dialogueList || dialogueList.length === 0) {
        if (onComplete) onComplete();
        return;
      }
      this.dialogueQueue = dialogueList;
      this.dialogueIndex = 0;
      this.isDialogueActive = true;
      this.dialogueOnComplete = onComplete;
      this.buildUI();
    },

    advanceDialogue() {
      if (!this.isDialogueActive) return;
      this.dialogueIndex++;
      if (this.dialogueIndex >= this.dialogueQueue.length) {
        this.isDialogueActive = false;
        const cb = this.dialogueOnComplete;
        this.dialogueOnComplete = null;
        if (cb) cb();
      }
      this.buildUI();
    },

    enter(data) {
      soundManager.stopAllSfx();
      soundManager.playBgm('shop');

      if (data?.runState) runManager.setState(data.runState);
      else runManager.load();
      this.runState = runManager.state;
      this.tab = 'cards'; 
      this.furnaceSubTab = 'craft'; 
      this.showLeaveModal = false; 
      this.showBag = false; 
      this.suppressNextTap = false;
      this.shopScrollY = 0; 
      this.bagScrollY = 0;
      this.refreshCount = 0;
      this.isDialogueActive = false;

      this.initShopGoods();
      this.initShopTouchListeners();

      this.startDialogue(SHOPKEEPER_DIALOGUES, () => {
        // 已移除商店新手引导
        // this._startShopTutorialIfNeeded();
      });
      this.buildUI();
    },

    _startShopTutorialIfNeeded() {
      const activated = TutorialManager.enterScene('shop', SHOP_STEPS, {
        onStepChange: () => { this.buildUI(); },
        onComplete: () => { this.buildUI(); }
      });
      if (activated) this.buildUI();
    },

    getRefreshCost() {
      return ECONOMY.REFRESH_COST_BASE + (this.refreshCount || 0) * ECONOMY.REFRESH_COST_INCREMENT;
    },

    initShopGoods() {
      const ownedCards = this.runState?.allCards || [];
      const ownedBaseCardNames = new Set(ownedCards.map(c => getCleanBaseName(c.name)));

      let availableSpecialCards = SPECIAL_SHOP_CARDS.filter(c => !ownedBaseCardNames.has(getCleanBaseName(c.name)));

      // ★ 因果系统：过滤卡牌商品池
      availableSpecialCards = this.karmaSystem.filterCardPool(availableSpecialCards);

      let shuffledSpecial = [...availableSpecialCards].sort(() => 0.5 - Math.random());
      let pickedCards = shuffledSpecial.slice(0, 3);

      if (pickedCards.length < 3) {
        const fallbackCards = CARD_TEMPLATES.map(c => getUpgradedCard(c)).filter(c => !ownedBaseCardNames.has(getCleanBaseName(c.name)) && c.name !== '净心咒');
        const shuffledFallback = [...fallbackCards].sort(() => 0.5 - Math.random());
        const needed = 3 - pickedCards.length;
        const extraCards = shuffledFallback.slice(0, needed).map(c => ({
          ...c,
          price: ECONOMY.SHOP_FALLBACK_CARD_PRICE
        }));
        pickedCards = pickedCards.concat(extraCards);
      }

      const randomShopCards = pickedCards.map(c => {
        // ★ 因果系统：调整价格并标记锁定状态
        const adjustedPrice = this.karmaSystem.adjustPrice(c.price || ECONOMY.SHOP_FALLBACK_CARD_PRICE);
        const isLocked = this.karmaSystem.isCardLocked(c);
        return {
          ...c,
          id: generateCardId(),
          price: adjustedPrice,
          basePrice: c.price,
          bought: false,
          locked: isLocked
        };
      });

      const jingxinTpl = CARD_TEMPLATES.find(c => c.name === '净心咒') || {
        name: "净心咒", type: "符咒", element: "水", cost: 1, value: 0, star: 0,
        description: "清除负面状态与诅咒，获得3点护盾", effectType: "clear_debuff"
      };

      const permanentJingxin = {
        ...jingxinTpl,
        id: generateCardId(),
        price: this.karmaSystem.adjustPrice(ECONOMY.SHOP_PERMANENT_JINGXIN_PRICE),
        basePrice: ECONOMY.SHOP_PERMANENT_JINGXIN_PRICE,
        bought: false,
        isPermanentSupply: true,
        locked: this.karmaSystem.isCardLocked(jingxinTpl)
      };

      this.shopCards = [permanentJingxin, ...randomShopCards];

      const ownedRelicIds = (this.runState?.relics || []).map(r => r.id);
      let availableRelics = RELIC_TEMPLATES.filter(r => !ownedRelicIds.includes(r.id));

      // ★ 因果系统：过滤遗物商品池
      availableRelics = this.karmaSystem.filterRelicPool(availableRelics);

      const shuffledRelics = [...availableRelics].sort(() => 0.5 - Math.random());
      this.shopRelics = shuffledRelics.slice(0, 2).map(r => {
        const basePrice = (ECONOMY.SHOP_RELIC_PRICES && ECONOMY.SHOP_RELIC_PRICES[r.rarity]) || ECONOMY.SHOP_RELIC_PRICES['普通'];
        return {
          ...r,
          price: this.karmaSystem.adjustPrice(basePrice),
          basePrice: basePrice,
          bought: false,
          locked: this.karmaSystem.isRelicLocked(r)
        };
      });
    },

    refreshShopGoods() {
      const cost = this.getRefreshCost();
      const currentGold = this.runState?.gold || 0;

      if (currentGold < cost) {
        soundManager.playSfx('btn_click');
        wx.showToast({ title: `铜钱不足(需${cost}铜)`, icon: 'none' });
        return;
      }

      this.runState.gold -= cost;
      this.refreshCount = (this.refreshCount || 0) + 1;
      this.initShopGoods();
      runManager.save();
      soundManager.playSfx('coin');
      wx.showToast({ title: '已换一批货物', icon: 'success' });
      this.buildUI();
    },

    clampBagScroll() {
      const height = this.manager.height;
      const panelH = Math.min(480, height - 80);
      const viewportH = panelH - 80;
      if (this.bagContentHeight <= viewportH) {
        this.bagScrollY = 0;
        return;
      }
      const minScroll = viewportH - this.bagContentHeight;
      this.bagScrollY = Math.max(minScroll, Math.min(0, this.bagScrollY));
    },

    initShopTouchListeners() {
      if (this.hasBoundTouch) return;
      this.hasBoundTouch = true;
      
      wx.onTouchStart((e) => {
        if (this.manager.getCurrentSceneName() !== 'shop') return;
        if (!e.touches || e.touches.length === 0) return;
        const touch = e.touches[0];

        if (this.isDialogueActive) return;

        if (this.showBag) {
          this.isDraggingBag = true;
          this.bagTouchStartY = touch.clientY;
          this.bagLastTouchY = touch.clientY;
          return;
        }

        if (this.showLeaveModal) return;
        const scrollMarginTop = SAFE_TOP + 74;
        if (touch.clientY > scrollMarginTop) {
          this.isDragging = true;
          this.lastTouchY = touch.clientY;
          this.touchStartY = touch.clientY;
        }
      });

      wx.onTouchMove((e) => {
        if (!e.touches || e.touches.length === 0) return;
        const touch = e.touches[0];

        if (this.isDialogueActive) return;

        if (this.showBag && this.isDraggingBag) {
          const dy = touch.clientY - this.bagLastTouchY;
          this.bagLastTouchY = touch.clientY;
          this.bagScrollY += dy;
          this.clampBagScroll();
          return;
        }

        if (!this.isDragging || this.showLeaveModal) return;
        const dy = touch.clientY - this.lastTouchY;
        this.lastTouchY = touch.clientY;
        this.shopScrollY += dy;
        this.clampScroll();
        this.updateButtonPositions();
      });

      const endDrag = () => {
        if (this.isDraggingBag) {
          this.isDraggingBag = false;
          this.clampBagScroll();
        }
        this.isDragging = false;
        this.clampScroll();
        this.updateButtonPositions();
      };
      wx.onTouchEnd(endDrag);
      wx.onTouchCancel(endDrag);
    },

    clampScroll() {
      const { height } = this.manager;
      const scrollMarginTop = SAFE_TOP + 74;
      const viewportH = height - scrollMarginTop - 16;
      if (this.contentHeight <= viewportH) { 
        this.shopScrollY = 0; 
        return; 
      }
      const minScroll = viewportH - this.contentHeight;
      this.shopScrollY = Math.max(minScroll, Math.min(0, this.shopScrollY));
    },

    updateButtonPositions() {
      this.buttons.forEach(btn => {
        if (btn.isScrollable && btn.baseY !== undefined) {
          btn.y = btn.baseY + this.shopScrollY;
        }
      });
    },

    buildUI() {
      const { width, height } = this.manager;
      this.manager.input.clearButtons();
      this.buttons = [];

      if (this.isDialogueActive) {
        this.manager.input.addTapHandler(() => {
          soundManager.playSfx('btn_click');
          this.advanceDialogue();
        });
        return;
      }

      if (this.showLeaveModal) { this.buildLeaveModalUI(); return; }

      if (this.showBag) {
        this.manager.input.addTapHandler((x, y) => {
          if (!this.showBag) return;
          if (Math.abs(y - this.bagTouchStartY) > 12) return;
          soundManager.playSfx('btn_click');
          this.showBag = false;
          this.buildUI();
        });
        return;
      }

      this._tutorialBlockTaps = false;
      if (TutorialManager.isActive) {
        const step = TutorialManager.getCurrentStep();
        this.manager.input.addTapHandler((x, y) => {
          if (isSkipButtonTapped(x, y, width)) {
            TutorialManager.skipAll();
            this.buildUI();
          }
        });
        if (!step || step.type !== 'action') {
          this._tutorialBlockTaps = true;
        }
      }

      this.buttons.push(createButton(12, TOP_BAR_Y, 52, TOP_BAR_H, '离店', { 
        fontSize: 13, 
        tap: () => {
          soundManager.playSfx('btn_click');
          this.onLeaveShop();
        }, 
        color: UI_COLORS.inkSoft, 
        textColor: '#F4E5C0' 
      }));

      this.buttons.push(createButton(68, TOP_BAR_Y, 52, TOP_BAR_H, '锦囊', { 
        fontSize: 13, 
        tap: () => { 
          soundManager.playSfx('btn_click');
          this.showBag = true; 
          this.bagScrollY = 0;
          this.buildUI(); 
        }, 
        color: UI_COLORS.cinnabar, 
        textColor: '#FFF3CA' 
      }));

      const tabY = SAFE_TOP + 6;
      const tabH = 30;
      const tabW = Math.floor((width - 32 - 12) / 3);

      this.buttons.push(
        createButton(16, tabY, tabW, tabH, '神通阁', { 
          fontSize: 13, 
          color: this.tab === 'cards' ? UI_COLORS.cinnabar : UI_COLORS.inkSoft, 
          textColor: this.tab === 'cards' ? '#FFF3CA' : '#D0C8B8', 
          tap: () => { 
            soundManager.playSfx('btn_click');
            this.tab = 'cards'; 
            this.shopScrollY = 0; 
            this.buildUI(); 
          } 
        }),
        createButton(16 + tabW + 6, tabY, tabW, tabH, '八卦炉', { 
          fontSize: 13, 
          color: this.tab === 'furnace' ? UI_COLORS.cinnabar : UI_COLORS.inkSoft, 
          textColor: this.tab === 'furnace' ? '#FFF3CA' : '#D0C8B8', 
          tap: () => { 
            soundManager.playSfx('btn_click');
            this.tab = 'furnace'; 
            this.shopScrollY = 0; 
            this.buildUI(); 
          } 
        }),
        createButton(16 + (tabW + 6) * 2, tabY, tabW, tabH, '法宝阁', { 
          fontSize: 13, 
          color: this.tab === 'relics' ? UI_COLORS.cinnabar : UI_COLORS.inkSoft, 
          textColor: this.tab === 'relics' ? '#FFF3CA' : '#D0C8B8', 
          tap: () => { 
            soundManager.playSfx('btn_click');
            this.tab = 'relics'; 
            this.shopScrollY = 0; 
            this.buildUI(); 
          } 
        })
      );

      const subBarY = tabY + 36;

      if (this.tab === 'cards' || this.tab === 'relics') {
        const refreshCost = this.getRefreshCost();
        const canAffordRefresh = (this.runState?.gold || 0) >= refreshCost;
        const refreshBtnW = 86;
        const refreshBtnH = 26;

        this.buttons.push(createButton(width - 16 - refreshBtnW, subBarY, refreshBtnW, refreshBtnH, `换货 ${refreshCost}铜`, { 
          fontSize: 12, 
          tap: () => this.refreshShopGoods(), 
          color: canAffordRefresh ? '#2B6B46' : '#5A5148', 
          textColor: canAffordRefresh ? '#FFF8DD' : '#C0B4A0' 
        }));
      } else if (this.tab === 'furnace') {
        const subTabW = Math.floor((width - 32 - 8) / 2);
        const subTabH = 26;

        this.buttons.push(
          createButton(16, subBarY, subTabW, subTabH, '点化与合成', {
            fontSize: 12,
            color: this.furnaceSubTab === 'craft' ? '#8C2A24' : '#4A3728',
            textColor: this.furnaceSubTab === 'craft' ? '#FFF3CA' : '#C0B4A0',
            tap: () => { 
              soundManager.playSfx('btn_click');
              this.furnaceSubTab = 'craft'; 
              this.shopScrollY = 0; 
              this.buildUI(); 
            }
          }),
          createButton(16 + subTabW + 8, subBarY, subTabW, subTabH, '焚符化灵 (碎符)', {
            fontSize: 12,
            color: this.furnaceSubTab === 'burn' ? '#8C2A24' : '#4A3728',
            textColor: this.furnaceSubTab === 'burn' ? '#FFF3CA' : '#C0B4A0',
            tap: () => { 
              soundManager.playSfx('btn_click');
              this.furnaceSubTab = 'burn'; 
              this.shopScrollY = 0; 
              this.buildUI(); 
            }
          })
        );
      }

      if (this.tab === 'cards') this.buildCardsTabUI(); 
      else if (this.tab === 'furnace') this.buildFurnaceTabUI(); 
      else if (this.tab === 'relics') this.buildRelicsTabUI();
      
      if (this._tutorialBlockTaps) {
        this.manager.input.addTapHandler((x, y) => {
          if (isSkipButtonTapped(x, y, width)) return;
          const advanced = TutorialManager.advance();
          if (advanced) {
            soundManager.playSfx('btn_click');
            this.buildUI();
          }
        });
        this._tutorialBlockTaps = false;
      } else {
        this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
      }
      this.clampScroll();
      this.updateButtonPositions();
    },

    onLeaveShop() { this.showLeaveModal = true; this.buildUI(); },

    buildLeaveModalUI() {
      const { width, height } = this.manager; 
      this.manager.input.clearButtons(); 
      this.buttons = [];
      const panelW = Math.min(310, width - 36); 
      const panelH = 210; 
      const panelY = (height - panelH) / 2;
      const btnW = 108; 
      const btnH = 38; 
      const btnY = panelY + panelH - 48;

      const cancelBtn = createButton(width / 2 - btnW - 10, btnY, btnW, btnH, '暂且驻足', { 
        fontSize: 14, color: UI_COLORS.inkSoft, textColor: '#D0C8B8', 
        tap: () => { 
          soundManager.playSfx('btn_click');
          this.showLeaveModal = false; 
          this.buildUI(); 
        } 
      });
      const confirmBtn = createButton(width / 2 + 10, btnY, btnW, btnH, '确定启程', { 
        fontSize: 14, color: UI_COLORS.cinnabar, textColor: '#FFF3CA', 
        tap: () => { 
          soundManager.playSfx('btn_click');
          this.proceedToMap(); 
        } 
      });
      this.buttons = [cancelBtn, confirmBtn]; 
      this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
    },

    proceedToMap() {
      TutorialManager.completeAction('leave_shop');

      this.showLeaveModal = false;
      if (this.runState) {
        if (this.runState.currentNodeId && this.runState.map) this.runState.map = stepToNode(this.runState.map, this.runState.currentNodeId);
        runManager.save();
      }
      this.manager.enterScene('map');
    },

    buildCardsTabUI() {
      const { width } = this.manager; 
      const startY = SAFE_TOP + 80; 
      const cardH = 78; 
      const gap = 12;
      const currentGold = this.runState?.gold || 0;
      this.contentHeight = this.shopCards.length * (cardH + gap) + 16;

      this.shopCards.forEach((card, idx) => {
        if (!card.bought) {
          const isLocked = card.locked;
          const canAfford = !isLocked && currentGold >= card.price;
          const btnColor = isLocked ? '#4A4A4A' : (canAfford ? AFFORDABLE_BTN_COLOR : UNAFFORDABLE_BTN_COLOR);
          const btnText = isLocked ? '禁售' : `${card.price}铜`;

          const btn = createButton(width - 80, startY + idx * (cardH + gap) + 24, 60, 28, btnText, { 
            fontSize: 12, 
            color: btnColor, 
            textColor: isLocked ? '#888' : '#FFF8DD', 
            tap: () => this.buyCard(card) 
          });
          btn.isScrollable = true; 
          btn.baseY = startY + idx * (cardH + gap) + 24;
          this.buttons.push(btn);
        }
      });
    },

    buyCard(card) {
      if (card.bought) return;
      if (card.locked) {
        soundManager.playSfx('btn_click');
        wx.showToast({ title: this.karmaSystem.getLockedReason(), icon: 'none' });
        return;
      }
      if (this.runState.gold < card.price) { 
        soundManager.playSfx('btn_click');
        wx.showToast({ title: '铜钱不足！', icon: 'none' }); 
        return; 
      }
      this.runState.gold -= card.price; 
      card.bought = true;
      
      if (!this.runState.allCards) this.runState.allCards = []; 
      this.runState.allCards.push({ ...card });
      
      runManager.save(); 
      soundManager.playSfx('coin');
      wx.showToast({ title: `购得：${card.name}`, icon: 'success' }); 
      this.buildUI();
    },

    buildRelicsTabUI() {
      const { width } = this.manager; 
      const startY = SAFE_TOP + 80; 
      const cardH = 78; 
      const gap = 14;
      const currentGold = this.runState?.gold || 0;
      
      this.shopRelics.forEach((relic, idx) => {
        if (!relic.bought) {
          const isLocked = relic.locked;
          const canAfford = !isLocked && currentGold >= relic.price;
          const btnColor = isLocked ? '#4A4A4A' : (canAfford ? AFFORDABLE_BTN_COLOR : UNAFFORDABLE_BTN_COLOR);
          const btnText = isLocked ? '禁售' : `${relic.price}铜`;

          const btn = createButton(width - 80, startY + idx * (cardH + gap) + 24, 60, 28, btnText, { 
            fontSize: 12, 
            color: btnColor, 
            textColor: isLocked ? '#888' : '#FFF8DD', 
            tap: () => this.buyRelic(relic) 
          });
          btn.isScrollable = true; 
          btn.baseY = startY + idx * (cardH + gap) + 24;
          this.buttons.push(btn);
        }
      });

      const healY = startY + this.shopRelics.length * (cardH + gap) + 6;
      this.contentHeight = healY - (SAFE_TOP + 74) + 64 + 20;

      const canAffordHeal = currentGold >= ECONOMY.HEAL_COST;
      const healBtnColor = canAffordHeal ? AFFORDABLE_BTN_COLOR : UNAFFORDABLE_BTN_COLOR;

      const healBtn = createButton(width - 80, healY + 18, 60, 28, `${ECONOMY.HEAL_COST}铜`, { 
        fontSize: 12, 
        color: healBtnColor, 
        textColor: '#FFF8DD', 
        tap: () => this.buyHeal() 
      });
      healBtn.isScrollable = true; 
      healBtn.baseY = healY + 18;
      this.buttons.push(healBtn);
    },

    buyRelic(relic) {
      if (relic.bought) return;
      if (relic.locked) {
        soundManager.playSfx('btn_click');
        wx.showToast({ title: this.karmaSystem.getLockedReason(), icon: 'none' });
        return;
      }
      if (this.runState.gold < relic.price) { 
        soundManager.playSfx('btn_click');
        wx.showToast({ title: '铜钱不足！', icon: 'none' }); 
        return; 
      }
      this.runState.gold -= relic.price; 
      relic.bought = true;
      
      const addResult = runManager.addRelic(relic);
      if (!addResult.success) {
        // 回退金币
        this.runState.gold += relic.price;
        relic.bought = false;
        soundManager.playSfx('btn_click');
        wx.showToast({ title: addResult.reason, icon: 'none' });
        this.buildUI();
        return;
      }
      
      soundManager.playSfx('coin');
      wx.showToast({ title: `收纳法宝：${relic.name}`, icon: 'success' }); 
      this.buildUI();
    },

    buyHeal() {
      if (this.runState.gold < ECONOMY.HEAL_COST) { 
        soundManager.playSfx('btn_click');
        wx.showToast({ title: `铜钱不足（需${ECONOMY.HEAL_COST}铜）`, icon: 'none' }); 
        return; 
      }
      if (this.runState.hp >= this.runState.maxHp) { 
        soundManager.playSfx('btn_click');
        wx.showToast({ title: '气血充盈无需调理', icon: 'none' }); 
        return; 
      }
      this.runState.gold -= ECONOMY.HEAL_COST; 
      this.runState.hp = Math.min(this.runState.maxHp, this.runState.hp + ECONOMY.HEAL_HP_AMOUNT);
      runManager.save(); 
      soundManager.playSfx('heal');
      wx.showToast({ title: `气血 +${ECONOMY.HEAL_HP_AMOUNT}`, icon: 'success' }); 
      this.buildUI();
    },

    buildFurnaceTabUI() {
      const { width } = this.manager; 
      const allCards = this.runState.allCards || [];
      const currentGold = this.runState?.gold || 0;

      if (this.furnaceSubTab === 'craft') {
        const cardGroups = {};
        allCards.forEach((c) => {
          const star = c.star !== undefined ? c.star : (c.isUpgraded ? 1 : 0);
          if (star < 2) {
            const baseName = getCleanBaseName(c.name);
            const key = `${baseName}__${star}`;
            if (!cardGroups[key]) {
              cardGroups[key] = { baseName, star, count: 0, sampleCard: c };
            }
            cardGroups[key].count++;
          }
        });

        this.furnaceItems = [];

        Object.values(cardGroups).forEach(group => {
          if (group.count >= 2) {
            const nextCard = getUpgradedCard(group.sampleCard);
            const nextStarDesc = nextCard.star === 2 ? '★★ 二星·极' : '★ 一星';
            const price = group.star === 0 ? ECONOMY.SYNTHESIZE_COST.STAR_0_TO_1 : ECONOMY.SYNTHESIZE_COST.STAR_1_TO_2;
            this.furnaceItems.push({
              type: 'combine',
              name: group.baseName,
              star: group.star,
              card: group.sampleCard,
              price: price,
              title: group.star === 0 ? `二合一：${group.baseName} ★` : `二合一：${group.baseName} ★★极`,
              desc: `【合为${nextStarDesc}】${nextCard.description || nextCard.desc || ''}`
            });
          }
        });

        Object.values(cardGroups).forEach(group => {
          const nextCard = getUpgradedCard(group.sampleCard);
          const nextStarDesc = nextCard.star === 2 ? '★★ 二星·极' : '★ 一星';
          const price = group.star === 0 ? ECONOMY.ENLIGHTEN_COST.STAR_0_TO_1 : ECONOMY.ENLIGHTEN_COST.STAR_1_TO_2;
          this.furnaceItems.push({
            type: 'upgrade',
            name: group.baseName,
            star: group.star,
            card: group.sampleCard,
            price: price,
            title: group.star === 0 ? `点化：${group.baseName} ★` : `极品点化：${group.baseName} ★★极`,
            desc: `【点化为${nextStarDesc}】${nextCard.description || nextCard.desc || ''}`
          });
        });

        const startY = SAFE_TOP + 80; 
        const itemH = 78; 
        const gap = 12;
        this.contentHeight = this.furnaceItems.length * (itemH + gap) + 16;

        this.furnaceItems.forEach((item, idx) => {
          const baseY = startY + idx * (itemH + gap);
          const canAfford = currentGold >= item.price;
          const btnColor = canAfford ? AFFORDABLE_BTN_COLOR : UNAFFORDABLE_BTN_COLOR;

          const btn = createButton(width - 74, baseY + 25, 54, 28, `${item.price}铜`, {
            fontSize: 12, color: btnColor, textColor: '#FFF8DD',
            tap: () => {
              if (Math.abs(this.touchStartY - this.lastTouchY) > 6) return;
              if (item.type === 'combine') {
                this.combineCardsByNameAndStar(item.name, item.star);
              } else {
                this.upgradeCardByNameAndStar(item.name, item.star);
              }
            }
          });
          btn.isScrollable = true;
          btn.baseY = baseY + 25;
          this.buttons.push(btn);
        });
      } else {
        const startY = SAFE_TOP + 80; 
        const itemH = 74; 
        const gap = 10;
        this.contentHeight = allCards.length * (itemH + gap) + 16;

        allCards.forEach((card, idx) => {
          const baseY = startY + idx * (itemH + gap);
          const canAfford = currentGold >= ECONOMY.PURGE_CARD_COST;
          const btnColor = canAfford ? AFFORDABLE_BTN_COLOR : UNAFFORDABLE_BTN_COLOR;

          const btn = createButton(width - 74, baseY + 22, 52, 28, `${ECONOMY.PURGE_CARD_COST}铜`, {
            fontSize: 12, color: btnColor, textColor: '#FFF8DD',
            tap: () => {
              if (Math.abs(this.touchStartY - this.lastTouchY) > 6) return;
              this.burnCard(idx);
            }
          });
          btn.isScrollable = true;
          btn.baseY = baseY + 22;
          this.buttons.push(btn);
        });
      }
    },

    burnCard(cardIndex) {
      const allCards = this.runState.allCards || [];
      if (allCards.length <= ECONOMY.MIN_DECK_LIMIT_FOR_PURGE) {
        soundManager.playSfx('btn_click');
        wx.showToast({ title: `牌藏过少(至少保留${ECONOMY.MIN_DECK_LIMIT_FOR_PURGE}张)`, icon: 'none' });
        return;
      }
      const BURN_COST = ECONOMY.PURGE_CARD_COST;
      if (this.runState.gold < BURN_COST) {
        soundManager.playSfx('btn_click');
        wx.showToast({ title: `铜钱不足(需${BURN_COST}铜)`, icon: 'none' });
        return;
      }
      const targetCard = allCards[cardIndex];
      if (!targetCard) return;

      this.runState.gold -= BURN_COST;
      allCards.splice(cardIndex, 1);
      runManager.save();
      soundManager.playSfx('coin');
      wx.showToast({ title: `已焚除：${targetCard.name}`, icon: 'success' });
      this.buildUI();
    },

    combineCardsByNameAndStar(baseName, star) {
      const price = star === 0 ? ECONOMY.SYNTHESIZE_COST.STAR_0_TO_1 : ECONOMY.SYNTHESIZE_COST.STAR_1_TO_2;
      if (this.runState.gold < price) { 
        soundManager.playSfx('btn_click');
        wx.showToast({ title: `铜钱不足（需${price}铜）`, icon: 'none' }); 
        return; 
      }
      const allCards = this.runState.allCards || []; 
      const matchIndices = [];
      allCards.forEach((c, idx) => {
        const cStar = c.star !== undefined ? c.star : (c.isUpgraded ? 1 : 0);
        const cName = getCleanBaseName(c.name);
        if (cName === baseName && cStar === star && matchIndices.length < 2) {
          matchIndices.push(idx);
        }
      });
      if (matchIndices.length < 2) return;

      this.runState.gold -= price; 
      const upgraded = getUpgradedCard(allCards[matchIndices[0]]);
      allCards.splice(matchIndices[1], 1); 
      allCards.splice(matchIndices[0], 1); 
      allCards.push(upgraded);
      runManager.save(); 
      soundManager.playSfx('coin');
      const starTag = upgraded.star === 2 ? '【二星·极】' : '【一星】';
      wx.showToast({ title: `合卡成功: ${starTag}${upgraded.name}`, icon: 'success' }); 
      this.buildUI();
    },

    upgradeCardByNameAndStar(baseName, star) {
      const price = star === 0 ? ECONOMY.ENLIGHTEN_COST.STAR_0_TO_1 : ECONOMY.ENLIGHTEN_COST.STAR_1_TO_2;
      if (this.runState.gold < price) { 
        soundManager.playSfx('btn_click');
        wx.showToast({ title: `铜钱不足（需${price}铜）`, icon: 'none' }); 
        return; 
      }
      const allCards = this.runState.allCards || [];
      const idx = allCards.findIndex(c => {
        const cStar = c.star !== undefined ? c.star : (c.isUpgraded ? 1 : 0);
        const cName = getCleanBaseName(c.name);
        return cName === baseName && cStar === star;
      });
      if (idx !== -1) {
        this.runState.gold -= price; 
        allCards[idx] = getUpgradedCard(allCards[idx]);
        runManager.save(); 
        soundManager.playSfx('coin');
        const starTag = allCards[idx].star === 2 ? '【二星·极】' : '【一星】';
        wx.showToast({ title: `点化成功: ${starTag}${allCards[idx].name}`, icon: 'success' }); 
        this.buildUI();
      }
    },

    render(ctx) {
      const { width, height } = this.manager; 
      ctx.clearRect(0, 0, width, height); 
      drawParchmentBackground(ctx, width, height);
      
      if (!this.runState) return;

      const titleX = 126;
      const barMidY = TOP_BAR_Y + TOP_BAR_H / 2;
      drawTextLeft(ctx, '【山路货郎】', titleX, barMidY, UI_COLORS.ink, 13, 'serif');

      const titleW = measureText(ctx, '【山路货郎】', 13);
      const goldStr = `${this.runState.gold}`;
      const numW = measureText(ctx, goldStr, 12);
      const coinCardW = Math.max(56, numW + 34);
      const coinCardH = 22;
      const coinCardX = titleX + titleW + 4;
      const coinCardY = barMidY - coinCardH / 2;

      drawRoundedRect(ctx, coinCardX, coinCardY, coinCardW, coinCardH, 11, 'rgba(244, 230, 215, 0.95)', 'rgba(184, 134, 11, 0.55)', 1.2);
      drawRoundedRect(ctx, coinCardX + 2, coinCardY + 2, 18, 18, 9, '#9A731F', '#FFE599', 1);
      drawTextCentered(ctx, '铜', coinCardX + 11, coinCardY + 11, '#FFF8DD', 10, 'serif');
      drawTextLeft(ctx, goldStr, coinCardX + 23, coinCardY + 11, '#8C6212', 12, 'serif');
      
      const subBarY = SAFE_TOP + 42;
      if (this.tab === 'cards') {
        drawTextLeft(ctx, '◆ 秘术神通 · 常备破煞', 18, subBarY + 13, '#6B4A2E', 12, 'serif');
      } else if (this.tab === 'relics') {
        drawTextLeft(ctx, '◆ 稀世法宝 · 灵丹妙药', 18, subBarY + 13, '#6B4A2E', 12, 'serif');
      }

      // ★ 因果系统：显示当前因果阶位和价格调整
      const karmaInfo = this.karmaSystem.getTierInfo();
      const priceAdjustText = this.karmaSystem.getPriceAdjustText();
      if (karmaInfo.tier !== 'neutral' || priceAdjustText) {
        const karmaText = `【${karmaInfo.tierName}】${priceAdjustText ? ' · ' + priceAdjustText : ''}`;
        drawTextRight(ctx, karmaText, width - 18, subBarY + 13, karmaInfo.themeColor, 11, 'serif');
      }

      const scrollMarginX = 10; 
      const scrollMarginTop = SAFE_TOP + 74; 
      const scrollH = height - scrollMarginTop - 12;

      ctx.save();
      drawInkGoldScrollModal(ctx, scrollMarginX, scrollMarginTop, width - scrollMarginX * 2, scrollH, false);

      ctx.beginPath();
      ctx.rect(scrollMarginX + 8, scrollMarginTop + 8, width - scrollMarginX * 2 - 16, scrollH - 16);
      ctx.clip();

      if (this.tab === 'cards') this.renderCardsTab(ctx, width); 
      else if (this.tab === 'furnace') this.renderFurnaceTab(ctx, width); 
      else if (this.tab === 'relics') this.renderRelicsTab(ctx, width);
      
      if (!this.showLeaveModal && !this.showBag && !this.isDialogueActive) {
        this.buttons.filter(b => b.isScrollable).forEach(b => drawSealButton(ctx, b));
      }
      ctx.restore();

      if (!this.showLeaveModal && !this.showBag && !this.isDialogueActive) {
        this.buttons.filter(b => !b.isScrollable).forEach(b => drawSealButton(ctx, b));
      } else {
        const topBtns = this.buttons.slice(0, 2);
        for (const btn of topBtns) drawSealButton(ctx, btn);
        if (this.showLeaveModal) {
          this.renderLeaveModal(ctx, width, height);
          this.buttons.filter(b => !b.isScrollable).forEach(b => drawSealButton(ctx, b));
        }
      }
      
      if (this.showBag) this.renderBagModal(ctx, width, height);
      if (this.isDialogueActive) this.renderDialogueBox(ctx, width, height);

      if (TutorialManager.isActive) {
        const step = TutorialManager.getCurrentStep();
        const idx = TutorialManager.currentStepIndex;
        const total = TutorialManager.currentSteps.length;
        renderTutorial(ctx, step, width, height, idx, total);
      }
    },

    renderDialogueBox(ctx, width, height) {
      const line = this.dialogueQueue[this.dialogueIndex];
      if (!line) return;

      ctx.fillStyle = 'rgba(6, 3, 1, 0.90)';
      ctx.fillRect(0, 0, width, height);

      const panelW = width - 20;
      const panelH = 184;
      const panelX = 10;
      const panelY = height - panelH - 24;

      drawInkGoldScrollModal(ctx, panelX, panelY, panelW, panelH, true);

      const isLeft = line.side === 'left';
      ctx.font = 'bold 14px serif';
      const nameWidth = ctx.measureText(line.speaker).width;
      const nameplateW = Math.max(114, nameWidth + 56);
      const nameplateH = 32;
      const nameplateX = isLeft ? panelX + 18 : panelX + panelW - 18 - nameplateW;
      const nameplateY = panelY - 16;

      drawRoundedRect(ctx, nameplateX + 2, nameplateY + 2, nameplateW, nameplateH, 16, UI_COLORS.shadow, null);
      drawRoundedRect(ctx, nameplateX, nameplateY, nameplateW, nameplateH, 16, 'rgba(28, 16, 10, 0.98)', '#D4AF37', 1.5);

      const badgeR = 12;
      const badgeX = isLeft ? nameplateX + 16 : nameplateX + nameplateW - 16;
      const badgeY = nameplateY + nameplateH / 2;
      drawRoundedRect(ctx, badgeX - badgeR, badgeY - badgeR, badgeR * 2, badgeR * 2, 5, line.avatarColor || UI_COLORS.cinnabar, '#FFD700', 1);
      drawTextCentered(ctx, line.tag || '贾', badgeX, badgeY, '#FFF8DD', 12, 'serif');

      const nameTextX = isLeft ? nameplateX + 36 : nameplateX + 14;
      ctx.font = 'bold 14px "Songti SC", "SimSun", serif';
      ctx.fillStyle = '#FFF8DD';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(line.speaker, nameTextX, nameplateY + nameplateH / 2);

      wrapDetailText(ctx, line.text, panelX + 24, panelY + 40, panelW - 48, 24, '#120904', 14);

      const alpha = Math.abs(Math.sin(Date.now() / 350));
      ctx.fillStyle = `rgba(150, 42, 31, ${0.65 + 0.35 * alpha})`;
      ctx.font = '12px serif';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'bottom';
      ctx.fillText('轻触继续 ▾', panelX + panelW - 22, panelY + panelH - 16);
    },

    renderLeaveModal(ctx, width, height) {
      ctx.fillStyle = "rgba(4, 2, 1, 0.94)"; 
      ctx.fillRect(0, 0, width, height);
      const panelW = Math.min(310, width - 36); 
      const panelH = 210; 
      const panelX = (width - panelW) / 2;
      const panelY = (height - panelH) / 2;

      drawInkGoldScrollModal(ctx, panelX, panelY, panelW, panelH, true);
      drawTextCentered(ctx, "【 离 店 启 程 】", width / 2, panelY + 36, UI_COLORS.cinnabar, 19, "serif");

      ctx.strokeStyle = "#D4AF37"; 
      ctx.lineWidth = 1; 
      ctx.beginPath(); 
      ctx.moveTo(panelX + 24, panelY + 56); 
      ctx.lineTo(panelX + panelW - 24, panelY + 56); 
      ctx.stroke();

      drawTextCentered(ctx, "秘宝阁中奇珍已览", width / 2, panelY + 88, '#120904', 14, "serif");
      drawTextCentered(ctx, "道友确定要离店踏入下一处险境吗？", width / 2, panelY + 116, "#8C2A24", 12, "serif");
    },

    renderBagModal(ctx, width, height) {
      ctx.fillStyle = 'rgba(10, 6, 2, 0.78)'; 
      ctx.fillRect(0, 0, width, height); 
      const panelW = Math.min(320, width - 36); 
      const panelH = Math.min(480, height - 80); 
      const panelX = (width - panelW) / 2; 
      const panelY = (height - panelH) / 2;
      
      drawInkGoldScrollModal(ctx, panelX, panelY, panelW, panelH, false); 
      drawTextCentered(ctx, "修 真 锦 囊", width / 2, panelY + 28, UI_COLORS.cinnabar, 20, "serif");
      
      ctx.strokeStyle = '#D4AF37'; 
      ctx.lineWidth = 1; 
      ctx.beginPath(); 
      ctx.moveTo(panelX + 20, panelY + 46); 
      ctx.lineTo(panelX + panelW - 20, panelY + 46); 
      ctx.stroke();

      const clipY = panelY + 48;
      const clipH = panelH - 74;
      ctx.save();
      ctx.beginPath();
      ctx.rect(panelX + 4, clipY, panelW - 8, clipH);
      ctx.clip();
      
      let curY = clipY + 8 + this.bagScrollY;

      drawTextLeft(ctx, "【 道 体 资 产 】", panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
      curY += 16;
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, 34, 5, 'rgba(238, 226, 198, 0.75)', 'rgba(160, 120, 70, 0.3)', 1);
      drawTextLeft(ctx, `铜钱: ${this.runState ? this.runState.gold : 0} 文`, panelX + 28, curY + 17, "#C99A3A", 13, "serif"); 
      drawTextLeft(ctx, `因果善业: ${(this.runState?.karma || 0) > 0 ? '+' : ''}${this.runState?.karma || 0}`, panelX + 155, curY + 17, "#2B6B46", 13, "serif");
      curY += 44;

      const charConfig = CHARACTERS[this.runState?.characterId] || CHARACTERS.taoist;
      drawTextLeft(ctx, "【 道 统 传 承 】", panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
      curY += 16;
      const passiveText = `【${charConfig.name}】 被动：${charConfig.passive}`;
      const passiveLines = getWrappedLines(ctx, passiveText, panelW - 48, 11);
      const passiveBoxH = Math.max(34, 12 + passiveLines.length * 16);
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, passiveBoxH, 5, 'rgba(238, 226, 198, 0.75)', 'rgba(160, 120, 70, 0.3)', 1);
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#2B6B46'; 
      ctx.textAlign = 'left'; 
      ctx.textBaseline = 'top';
      passiveLines.forEach((l, i) => {
        ctx.fillText(l, panelX + 24, curY + 8 + i * 16);
      });
      curY += passiveBoxH + 12;

      const allCards = this.runState?.allCards || [];
      const star2Cards = allCards.filter(c => c.star === 2);
      const star1Cards = allCards.filter(c => c.star === 1 || (c.isUpgraded && c.star !== 2));
      const shopBoughtCards = allCards.filter(c => c.price !== undefined || c.isPermanentSupply);
      
      drawTextLeft(ctx, `【 道 藏 牌 库 一 览 】 (共 ${allCards.length} 张)`, panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
      curY += 16;

      const star2Str = star2Cards.length > 0 ? star2Cards.map(c => c.name.replace(/\+*$/, '★★极')).join('、') : '暂无二星极品符箓';
      const star2Lines = getWrappedLines(ctx, star2Str, panelW - 48, 11);
      const star2BoxH = 22 + star2Lines.length * 16 + 6;
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, star2BoxH, 5, 'rgba(244, 235, 212, 0.88)', '#BA43AA', 1.2);
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#5C1D54'; 
      ctx.textAlign = 'left'; 
      ctx.textBaseline = 'top';
      ctx.fillText(`二星·极阶符箓 (${star2Cards.length}张):`, panelX + 24, curY + 6);
      star2Lines.forEach((l, i) => {
        ctx.fillText(l, panelX + 24, curY + 22 + i * 16);
      });
      curY += star2BoxH + 8;

      const star1Str = star1Cards.length > 0 ? star1Cards.map(c => c.name.replace(/\+*$/, '★')).join('、') : '暂无一星进阶符箓';
      const star1Lines = getWrappedLines(ctx, star1Str, panelW - 48, 11);
      const star1BoxH = 22 + star1Lines.length * 16 + 6;
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, star1BoxH, 5, 'rgba(244, 235, 212, 0.88)', '#2B6B46', 1.2);
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#2B6B46'; 
      ctx.textAlign = 'left'; 
      ctx.textBaseline = 'top';
      ctx.fillText(`一星·进阶符箓 (${star1Cards.length}张):`, panelX + 24, curY + 6);
      star1Lines.forEach((l, i) => {
        ctx.fillText(l, panelX + 24, curY + 22 + i * 16);
      });
      curY += star1BoxH + 8;

      const shopStr = shopBoughtCards.length > 0 ? shopBoughtCards.map(c => c.name).join('、') : '暂无';
      const shopLines = getWrappedLines(ctx, shopStr, panelW - 48, 11);
      const shopBoxH = 22 + shopLines.length * 16 + 6;
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, shopBoxH, 5, 'rgba(244, 235, 212, 0.88)', '#C99A3A', 1.2);
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#8C6212'; 
      ctx.textAlign = 'left'; 
      ctx.textBaseline = 'top';
      ctx.fillText(`货郎坊市购得 (${shopBoughtCards.length}张):`, panelX + 24, curY + 6);
      shopLines.forEach((l, i) => {
        ctx.fillText(l, panelX + 24, curY + 22 + i * 16);
      });
      curY += shopBoxH + 12;

      const relics = this.runState?.relics || []; 
      drawTextLeft(ctx, `【 已 纳 法 宝 】 (${relics.length} 件)`, panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
      curY += 16;
      
      if (relics.length === 0) { 
        drawTextCentered(ctx, "行囊空空，尚未寻得法宝机缘", width / 2, curY + 16, "#888888", 12, "serif"); 
        curY += 36;
      } else { 
        relics.forEach((relic) => { 
          const relicDesc = relic.description || relic.desc || '蕴含灵力的随身秘宝。';
          const relicLines = getWrappedLines(ctx, relicDesc, panelW - 52, 11);
          const relicBoxH = Math.max(46, 20 + relicLines.length * 15 + 6);
          drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, relicBoxH, 5, 'rgba(244, 235, 212, 0.9)', '#C99A3A', 1); 
          drawTextLeft(ctx, relic.name, panelX + 26, curY + 12, UI_COLORS.ink, 13, "serif"); 
          ctx.font = '11px serif'; 
          ctx.fillStyle = '#543825'; 
          ctx.textAlign = 'left'; 
          ctx.textBaseline = 'top';
          relicLines.forEach((l, i) => {
            ctx.fillText(l, panelX + 26, curY + 24 + i * 15);
          });
          curY += relicBoxH + 8; 
        }); 
      }

      this.bagContentHeight = curY - (clipY + 8 + this.bagScrollY) + 12;
      ctx.restore();

      drawTextCentered(ctx, "— 上下滑动浏览 · 点击任意处收拢 —", width / 2, panelY + panelH - 14, "#8A6D4B", 11, "serif");
    },

    renderCardsTab(ctx, width) {
      const startY = SAFE_TOP + 86; 
      const cardH = 78; 
      const gap = 12; 
      const cardW = width - 40;
      
      if (this.shopCards.length === 0) {
        drawTextCentered(ctx, '秘宝阁中神通已被道友搜罗一空！', width / 2, startY + 60, '#888888', 14, 'serif');
        return;
      }

      this.shopCards.forEach((card, idx) => {
        const cy = startY + idx * (cardH + gap) + this.shopScrollY;
        const isJingxin = card.name === '净心咒';
        const borderColor = isJingxin ? '#4A90D9' : getElementColor(card.element);

        drawRoundedRect(ctx, 20, cy, cardW, cardH, 6, card.bought ? '#D8CDBA' : 'rgba(244, 235, 212, 0.95)', borderColor, 1.5);
        drawElementBadge(ctx, card.element, 38, cy + 22, 13);
        drawTextLeft(ctx, card.name, 58, cy + 20, card.bought ? '#888888' : UI_COLORS.ink, 15, 'serif');
        drawTextLeft(ctx, `灵气: ${card.cost}  |  ${card.type || '普通'}`, 134, cy + 20, '#7A5531', 11, 'serif');

        if (isJingxin) {
          drawRoundedRect(ctx, 20 + cardW - 132, cy + 8, 42, 18, 4, '#1E3A5F', '#4A90D9', 1);
          drawTextCentered(ctx, '破煞', 20 + cardW - 111, cy + 17, '#D8EBFF', 10, 'serif');
        } else if (SPECIAL_SHOP_CARDS.some(sc => sc.name === card.name)) {
          drawRoundedRect(ctx, 20 + cardW - 132, cy + 8, 42, 18, 4, '#5C1D54', '#FFD6FA', 1);
          drawTextCentered(ctx, '神通', 20 + cardW - 111, cy + 17, '#FFF8DD', 10, 'serif');
        }

        drawTextLeft(ctx, card.bought ? '【已售罄 · 收入囊中】' : (card.description || card.desc || ''), 28, cy + 44, card.bought ? '#999999' : '#543825', 11, 'serif');
      });
    },

    renderRelicsTab(ctx, width) {
      const startY = SAFE_TOP + 86; 
      const cardH = 78; 
      const gap = 14; 
      const cardW = width - 40;

      this.shopRelics.forEach((relic, idx) => {
        const cy = startY + idx * (cardH + gap) + this.shopScrollY;
        drawRoundedRect(ctx, 20, cy, cardW, cardH, 6, relic.bought ? '#D8CDBA' : 'rgba(244, 235, 212, 0.95)', '#C99A3A', 1.5);
        drawRoundedRect(ctx, 28, cy + 12, 34, 18, 3, '#9A731F', '#FFE599', 1);
        drawTextCentered(ctx, relic.rarity, 45, cy + 21, '#FFF8DD', 10, 'serif');
        drawTextLeft(ctx, relic.name, 68, cy + 20, relic.bought ? '#888888' : UI_COLORS.ink, 15, 'serif');
        drawTextLeft(ctx, relic.bought ? '【已被纳走 · 无法重复获取】' : (relic.description || relic.desc || ''), 28, cy + 44, relic.bought ? '#999999' : '#543825', 11, 'serif');
      });
      const healY = startY + this.shopRelics.length * (cardH + gap) + 6 + this.shopScrollY;
      drawRoundedRect(ctx, 20, healY, cardW, 64, 6, 'rgba(244, 235, 212, 0.95)', '#2B6B46', 1.5);
      drawRoundedRect(ctx, 28, healY + 12, 34, 18, 3, '#2B6B46', '#A3E4D7', 1);
      drawTextCentered(ctx, '丹药', 45, healY + 21, '#FFF8DD', 10, 'serif');
      drawTextLeft(ctx, '九转回春丹', 68, healY + 20, UI_COLORS.ink, 15, 'serif');
      drawTextLeft(ctx, `调理道体气血，立即恢复 ${ECONOMY.HEAL_HP_AMOUNT} 点气血`, 28, healY + 42, '#2B6B46', 11, 'serif');
    },

    renderFurnaceTab(ctx, width) {
      const allCards = this.runState.allCards || []; 
      const startY = SAFE_TOP + 86 + this.shopScrollY; 
      const cardW = width - 40;

      if (this.furnaceSubTab === 'craft') {
        const star1Count = allCards.filter(c => (c.star === 1 || (c.isUpgraded && c.star !== 2))).length;
        const star2Count = allCards.filter(c => c.star === 2).length;

        drawTextCentered(ctx, `牌库: ${allCards.length} 张  |  一星: ${star1Count} 张  |  二星极: ${star2Count} 张`, width / 2, SAFE_TOP + 64, '#6B4A2E', 11, 'serif');

        if (this.furnaceItems.length === 0) {
          drawTextCentered(ctx, '当前囊中暂无可强化的符箓', width / 2, startY + 40, '#888888', 13, 'serif');
          return;
        }

        const itemH = 78; 
        const gap = 12;
        this.furnaceItems.forEach((item, idx) => {
          const cy = startY + idx * (itemH + gap);
          const isStar2 = item.star === 1;
          const strokeColor = isStar2 ? '#BA43AA' : (item.type === 'combine' ? '#8C2A24' : '#C99A3A');
          const badgeText = isStar2 ? '极' : (item.type === 'combine' ? '合' : '炼');
          const badgeColor = isStar2 ? '#5C1D54' : (item.type === 'combine' ? '#8C2A24' : '#8A6225');

          drawRoundedRect(ctx, 20, cy, cardW, itemH, 6, 'rgba(244, 235, 212, 0.95)', strokeColor, isStar2 ? 1.5 : 1.2);
          drawRoundedRect(ctx, 28, cy + 14, 24, 24, 4, badgeColor, '#FFE599', 1);
          drawTextCentered(ctx, badgeText, 40, cy + 26, '#FFF8DD', 12, 'serif');

          drawTextLeft(ctx, item.title, 60, cy + 22, UI_COLORS.ink, 14, 'serif');
          wrapDetailText(ctx, item.desc || '', 28, cy + 46, cardW - 84, 14, '#2B6B46', 11);
        });
      } else {
        const itemH = 74; 
        const gap = 10;
        allCards.forEach((card, idx) => {
          const cy = startY + idx * (itemH + gap);
          drawRoundedRect(ctx, 20, cy, cardW, itemH, 6, 'rgba(244, 235, 212, 0.95)', '#9E2F24', 1.2);
          drawElementBadge(ctx, card.element, 38, cy + 20, 12);
          drawTextLeft(ctx, card.name, 58, cy + 18, UI_COLORS.ink, 14, 'serif');
          drawTextLeft(ctx, `灵气: ${card.cost}  |  ${card.type || '普通'}`, 134, cy + 18, '#7A5531', 11, 'serif');
          wrapDetailText(ctx, card.description || card.desc || '', 28, cy + 38, cardW - 84, 14, '#543825', 11);
        });
      }
    },

    exit() {
      TutorialManager.exitScene();
    }
  };
}