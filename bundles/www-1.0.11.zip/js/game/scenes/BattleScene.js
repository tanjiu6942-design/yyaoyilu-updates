import { globalPool } from '../../base/pool.js';
import { SCREEN_WIDTH, SCREEN_HEIGHT, SAFE_TOP, TOP_BAR_Y, TOP_BAR_H, CAPSULE_LEFT } from '../../render.js';
import { 
  getElementColor, getElementColorDark, drawRoundedRect, drawScrollPanel,
  drawTextCentered, drawTextLeft, drawTextRight, createButton, drawParchmentBackground, 
  drawInkPanel, drawElementBadge, drawSealButton, UI_COLORS 
} from '../scene.js';
import { 
  drawInkGoldModal, drawNameplate, getWrappedLines, wrapDetailText 
} from '../../config/ui-components.js';
import { hapticLight, hapticMedium, hapticHeavy } from '../../config/haptics.js';
import { 
  createBattle, createBattleFromRun, playCard, resolveEnemyTurn, startPlayerTurn, discardCard 
} from '../battle.js';
import { createEnemy, TUTORIAL_BATTLE } from '../data.js';
import { stepToNode, generateChapterMap, findNodeById } from '../map.js'; 
import { PROLOGUE_STORY_PAGES } from './MapScene.js';
import { RELIC_TEMPLATES, CHARACTERS, unlockAchievement } from '../types.js';
import { soundManager } from '../../runtime/music.js';
import EffectEngine from '../../runtime/effect.js';
import { TutorialManager, renderTutorial, isSkipButtonTapped, BATTLE_STEPS, TUTORIAL_BATTLE_STEPS } from '../tutorial/index.js';
import { loadCardTemplate, drawCardTemplate, isCardTemplateReady, drawCardIcon, loadCardIcons } from '../cardFrame.js';
import { BATTLE, ECONOMY, randomRangeInt, CARD_LAYOUT } from '../../config/constants.js';
import { isPrologueDone, setPrologueDone, isStoryIntroDone, setStoryIntroDone, isSkipHandFullWarning, setSkipHandFullWarning, unlockZhongKui, unlockNezha, getSelectedChar } from '../../config/storage.js';
import { runManager } from '../RunManager.js';
import { isCurseCard } from '../effect-engine.js';
import { KarmaSystem } from '../systems/KarmaSystem.js';
import { CHAPTER_1_DIALOGUES } from '../battle/BattleDialogue.js';
import { CHAPTER_2_DIALOGUES } from '../story/chapter2Dialogues.js';
import { CHAPTER_3_DIALOGUES } from '../story/chapter3Dialogues.js';
import { calculateVictoryReward, buildVictoryRewardUI, onClaimVictoryRewards, buildRelicRewardUI, selectRewardRelic, skipRewardRelic, buildChapterEndModalUI, onChapterEndConfirm, buildCardRewardUI, selectRewardCard, skipRewardCard, buildFinalChoiceUI } from '../battle/BattleReward.js';
import { BattleAnimation } from '../battle/BattleAnimation.js';
import { BattleInput } from '../battle/BattleInput.js';
import { renderEnemyArea, renderCardPreview, renderLogArea, renderPlayerStatus, renderHand, renderDialogueBox, renderButtons, renderHandFullModal, renderChapterEndModal, renderVictoryRewardModal, renderRelicReward, renderBagModal, renderBuildStatus, renderBuildDetailModal, renderCardReward, renderFinalChoiceModal } from '../battle/BattleRenderer.js';

globalPool.register(
  'damageText', 
  () => ({ text: '', x: 0, y: 0, color: '#FFF', alpha: 1, vy: -1.2, life: 35 }), 
  (item, text, x, y, color) => { 
    item.text = text; 
    item.x = x + (Math.random() * 24 - 12); 
    item.y = y; 
    item.color = color || '#FF4444'; 
    item.alpha = 1.0; 
    item.vy = -1.2; 
    item.life = 35; 
  }
);

const RARITY_COLORS = { 
  '普通': { fill: '#4A4036', stroke: '#8C7E6C', text: '#DDD4C4' }, 
  '稀有': { fill: '#1E3A5F', stroke: '#4A90D9', text: '#D8EBFF' }, 
  '史诗': { fill: '#5C1D54', stroke: '#BA43AA', text: '#FFD6FA' }, 
  '传说': { fill: '#664511', stroke: '#FFB834', text: '#FFF2C6' } 
};

const { CARD_W, CARD_H, CARD_GAP, TRAY_PADDING_X } = CARD_LAYOUT;

function drawInkGoldScrollModal(ctx, x, y, w, h, isDialogue = false) {
  ctx.save();
  ctx.shadowColor = 'rgba(212, 175, 55, 0.22)';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetY = 10;
  drawRoundedRect(ctx, x, y, w, h, 14, '#1A0E08', '#0D0704', 3);
  ctx.restore();

  const goldGrad = ctx.createLinearGradient(x, y, x + w, y + h);
  goldGrad.addColorStop(0, '#E6C875');
  goldGrad.addColorStop(0.25, '#FFF6C2');
  goldGrad.addColorStop(0.5, '#C49838');
  goldGrad.addColorStop(0.75, '#FCE38A');
  goldGrad.addColorStop(1, '#8C6018');
  drawRoundedRect(ctx, x + 2, y + 2, w - 4, h - 4, 12, null, goldGrad, 2);

  const paperGrad = ctx.createRadialGradient(
    x + w / 2, y + h * 0.45, w * 0.15,
    x + w / 2, y + h * 0.5, w * 0.85
  );
  paperGrad.addColorStop(0, '#FFFDF8');
  paperGrad.addColorStop(0.35, '#F9EED9');
  paperGrad.addColorStop(0.75, '#EBD5AD');
  paperGrad.addColorStop(1, '#CFA968');
  drawRoundedRect(ctx, x + 5, y + 5, w - 10, h - 10, 10, paperGrad, '#8F6126', 1.5);

  ctx.save();
  const centerX = x + w / 2;
  const centerY = isDialogue ? y + h / 2 : y + h * 0.52;
  const wmR = Math.min(w, h) * 0.32;
  ctx.strokeStyle = 'rgba(184, 134, 40, 0.075)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(centerX, centerY, wmR, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(centerX, centerY, wmR * 0.85, 0, Math.PI * 2);
  ctx.setLineDash([8, 6]);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.beginPath();
  ctx.arc(centerX, centerY - wmR * 0.4, wmR * 0.4, Math.PI * 0.5, Math.PI * 1.5);
  ctx.arc(centerX, centerY + wmR * 0.4, wmR * 0.4, Math.PI * 1.5, Math.PI * 0.5);
  ctx.stroke();
  ctx.fillStyle = 'rgba(180, 120, 40, 0.04)';
  for (let i = 0; i < 28; i++) {
    const rx = x + 10 + ((i * 73 + 19) % (w - 20));
    const ry = y + 10 + ((i * 101 + 37) % (h - 20));
    ctx.beginPath();
    ctx.arc(rx, ry, (i % 3) + 1.2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  const innerMargin = 12;
  const ix = x + innerMargin;
  const iy = y + innerMargin;
  const iw = w - innerMargin * 2;
  const ih = h - innerMargin * 2;
  ctx.save();
  ctx.strokeStyle = 'rgba(150, 42, 31, 0.35)';
  ctx.lineWidth = 1;
  ctx.strokeRect(ix, iy, iw, ih);
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 1.2;
  ctx.strokeRect(ix + 3, iy + 3, iw - 6, ih - 6);

  const drawRoyalCorner = (cx, cy, dirX, dirY) => {
    ctx.save();
    ctx.strokeStyle = '#C99A3A';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(cx, cy + dirY * 18);
    ctx.lineTo(cx, cy);
    ctx.lineTo(cx + dirX * 18, cy);
    ctx.stroke();
    ctx.strokeStyle = '#EAD7A3';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(cx + dirX * 5, cy + dirY * 14);
    ctx.lineTo(cx + dirX * 5, cy + dirY * 5);
    ctx.lineTo(cx + dirX * 14, cy + dirY * 5);
    ctx.stroke();
    ctx.fillStyle = '#962A1F';
    ctx.beginPath();
    ctx.arc(cx + dirX * 7, cy + dirY * 7, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FFD700';
    ctx.fillRect(cx + dirX * 6, cy + dirY * 6, 2, 2);
    ctx.restore();
  };
  drawRoyalCorner(ix + 5, iy + 5, 1, 1);
  drawRoyalCorner(ix + iw - 5, iy + 5, -1, 1);
  drawRoyalCorner(ix + 5, iy + ih - 5, 1, -1);
  drawRoyalCorner(ix + iw - 5, iy + ih - 5, -1, -1);

  const drawCenterRuyi = (midX, midY, isFlip) => {
    ctx.save();
    ctx.translate(midX, midY);
    if (isFlip) ctx.scale(1, -1);
    ctx.strokeStyle = '#C99A3A';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(-10, 0, 4, Math.PI * 0.5, Math.PI * 2);
    ctx.arc(0, -2, 6, Math.PI, 0);
    ctx.arc(10, 0, 4, Math.PI, Math.PI * 0.5);
    ctx.stroke();
    ctx.fillStyle = '#962A1F';
    ctx.beginPath();
    ctx.arc(0, -2, 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };
  drawCenterRuyi(ix + iw / 2, iy + 3, false);
  drawCenterRuyi(ix + iw / 2, iy + ih - 3, true);
  ctx.restore();
}

export function createBattleScene(manager) {
  return {
    manager: manager, 
    battle: null, 
    selectedCardIndex: -1,
    selectedRewardCardIndex: -1, 
    previewCardIndex: -1,
    logs: [], 
    logScrollY: 0, 
    enemyIndex: 0,
    buttons: [], 
    cardButtons: [], 
    runState: null,
    entrySnapshot: null,
    suppressNextTap: false,
    showVictoryModal: false, 
    victoryRewardData: null, 
    showChapterEndModal: false,
    showFinalChoice: false,
    ch3ChoiceKey: null,
    showBag: false, 
    showRelicReward: false, 
    rewardRelics: [], 
    relicCards: [], 
    showCardReward: false,
    rewardCards: [],
    rewardCardButtons: [],
    showStoryIntro: false, 
    storyData: null,
    tutorialStep: 0,
    handScrollX: 0, 
    isDraggingHand: false, 
    touchStartX: 0, 
    touchStartY: 0, 
    lastTouchX: 0, 
    dragDistance: 0, 
    hasBoundTouch: false,

    // 双击与手势拖拽出牌状态
    lastCardTapIndex: -1,
    lastCardTapTime: 0,
    draggingCardIndex: -1,
    candidateDragIndex: -1,
    dragTouchStartX: 0,
    dragTouchStartY: 0,
    dragCurrentX: 0,
    dragCurrentY: 0,
    isTargetLocked: false,

    isDiscardMode: false,
    isWaitingEnemyTurn: false,
    showHandFullModal: false,
    effects: new EffectEngine(),

    isDialogueActive: false,
    dialogueQueue: [],
    showBuildDetail: false,
    selectedBuildDetail: null,
    buildTagAreas: [],
    dialogueIndex: 0,
    dialogueOnComplete: null,
    enrageDialogueTriggered: false,
    jiuWeiPhase2DialoguePlayed: false,
    jiuWeiPhase3DialoguePlayed: false,

    bagScrollY: 0,
    isDraggingBag: false,
    bagTouchStartY: 0,
    bagLastTouchY: 0,
    bagDragDistance: 0,
    bagContentHeight: 0,

    addFloater(text, x, y, color) {
      this.animation.addFloater(text, x, y, color);
    },

    startDialogue(dialogueList, onComplete = null) {
      if (!dialogueList || dialogueList.length === 0) {
        if (onComplete) onComplete();
        return;
      }
      this.dialogueQueue = dialogueList;
      this.dialogueIndex = 0;
      this.isDialogueActive = true;
      this.dialogueOnComplete = onComplete;
      this.buildUI();
    },

    advanceDialogue() {
      if (!this.isDialogueActive) return;
      this.dialogueIndex++;
      if (this.dialogueIndex >= this.dialogueQueue.length) {
        this.isDialogueActive = false;
        const cb = this.dialogueOnComplete;
        this.dialogueOnComplete = null;
        if (cb) cb();
      }
      this.buildUI();
    },

    applyDrawAnimation(startIndex, count) {
      this.animation.applyDrawAnimation(startIndex, count);
    },

    enter(data) {
      this.enemyIndex = data?.enemyIndex !== undefined ? data.enemyIndex : 0;
      this.isTutorial = data?.isTutorial === true;
      this._tutorialPending = false;
      this.storyPageIndex = -1;
      this.isDiscardMode = false;
      this.isWaitingEnemyTurn = false;
      this.showHandFullModal = false;
      this.dragDistance = 0;
      this.isDraggingHand = false;
      this.draggingCardIndex = -1;
      this.candidateDragIndex = -1;
      this.isTargetLocked = false;
      this.lastCardTapIndex = -1;
      this.lastCardTapTime = 0;
      this.bagScrollY = 0;
      this.isDialogueActive = false;
      this.enrageDialogueTriggered = false;
      this.jiuWeiPhase2DialoguePlayed = false;
      this.jiuWeiPhase3DialoguePlayed = false;

      loadCardTemplate();
      loadCardIcons();
      
      const isBoss = (this.enemyIndex === 5 || this.enemyIndex === 10 || this.enemyIndex === 16);
      soundManager.playBgm(isBoss ? 'battle2' : 'battle1');

      this.effects = new EffectEngine();
      this.animation = new BattleAnimation(this);
      this.input = new BattleInput(this);
      this.storyData = data?.storyData || null; 
      this.showStoryIntro = !!this.storyData;
      
      // ★ 教学模式：使用固定配置
      if (this.isTutorial) {
        const tutEnemy = { ...TUTORIAL_BATTLE.enemy, id: "enemy_tutorial", shield: 0, burnTurns: 0, burnDamage: 0, skipTurn: false, attackBuff: 0, enraged: false, invulnerableTurns: 0, barrierTriggered: false, nextAction: "笨拙挥击", nextActionType: "attack", nextActionValue: TUTORIAL_BATTLE.enemy.attack, intentDesc: `准备出招 (造成 ${TUTORIAL_BATTLE.enemy.attack} 点伤害)` };
        const tutRunState = {
          chapter: 0,
          characterId: getSelectedChar() || 'taoist',
          hp: TUTORIAL_BATTLE.playerHp,
          maxHp: TUTORIAL_BATTLE.playerHp,
          allCards: TUTORIAL_BATTLE.startingHand.map(c => ({ ...c })),
          relics: [],
          karma: 0,
          isTutorial: true
        };
        this.runState = { ...tutRunState, gold: 0, currentNodeId: null, map: [] };
        this.entrySnapshot = JSON.parse(JSON.stringify(this.runState));
        this.battle = createBattleFromRun(tutRunState, tutEnemy);
        // 覆盖手牌为固定的两张教学卡
        this.battle.player.cards = TUTORIAL_BATTLE.startingHand.map(c => ({ ...c, id: 'tut_' + Math.random().toString(36).substring(2, 8) }));
        this.battle.player.deck = [];
        this.battle.log = ['【教学关】桃木傀儡已就位，且随师尊研习五行斗法之基！'];
        this._needsTutorial = true;
      } else {
        const rawRunState = data?.runState || this.loadRunState();
        if (rawRunState) {
          this.runState = JSON.parse(JSON.stringify(rawRunState));
          if (data?.runState) runManager.setState(this.runState);
          if (this.runState.hp <= 0) this.runState.hp = this.runState.maxHp || 30;
          this.entrySnapshot = JSON.parse(JSON.stringify(this.runState));
        } else { 
          this.runState = null; 
          this.entrySnapshot = null; 
        }

        const enemy = createEnemy(this.enemyIndex);
        this.battle = this.runState ? createBattleFromRun(this.runState, enemy) : createBattle(this.enemyIndex);
      }

      // ★ 因果系统：战斗开始时显示世界状态提示
      if (this.runState && this.runState.karma !== undefined) {
        const karmaSystem = new KarmaSystem(runManager);
        const worldStatus = karmaSystem.getWorldStatusText();
        if (worldStatus) {
          this.battle.log.push(worldStatus);
        }
        // 负因果：敌人伤害提升
        if (karmaSystem.isDemonic()) {
          const dmgMult = karmaSystem.getEnemyDamageMultiplier();
          if (dmgMult > 1) {
            this.battle.enemy.attack = Math.round(this.battle.enemy.attack * dmgMult);
          }
        }
        // 正/负因果：玩家伤害提升（正因果+10%，负因果+15%）
        const playerDmgMult = karmaSystem.getPlayerDamageMultiplier();
        if (playerDmgMult > 1) {
          this.battle.player.damageMultiplier = playerDmgMult;
        }
      }
      
      if (this.battle.player.cards.length > 0) {
        this.applyDrawAnimation(0, this.battle.player.cards.length);
      }

      const isFirstChapter = (!this.runState || this.runState.chapter === 1 || this.enemyIndex < 6);
      const _curNode = this.runState?.currentNodeId ? findNodeById(this.runState.map, this.runState.currentNodeId) : null;
      const isFirstRow = (!_curNode || _curNode.row === 0);
      const isNormalBattle = isFirstChapter ? this.enemyIndex < 4 : this.enemyIndex < 9;
      // 真正战斗中不再触发新手教程，只在独立教学关触发
      if (!this.isTutorial) {
        this._needsTutorial = false;
      }

      this.tutorialStep = 0;

      this.logs = [...this.battle.log]; 
      this.logScrollY = 9999; 
      this.selectedCardIndex = -1;
      this.previewCardIndex = -1;
      this.cardButtons = []; 
      this.buttons = []; 
      this.suppressNextTap = false;
      this.showRelicReward = false; 
      this.showVictoryModal = false; 
      this.showChapterEndModal = false;
      this.showFinalChoice = false;
      this.ch3ChoiceKey = null; 
      this.showBag = false;
      this.rewardRelics = []; 
      this.relicCards = []; 
      this.handScrollX = 0;

      this.input.bind();

      const isPrologueNeeded = isFirstChapter && isFirstRow && !isPrologueDone();
      const onDialogueDone = () => { 
        this._startTutorialIfNeeded(); 
        // 对话结束后重新应用发牌动画（对话期间动画已结束）
        if (this.battle?.player?.cards?.length > 0) {
          this.applyDrawAnimation(0, this.battle.player.cards.length);
        }
        this.buildUI();
      };

      // ★ 教学模式：先播放4页背景故事，再播放序幕+进场对话，最后开始教程
      if (this.isTutorial) {
        TutorialManager.resetScene('battle');
        // 教学关步骤 id 是 tut_ 开头，需要单独重置
        Object.keys(TutorialManager.progress).forEach(key => {
          if (key.startsWith('tut_')) delete TutorialManager.progress[key];
        });
        TutorialManager.saveProgress();
        this._tutorialPending = true;
        this.storyPageIndex = 0;
        this.buildUI();
        return;
      }

      if (isPrologueNeeded) {
        this.startDialogue(CHAPTER_1_DIALOGUES.PROLOGUE, () => {
          setPrologueDone();
          this.startDialogue(CHAPTER_1_DIALOGUES.SHANXIAO_INTRO, onDialogueDone);
        });
      } else if (isFirstChapter) {
        if (this.enemyIndex === 0) {
          this.startDialogue(CHAPTER_1_DIALOGUES.SHANXIAO_INTRO, onDialogueDone);
        } else if (this.enemyIndex === 1) {
          this.startDialogue(CHAPTER_1_DIALOGUES.JIANGSHI_INTRO, onDialogueDone);
        } else if (this.enemyIndex === 2) {
          this.startDialogue(CHAPTER_1_DIALOGUES.HULI_INTRO, onDialogueDone);
        } else if (this.enemyIndex === 3) {
          this.startDialogue(CHAPTER_1_DIALOGUES.HUAPI_INTRO, onDialogueDone);
        } else if (this.enemyIndex === 4) {
          this.startDialogue(CHAPTER_1_DIALOGUES.ELITE_WU_CHANG_INTRO, onDialogueDone);
        } else if (this.enemyIndex === 5) {
          this.startDialogue(CHAPTER_1_DIALOGUES.BOSS_INTRO);
        }
      } else {
        if (this.enemyIndex === 6) {
          this.startDialogue(CHAPTER_2_DIALOGUES.GUHUN_INTRO, onDialogueDone);
        } else if (this.enemyIndex === 7) {
          this.startDialogue(CHAPTER_2_DIALOGUES.GUIHUO_INTRO, onDialogueDone);
        } else if (this.enemyIndex === 8) {
          this.startDialogue(CHAPTER_2_DIALOGUES.ZHIZHA_INTRO, onDialogueDone);
        } else if (this.enemyIndex === 9) {
          this.startDialogue(CHAPTER_2_DIALOGUES.ELITE_NIUTOU_INTRO, onDialogueDone);
        } else if (this.enemyIndex === 10) {
          this.startDialogue(CHAPTER_2_DIALOGUES.BOSS_INTRO);
        } else if (this.enemyIndex >= 11) {
          // 第三章敌人
          if (this.enemyIndex === 11) {
            this.startDialogue(CHAPTER_3_DIALOGUES.GUIXU_YUANHUN_INTRO, onDialogueDone);
          } else if (this.enemyIndex === 12) {
            this.startDialogue(CHAPTER_3_DIALOGUES.SHILING_CANKE_INTRO, onDialogueDone);
          } else if (this.enemyIndex === 13) {
            this.startDialogue(CHAPTER_3_DIALOGUES.HUNDUN_YOUHUN_INTRO, onDialogueDone);
          } else if (this.enemyIndex === 14) {
            this.startDialogue(CHAPTER_3_DIALOGUES.GUIXU_SHIKUI_INTRO, onDialogueDone);
          } else if (this.enemyIndex === 15) {
            this.startDialogue(CHAPTER_3_DIALOGUES.JIUWEI_SHANNIAN_INTRO, onDialogueDone);
          } else if (this.enemyIndex === 16) {
            // 持有绣娘玉佩时，BOSS开场对话后追加一段玉佩特殊对话
            const hasJade = (this.runState?.relics || []).some(r => r.id === 'relic_xiuniang_yupei');
            if (hasJade) {
              this.startDialogue(CHAPTER_3_DIALOGUES.BOSS_INTRO, () => {
                this.startDialogue(CHAPTER_3_DIALOGUES.BOSS_JADE_DIALOGUE);
              });
            } else {
              this.startDialogue(CHAPTER_3_DIALOGUES.BOSS_INTRO);
            }
          } else {
            onDialogueDone();
          }
        }
      }

      this.buildUI();
    },

    _startTutorialIfNeeded() {
      if (!this._needsTutorial) return;
      const steps = this.isTutorial ? TUTORIAL_BATTLE_STEPS : BATTLE_STEPS;
      // 教学关：强制重置所有 tut_ 步骤，避免持久化进度过滤
      if (this.isTutorial) {
        Object.keys(TutorialManager.progress).forEach(key => {
          if (key.startsWith('tut_')) delete TutorialManager.progress[key];
        });
        TutorialManager.saveProgress();
      }
      const activated = TutorialManager.enterScene('battle', steps, {
        onStepChange: () => { this.buildUI(); },
        onComplete: () => { this.buildUI(); }
      });
      if (activated) this.buildUI();
    },

    clampBagScroll() {
      this.input.clampBagScroll();
    },

    initHandTouchListeners() {
      this.input.bind();
    },

    clampHandScroll() {
      this.input.clampHandScroll();
    },

    updateCardPositions() {
      this.input.updateCardPositions();
    },

    buildUI() {
      const { width, height } = this.manager; 
      this.manager.input.clearButtons();

      // ★ 教学模式：背景故事翻页
      if (this.isTutorial && this.storyPageIndex >= 0 && this.storyPageIndex < PROLOGUE_STORY_PAGES.length) {
        this.manager.input.addTapHandler(() => {
          soundManager.playSfx('btn_click');
          this.storyPageIndex++;
          if (this.storyPageIndex >= PROLOGUE_STORY_PAGES.length) {
            // 背景故事结束，开始播放序幕对话
            this.storyPageIndex = -1;
            this.startDialogue(CHAPTER_1_DIALOGUES.PROLOGUE, () => {
              this.startDialogue(CHAPTER_1_DIALOGUES.TUTORIAL_INTRO, () => {
                this._tutorialPending = false;
                this._startTutorialIfNeeded();
                // 对话结束后重新应用发牌动画
                if (this.battle?.player?.cards?.length > 0) {
                  this.applyDrawAnimation(0, this.battle.player.cards.length);
                }
                this.buildUI();
              });
            });
          }
          this.buildUI();
        });
        return;
      }

      if (this.isDialogueActive) {
        this.manager.input.addTapHandler(() => {
          soundManager.playSfx('btn_click');
          this.advanceDialogue();
        });
        return;
      }

      if (this.showStoryIntro) {
        this.manager.input.addTapHandler(() => { 
          if (this.showStoryIntro) { 
            this.showStoryIntro = false; 
            this.buildUI(); 
          } 
        }); 
        return;
      }

      if (this.showHandFullModal) {
        this.buildHandFullModalUI();
        return;
      }
      
      if (this.showChapterEndModal) {
        buildChapterEndModalUI(this);
        return;
      }

      if (this.showFinalChoice) {
        buildFinalChoiceUI(this);
        return;
      }
      
      if (this.showVictoryModal) { buildVictoryRewardUI(this); return; }
      if (this.showRelicReward) { buildRelicRewardUI(this); return; }
      if (this.showCardReward) { buildCardRewardUI(this); return; }

      if (this.previewCardIndex >= 0) {
        this.clampHandScroll();
        const HAND_Y = height - CARD_H - 58;
        const count = this.battle.player.cards.length;
        const totalCardsWidth = count * (CARD_W + CARD_GAP) - CARD_GAP;
        const trayWidth = width - TRAY_PADDING_X * 2;
        let startX = TRAY_PADDING_X;
        if (totalCardsWidth <= trayWidth) {
          startX = (width - totalCardsWidth) / 2;
        } else {
          startX = TRAY_PADDING_X + this.handScrollX;
        }
        this.cardButtons = this.battle.player.cards.map((card, i) => {
          const btn = createButton(
            startX + i * (CARD_W + CARD_GAP),
            HAND_Y - 26,
            CARD_W,
            CARD_H + 26,
            card.name,
            { fontSize: 12, tap: () => this.onCardTap(i), color: "#333333" }
          );
          btn.card = card;
          btn.cardIndex = i;
          return btn;
        });
        this.cardButtons.forEach(btn => this.manager.input.addTouchButton(btn));

        const logTop = SAFE_TOP + 104;
        const trayY = HAND_Y - 24;
        const barY = trayY - 34;
        const logBottom = barY - 10;
        const scale = 1.8;
        const cardW = CARD_W * scale;
        const cardH = CARD_H * scale;
        const cx = width / 2;
        const cy = (logTop + logBottom) / 2 - 8;
        const previewLeft = cx - cardW / 2;
        const previewTop = cy - cardH / 2;
        const previewRight = cx + cardW / 2;
        const previewBottom = cy + cardH / 2;

        this.manager.input.addTapHandler((x, y) => {
          for (const btn of this.cardButtons) {
            if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) return;
          }
          if (x >= previewLeft && x <= previewRight && y >= previewTop && y <= previewBottom) return;
          this.onPreviewCancel();
        });
        return;
      }

      this.clampHandScroll();
      const HAND_Y = height - CARD_H - 58; 
      const count = this.battle.player.cards.length; 
      const totalCardsWidth = count * (CARD_W + CARD_GAP) - CARD_GAP; 
      const trayWidth = width - TRAY_PADDING_X * 2;
      let startX = TRAY_PADDING_X;
      if (totalCardsWidth <= trayWidth) {
        startX = (width - totalCardsWidth) / 2; 
      } else {
        startX = TRAY_PADDING_X + this.handScrollX;
      }

      this.cardButtons = this.battle.player.cards.map((card, i) => {
        const totalCost = card.cost + (card.dualElement ? 1 : 0); 
        const canAfford = this.battle.player.energy >= totalCost;
        const isCurse = isCurseCard(card);
        
        let btnColor;
        if (this.isDiscardMode) {
          btnColor = isCurse ? "#2A2A2A" : "#5C201A";
        } else {
          btnColor = canAfford ? getElementColorDark(card.element) : "#333333";
        }

        const btn = createButton(
          startX + i * (CARD_W + CARD_GAP), 
          HAND_Y - 26, 
          CARD_W, 
          CARD_H + 26, 
          card.name, 
          { 
            fontSize: 12, 
            tap: () => this.onCardTap(i), 
            color: btnColor 
          }
        );
        btn.card = card; 
        btn.canAfford = canAfford; 
        btn.cardIndex = i; 
        btn.isCurse = isCurse;
        return btn;
      });

      const discardBtnW = 76;
      const gap = 10;
      const endTurnBtnW = width - 36 - discardBtnW - gap;
      const discardBtnX = 18;
      const endTurnBtnX = discardBtnX + discardBtnW + gap;

      this.buttons = [
        createButton(12, TOP_BAR_Y, 58, TOP_BAR_H, '锦囊', { 
          fontSize: 13, 
          tap: () => { 
            if (!this.isWaitingEnemyTurn) { 
              hapticLight();
              this.showBag = true; 
              this.bagScrollY = 0;
              this.buildUI(); 
            } 
          }, 
          color: UI_COLORS.cinnabar, 
          textColor: '#FFF3CA' 
        }),
        createButton(discardBtnX, height - 48, discardBtnW, 38, this.isDiscardMode ? "退出弃牌" : "弃牌", { 
          fontSize: 13, 
          tap: () => { 
            if (this.isWaitingEnemyTurn) return;
            hapticLight();
            this.isDiscardMode = !this.isDiscardMode; 
            this.buildUI(); 
          }, 
          color: this.isDiscardMode ? "#8C2A24" : UI_COLORS.inkSoft, 
          textColor: this.isDiscardMode ? "#FFE0D0" : "#FFF3CA" 
        }),
        createButton(endTurnBtnX, height - 48, endTurnBtnW, 38, this.isWaitingEnemyTurn ? "妖邪出招中..." : "结束回合", { 
          fontSize: 16, 
          tap: () => {
            this.onEndTurn();
          }, 
          color: this.isWaitingEnemyTurn ? "#5A5148" : UI_COLORS.cinnabar, 
          textColor: "#FFF3CA" 
        })
      ];

      if (TutorialManager.isActive) {
        const step = TutorialManager.getCurrentStep();
        this.manager.input.addTapHandler((x, y) => {
          if (isSkipButtonTapped(x, y, width)) {
            TutorialManager.skipAll();
            this.buildUI();
          }
        });
        if (!step || step.type !== 'action') {
          this.manager.input.addTapHandler((x, y) => {
            if (isSkipButtonTapped(x, y, width)) return;
            const advanced = TutorialManager.advance();
            if (advanced) {
              soundManager.playSfx('btn_click');
              this.buildUI();
            }
          });
          return;
        }
      }

      this.cardButtons.forEach(btn => this.manager.input.addTouchButton(btn));
      this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));

      if (this.manager.input.addTapHandler) {
        this.manager.input.addTapHandler((x, y) => {
          // 点击流派详情弹窗外部关闭
          if (this.showBuildDetail) {
            this.showBuildDetail = false;
            this.selectedBuildDetail = null;
            this.buildUI();
            return;
          }
          if (this.showBag) {
            if (this.bagDragDistance > 8) {
              this.bagDragDistance = 0;
              return;
            }
            this.showBag = false;
            this.suppressNextTap = true;
            setTimeout(() => { this.suppressNextTap = false; }, 80);
            this.buildUI();
            return;
          }
          const HAND_Y_TAP = this.manager.height - CARD_H - 58;
          if (this.selectedCardIndex !== -1 && (y < HAND_Y_TAP - 45 || y > HAND_Y_TAP + CARD_H + 16)) {
            this.selectedCardIndex = -1;
            this.buildUI();
          }
        });
      }

      // 流派标签长按显示详情
      if (this.manager.input) {
        this.manager.input.longPressCallback = (x, y) => {
          if (this.showBuildDetail || this.showBag || this.showVictoryModal || this.showStoryIntro) return;
          if (!this.buildTagAreas) return;
          for (const area of this.buildTagAreas) {
            if (x >= area.x && x <= area.x + area.w && y >= area.y && y <= area.y + area.h) {
              if (this.battle && this.battle.buildSystem) {
                this.selectedBuildDetail = this.battle.buildSystem.getBuildDetail(area.buildKey);
                if (this.selectedBuildDetail) {
                  this.showBuildDetail = true;
                  soundManager.playSfx('btn_click');
                }
              }
              break;
            }
          }
        };
      }
    },

    buildHandFullModalUI() {
      const { width, height } = this.manager;
      this.manager.input.clearButtons();
      this.buttons = [];

      const panelW = Math.min(310, width - 40);
      const panelH = 220;
      const panelY = (height - panelH) / 2;
      const btnW = 110;
      const btnH = 38;
      const btnY = panelY + panelH - 52;

      const knowBtn = createButton(width / 2 - btnW - 10, btnY, btnW, btnH, '我已知晓', {
        fontSize: 14,
        color: UI_COLORS.cinnabar,
        textColor: '#FFF3CA',
        tap: () => {
          hapticLight();
          this.showHandFullModal = false;
          this.proceedEndTurn();
        }
      });

      const dontShowAgainBtn = createButton(width / 2 + 10, btnY, btnW, btnH, '不再提示', {
        fontSize: 14,
        color: UI_COLORS.inkSoft,
        textColor: '#D0C8B8',
        tap: () => {
          setSkipHandFullWarning();
          hapticLight();
          this.showHandFullModal = false;
          this.proceedEndTurn();
        }
      });

      this.buttons = [knowBtn, dontShowAgainBtn];
      this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
    },

    // ==================== 奖励系统（委托给 BattleReward 模块） ====================

    buildVictoryRewardUI() { buildVictoryRewardUI(this); },
    onClaimVictoryRewards() { onClaimVictoryRewards(this); },
    buildRelicRewardUI() { buildRelicRewardUI(this); },
    selectRewardRelic(relic) { selectRewardRelic(this, relic); },
    skipRewardRelic() { skipRewardRelic(this); },

    onCardTap(index) {
      if (this.isWaitingEnemyTurn || this.suppressNextTap || this.showRelicReward || this.showBag || this.showVictoryModal || this.showChapterEndModal || this.showFinalChoice || this.showStoryIntro || this.showHandFullModal || this.isDialogueActive) {
        this.suppressNextTap = false;
        return;
      }
      const btn = this.cardButtons[index]; 
      if (btn && (btn.x + btn.w <= TRAY_PADDING_X || btn.x >= this.manager.width - TRAY_PADDING_X)) return;
      if (!this.battle || this.battle.phase !== "player_action") return;
      const card = this.battle.player.cards[index]; 
      if (!card) return;

      if (this.isDiscardMode) {
        const isCurse = isCurseCard(card);
        if (isCurse) {
          soundManager.playSfx('btn_click');
          hapticLight();
          wx.showToast({ title: '索魂咒附骨缠身，无法弃置！需耗灵气焚化', icon: 'none' });
          this.addFloater('无法弃置', this.manager.width / 2, this.manager.height - 210, '#FF4444');
          return;
        }

        this.battle = discardCard(this.battle, index);
        soundManager.playSfx('btn_click');
        hapticLight();
        this.addFloater('弃置', this.manager.width / 2, this.manager.height - 210, '#C0B4A0');
        this.logs = [...this.battle.log];
        this.logScrollY = 9999;
        this.buildUI();
        return;
      }

      const totalCost = card.cost + (card.dualElement ? 1 : 0); 
      if (this.battle.player.energy < totalCost) {
        wx.showToast({ title: '灵气不足', icon: 'none' });
        return;
      }

      const now = Date.now();
      const isRapidDoubleTap = (this.lastCardTapIndex === index && (now - this.lastCardTapTime) < 380);

      if (isRapidDoubleTap || this.selectedCardIndex === index) {
        this.lastCardTapIndex = -1;
        this.lastCardTapTime = 0;
        this.executePlayCard(index);
        return;
      }

      this.selectedCardIndex = index;
      this.previewCardIndex = index;
      this.lastCardTapIndex = index;
      this.lastCardTapTime = now;
      soundManager.playSfx('btn_click');
      hapticLight();
      this.buildUI();
    },

    onPreviewPlay() {
      if (this.previewCardIndex < 0) return;
      const idx = this.previewCardIndex;
      this.previewCardIndex = -1;
      this.executePlayCard(idx);
    },

    onPreviewCancel() {
      this.previewCardIndex = -1;
      this.selectedCardIndex = -1;
      soundManager.playSfx('btn_click');
      hapticLight();
      this.buildUI();
    },

    executePlayCard(index) {
      if (!this.battle || this.battle.phase !== "player_action") return;
      const card = this.battle.player.cards[index];
      if (!card) return;

      this.selectedCardIndex = -1;
      this.previewCardIndex = -1;
      this.lastCardTapIndex = -1;
      soundManager.playSfx('card_play');
      hapticLight();

      const prevEnemyHp = this.battle.enemy.hp; 
      const prevEnemyShield = this.battle.enemy.shield || 0;
      const prevPlayerHp = this.battle.player.hp; 
      const prevPlayerShield = this.battle.player.shield || 0;
      const prevCardCount = this.battle.player.cards.length;

      this.battle = playCard(this.battle, index); 
      this.logs = [...this.battle.log]; 
      this.logScrollY = 9999; 

      TutorialManager.completeAction('play_card');
      
      const newDrawnCount = this.battle.player.cards.length - (prevCardCount - 1);
      if (newDrawnCount > 0) {
        this.applyDrawAnimation(this.battle.player.cards.length - newDrawnCount, newDrawnCount);
      }

      const enemyHpDmg = prevEnemyHp - this.battle.enemy.hp; 
      const enemyShieldDmg = prevEnemyShield - (this.battle.enemy.shield || 0);

      const enemyCenterX = this.manager.width / 2;
      const enemyCenterY = SAFE_TOP + 46;
      const playerCenterX = this.manager.width / 2;
      const playerCenterY = this.manager.height - 210;

      if (enemyHpDmg > 0) {
        const lastLog = this.logs[this.logs.length - 1] || ""; 
        const isCrit = lastLog.includes("克制") || lastLog.includes("引爆");
        this.addFloater(`-${enemyHpDmg}${isCrit ? ' 暴击' : ''}`, enemyCenterX, SAFE_TOP + 15, isCrit ? '#FFD700' : '#FF4444');
        
        if (isCrit) {
          soundManager.playSfx('crit');
          this.effects.triggerShake(14, 8);
          hapticHeavy();
        } else {
          soundManager.playSfx('hit');
          this.effects.triggerShake(6, 3.5);
          hapticLight();
        }
      } else if (enemyShieldDmg > 0) { 
        this.addFloater(`-${enemyShieldDmg} 破盾`, enemyCenterX, SAFE_TOP + 15, '#87CEEB');
        soundManager.playSfx('shield_break');
        this.effects.triggerShake(5, 2.5);
        hapticLight();
      }

      const heal = this.battle.player.hp - prevPlayerHp; 
      if (heal > 0) { 
        this.addFloater(`+${heal} 恢复`, playerCenterX, playerCenterY, '#4CAF50'); 
        soundManager.playSfx('heal');
        hapticLight();
      }
      const shieldGained = (this.battle.player.shield || 0) - prevPlayerShield; 
      if (shieldGained > 0) { 
        this.addFloater(`+${shieldGained} 护盾`, playerCenterX, playerCenterY - (heal > 0 ? 25 : 0), '#4A90D9'); 
        soundManager.playSfx('shield_block');
        hapticLight();
      }

      const lastLogMsg = this.logs[this.logs.length - 1] || '';
      if (lastLogMsg.includes('金印引爆')) {
        this.effects.triggerGoldSlash(enemyCenterX, enemyCenterY);
        soundManager.playSfx('mark_gold');
        hapticHeavy();
      } else if (lastLogMsg.includes('火印引爆')) {
        this.effects.triggerFireBurst(enemyCenterX, enemyCenterY);
        soundManager.playSfx('mark_fire');
        hapticHeavy();
      } else if (lastLogMsg.includes('水印引爆')) {
        this.effects.triggerWaterFreeze(enemyCenterX, enemyCenterY);
        soundManager.playSfx('mark_water');
        hapticHeavy();
      } else if (lastLogMsg.includes('木印引爆')) {
        this.effects.triggerWoodHeal(playerCenterX, playerCenterY);
        soundManager.playSfx('mark_wood');
        hapticMedium();
      } else if (lastLogMsg.includes('土印引爆')) {
        this.effects.triggerEarthShield(playerCenterX, playerCenterY);
        soundManager.playSfx('mark_earth');
        hapticMedium();
      }

      if (this.battle.enemy.hp > 0 && this.battle.enemy.hp <= this.battle.enemy.maxHp * 0.5 && !this.enrageDialogueTriggered) {
        if (this.battle.enemy.key === 'hei_shan_shan_xiao_wang') {
          this.enrageDialogueTriggered = true;
          this.startDialogue(CHAPTER_1_DIALOGUES.BOSS_ENRAGE);
          return;
        } else if (this.battle.enemy.key === 'yin_yang_pan_guan') {
          this.enrageDialogueTriggered = true;
          this.startDialogue(CHAPTER_2_DIALOGUES.BOSS_PHASE2);
          return;
        }
      }

      // 第三章 BOSS 九尾狐：两段形态转换剧情（60% 混沌之兽 / 30% 归墟之门）
      if (this.battle.enemy.key === 'jiu_wei_hu' && this.battle.enemy.hp > 0) {
        const ratio = this.battle.enemy.hp / this.battle.enemy.maxHp;
        if (ratio <= 0.3) {
          // 直接打进阶段三：标记阶段二已播过，避免重复
          this.jiuWeiPhase2DialoguePlayed = true;
          if (!this.jiuWeiPhase3DialoguePlayed) {
            this.jiuWeiPhase3DialoguePlayed = true;
            this.startDialogue(CHAPTER_3_DIALOGUES.BOSS_PHASE3, () => {
              this.showFinalChoice = true;
              this.buildUI();
            });
            return;
          }
        } else if (ratio <= 0.6 && !this.jiuWeiPhase2DialoguePlayed) {
          this.jiuWeiPhase2DialoguePlayed = true;
          this.startDialogue(CHAPTER_3_DIALOGUES.BOSS_PHASE2);
          return;
        }
      }

      if (this.battle.phase === "battle_end") {
        this.onBattleEnd(this.battle.win); 
      } else {
        this.buildUI();
      }
    },

    onEndTurn() {
      if (this.isWaitingEnemyTurn || this.suppressNextTap || this.showRelicReward || this.showBag || this.showVictoryModal || this.showChapterEndModal || this.showFinalChoice || this.showStoryIntro || this.showHandFullModal || this.isDialogueActive) {
        this.suppressNextTap = false;
        return;
      }
      if (!this.battle || this.battle.phase !== "player_action") return;

      const handCount = this.battle.player.cards.length;
      const skipWarning = isSkipHandFullWarning();

      if (handCount >= BATTLE.MAX_HAND_LIMIT && !skipWarning) {
        hapticLight();
        this.showHandFullModal = true;
        this.buildUI();
        return;
      }

      this.proceedEndTurn();
    },

    proceedEndTurn() {
      TutorialManager.completeAction('end_turn');

      this.isDiscardMode = false;
      this.isWaitingEnemyTurn = true;
      this.selectedCardIndex = -1;
      hapticLight();

      const prevPlayerHp = this.battle.player.hp; 
      const prevPlayerShield = this.battle.player.shield || 0; 
      const prevEnemyHp = this.battle.enemy.hp;
      
      this.battle = resolveEnemyTurn(this.battle); 
      this.logs = [...this.battle.log]; 
      this.logScrollY = 9999;
      this.buildUI();

      const enemyBurnDmg = prevEnemyHp - this.battle.enemy.hp; 
      if (enemyBurnDmg > 0) { 
        this.addFloater(`-${enemyBurnDmg} 灼烧`, this.manager.width / 2, SAFE_TOP + 15, '#FF6600'); 
        soundManager.playSfx('hit');
      }

      const playerDmg = prevPlayerHp - this.battle.player.hp; 
      const shieldAbsorbed = prevPlayerShield - (this.battle.player.shield || 0);

      if (playerDmg > 0) { 
        this.addFloater(`-${playerDmg}`, this.manager.width / 2, this.manager.height - 210, '#FF4444'); 
        soundManager.playSfx('hit');
        this.effects.triggerShake(10, 6);
        hapticHeavy();
      } else if (shieldAbsorbed > 0) { 
        this.addFloater(`-${shieldAbsorbed} 抵消`, this.manager.width / 2, this.manager.height - 210, '#87CEEB'); 
        soundManager.playSfx('shield_block');
        hapticLight();
      }

      if (this.battle.phase === "battle_end") {
        this.isWaitingEnemyTurn = false;
        this.onBattleEnd(this.battle.win); 
        return;
      }

      setTimeout(() => {
        if (this.manager.getCurrentSceneName() !== 'battle' || this.battle.phase === 'battle_end') return;
        
        const { battle: nextBattle, actualDrawn, keptCount } = startPlayerTurn(this.battle);
        this.battle = nextBattle;
        this.logs = [...this.battle.log];
        this.logScrollY = 9999;

        if (actualDrawn > 0) {
          this.applyDrawAnimation(keptCount, actualDrawn);
        }

        this.isWaitingEnemyTurn = false;
        this.buildUI();
      }, 450);
    },

    onBattleEnd(win) {
      this.showBag = false;
      this.isDiscardMode = false;
      this.isWaitingEnemyTurn = false;
      this.showHandFullModal = false;
      this.selectedCardIndex = -1;
      this.manager.input.clearButtons();

      // ★ 教学模式：胜利后直接进入正式游戏
      if (this.isTutorial) {
        if (win) {
          soundManager.playSfx('victory');
          hapticMedium();
          // 播放桃木傀儡战败对话，然后进入第一章
          this.startDialogue(CHAPTER_1_DIALOGUES.TUTORIAL_DEFEAT, () => {
            // 标记背景故事和序幕已完成，避免 MapScene 重复播放
            setStoryIntroDone(true);
            setPrologueDone(true);
            runManager.initRun(getSelectedChar() || 'taoist', 1);
            setTimeout(() => {
              this.manager.enterScene('map', { chapter: 1 });
            }, 500);
          });
        } else {
          // 教学失败，重试
          setTimeout(() => {
            this.enter({ isTutorial: true });
          }, 800);
        }
        return;
      }

      if (win) {
        const isCh1 = this.enemyIndex < 6;
        if (isCh1) {
          if (this.enemyIndex === 0) {
            this.startDialogue(CHAPTER_1_DIALOGUES.SHANXIAO_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex === 1) {
            this.startDialogue(CHAPTER_1_DIALOGUES.JIANGSHI_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex === 2) {
            this.startDialogue(CHAPTER_1_DIALOGUES.HULI_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex === 3) {
            this.startDialogue(CHAPTER_1_DIALOGUES.HUAPI_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex === 4) {
            this.startDialogue(CHAPTER_1_DIALOGUES.ELITE_WU_CHANG_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex === 5 || this.battle.enemy.key === 'hei_shan_shan_xiao_wang') {
            this.startDialogue(CHAPTER_1_DIALOGUES.BOSS_DEFEAT, () => this.proceedVictoryRewards());
          } else {
            this.proceedVictoryRewards();
          }
        } else {
          if (this.enemyIndex === 6) {
            this.startDialogue(CHAPTER_2_DIALOGUES.GUHUN_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex === 7) {
            this.startDialogue(CHAPTER_2_DIALOGUES.GUIHUO_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex === 8) {
            this.startDialogue(CHAPTER_2_DIALOGUES.ZHIZHA_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex === 9) {
            this.startDialogue(CHAPTER_2_DIALOGUES.ELITE_NIUTOU_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex === 10 || this.battle.enemy.key === 'yin_yang_pan_guan') {
            this.startDialogue(CHAPTER_2_DIALOGUES.BOSS_DEFEAT, () => this.proceedVictoryRewards());
          } else if (this.enemyIndex >= 11) {
            // 第三章敌人战败对话
            if (this.enemyIndex === 11) {
              this.startDialogue(CHAPTER_3_DIALOGUES.GUIXU_YUANHUN_DEFEAT, () => this.proceedVictoryRewards());
            } else if (this.enemyIndex === 12) {
              this.startDialogue(CHAPTER_3_DIALOGUES.SHILING_CANKE_DEFEAT, () => this.proceedVictoryRewards());
            } else if (this.enemyIndex === 13) {
              this.startDialogue(CHAPTER_3_DIALOGUES.HUNDUN_YOUHUN_DEFEAT, () => this.proceedVictoryRewards());
            } else if (this.enemyIndex === 14) {
              this.startDialogue(CHAPTER_3_DIALOGUES.GUIXU_SHIKUI_DEFEAT, () => this.proceedVictoryRewards());
            } else if (this.enemyIndex === 15) {
              this.startDialogue(CHAPTER_3_DIALOGUES.JIUWEI_SHANNIAN_DEFEAT, () => this.proceedVictoryRewards());
            } else if (this.enemyIndex === 16 || this.battle.enemy.key === 'jiu_wei_hu') {
              // 第三章Boss战败：特殊结局选择，暂直接进入奖励
              this.proceedVictoryRewards();
            } else {
              this.proceedVictoryRewards();
            }
          } else {
            this.proceedVictoryRewards();
          }
        }
      } else {
        soundManager.playSfx('defeat');
        hapticHeavy();
        const { width, height } = this.manager; 
        const btnW = 120; 
        const btnH = 42;
        const retryBtn = createButton(width / 2 - btnW - 12, height / 2 + 50, btnW, btnH, "重新挑战", { 
          fontSize: 15, 
          color: UI_COLORS.cinnabar, 
          textColor: "#FFF3CA", 
          tap: () => { 
            this.enter({ enemyIndex: this.enemyIndex, runState: this.entrySnapshot }); 
          } 
        });
        const giveUpBtn = createButton(width / 2 + 12, height / 2 + 50, btnW, btnH, "放弃轮回", { 
          fontSize: 15, 
          color: UI_COLORS.inkSoft, 
          textColor: "#D0C8B8", 
          tap: () => { 
            runManager.clearRun();
            this.manager.enterScene("menu"); 
          } 
        });
        this.manager.input.addTouchButton(retryBtn); 
        this.manager.input.addTouchButton(giveUpBtn); 
        this.buttons = [retryBtn, giveUpBtn];
      }
    },

    proceedVictoryRewards() {
      soundManager.playSfx('victory');
      hapticMedium();
      calculateVictoryReward(this);
    },

    // 第三章最终选择：玩家在4个结局分支中做选择
    handleFinalChoice(choiceKey) {
      this.showFinalChoice = false;
      this.ch3ChoiceKey = choiceKey;
      if (this.runState) {
        this.runState.ch3Choice = choiceKey;
        this.saveRunState();
      }
      const choiceDialogueMap = {
        fight: CHAPTER_3_DIALOGUES.CHOICE_FIGHT,
        join: CHAPTER_3_DIALOGUES.CHOICE_JOIN,
        persuade: CHAPTER_3_DIALOGUES.CHOICE_PERSUADE,
        truth: CHAPTER_3_DIALOGUES.CHOICE_TRUTH
      };
      const choiceDialogue = choiceDialogueMap[choiceKey] || CHAPTER_3_DIALOGUES.CHOICE_FIGHT;
      // 选择对话播完后，链入结尾过场
      this.startDialogue(choiceDialogue, () => {
        this.startDialogue(CHAPTER_3_DIALOGUES.ENDING_XUANMING_EYE, () => {
          this.startDialogue(CHAPTER_3_DIALOGUES.ENDING_TIANTING, () => {
            this.startDialogue(CHAPTER_3_DIALOGUES.ENDING_COMA, () => {
              this.startDialogue(CHAPTER_3_DIALOGUES.ENDING_CHAPTER4, () => {
                this.showChapterEndModal = true;
                this.buildUI();
              });
            });
          });
        });
      });
    },

    loadRunState() { 
      return runManager.state || runManager.load();
    },
    
    saveRunState() { 
      if (!this.runState) return; 
      runManager.setState(this.runState);
    },

    exit() {
      TutorialManager.exitScene();
      if (this.animation) this.animation.clear();
    },

    update() {
      if (this.effects) this.effects.update();
      if (this.animation) this.animation.update();
    },

    render(ctx) {
      const { width, height } = this.manager; 
      ctx.clearRect(0, 0, width, height);

      ctx.save();
      if (this.effects) {
        ctx.translate(this.effects.shakeOffsetX, this.effects.shakeOffsetY);
      }

      drawParchmentBackground(ctx, width, height);
      if (!this.battle) {
        ctx.restore();
        return;
      }

      // ★ 教学模式：播放4页背景故事
      if (this.isTutorial && this.storyPageIndex >= 0 && this.storyPageIndex < PROLOGUE_STORY_PAGES.length) {
        const page = PROLOGUE_STORY_PAGES[this.storyPageIndex];
        
        ctx.fillStyle = 'rgba(6, 3, 1, 0.94)';
        ctx.fillRect(0, 0, width, height);

        const panelW = Math.min(348, width - 20);
        const panelH = 430;
        const panelX = (width - panelW) / 2;
        const panelY = (height - panelH) / 2 - 10;

        drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: false });

        const titleY = panelY + 36;
        ctx.save();
        ctx.font = 'bold 18px "Songti SC", "SimSun", "STSong", serif';
        ctx.fillStyle = '#962A1F';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor = 'rgba(150, 42, 31, 0.35)';
        ctx.shadowBlur = 4;
        ctx.fillText(page.title, width / 2, titleY);
        ctx.restore();

        const lineY = panelY + 54;
        ctx.strokeStyle = '#D4AF37';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(panelX + 36, lineY);
        ctx.lineTo(panelX + panelW - 36, lineY);
        ctx.stroke();

        ctx.fillStyle = '#962A1F';
        ctx.beginPath();
        ctx.arc(width / 2, lineY, 2.5, 0, Math.PI * 2);
        ctx.fill();

        let curY = panelY + 74;
        page.paragraphs.forEach((pText) => {
          const maxTextW = panelW - 48;
          wrapDetailText(ctx, pText, panelX + 24, curY, maxTextW, 24, '#120904', 14);
          const lineCount = getWrappedLines(ctx, pText, maxTextW, 14).length;
          curY += lineCount * 24 + 10;
        });

        const alpha = Math.abs(Math.sin(Date.now() / 360));
        ctx.save();
        ctx.fillStyle = `rgba(150, 42, 31, ${0.65 + 0.35 * alpha})`;
        ctx.font = 'bold 12px "Songti SC", "SimSun", serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`— 轻触翻卷 (${this.storyPageIndex + 1}/${PROLOGUE_STORY_PAGES.length}) —`, width / 2, panelY + panelH - 24);
        ctx.restore();

        ctx.restore();
        return;
      }

      // ★ 教学模式对话阶段：隐藏战斗UI，只显示背景和对话框
      const hideBattleUI = this.isTutorial && this._tutorialPending;

      if (!hideBattleUI) {
        if (this.battle.phase === "battle_end" && !this.battle.win) {
          drawTextCentered(ctx, "道消身陨", width / 2, height / 2 - 35, "#9E2F24", 32, "serif"); 
          drawTextCentered(ctx, "妖气侵蚀，道基受损", width / 2, height / 2 + 10, "#5C3A1E", 14, "serif"); 
          renderButtons(this, ctx); 
          ctx.restore();
          return;
        }

        renderEnemyArea(this, ctx, width); 
        if (this.previewCardIndex >= 0) {
          renderCardPreview(this, ctx, width, height);
        } else {
          renderLogArea(this, ctx, width, height);
        }
        renderHand(this, ctx, width, height);       
        renderPlayerStatus(this, ctx, width, height);
        renderBuildStatus(this, ctx, width, height); 
      
      const isModalOpen = this.showStoryIntro || this.showBag || this.showVictoryModal || 
                          this.showChapterEndModal || this.showFinalChoice || this.showRelicReward || 
                          this.showHandFullModal || this.isDialogueActive || this.showBuildDetail || this.showCardReward;

      if (!isModalOpen) {
        renderButtons(this, ctx);
      }

      if (this.effects) {
        this.effects.render(ctx, width, height);
      }

      // 绘制拖拽出牌飞剑曲线与锁定准星
      if (this.draggingCardIndex !== -1 && this.effects) {
        const btn = this.cardButtons[this.draggingCardIndex];
        const startX = btn ? (btn.x + btn.w / 2) : width / 2;
        const startY = btn ? (btn.y + 10) : (height - 180);
        const enemyX = width / 2;
        const enemyY = SAFE_TOP + 46;

        this.effects.renderDragTrajectory(
          ctx,
          startX,
          startY,
          this.dragCurrentX,
          this.dragCurrentY,
          enemyX,
          enemyY,
          this.isTargetLocked
        );
      }

      if (this.animation) this.animation.renderFloaters(ctx);
      } // end if (!isPrologueStep)

      if (this.showVictoryModal) renderVictoryRewardModal(this, ctx, width, height);
      if (this.showRelicReward) renderRelicReward(this, ctx, width, height);
      if (this.showCardReward) renderCardReward(this, ctx, width, height);
      if (this.showChapterEndModal) renderChapterEndModal(this, ctx, width, height);
      if (this.showFinalChoice) renderFinalChoiceModal(this, ctx, width, height);
      if (this.showBag) renderBagModal(this, ctx, width, height);
      if (this.showStoryIntro) renderStoryOverlay(ctx, width, height, this.storyData);
      if (this.showHandFullModal) renderHandFullModal(this, ctx, width, height);
      if (this.showBuildDetail) renderBuildDetailModal(this, ctx, width, height);
      
      if (TutorialManager.isActive && !this.showStoryIntro) {
        const step = TutorialManager.getCurrentStep();
        const idx = TutorialManager.currentStepIndex;
        const total = TutorialManager.currentSteps.length;
        renderTutorial(ctx, step, width, height, idx, total);
      }

      if (this.isDialogueActive) {
        renderDialogueBox(this, ctx, width, height);
      }

      ctx.restore();
    },

    exit() {
      TutorialManager.exitScene();
    }
  };
}