import { 
  drawParchmentBackground, drawScrollPanel, drawTextCentered, createButton, drawSealButton, drawRoundedRect, UI_COLORS 
} from '../scene.js';
import { stepToNode } from '../map.js';
import { TutorialManager, renderTutorial, isSkipButtonTapped, REST_STEPS } from '../tutorial/index.js';
import { runManager } from '../RunManager.js';

// 墨金重工华彩框体
function drawInkGoldScrollModal(ctx, x, y, w, h) {
  ctx.save();
  ctx.shadowColor = 'rgba(212, 175, 55, 0.22)';
  ctx.shadowBlur = 20;
  ctx.shadowOffsetY = 8;
  drawRoundedRect(ctx, x, y, w, h, 14, '#1A0E08', '#0D0704', 3);
  ctx.restore();

  const goldGrad = ctx.createLinearGradient(x, y, x + w, y + h);
  goldGrad.addColorStop(0, '#E6C875');
  goldGrad.addColorStop(0.5, '#C49838');
  goldGrad.addColorStop(1, '#8C6018');
  drawRoundedRect(ctx, x + 2, y + 2, w - 4, h - 4, 12, null, goldGrad, 2);

  const paperGrad = ctx.createRadialGradient(x + w / 2, y + h * 0.45, w * 0.15, x + w / 2, y + h * 0.5, w * 0.85);
  paperGrad.addColorStop(0, '#FFFDF8');
  paperGrad.addColorStop(0.35, '#F9EED9');
  paperGrad.addColorStop(0.75, '#EBD5AD');
  paperGrad.addColorStop(1, '#CFA968');
  drawRoundedRect(ctx, x + 5, y + 5, w - 10, h - 10, 10, paperGrad, '#8F6126', 1.5);

  const innerMargin = 12;
  const ix = x + innerMargin;
  const iy = y + innerMargin;
  const iw = w - innerMargin * 2;
  const ih = h - innerMargin * 2;

  ctx.save();
  ctx.strokeStyle = 'rgba(150, 42, 31, 0.35)';
  ctx.lineWidth = 1;
  ctx.strokeRect(ix, iy, iw, ih);
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 1.2;
  ctx.strokeRect(ix + 3, iy + 3, iw - 6, ih - 6);

  const drawRoyalCorner = (cx, cy, dirX, dirY) => {
    ctx.strokeStyle = '#C99A3A';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(cx, cy + dirY * 16);
    ctx.lineTo(cx, cy);
    ctx.lineTo(cx + dirX * 16, cy);
    ctx.stroke();

    ctx.fillStyle = '#962A1F';
    ctx.fillRect(cx + dirX * 5, cy + dirY * 5, 3, 3);
  };

  drawRoyalCorner(ix + 5, iy + 5, 1, 1);
  drawRoyalCorner(ix + iw - 5, iy + 5, -1, 1);
  drawRoyalCorner(ix + 5, iy + ih - 5, 1, -1);
  drawRoyalCorner(ix + iw - 5, iy + ih - 5, -1, -1);
  ctx.restore();
}

function getWrappedLines(ctx, text, maxWidth, fontSize) {
  ctx.font = `${fontSize}px "Songti SC", "SimSun", "STSong", serif`;
  const str = text ? String(text) : '';
  if (!str) return [];
  const lines = [];
  let line = '';
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    const testLine = line + char;
    if (ctx.measureText(testLine).width > maxWidth && line !== '') {
      lines.push(line);
      line = char;
    } else {
      line = testLine;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function wrapDetailText(ctx, text, x, y, maxWidth, lineHeight, color, fontSize) {
  ctx.font = `500 ${fontSize}px "Songti SC", "SimSun", "STSong", serif`; 
  ctx.fillStyle = color || '#120904'; 
  ctx.textAlign = 'left'; 
  ctx.textBaseline = 'top';
  const lines = getWrappedLines(ctx, text, maxWidth, fontSize);
  lines.forEach((l, idx) => {
    ctx.fillText(l, x, y + idx * lineHeight);
  });
}

export function createRestScene(manager) {
  return {
    manager, 
    runState: null, 
    buttons: [], 
    hasRested: false, 
    restMessage: '',

    enter(data) {
      if (data?.runState) runManager.setState(data.runState);
      else runManager.load();
      this.runState = runManager.state;
      this.hasRested = false; 
      this.restMessage = '';
      this.buildUI();

      // 启动休息新手引导
      const activated = TutorialManager.enterScene('rest', REST_STEPS, {
        onStepChange: () => { this.buildUI(); },
        onComplete: () => { this.buildUI(); }
      });
      if (activated) this.buildUI();
    },

    buildUI() {
      const { width, height } = this.manager; 
      this.manager.input.clearButtons(); 
      this.buttons = [];
      this._tutorialBlockTaps = false;

      // 新手教程触摸拦截
      if (TutorialManager.isActive && !this.hasRested) {
        const step = TutorialManager.getCurrentStep();
        this.manager.input.addTapHandler((x, y) => {
          if (isSkipButtonTapped(x, y, width)) {
            TutorialManager.skipAll();
            this.buildUI();
          }
        });
        if (!step || step.type !== 'action') {
          this._tutorialBlockTaps = true;
        }
      }
      
      if (!this.hasRested) {
        const btnW = 160; 
        const btnH = 42; 
        const btnX = width / 2 - btnW / 2;
        const maxHp = this.runState.maxHp || 30; 
        const healAmount = Math.floor(maxHp * 0.3);
        
        this.buttons.push(createButton(btnX, height - 160, btnW, btnH, `吐纳调息 (气血+${healAmount})`, { 
          fontSize: 13, 
          color: '#2B6B46', 
          strokeColor: '#A3E4D7',
          textColor: '#FFF8DD', 
          tap: () => this.doRest('heal', healAmount) 
        }));
        this.buttons.push(createButton(btnX, height - 100, btnW, btnH, '静心冥想 (因果+1)', { 
          fontSize: 13, 
          color: '#8A6225', 
          strokeColor: '#FFE599',
          textColor: '#FFF8DD', 
          tap: () => this.doRest('karma', 1) 
        }));
      } else {
        this.buttons.push(createButton(width / 2 - 75, height - 80, 150, 42, '启程前行', { 
          fontSize: 15, 
          color: UI_COLORS.cinnabar, 
          strokeColor: '#FFD700',
          textColor: '#FFF8DD', 
          tap: () => this.proceedToMap() 
        }));
      }

      if (this._tutorialBlockTaps) {
        this.manager.input.addTapHandler((x, y) => {
          if (isSkipButtonTapped(x, y, width)) return;
          const advanced = TutorialManager.advance();
          if (advanced) this.buildUI();
        });
        this._tutorialBlockTaps = false;
      } else {
        this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
      }
    },

    doRest(type, amount) {
      // 新手引导：完成"选择调息方式"操作
      TutorialManager.completeAction('do_rest');

      if (type === 'heal') {
        this.runState.hp = Math.min(this.runState.maxHp, this.runState.hp + amount);
        this.restMessage = `你盘膝坐于蒲团之上，双目微阖，抱元守一。引一缕清风入泥丸宫，周天运转，洗涤脏腑中的尸瘴与煞气，道体气血恢复了 ${amount} 点。`;
      } else {
        this.runState.karma = Math.min(10, (this.runState.karma || 0) + amount);
        this.restMessage = `你面壁叩问本心，凝视着山神断首处的粗糙石痕，思索着这漫山妖魔生前的悲苦与执念。心中杀意渐退，道心愈发澄澈空明，善业因果增加了 ${amount} 点。`;
      }
      this.hasRested = true; 
      runManager.save(); 
      this.buildUI();
    },

    proceedToMap() {
      if (this.runState && this.runState.currentNodeId && this.runState.map) {
         this.runState.map = stepToNode(this.runState.map, this.runState.currentNodeId);
         runManager.save();
      }
      this.manager.enterScene('map');
    },

    render(ctx) {
      const { width, height } = this.manager; 
      ctx.clearRect(0, 0, width, height); 
      drawParchmentBackground(ctx, width, height);
      
      if (!this.runState) return;

      const panelW = width - 20;
      const panelH = 340;
      const panelX = 10;
      const panelY = 48;

      drawInkGoldScrollModal(ctx, panelX, panelY, panelW, panelH);

      drawTextCentered(ctx, '【 残 龛 调 息 · 山 神 残 像 】', width / 2, panelY + 34, UI_COLORS.cinnabar, 18, 'serif');

      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(panelX + 32, panelY + 54);
      ctx.lineTo(panelX + panelW - 32, panelY + 54);
      ctx.stroke();

      if (!this.hasRested) {
        const ambientText = "在绝壁背风处，有一方凿空山岩而建的古老石龛。龛内供奉着一尊早已断去头颅的山神石雕。不知是哪位过路的樵夫在石像前插了半截未燃尽的松香。在这充满暴戾妖气的黑风山中，唯有这方寸之地，依然残留着一丝纯净的天地灵气。";
        wrapDetailText(ctx, ambientText, panelX + 24, panelY + 74, panelW - 48, 22, '#120904', 13);
        
        drawTextCentered(ctx, `当前道体：气血 ${this.runState.hp}/${this.runState.maxHp}  |  善因果 ${this.runState.karma || 0}`, width / 2, panelY + 280, '#8C2A24', 12, 'serif');
      } else {
        wrapDetailText(ctx, this.restMessage, panelX + 24, panelY + 80, panelW - 48, 24, '#120904', 14);
        
        ctx.strokeStyle = "rgba(180, 130, 70, 0.4)"; 
        ctx.lineWidth = 1; 
        ctx.beginPath(); 
        ctx.moveTo(panelX + 30, panelY + 240); 
        ctx.lineTo(panelX + panelW - 30, panelY + 240); 
        ctx.stroke();
        
        drawTextCentered(ctx, `调息完毕：气血 ${this.runState.hp}/${this.runState.maxHp}  |  善因果 ${this.runState.karma || 0}`, width / 2, panelY + 265, '#2E6B46', 13, 'serif');
      }

      this.buttons.forEach(btn => drawSealButton(ctx, btn));

      // 新手引导层
      if (TutorialManager.isActive && !this.hasRested) {
        const step = TutorialManager.getCurrentStep();
        const idx = TutorialManager.currentStepIndex;
        const total = TutorialManager.currentSteps.length;
        renderTutorial(ctx, step, width, height, idx, total);
      }
    },

    exit() {
      TutorialManager.exitScene();
    }
  };
}