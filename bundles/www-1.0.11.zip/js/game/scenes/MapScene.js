import { 
  SCREEN_WIDTH, SCREEN_HEIGHT, SAFE_TOP, TOP_BAR_Y, TOP_BAR_H, CAPSULE_LEFT 
} from '../../render.js';
import { 
  drawParchmentBackground, drawScrollPanel, drawSealButton, drawRoundedRect, 
  drawTextCentered, drawTextLeft, drawTextRight, measureText, createButton, UI_COLORS 
} from '../scene.js';
import { 
  drawInkGoldModal, drawNameplate, getWrappedLines, wrapDetailText 
} from '../../config/ui-components.js';
import { NODE_TYPES, generateChapterMap, stepToNode, findNodeById } from '../map.js';
import { CHARACTERS } from '../types.js';
import { soundManager } from '../../runtime/music.js';
import { TutorialManager, renderTutorial, isSkipButtonTapped, MAP_STEPS } from '../tutorial/index.js';
import { isStoryIntroDone, setStoryIntroDone, setPrologueDone, isChapter2IntroDone, setChapter2IntroDone, isChapter3IntroDone, setChapter3IntroDone, getSelectedChar } from '../../config/storage.js';
import { CHAPTER_2_DIALOGUES } from '../story/chapter2Dialogues.js';
import { getKarmaModifier, calculateKarmaTier, KARMA_TIERS } from '../../config/KarmaModifiers.js';
import { hapticLight } from '../../config/haptics.js';
import { runManager } from '../RunManager.js';

const NODE_CONFIG = {
  [NODE_TYPES.BATTLE]: { bg: '#78231C', border: '#D4AF37', text: '#FFF3CA', icon: '⚔', label: '古刹小妖' },
  [NODE_TYPES.ELITE]: { bg: '#4D1845', border: '#BA43AA', text: '#FFD6FA', icon: '👹', label: '阴司凶煞' },
  [NODE_TYPES.EVENT]: { bg: '#183152', border: '#4A90D9', text: '#D8EBFF', icon: '📜', label: '荒冢机缘' },
  [NODE_TYPES.SHOP]:  { bg: '#5C3C0D', border: '#FFB834', text: '#FFF2C6', icon: '🪙', label: '山路坊市' },
  [NODE_TYPES.REST]:  { bg: '#1E5235', border: '#52BE80', text: '#E8F8F0', icon: '🪷', label: '残龛调息' },
  [NODE_TYPES.BOSS]:  { bg: '#911717', border: '#FFD700', text: '#FFF8DD', icon: '👑', label: '终局魁首' }
};

// ==================== 完整宏大背景与序幕长卷 ====================
export const PROLOGUE_STORY_PAGES = [
  {
    title: '【 天 道 有 阙 · 三 界 崩 解 】',
    paragraphs: [
      '自上古封神定序以来，天地分为天庭、人间、幽冥三界。天庭掌日月星辰与五行气运，人间承生老病死与红尘万象，幽冥司转世轮回与善恶清算。三界各安其道，维系于一口自鸿蒙初辟便流转不息的“周天五行灵脉”。',
      '近百年来人间战乱频仍，饿殍遍野，怨气冲霄；天庭神明寂然无声，幽冥六道轮回巨轮渐渐滞涩生锈。每逢月圆之夜极阴滋生，两界壁垒薄如蝉翼。',
      '阴阳失衡导致五行逆流：金失其锐化为杀孽，木失其生化为枯腐，水失其润化为阴浊，火失其烈化为煞火，土失其厚化为尸瘴。'
    ]
  },
  {
    title: '【 兰 若 古 刹 · 隐 秘 往 事 】',
    paragraphs: [
      '黑风岭地处中原与西陲交界，山巅筑有一座始建于梁唐时期的千年巨刹——兰若寺。寺庙所坐落的灵穴深处，恰好镇压着一条直通幽冥枉死城的“黄泉阴脉”。',
      '当年寺中主持法显禅师亲手种下一株通灵古柏，受百年生人香火洗礼化为护寺神灵“黑山山神”。',
      '十年前幽冥地府突发惊天异变，判官颠倒生死簿封锁鬼门关，千万冤魂逆流上涌。兰若寺僧众舍命布阵尽数圆寂。佛光湮灭后，古树根须浸透冤魂血泪，山神堕为万妖之首“黑山山魈王”，黑风岭彻底沦为人间鬼蜮。'
    ]
  },
  {
    title: '【 青 城 道 承 · 师 尊 托 孤 】',
    paragraphs: [
      '你本是青城山玄门正宗的一名寻常游方道士，自幼随师在深山研习五行符箓与八卦易理。中元前夕，师尊夜观天象，见紫微垣晦暗、天狼星赤红如血，地脉灵泉一夜干涸。',
      '师尊焚香推演七日七夜，得出血染卦象：“阴阳倒悬，冥府空寂；五行逆乱，生灵涂炭。”',
      '弥留之际，师尊将代代相传的五行符囊、斩妖桃木剑与能映照三世因果的【因果镜】郑重托付于你：'
    ]
  },
  {
    title: '【 负 剑 启 程 · 雾 锁 黑 风 】',
    paragraphs: [
      '“徒儿，此去黑风岭，只为探明阴泉渗漏之源。山中妖邪皆为恶世所逼。出牌之时，心怀慈悲则因果归善，行雷霆手段则因果归杀。降妖者若心堕欲海，便与妖邪无异……”',
      '你负剑背囊，毅然踏出山门。山下暮色如血，远处黑风岭上空黑云如墨，隐隐传来凄厉的鬼哭与野兽的咆哮。',
      '手握青铜因果镜，眼前的漫天妖雾与幽冥深渊，正等待你的道法与初心去裁决……'
    ]
  }
];

const PROLOGUE_DIALOGUES = [
  {
    speaker: '游方道士',
    tag: '道',
    side: 'left',
    avatarColor: '#2B6B46',
    text: '（按住怀中剧烈发烫的因果镜）黑风岭果然煞气滔天……漫山古木尽化枯煞，地底阴脉已然彻底暴动！'
  },
  {
    speaker: '师尊遗音',
    tag: '魂',
    side: 'right',
    avatarColor: '#C99A3A',
    text: '『徒儿，五行相克乃天地至理。金克木、木克土、土克水、水克火、火克金。善用符印，莫负苍生……』'
  },
  {
    speaker: '游方道士',
    tag: '道',
    side: 'left',
    avatarColor: '#2B6B46',
    text: '弟子谨遵师命！前方山门小妖作祟，且容弟子拔剑破开这漫天阴障！'
  }
];

// ==================== 第二章背景与序幕 ====================
const CH2_STORY_PAGES = [
  {
    title: '【 幽 冥 枉 死 · 六 道 崩 坏 】',
    paragraphs: [
      '黑山山魈王伏诛之际，兰若寺地底深渊轰然洞开，黄泉死水咆哮上涌。你手持阴司判官令，随钟馗天师踏入这传说中的幽冥地府。',
      '然而映入眼帘的并非庄严肃穆的十殿阎罗，而是一片死寂绝望的枉死鬼城。忘川之水逆流翻滚，奈何桥被生生斩断，亿万生魂在血水中哀嚎挣扎。',
      '十殿阎罗尽被封禁，六道轮回巨轮锈迹斑斑。阴阳判官私篡生死簿，将整座地府化作一座吞噬魂魄的熔魂磨盘。'
    ]
  },
  {
    title: '【 熔 魂 磨 盘 · 生 死 逆 判 】',
    paragraphs: [
      '判官以朱笔重画乾坤：善人横死、恶人长生，阳间寿数被随意涂改，无数冤魂被强行塞入纸人躯壳充作阴司衙役。',
      '更有甚者，他在森罗大殿中央开启了【万劫生死冥界阵】，借用归墟深处的上古妖煞，将十殿阎罗封入血海阵眼，妄图以一己意志取代天道轮回。',
      '而这一切的背后，似乎还隐藏着一个更大的阴谋——归墟封印的裂痕中，九道幽红妖尾正在深渊中缓缓苏醒。'
    ]
  },
  {
    title: '【 仗 剑 入 冥 · 荡 平 枉 死 】',
    paragraphs: [
      '钟馗天师按剑而立，沉声道：「小道友，地府乃三界之基。判官虽强，却不过是受人摆布的提线木偶。真正的浩劫，在归墟深渊之下。」',
      '你握紧桃木剑，五行符囊在腰间微微震颤。前方鬼门紧闭，牛头阿傍把守要道，无数孤魂野鬼在死雾中游荡。',
      '但你道心已决——纵是九幽地狱，今日也要闯上一闯！荡平枉死城，重开六道轮，揭开归墟封印背后的惊天秘密！'
    ]
  }
];

// ==================== 第三章背景与序幕 ====================
const CH3_STORY_PAGES = [
  {
    title: '【 归 墟 裂 口 · 九 幽 深 渊 】',
    paragraphs: [
      '阴阳判官伏法之际，森罗大殿地底轰然塌陷，一道深不见底的归墟裂口赫然显现。九道遮天蔽日的幽红妖尾在深渊暗影中狂乱舞动，上古封印已然破碎。',
      '钟馗天师按剑立于深渊之畔，沉声道：「判官不过是受人摆布的提线木偶。归墟已破，混沌九尾即将吞噬三界灵脉！小道友，持此莲花化身之引，随吾杀入九幽最深处！」',
      '你纵身跃入归墟裂口，四周阴风呼啸如雷，夹杂着亿万生魂的哭嚎。脚下不再是人间泥土，而是泛着铅灰色微光的冰冷沙砾。天穹无日无月，唯有惨白磷火在浓重的黑色死雾中幽幽沉浮。'
    ]
  },
  {
    title: '【 万 魂 哭 墙 · 前 世 回 廊 】',
    paragraphs: [
      '穿过怨魂群，你来到一面巨大的哭墙前。墙面上无数张扭曲的面孔在不断蠕动、哀嚎——那是被九尾吞噬的亿万生魂。突然，一张熟悉的面孔引起了你的注意——兰若寺的绣娘。',
      '继续深入，你进入了一片奇异的空间——前世回廊。无数面巨大的铜镜悬浮在虚空中，每一面镜子都映照出不同的画面。伏魔天师的声音从镜中传来：「这里是前世回廊。归墟之力将你的三生三世都翻了出来。」',
      '第二面镜子照见了你的前世——身着天庭官服，手持执律金鞭，站在归墟封印之前。你偷了天庭的蟠桃，送给了被封印的九尾。然后，你走到封印最深处，看到了那扇门——玄冥封印录。'
    ]
  },
  {
    title: '【 封 神 遗 址 · 六 道 崩 毁 】',
    paragraphs: [
      '青丘废墟深处，你遇到了九尾分离出的最后一丝善念残响。她等待着你的到来，只为问一句：如果天道本身是谎言，你会怎么做？',
      '封神台遗址上，你翻阅着上古神将留下的残页，得知了一个惊天秘密——钟馗当年并非自愿入地府，而是被天庭灭口后封入伏魔镜中。',
      '六道轮回盘前，你面临最终抉择：修复轮回，维持天道秩序；还是加速崩毁，让玄冥重见天日。而在这一切的尽头，九尾狐正在开启归墟之门，门后是被封印了万亿年的创世古神——玄冥。'
    ]
  }
];

export function createMapScene(manager) {
  return {
    manager,
    runState: null,
    buttons: [],
    nodeButtons: [],
    selectedNode: null,
    showConfirmModal: false,
    showBag: false,
    showReturnModal: false,
    scrollY: 0,
    isDragging: false,
    touchStartY: 0,
    lastTouchY: 0,
    contentHeight: 0,
    topLimit: 0,
    hasBoundTouch: false,

    showStoryIntro: false,
    storyPageIndex: 0,
    dialogueIndex: 0,
    showSkipConfirmModal: false,

    bagScrollY: 0,
    isDraggingBag: false,
    bagTouchStartY: 0,
    bagLastTouchY: 0,
    bagDragDistance: 0,
    bagContentHeight: 0,

    // 因果长按详情
    showKarmaDetail: false,
    _karmaLongPressTimer: null,
    _karmaTouchStart: null,

    // 渲染坐标缓存（不进入游戏数据模型，不持久化）
    nodeRenderCache: {},

    enter(data) {
      soundManager.stopAllSfx();
      soundManager.playBgm('map');

      // 统一通过 RunManager 管理单局状态
      if (data?.runState) {
        runManager.setState(data.runState);
      } else {
        runManager.load();
      }
      this.runState = runManager.state;
      
      if (!this.runState) {
        this.runState = runManager.initRun(data?.charId || 'taoist');
      }

      if (!Array.isArray(this.runState.map) || this.runState.map.length === 0) {
        const chapter = this.runState.chapter || 1;
        this.runState.map = generateChapterMap(chapter, 8, this.runState.karma || 0);
        this.runState.currentNodeId = null;
        runManager.save();
      }

      this.showConfirmModal = false;
      this.selectedNode = null;
      this.showBag = false;
      this.showReturnModal = false;
      this.showSkipConfirmModal = false;
      this.bagScrollY = 0;
      this.nodeRenderCache = {}; // 清空渲染坐标缓存

      const isFirstChapter = (this.runState.chapter === 1);
      const isSecondChapter = (this.runState.chapter === 2);
      const isThirdChapter = (this.runState.chapter === 3);
      const currentNode = findNodeById(this.runState.map, this.runState.currentNodeId);
      const isFirstNode = (!currentNode || currentNode.row === 0);
      const ch1StoryDone = isStoryIntroDone();
      const ch2StoryDone = isChapter2IntroDone();
      const ch3StoryDone = isChapter3IntroDone();

      if (isFirstChapter && isFirstNode && !ch1StoryDone) {
        this.showStoryIntro = true;
        this.storyPageIndex = 0;
        this.dialogueIndex = 0;
        this._storyChapter = 1;
      } else if (isSecondChapter && isFirstNode && !ch2StoryDone) {
        this.showStoryIntro = true;
        this.storyPageIndex = 0;
        this.dialogueIndex = 0;
        this._storyChapter = 2;
      } else if (isThirdChapter && isFirstNode && !ch3StoryDone) {
        this.showStoryIntro = true;
        this.storyPageIndex = 0;
        this.dialogueIndex = 0;
        this._storyChapter = 3;
      } else {
        this.showStoryIntro = false;
        this._storyChapter = this.runState.chapter || 1;
      }

      this.initMapTouchListeners();
      this.buildUI(true); 

      if (!this.showStoryIntro) {
        this._startMapTutorialIfNeeded();
      }
    },

    clampBagScroll() {
      const height = this.manager.height;
      const panelH = Math.min(480, height - 80);
      const viewportH = panelH - 80;
      if (this.bagContentHeight <= viewportH) {
        this.bagScrollY = 0;
        return;
      }
      const minScroll = viewportH - this.bagContentHeight;
      this.bagScrollY = Math.max(minScroll, Math.min(0, this.bagScrollY));
    },

    initMapTouchListeners() {
      if (this.hasBoundTouch) return;
      this.hasBoundTouch = true;

      wx.onTouchStart((e) => {
        if (this.manager.getCurrentSceneName() !== 'map') return;
        if (!e.touches || e.touches.length === 0) return;
        const touch = e.touches[0];

        // 因果详情弹窗已显示时，点击任意处关闭
        if (this.showKarmaDetail) {
          this.showKarmaDetail = false;
          this.buildUI();
          return;
        }

        if (this.showStoryIntro) return;

        // 因果图标长按检测
        if (this._karmaBadgeRect) {
          const r = this._karmaBadgeRect;
          if (touch.clientX >= r.x && touch.clientX <= r.x + r.w &&
              touch.clientY >= r.y && touch.clientY <= r.y + r.h) {
            this._karmaTouchStart = { x: touch.clientX, y: touch.clientY, time: Date.now() };
            this._karmaLongPressTimer = setTimeout(() => {
              this.showKarmaDetail = true;
              this._karmaLongPressTimer = null;
              hapticLight();
              this.buildUI();
            }, 500);
          }
        }

        if (this.showBag) {
          this.isDraggingBag = true;
          this.bagTouchStartY = touch.clientY;
          this.bagLastTouchY = touch.clientY;
          return;
        }

        if (this.showConfirmModal || this.showReturnModal || this.showSkipConfirmModal) return;
        if (touch.clientY > this.topLimit) {
          this.isDragging = true;
          this.lastTouchY = touch.clientY;
          this.touchStartY = touch.clientY;
        }
      });

      wx.onTouchMove((e) => {
        if (!e.touches || e.touches.length === 0) return;
        const touch = e.touches[0];

        if (this.showStoryIntro) return;

        // 移动距离过大时取消因果长按
        if (this._karmaTouchStart && this._karmaLongPressTimer) {
          const dx = touch.clientX - this._karmaTouchStart.x;
          const dy = touch.clientY - this._karmaTouchStart.y;
          if (Math.sqrt(dx * dx + dy * dy) > 15) {
            clearTimeout(this._karmaLongPressTimer);
            this._karmaLongPressTimer = null;
            this._karmaTouchStart = null;
          }
        }

        if (this.showBag && this.isDraggingBag) {
          const dy = touch.clientY - this.bagLastTouchY;
          this.bagLastTouchY = touch.clientY;
          this.bagScrollY += dy;
          this.clampBagScroll();
          return;
        }

        if (!this.isDragging || this.showConfirmModal || this.showReturnModal || this.showSkipConfirmModal) return;
        const dy = touch.clientY - this.lastTouchY;
        this.lastTouchY = touch.clientY;
        this.scrollY += dy;
        this.clampScroll();
        this.updateNodePositions();
      });

      const endDrag = () => {
        // 清除因果长按定时器
        if (this._karmaLongPressTimer) {
          clearTimeout(this._karmaLongPressTimer);
          this._karmaLongPressTimer = null;
        }
        this._karmaTouchStart = null;

        if (this.showStoryIntro) return;
        if (this.isDraggingBag) {
          this.isDraggingBag = false;
          this.clampBagScroll();
        }
        this.isDragging = false;
        this.clampScroll();
        this.updateNodePositions();
      };
      wx.onTouchEnd(endDrag);
      wx.onTouchCancel(endDrag);
    },

    clampScroll() {
      const { height } = this.manager;
      const viewportH = height - this.topLimit - 12;
      if (this.contentHeight <= viewportH) {
        this.scrollY = 0;
        return;
      }
      const minScroll = viewportH - this.contentHeight;
      this.scrollY = Math.max(minScroll, Math.min(0, this.scrollY));
    },

    updateNodePositions() {
      this.nodeButtons.forEach(btn => {
        if (btn.baseY !== undefined) {
          btn.y = btn.baseY + this.scrollY;
        }
      });
    },

    getNodeMetrics(type) {
      if (type === NODE_TYPES.BOSS) {
        return { radius: 30, iconSize: 24, btnW: 72, btnH: 84 };
      } else if (type === NODE_TYPES.ELITE) {
        return { radius: 25, iconSize: 20, btnW: 64, btnH: 76 };
      } else {
        return { radius: 23, iconSize: 18, btnW: 60, btnH: 72 };
      }
    },

    advanceStory() {
      const isCh2 = this._storyChapter === 2;
      const isCh3 = this._storyChapter === 3;
      let storyPages, dialogues;
      if (isCh3) {
        storyPages = CH3_STORY_PAGES;
        dialogues = [];
      } else if (isCh2) {
        storyPages = CH2_STORY_PAGES;
        dialogues = CHAPTER_2_DIALOGUES.PROLOGUE;
      } else {
        storyPages = PROLOGUE_STORY_PAGES;
        dialogues = PROLOGUE_DIALOGUES;
      }

      if (this.storyPageIndex < storyPages.length - 1) {
        this.storyPageIndex++;
        this.buildUI();
      } else if (this.storyPageIndex === storyPages.length - 1 && dialogues.length > 0 && this.dialogueIndex === 0) {
        this.storyPageIndex++;
        this.buildUI();
      } else if (dialogues.length > 0 && this.dialogueIndex < dialogues.length - 1) {
        this.dialogueIndex++;
        this.buildUI();
      } else {
        this.finishStoryIntro();
      }
    },

    finishStoryIntro() {
      this.showStoryIntro = false;
      this.showSkipConfirmModal = false;
      if (this._storyChapter === 3) {
        setChapter3IntroDone(true);
      } else if (this._storyChapter === 2) {
        setChapter2IntroDone(true);
      } else {
        setStoryIntroDone(true);
        setPrologueDone(true);
      }

      if (!this.runState) {
        this.runState = { chapter: 1, characterId: getSelectedChar() || 'taoist', hp: 30, maxHp: 30, gold: 50, karma: 0, relics: [], allCards: [], currentNodeId: null, map: [] };
      }
      if (!Array.isArray(this.runState.map) || this.runState.map.length === 0) {
        this.runState.map = generateChapterMap(this.runState.chapter || 1, 8);
        this.runState.currentNodeId = null;
        runManager.save();
      }

      this.buildUI(true);
      this._startMapTutorialIfNeeded();
    },

    _startMapTutorialIfNeeded() {
      if (this.runState?.currentNode) return;
      const activated = TutorialManager.enterScene('map', MAP_STEPS, {
        onStepChange: () => { this.buildUI(); },
        onComplete: () => { this.buildUI(); }
      });
      if (activated) this.buildUI();
    },

    buildUI(autoFocusCurrentRow = false) {
      const { width, height } = this.manager;
      this.manager.input.clearButtons();
      this.buttons = [];
      this.nodeButtons = [];

      const safeTopY = isFinite(TOP_BAR_Y) ? TOP_BAR_Y : 50;
      const safeTopH = isFinite(TOP_BAR_H) ? TOP_BAR_H : 32;

      if (this.showStoryIntro) {
        if (this.showSkipConfirmModal) {
          this.buildSkipConfirmModalUI();
          return;
        }

        const skipBtnW = 54;
        const skipBtnX = width - skipBtnW - 12;
        const skipBtnY = safeTopY;
        const skipBtnH = safeTopH;

        const skipBtn = createButton(skipBtnX, skipBtnY, skipBtnW, skipBtnH, '跳过', {
          fontSize: 13,
          color: 'rgba(38, 24, 14, 0.94)',
          strokeColor: '#D4AF37',
          textColor: '#FFF3CA',
          tap: () => {
            soundManager.playSfx('btn_click');
            this.showSkipConfirmModal = true;
            this.buildUI();
          }
        });
        this.buttons.push(skipBtn);
        this.manager.input.addTouchButton(skipBtn);

        this.manager.input.addTapHandler((x, y) => {
          if (!this.showStoryIntro || this.showSkipConfirmModal) return;
          if (x >= skipBtnX && x <= skipBtnX + skipBtnW && y >= skipBtnY && y <= skipBtnY + skipBtnH) return;
          soundManager.playSfx('btn_click');
          this.advanceStory();
        });
        return;
      }

      if (!this.runState || !Array.isArray(this.runState.map)) return;

      if (this.showReturnModal) {
        this.buildReturnModalUI();
        return;
      }

      if (this.showConfirmModal) {
        this.buildConfirmModalUI();
        return;
      }

      if (this.showBag) {
        this.manager.input.addTapHandler((x, y) => {
          if (!this.showBag) return;
          if (Math.abs(y - this.bagTouchStartY) > 12) return;
          soundManager.playSfx('btn_click');
          this.showBag = false;
          this.buildUI();
        });
        return;
      }

      this._tutorialBlockTaps = false;
      if (TutorialManager.isActive) {
        const step = TutorialManager.getCurrentStep();
        this.manager.input.addTapHandler((x, y) => {
          if (isSkipButtonTapped(x, y, width)) {
            TutorialManager.skipAll();
            this.buildUI();
          }
        });
        if (!step || step.type !== 'action') {
          this._tutorialBlockTaps = true;
        }
      }

      this.buttons.push(createButton(12, safeTopY, 52, safeTopH, '归卷', {
        fontSize: 13,
        tap: () => {
          soundManager.playSfx('btn_click');
          this.showReturnModal = true;
          this.buildUI();
        },
        color: UI_COLORS.inkSoft,
        textColor: '#D0C8B8'
      }));

      this.buttons.push(createButton(68, safeTopY, 52, safeTopH, '锦囊', {
        fontSize: 13,
        tap: () => {
          soundManager.playSfx('btn_click');
          this.showBag = true;
          this.bagScrollY = 0;
          this.buildUI();
        },
        color: UI_COLORS.cinnabar,
        textColor: '#FFF3CA'
      }));

      const statusY = safeTopY + safeTopH + 8;
      const badgeH = 26;
      this.topLimit = statusY + badgeH + 12;

      const mapData = this.runState.map;
      const totalRows = mapData.length;
      const rowHeight = 98;    
      const paddingTop = 54;   
      const paddingBottom = 48;

      this.contentHeight = (totalRows - 1) * rowHeight + paddingTop + paddingBottom;

      for (let r = 0; r < totalRows; r++) {
        const rowNodes = mapData[r] || [];
        const colsCount = rowNodes.length;
        const spacingX = width / (colsCount + 1);
        const nodeY = this.topLimit + paddingTop + (totalRows - 1 - r) * rowHeight;

        for (let c = 0; c < colsCount; c++) {
          const node = rowNodes[c];
          if (!node) continue;

          const nodeX = spacingX * (c + 1);
          this.nodeRenderCache[node.id] = { x: nodeX, y: nodeY };

          const metrics = this.getNodeMetrics(node.type);
          const isClickable = node.status === 'available';

          const btn = createButton(
            nodeX - metrics.btnW / 2, 
            nodeY - metrics.radius - 4, 
            metrics.btnW, 
            metrics.btnH, 
            '', 
            {
              tap: () => {
                if (Math.abs(this.touchStartY - this.lastTouchY) > 8) return;
                if (isClickable) {
                  soundManager.playSfx('btn_click');
                  this.selectedNode = node;
                  this.showConfirmModal = true;
                  this.buildUI();
                } else if (node.status === 'locked') {
                  wx.showToast({ title: '前路未通，需先清肃前哨', icon: 'none' });
                } else if (node.status === 'visited') {
                  wx.showToast({ title: '此处妖患已除', icon: 'none' });
                }
              }
            }
          );

          btn.baseY = nodeY - metrics.radius - 4;
          btn.node = node;
          this.nodeButtons.push(btn);
        }
      }

      if (this._tutorialBlockTaps) {
        this.manager.input.addTapHandler((x, y) => {
          if (isSkipButtonTapped(x, y, width)) return;
          const advanced = TutorialManager.advance();
          if (advanced) {
            soundManager.playSfx('btn_click');
            this.buildUI();
          }
        });
        this._tutorialBlockTaps = false;
      } else {
        this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
        this.nodeButtons.forEach(btn => this.manager.input.addTouchButton(btn));
      }

      if (autoFocusCurrentRow) {
        let focusRow = 0;
        const currentNode = findNodeById(this.runState.map, this.runState.currentNodeId);
        if (currentNode) {
          focusRow = currentNode.row;
        } else {
          for (let r = 0; r < totalRows; r++) {
            if ((mapData[r] || []).some(n => n.status === 'available')) {
              focusRow = r;
              break;
            }
          }
        }

        const viewportH = height - this.topLimit - 12;
        const targetNodeY = this.topLimit + paddingTop + (totalRows - 1 - focusRow) * rowHeight;
        const idealScroll = (this.topLimit + viewportH * 0.65) - targetNodeY;
        const minScroll = viewportH - this.contentHeight;
        this.scrollY = Math.max(minScroll, Math.min(0, idealScroll));
      }

      this.clampScroll();
      this.updateNodePositions();
    },

    buildSkipConfirmModalUI() {
      const { width, height } = this.manager;
      this.manager.input.clearButtons();
      this.buttons = [];

      const panelW = Math.min(310, width - 36);
      const panelH = 210;
      const panelY = (height - panelH) / 2;
      const btnW = 110;
      const btnH = 38;
      const btnY = panelY + panelH - 48;

      const cancelBtn = createButton(width / 2 - btnW - 10, btnY, btnW, btnH, '暂且细看', {
        fontSize: 14,
        color: UI_COLORS.cinnabar,
        textColor: '#FFF3CA',
        tap: () => {
          soundManager.playSfx('btn_click');
          this.showSkipConfirmModal = false;
          this.buildUI();
        }
      });

      const confirmSkipBtn = createButton(width / 2 + 10, btnY, btnW, btnH, '执意跳过', {
        fontSize: 14,
        color: UI_COLORS.inkSoft,
        textColor: '#D0C8B8',
        tap: () => {
          soundManager.playSfx('btn_click');
          this.finishStoryIntro();
        }
      });

      this.buttons = [cancelBtn, confirmSkipBtn];
      this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
    },

    buildReturnModalUI() {
      const { width, height } = this.manager;
      this.manager.input.clearButtons();
      this.buttons = [];
      const panelW = Math.min(300, width - 40);
      const panelH = 190;
      const panelY = (height - panelH) / 2;
      const btnW = 105;
      const btnH = 36;
      const btnY = panelY + panelH - 46;

      const cancelBtn = createButton(width / 2 - btnW - 10, btnY, btnW, btnH, '继续降妖', {
        fontSize: 14, color: UI_COLORS.cinnabar, textColor: '#FFF3CA',
        tap: () => { soundManager.playSfx('btn_click'); this.showReturnModal = false; this.buildUI(); }
      });
      const confirmBtn = createButton(width / 2 + 10, btnY, btnW, btnH, '封卷存录', {
        fontSize: 14, color: UI_COLORS.inkSoft, textColor: '#D0C8B8',
        tap: () => { soundManager.playSfx('btn_click'); this.showReturnModal = false; runManager.save(); this.manager.enterScene('menu'); }
      });
      this.buttons = [cancelBtn, confirmBtn];
      this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
    },

    buildConfirmModalUI() {
      const { width, height } = this.manager;
      this.manager.input.clearButtons();
      this.buttons = [];
      const node = this.selectedNode;
      if (!node) { this.showConfirmModal = false; this.buildUI(); return; }

      const panelW = Math.min(300, width - 40);
      const panelH = 210;
      const panelY = (height - panelH) / 2;
      const btnW = 105;
      const btnH = 36;
      const btnY = panelY + panelH - 48;

      const cancelBtn = createButton(width / 2 - btnW - 10, btnY, btnW, btnH, '暂缓决策', {
        fontSize: 14, color: UI_COLORS.inkSoft, textColor: '#D0C8B8',
        tap: () => { soundManager.playSfx('btn_click'); this.showConfirmModal = false; this.selectedNode = null; this.buildUI(); }
      });
      const confirmBtn = createButton(width / 2 + 10, btnY, btnW, btnH, '毅然前往', {
        fontSize: 14, color: UI_COLORS.cinnabar, textColor: '#FFF3CA',
        tap: () => { soundManager.playSfx('btn_click'); this.proceedToNode(node); }
      });
      this.buttons = [cancelBtn, confirmBtn];
      this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
    },

    proceedToNode(node) {
      TutorialManager.completeAction('select_node');

      this.showConfirmModal = false;
      this.runState.currentNodeId = node.id;
      runManager.save();

      if (node.type === NODE_TYPES.BATTLE || node.type === NODE_TYPES.ELITE || node.type === NODE_TYPES.BOSS) {
        this.manager.enterScene('battle', { enemyIndex: node.enemyIndex, runState: this.runState });
      } else if (node.type === NODE_TYPES.SHOP) {
        this.manager.enterScene('shop', { runState: this.runState });
      } else if (node.type === NODE_TYPES.EVENT) {
        this.manager.enterScene('event', { eventData: node.eventData, runState: this.runState });
      } else if (node.type === NODE_TYPES.REST) {
        this.manager.enterScene('rest', { runState: this.runState });
      }
    },

    render(ctx) {
      try {
        const { width, height } = this.manager;
        ctx.clearRect(0, 0, width, height);
        drawParchmentBackground(ctx, width, height);

        if (this.showStoryIntro) {
          this.renderStoryIntroSequence(ctx, width, height);
          if (this.showSkipConfirmModal) {
            this.renderSkipConfirmModal(ctx, width, height);
          }
          return;
        }

        if (!this.runState) return;

        if (this.nodeButtons.length === 0 && !this._buildingUI) {
          this._buildingUI = true;
          try {
            if (!Array.isArray(this.runState.map) || this.runState.map.length === 0) {
              this.runState.map = generateChapterMap(this.runState.chapter || 1, 8);
              this.runState.currentNodeId = null;
            }
            this.buildUI(true);
          } catch(e) { console.error('[MapScene] rebuild failed', e); }
          this._buildingUI = false;
        }

        this.renderTopBar(ctx, width);
        const scrollH = height - this.topLimit - 10;
        
        ctx.save();
        ctx.beginPath();
        ctx.rect(0, this.topLimit, width, scrollH);
        ctx.clip();

        this.renderConnections(ctx);
        this.renderNodes(ctx);
        ctx.restore();

        if (!this.showConfirmModal && !this.showBag && !this.showReturnModal) {
          this.buttons.forEach(btn => drawSealButton(ctx, btn));
        }

        if (this.showConfirmModal) this.renderConfirmModal(ctx, width, height);
        if (this.showReturnModal) this.renderReturnModal(ctx, width, height);
        if (this.showBag) this.renderBagModal(ctx, width, height);
        if (this.showKarmaDetail) this.renderKarmaDetail(ctx, width, height);

        if (TutorialManager.isActive) {
          const step = TutorialManager.getCurrentStep();
          const idx = TutorialManager.currentStepIndex;
          const total = TutorialManager.currentSteps.length;
          renderTutorial(ctx, step, width, height, idx, total);
        }
      } catch (e) {
        console.error('[MapScene render error]', e);
      }
    },

    renderStoryIntroSequence(ctx, width, height) {
      const isCh2 = this._storyChapter === 2;
      const isCh3 = this._storyChapter === 3;
      let storyPages, dialogues;
      if (isCh3) {
        storyPages = CH3_STORY_PAGES;
        dialogues = []; // 第三章暂无对话序幕
      } else if (isCh2) {
        storyPages = CH2_STORY_PAGES;
        dialogues = CHAPTER_2_DIALOGUES.PROLOGUE;
      } else {
        storyPages = PROLOGUE_STORY_PAGES;
        dialogues = PROLOGUE_DIALOGUES;
      }

      if (this.storyPageIndex < storyPages.length) {
        const page = storyPages[this.storyPageIndex];
        
        ctx.fillStyle = 'rgba(6, 3, 1, 0.94)';
        ctx.fillRect(0, 0, width, height);

        const panelW = Math.min(348, width - 20);
        const panelH = 430;
        const panelX = (width - panelW) / 2;
        const panelY = (height - panelH) / 2 - 10;

        drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: false });

        const titleY = panelY + 36;
        ctx.save();
        ctx.font = 'bold 18px "Songti SC", "SimSun", "STSong", serif';
        ctx.fillStyle = '#962A1F';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor = 'rgba(150, 42, 31, 0.35)';
        ctx.shadowBlur = 4;
        ctx.fillText(page.title, width / 2, titleY);
        ctx.restore();

        const lineY = panelY + 54;
        ctx.strokeStyle = '#D4AF37';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(panelX + 36, lineY);
        ctx.lineTo(panelX + panelW - 36, lineY);
        ctx.stroke();

        ctx.fillStyle = '#962A1F';
        ctx.beginPath();
        ctx.arc(width / 2, lineY, 2.5, 0, Math.PI * 2);
        ctx.fill();

        let curY = panelY + 74;
        page.paragraphs.forEach((pText) => {
          const maxTextW = panelW - 48;
          wrapDetailText(ctx, pText, panelX + 24, curY, maxTextW, 24, '#120904', 14);
          const lineCount = getWrappedLines(ctx, pText, maxTextW, 14).length;
          curY += lineCount * 24 + 10;
        });

        const alpha = Math.abs(Math.sin(Date.now() / 360));
        ctx.save();
        ctx.fillStyle = `rgba(150, 42, 31, ${0.65 + 0.35 * alpha})`;
        ctx.font = 'bold 12px "Songti SC", "SimSun", serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`— 轻触翻卷 (${this.storyPageIndex + 1}/${storyPages.length}) —`, width / 2, panelY + panelH - 24);
        ctx.restore();

      } else {
        const line = dialogues[this.dialogueIndex];
        if (!line) return;

        ctx.fillStyle = 'rgba(6, 3, 1, 0.90)';
        ctx.fillRect(0, 0, width, height);

        const panelW = width - 20;
        const panelH = 184;
        const panelX = 10;
        const panelY = height - panelH - 24;

        drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: true });

        const isLeft = line.side === 'left';
        drawNameplate(ctx, {
          speaker: line.speaker,
          tag: line.tag || '道',
          avatarColor: line.avatarColor || UI_COLORS.cinnabar,
          isLeft,
          panelX,
          panelY,
          panelW
        });

        wrapDetailText(ctx, line.text, panelX + 24, panelY + 40, panelW - 48, 24, '#120904', 14);

        const alpha = Math.abs(Math.sin(Date.now() / 350));
        ctx.fillStyle = `rgba(150, 42, 31, ${0.65 + 0.35 * alpha})`;
        ctx.font = '12px serif';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'bottom';
        ctx.fillText('轻触继续 ▾', panelX + panelW - 22, panelY + panelH - 16);
      }

      this.buttons.forEach(btn => drawSealButton(ctx, btn));
    },

    renderSkipConfirmModal(ctx, width, height) {
      ctx.fillStyle = 'rgba(4, 2, 1, 0.94)';
      ctx.fillRect(0, 0, width, height);

      const panelW = Math.min(310, width - 36);
      const panelH = 210;
      const panelX = (width - panelW) / 2;
      const panelY = (height - panelH) / 2;

      drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: true });

      drawTextCentered(ctx, '【 跳 过 剧 情 】', width / 2, panelY + 36, UI_COLORS.cinnabar, 19, 'serif');

      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(panelX + 24, panelY + 56);
      ctx.lineTo(panelX + panelW - 24, panelY + 56);
      ctx.stroke();

      drawTextCentered(ctx, '是否要跳过开篇背景故事与序幕对话？', width / 2, panelY + 88, '#120904', 14, 'serif');
      drawTextCentered(ctx, '（※ 提示：跳过可能导致剧情体验不完整）', width / 2, panelY + 116, '#8C2A24', 12, 'serif');

      this.buttons.forEach(btn => drawSealButton(ctx, btn));
    },

    renderTopBar(ctx, width) {
      const safeTopY = isFinite(TOP_BAR_Y) ? TOP_BAR_Y : 50;
      const safeTopH = isFinite(TOP_BAR_H) ? TOP_BAR_H : 32;
      const chapter = this.runState.chapter || 1;
      let chapTitle;
      if (chapter === 1) chapTitle = '第一章 · 荒冢古刹';
      else if (chapter === 2) chapTitle = '第二章 · 幽冥枉死城';
      else chapTitle = '第三章 · 归墟觉醒';
      drawTextLeft(ctx, `【${chapTitle}】`, 128, safeTopY + 16, UI_COLORS.ink, 15, 'serif');
      
      const statusY = safeTopY + safeTopH + 8;
      const totalW = width - 24;
      const badgeW = (totalW - 12) / 3;
      const badgeH = 26;

      const hpX = 12;
      drawRoundedRect(ctx, hpX, statusY, badgeW, badgeH, 13, 'rgba(244, 230, 215, 0.95)', 'rgba(140, 42, 36, 0.45)', 1.2);
      drawRoundedRect(ctx, hpX + 3, statusY + 3, 20, 20, 10, '#8C2A24', '#D4AF37', 1);
      drawTextCentered(ctx, '血', hpX + 13, statusY + 13, '#FFF3CA', 11, 'serif');
      drawTextCentered(ctx, `${this.runState.hp}/${this.runState.maxHp}`, hpX + 26 + (badgeW - 26) / 2, statusY + 13, '#8C2A24', 12, 'serif');

      const goldX = hpX + badgeW + 6;
      drawRoundedRect(ctx, goldX, statusY, badgeW, badgeH, 13, 'rgba(244, 230, 215, 0.95)', 'rgba(184, 134, 11, 0.45)', 1.2);
      drawRoundedRect(ctx, goldX + 3, statusY + 3, 20, 20, 10, '#9A731F', '#FFE599', 1);
      drawTextCentered(ctx, '铜', goldX + 13, statusY + 13, '#FFF8DD', 11, 'serif');
      drawTextCentered(ctx, `${this.runState.gold}`, goldX + 26 + (badgeW - 26) / 2, statusY + 13, '#8C6212', 12, 'serif');

      const karmaX = goldX + badgeW + 6;
      // 保存因果图标位置，用于长按检测
      this._karmaBadgeRect = { x: karmaX, y: statusY, w: badgeW, h: badgeH };
      drawRoundedRect(ctx, karmaX, statusY, badgeW, badgeH, 13, 'rgba(244, 235, 212, 0.95)', 'rgba(43, 107, 70, 0.45)', 1.2);
      drawRoundedRect(ctx, karmaX + 3, statusY + 3, 20, 20, 10, '#2B6B46', '#A3E4D7', 1);
      drawTextCentered(ctx, '因', karmaX + 13, statusY + 13, '#FFF8DD', 11, 'serif');
      drawTextCentered(ctx, `${this.runState.karma > 0 ? '+' : ''}${this.runState.karma}`, karmaX + 26 + (badgeW - 26) / 2, statusY + 13, '#1E5235', 12, 'serif');

      ctx.strokeStyle = 'rgba(180, 130, 70, 0.35)'; ctx.lineWidth = 1; ctx.beginPath();
      ctx.moveTo(12, statusY + badgeH + 7); ctx.lineTo(width - 12, statusY + badgeH + 7); ctx.stroke();
    },

    renderConnections(ctx) {
      if (!this.runState || !Array.isArray(this.runState.map)) return;
      const mapData = this.runState.map;

      ctx.save();
      for (let r = 0; r < mapData.length - 1; r++) {
        const currentNodes = mapData[r] || [];
        const nextNodes = mapData[r + 1] || [];
        currentNodes.forEach(fromNode => {
          if (!fromNode || !fromNode.next) return;
          fromNode.next.forEach(nextId => {
            const toNode = nextNodes.find(n => n.id === nextId);
            if (!toNode) return;
            const fromPos = this.nodeRenderCache[fromNode.id];
            const toPos = this.nodeRenderCache[toNode.id];
            if (!fromPos || !toPos) return;
            const fromY = fromPos.y + this.scrollY;
            const toY = toPos.y + this.scrollY;
            ctx.beginPath(); ctx.moveTo(fromPos.x, fromY); ctx.lineTo(toPos.x, toY);
            if (fromNode.status === 'visited' && (toNode.status === 'visited' || toNode.status === 'available')) {
              ctx.strokeStyle = '#D4AF37'; ctx.lineWidth = 2.8;
            } else {
              ctx.strokeStyle = 'rgba(140, 110, 80, 0.35)'; ctx.lineWidth = 1.4;
            }
            ctx.stroke();
          });
        });
      }
      ctx.restore();
    },

    drawNodeIcon(ctx, type, cx, cy, size, color) {
      ctx.save();
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.lineWidth = 1.6;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (type === NODE_TYPES.BATTLE) {
        // 双剑交叉
        const s = size * 0.5;
        ctx.beginPath();
        // 剑1（左上到右下）
        ctx.moveTo(cx - s, cy - s);
        ctx.lineTo(cx + s * 0.7, cy + s * 0.7);
        // 剑2（右上到左下）
        ctx.moveTo(cx + s, cy - s);
        ctx.lineTo(cx - s * 0.7, cy + s * 0.7);
        ctx.stroke();
        // 剑格（护手）
        ctx.lineWidth = 1.3;
        const g = s * 0.28;
        // 剑1护手
        ctx.beginPath();
        ctx.moveTo(cx - g - 1, cy - g + 1);
        ctx.lineTo(cx - g + 5, cy - g - 5);
        ctx.moveTo(cx + g - 1, cy + g + 1);
        ctx.lineTo(cx + g - 5, cy + g + 5);
        // 剑2护手
        ctx.moveTo(cx + g + 1, cy - g + 1);
        ctx.lineTo(cx + g - 5, cy - g - 5);
        ctx.moveTo(cx - g + 1, cy + g + 1);
        ctx.lineTo(cx - g + 5, cy + g + 5);
        ctx.stroke();
      } else if (type === NODE_TYPES.ELITE) {
        // 鬼面（妖邪面具）
        const s = size * 0.42;
        // 脸部轮廓
        ctx.beginPath();
        ctx.moveTo(cx, cy - s);
        ctx.quadraticCurveTo(cx + s, cy - s * 0.6, cx + s * 0.85, cy + s * 0.3);
        ctx.quadraticCurveTo(cx + s * 0.5, cy + s, cx, cy + s * 0.8);
        ctx.quadraticCurveTo(cx - s * 0.5, cy + s, cx - s * 0.85, cy + s * 0.3);
        ctx.quadraticCurveTo(cx - s, cy - s * 0.6, cx, cy - s);
        ctx.stroke();
        // 双角
        ctx.beginPath();
        ctx.moveTo(cx - s * 0.6, cy - s * 0.7);
        ctx.quadraticCurveTo(cx - s * 0.9, cy - s * 1.15, cx - s * 0.45, cy - s * 0.95);
        ctx.moveTo(cx + s * 0.6, cy - s * 0.7);
        ctx.quadraticCurveTo(cx + s * 0.9, cy - s * 1.15, cx + s * 0.45, cy - s * 0.95);
        ctx.stroke();
        // 双眼
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(cx - s * 0.32, cy - s * 0.05, 1.8, 0, Math.PI * 2);
        ctx.arc(cx + s * 0.32, cy - s * 0.05, 1.8, 0, Math.PI * 2);
        ctx.fill();
        // 獠牙缝
        ctx.beginPath();
        ctx.moveTo(cx - s * 0.2, cy + s * 0.35);
        ctx.lineTo(cx, cy + s * 0.55);
        ctx.lineTo(cx + s * 0.2, cy + s * 0.35);
        ctx.stroke();
      } else if (type === NODE_TYPES.EVENT) {
        // 卷轴
        const w = size * 0.7;
        const h = size * 0.55;
        // 卷轴主体
        ctx.beginPath();
        ctx.rect(cx - w / 2, cy - h / 2, w, h);
        ctx.stroke();
        // 左右轴杆
        ctx.beginPath();
        ctx.arc(cx - w / 2, cy, 2.5, -Math.PI / 2, Math.PI / 2);
        ctx.arc(cx + w / 2, cy, 2.5, Math.PI / 2, -Math.PI / 2);
        ctx.stroke();
        // 内部文字线
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(cx - w * 0.3, cy - h * 0.1);
        ctx.lineTo(cx + w * 0.3, cy - h * 0.1);
        ctx.moveTo(cx - w * 0.3, cy + h * 0.15);
        ctx.lineTo(cx + w * 0.15, cy + h * 0.15);
        ctx.stroke();
      } else if (type === NODE_TYPES.SHOP) {
        // 铜钱（外圆内方）
        const r = size * 0.4;
        const sq = r * 0.45;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.rect(cx - sq, cy - sq, sq * 2, sq * 2);
        ctx.stroke();
      } else if (type === NODE_TYPES.REST) {
        // 莲花
        const s = size * 0.42;
        ctx.beginPath();
        // 外层花瓣
        for (let i = 0; i < 6; i++) {
          const a = (Math.PI / 3) * i - Math.PI / 2;
          const px = cx + Math.cos(a) * s;
          const py = cy + Math.sin(a) * s;
          ctx.moveTo(cx, cy);
          ctx.quadraticCurveTo(
            cx + Math.cos(a - 0.3) * s * 0.6,
            cy + Math.sin(a - 0.3) * s * 0.6,
            px, py
          );
          ctx.quadraticCurveTo(
            cx + Math.cos(a + 0.3) * s * 0.6,
            cy + Math.sin(a + 0.3) * s * 0.6,
            cx, cy
          );
        }
        ctx.stroke();
        // 花心
        ctx.beginPath();
        ctx.arc(cx, cy, s * 0.25, 0, Math.PI * 2);
        ctx.stroke();
      } else if (type === NODE_TYPES.BOSS) {
        // 皇冠
        const w = size * 0.75;
        const h = size * 0.5;
        ctx.beginPath();
        ctx.moveTo(cx - w / 2, cy + h / 2);
        ctx.lineTo(cx - w / 2, cy - h / 4);
        ctx.lineTo(cx - w / 4, cy + h / 8);
        ctx.lineTo(cx, cy - h / 2);
        ctx.lineTo(cx + w / 4, cy + h / 8);
        ctx.lineTo(cx + w / 2, cy - h / 4);
        ctx.lineTo(cx + w / 2, cy + h / 2);
        ctx.closePath();
        ctx.stroke();
        // 底座线
        ctx.beginPath();
        ctx.moveTo(cx - w / 2, cy + h / 2);
        ctx.lineTo(cx + w / 2, cy + h / 2);
        ctx.stroke();
        // 宝石
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(cx, cy + h * 0.15, 2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    },

    renderNodes(ctx) {
      if (!this.runState || !Array.isArray(this.runState.map)) return;

      this.nodeButtons.forEach(btn => {
        const node = btn.node; if (!node) return;
        const pos = this.nodeRenderCache[node.id];
        if (!pos) return;
        const nx = pos.x; const ny = pos.y + this.scrollY;
        const metrics = this.getNodeMetrics(node.type); const radius = metrics.radius;
        const isBoss = node.type === NODE_TYPES.BOSS; const conf = NODE_CONFIG[node.type] || NODE_CONFIG[NODE_TYPES.BATTLE];

        ctx.save();
        if (node.status === 'available') {
          const alpha = 0.4 + 0.6 * Math.sin(Date.now() / 240); ctx.shadowColor = '#FFD700'; ctx.shadowBlur = 16 * alpha;
          drawRoundedRect(ctx, nx - radius - 4, ny - radius - 4, (radius + 4) * 2, (radius + 4) * 2, radius + 4, null, '#FFD700', 2.5);
        }

        let bg = conf.bg; let border = conf.border; let iconCol = conf.text; let nameCol = '#4A3425';
        if (node.status === 'visited') {
          bg = 'rgba(60, 48, 38, 0.85)'; border = '#7A685A'; iconCol = '#A09284'; nameCol = '#8A7A6A';
        } else if (node.status === 'locked') {
          ctx.globalAlpha = 0.52; nameCol = 'rgba(80, 60, 45, 0.65)';
        }

        drawRoundedRect(ctx, nx - radius, ny - radius, radius * 2, radius * 2, radius, bg, border, isBoss ? 3.0 : 2.0);
        this.drawNodeIcon(ctx, node.type, nx, ny + 1, metrics.iconSize, iconCol);
        ctx.globalAlpha = 1.0;

        const displayName = node.name || conf.label;
        ctx.font = '12px serif'; ctx.fillStyle = nameCol; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
        ctx.fillText(displayName, nx, ny + radius + 7);
        if (node.status === 'available') {
          ctx.font = '12px sans-serif'; ctx.fillStyle = '#FFD700'; ctx.fillText('▼', nx, ny - radius - 16);
        }
        ctx.restore();
      });
    },

    renderReturnModal(ctx, width, height) {
      ctx.fillStyle = 'rgba(10, 6, 2, 0.82)';
      ctx.fillRect(0, 0, width, height);

      const panelW = Math.min(300, width - 40);
      const panelH = 190;
      const panelY = (height - panelH) / 2;

      drawInkGoldModal(ctx, (width - panelW) / 2, panelY, panelW, panelH, { isDialogue: true });

      drawTextCentered(ctx, '【 归 卷 存 录 】', width / 2, panelY + 34, UI_COLORS.cinnabar, 19, 'serif');

      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo((width - panelW) / 2 + 20, panelY + 52);
      ctx.lineTo((width - panelW) / 2 + panelW - 20, panelY + 52);
      ctx.stroke();

      const desc = '道友欲暂歇修行？当前降妖机缘与道体修为皆已妥善封存，随时可自首页再续前缘。';
      wrapDetailText(ctx, desc, (width - panelW) / 2 + 20, panelY + 70, panelW - 40, 22, '#120904', 13);

      for (const btn of this.buttons) {
        drawSealButton(ctx, btn);
      }
    },

    renderConfirmModal(ctx, width, height) {
      const node = this.selectedNode; if (!node) return;
      ctx.fillStyle = 'rgba(10, 6, 2, 0.82)'; ctx.fillRect(0, 0, width, height);
      const panelW = Math.min(300, width - 40); const panelH = 210; const panelY = (height - panelH) / 2;
      
      drawInkGoldModal(ctx, (width - panelW) / 2, panelY, panelW, panelH, { isDialogue: true });

      drawTextCentered(ctx, `【 ${node.name} 】`, width / 2, panelY + 34, UI_COLORS.cinnabar, 19, 'serif');
      ctx.strokeStyle = '#D4AF37'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo((width - panelW) / 2 + 20, panelY + 52); ctx.lineTo((width - panelW) / 2 + panelW - 20, panelY + 52); ctx.stroke();
      
      let desc = '前路艰险，妖氛弥漫。道友是否要前往此地？';
      if (node.type === NODE_TYPES.ELITE) desc = '煞气浓烈！此地盘踞着强大的阴司凶煞，战胜可获稀世法宝。';
      else if (node.type === NODE_TYPES.BOSS) desc = '魁首巢穴！斩杀此地大妖即可功德圆满，涤荡妖氛！';
      else if (node.type === NODE_TYPES.SHOP) desc = '偶遇云游货郎与阴司鬼市，可在此消耗铜钱置办符箓法宝。';
      else if (node.type === NODE_TYPES.REST) desc = '灵气汇聚之地，可在此吐纳调息，恢复道体气血。';
      else if (node.type === NODE_TYPES.EVENT) desc = '前方偶现机缘微光，或为神仙洞府，或为山野奇遇。';
      wrapDetailText(ctx, desc, (width - panelW) / 2 + 20, panelY + 70, panelW - 40, 22, '#120904', 13);
      for (const btn of this.buttons) drawSealButton(ctx, btn);
    },

    renderBagModal(ctx, width, height) {
      ctx.fillStyle = 'rgba(10, 6, 2, 0.78)'; 
      ctx.fillRect(0, 0, width, height); 
      const panelW = Math.min(320, width - 36); 
      const panelH = Math.min(480, height - 80); 
      const panelX = (width - panelW) / 2; 
      const panelY = (height - panelH) / 2;
      
      drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: false }); 
      drawTextCentered(ctx, "修 真 锦 囊", width / 2, panelY + 28, UI_COLORS.cinnabar, 20, "serif");
      
      ctx.strokeStyle = '#D4AF37'; 
      ctx.lineWidth = 1; 
      ctx.beginPath(); 
      ctx.moveTo(panelX + 20, panelY + 46); 
      ctx.lineTo(panelX + panelW - 20, panelY + 46); 
      ctx.stroke();

      const clipY = panelY + 48;
      const clipH = panelH - 74;
      ctx.save();
      ctx.beginPath();
      ctx.rect(panelX + 4, clipY, panelW - 8, clipH);
      ctx.clip();
      
      let curY = clipY + 8 + this.bagScrollY;

      drawTextLeft(ctx, "【 道 体 资 产 】", panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
      curY += 16;
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, 34, 5, 'rgba(238, 226, 198, 0.75)', 'rgba(160, 120, 70, 0.3)', 1);
      drawTextLeft(ctx, `铜钱: ${this.runState ? this.runState.gold : 0} 文`, panelX + 28, curY + 17, "#C99A3A", 13, "serif"); 
      drawTextLeft(ctx, `因果善业: ${(this.runState?.karma || 0) > 0 ? '+' : ''}${this.runState?.karma || 0}`, panelX + 155, curY + 17, "#2B6B46", 13, "serif");
      curY += 44;

      const charConfig = CHARACTERS[this.runState?.characterId] || CHARACTERS.taoist;
      drawTextLeft(ctx, "【 道 统 传 承 】", panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
      curY += 16;
      const passiveText = `【${charConfig.name}】 被动：${charConfig.passive}`;
      const passiveLines = getWrappedLines(ctx, passiveText, panelW - 48, 11);
      const passiveBoxH = Math.max(34, 12 + passiveLines.length * 16);
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, passiveBoxH, 5, 'rgba(238, 226, 198, 0.75)', 'rgba(160, 120, 70, 0.3)', 1);
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#2B6B46'; 
      ctx.textAlign = 'left'; 
      ctx.textBaseline = 'top';
      passiveLines.forEach((l, i) => {
        ctx.fillText(l, panelX + 24, curY + 8 + i * 16);
      });
      curY += passiveBoxH + 12;

      const allCards = this.runState?.allCards || [];
      const star2Cards = allCards.filter(c => c.star === 2);
      const star1Cards = allCards.filter(c => c.star === 1 || (c.isUpgraded && c.star !== 2));
      const shopBoughtCards = allCards.filter(c => c.price !== undefined || c.isPermanentSupply);
      
      drawTextLeft(ctx, `【 道 藏 牌 库 一 览 】 (共 ${allCards.length} 张)`, panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
      curY += 16;

      const star2Str = star2Cards.length > 0 ? star2Cards.map(c => c.name.replace(/\+*$/, '★★极')).join('、') : '暂无二星极品符箓';
      const star2Lines = getWrappedLines(ctx, star2Str, panelW - 48, 11);
      const star2BoxH = 22 + star2Lines.length * 16 + 6;
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, star2BoxH, 5, 'rgba(244, 235, 212, 0.88)', '#BA43AA', 1.2);
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#5C1D54'; 
      ctx.textAlign = 'left'; 
      ctx.textBaseline = 'top';
      ctx.fillText(`二星·极阶符箓 (${star2Cards.length}张):`, panelX + 24, curY + 6);
      star2Lines.forEach((l, i) => {
        ctx.fillText(l, panelX + 24, curY + 22 + i * 16);
      });
      curY += star2BoxH + 8;

      const star1Str = star1Cards.length > 0 ? star1Cards.map(c => c.name.replace(/\+*$/, '★')).join('、') : '暂无一星进阶符箓';
      const star1Lines = getWrappedLines(ctx, star1Str, panelW - 48, 11);
      const star1BoxH = 22 + star1Lines.length * 16 + 6;
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, star1BoxH, 5, 'rgba(244, 235, 212, 0.88)', '#2B6B46', 1.2);
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#2B6B46'; 
      ctx.textAlign = 'left'; 
      ctx.textBaseline = 'top';
      ctx.fillText(`一星·进阶符箓 (${star1Cards.length}张):`, panelX + 24, curY + 6);
      star1Lines.forEach((l, i) => {
        ctx.fillText(l, panelX + 24, curY + 22 + i * 16);
      });
      curY += star1BoxH + 8;

      const shopStr = shopBoughtCards.length > 0 ? shopBoughtCards.map(c => c.name).join('、') : '暂无';
      const shopLines = getWrappedLines(ctx, shopStr, panelW - 48, 11);
      const shopBoxH = 22 + shopLines.length * 16 + 6;
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, shopBoxH, 5, 'rgba(244, 235, 212, 0.88)', '#C99A3A', 1.2);
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#8C6212'; 
      ctx.textAlign = 'left'; 
      ctx.textBaseline = 'top';
      ctx.fillText(`货郎坊市购得 (${shopBoughtCards.length}张):`, panelX + 24, curY + 6);
      shopLines.forEach((l, i) => {
        ctx.fillText(l, panelX + 24, curY + 22 + i * 16);
      });
      curY += shopBoxH + 12;

      const relics = this.runState?.relics || []; 
      drawTextLeft(ctx, `【 已 纳 法 宝 】 (${relics.length} 件)`, panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
      curY += 16;
      
      if (relics.length === 0) { 
        drawTextCentered(ctx, "行囊空空，尚未寻得法宝机缘", width / 2, curY + 16, "#888888", 12, "serif"); 
        curY += 36;
      } else { 
        relics.forEach((relic) => { 
          const relicDesc = relic.description || relic.desc || '蕴含灵力的随身秘宝。';
          const relicLines = getWrappedLines(ctx, relicDesc, panelW - 52, 11);
          const relicBoxH = Math.max(46, 20 + relicLines.length * 15 + 6);
          drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, relicBoxH, 5, 'rgba(244, 235, 212, 0.9)', '#C99A3A', 1); 
          drawTextLeft(ctx, relic.name, panelX + 26, curY + 12, UI_COLORS.ink, 13, "serif"); 
          ctx.font = '11px serif'; 
          ctx.fillStyle = '#543825'; 
          ctx.textAlign = 'left'; 
          ctx.textBaseline = 'top';
          relicLines.forEach((l, i) => {
            ctx.fillText(l, panelX + 26, curY + 24 + i * 15);
          });
          curY += relicBoxH + 8; 
        }); 
      }

      this.bagContentHeight = curY - (clipY + 8 + this.bagScrollY) + 12;
      ctx.restore();

      drawTextCentered(ctx, "— 上下滑动浏览 · 点击任意处收拢 —", width / 2, panelY + panelH - 14, "#8A6D4B", 11, "serif");
    },

    renderKarmaDetail(ctx, width, height) {
      const karma = this.runState?.karma || 0;
      const tier = calculateKarmaTier(karma);
      const mod = getKarmaModifier(tier);
      const isRighteous = tier === KARMA_TIERS.RIGHTEOUS;
      const isDemonic = tier === KARMA_TIERS.DEMONIC;

      ctx.fillStyle = 'rgba(4, 2, 1, 0.88)';
      ctx.fillRect(0, 0, width, height);

      const panelW = Math.min(320, width - 36);
      const panelH = 380;
      const panelX = (width - panelW) / 2;
      const panelY = (height - panelH) / 2;

      drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: false });

      // 标题
      const titleColor = isRighteous ? '#2E6B46' : (isDemonic ? '#7B1FA2' : '#6B4A2E');
      drawTextCentered(ctx, "【 因 果 鉴 】", width / 2, panelY + 28, titleColor, 20, "serif");

      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(panelX + 24, panelY + 46);
      ctx.lineTo(panelX + panelW - 24, panelY + 46);
      ctx.stroke();

      // 当前因果值和阶位
      const karmaStr = karma > 0 ? `+${karma}` : `${karma}`;
      drawTextCentered(ctx, `当前因果：${karmaStr}`, width / 2, panelY + 66, UI_COLORS.ink, 14, "serif");
      drawTextCentered(ctx, mod.tierName, width / 2, panelY + 88, titleColor, 16, "serif");
      drawTextCentered(ctx, mod.triggerDesc, width / 2, panelY + 108, '#8A6D4B', 11, "serif");

      // 分隔线
      ctx.strokeStyle = 'rgba(180, 130, 70, 0.4)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(panelX + 20, panelY + 124);
      ctx.lineTo(panelX + panelW - 20, panelY + 124);
      ctx.stroke();

      // 增幅详情
      let curY = panelY + 140;
      const itemX = panelX + 24;
      const itemW = panelW - 48;

      const effects = [];

      // 商店价格
      const priceMult = mod.shopPriceMultiplier;
      if (priceMult < 1) {
        effects.push({ label: '商人特惠', value: `商店价格 -${Math.round((1 - priceMult) * 100)}%`, color: '#2E6B46' });
      } else if (priceMult > 1) {
        effects.push({ label: '商贾戒备', value: `商店价格 +${Math.round((priceMult - 1) * 100)}%`, color: '#8C2A24' });
      } else {
        effects.push({ label: '市价如常', value: '商店价格 标准', color: '#6B4A2E' });
      }

      // 玩家伤害
      const dmgMult = mod.playerDamageMultiplier;
      if (dmgMult > 1) {
        effects.push({ label: isDemonic ? '煞气暴涌' : '灵威浩荡', value: `全伤害 +${Math.round((dmgMult - 1) * 100)}%`, color: '#8C2A24' });
      } else {
        effects.push({ label: '道法寻常', value: '全伤害 标准', color: '#6B4A2E' });
      }

      // 敌人伤害
      const enemyDmgMult = mod.enemyDamageMultiplier;
      if (enemyDmgMult > 1) {
        effects.push({ label: '凶煞戾气', value: `敌人伤害 +${Math.round((enemyDmgMult - 1) * 100)}%`, color: '#8C2A24' });
      } else {
        effects.push({ label: '妖邪敛迹', value: '敌人伤害 标准', color: '#6B4A2E' });
      }

      // 精英率
      const eliteMod = mod.eliteRateModifier;
      if (eliteMod < 0) {
        effects.push({ label: '妖邪避退', value: `精英遭遇率 ${Math.round(eliteMod * 100)}%`, color: '#2E6B46' });
      } else if (eliteMod > 0) {
        effects.push({ label: '强敌涌现', value: `精英遭遇率 +${Math.round(eliteMod * 100)}%`, color: '#8C2A24' });
      } else {
        effects.push({ label: '路途如常', value: '精英遭遇率 标准', color: '#6B4A2E' });
      }

      // 稀有掉落
      const relicBonus = mod.relicDropRateBonus;
      if (relicBonus > 0) {
        effects.push({ label: isRighteous ? '福缘加身' : '险中求贵', value: `稀有掉落率 +${Math.round(relicBonus * 100)}%`, color: '#9A731F' });
      }

      // 敌人池偏向
      const poolBias = mod.enemyPoolBias;
      if (poolBias === 'peaceful') {
        effects.push({ label: '温和妖邪', value: '敌人池偏向 普通妖邪', color: '#2E6B46' });
      } else if (poolBias === 'ferocious') {
        effects.push({ label: '凶煞妖魔', value: '敌人池偏向 高攻妖魔', color: '#8C2A24' });
      }

      // 商品池
      if (isRighteous) {
        effects.push({ label: '正道商品', value: '商店优先出现 治疗/防御卡', color: '#2E6B46' });
      } else if (isDemonic) {
        effects.push({ label: '妖魔商品', value: '商店混入 高攻/诅咒卡', color: '#7B1FA2' });
        effects.push({ label: '商品锁定', value: '部分治疗卡 被商人锁定', color: '#8C2A24' });
      }

      effects.forEach(eff => {
        drawRoundedRect(ctx, itemX, curY, itemW, 28, 5, 'rgba(244, 235, 212, 0.85)', 'rgba(160, 120, 70, 0.3)', 1);
        drawTextLeft(ctx, eff.label, itemX + 12, curY + 14, eff.color, 12, "serif");
        drawTextRight(ctx, eff.value, itemX + itemW - 12, curY + 14, UI_COLORS.ink, 12, "serif");
        curY += 34;
      });

      // 描述
      if (mod.description) {
        const descLines = getWrappedLines(ctx, mod.description, itemW, 11);
        const descY = panelY + panelH - 20 - descLines.length * 14;
        ctx.font = '11px serif';
        ctx.fillStyle = '#8A6D4B';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        descLines.forEach((l, i) => {
          ctx.fillText(l, width / 2, descY + i * 14);
        });
      }

      drawTextCentered(ctx, "— 点击任意处关闭 —", width / 2, panelY + panelH - 12, "#8A6D4B", 10, "serif");
    },

    exit() {
      TutorialManager.exitScene();
    }
  };
}