/**
 * EventStateMachine — 事件状态机
 *
 * 统一管理事件的触发、阶段推进、选择与结算。
 * 支持单阶段事件（当前所有事件）和多阶段事件（未来扩展）。
 *
 * 接口：
 * - canTrigger()       判断事件是否可触发（条件检查）
 * - getCurrentStage()  获取当前阶段数据（描述/选项）
 * - choose(index)      选择当前阶段的某个选项
 * - advanceStage()     推进到下一阶段
 * - resolve()          结算事件，应用所有效果
 * - isResolved()       事件是否已结算
 * - getGains()         获取结算收益列表
 */

export class EventStateMachine {
  /**
   * @param {object} eventData 事件数据（id/title/description/choices 或 stages）
   * @param {object} runState 当前运行状态
   */
  constructor(eventData, runState) {
    this.event = eventData;
    this.runState = runState;
    this.currentStageIndex = 0;
    this.resolved = false;
    this.resultText = '';
    this.gains = [];
    this.selectedChoice = null;
    this._stages = this._parseStages(eventData);
  }

  /**
   * 解析事件阶段：兼容旧格式（choices 数组）和新格式（stages 数组）
   */
  _parseStages(eventData) {
    // 新格式：stages 数组，每个阶段有 description 和 choices
    if (Array.isArray(eventData.stages) && eventData.stages.length > 0) {
      return eventData.stages.map(stage => ({
        description: stage.description || eventData.description || '',
        choices: stage.choices || [],
        nextStage: stage.nextStage !== undefined ? stage.nextStage : null
      }));
    }

    // 旧格式：单阶段，choices 在顶层
    return [{
      description: eventData.description || eventData.story || '',
      choices: eventData.choices || eventData.options || [],
      nextStage: null
    }];
  }

  // ==================== 触发检查 ====================

  /**
   * 判断事件是否可以触发
   * 检查事件的 triggerCondition（如果有）
   * @returns {boolean}
   */
  canTrigger() {
    if (!this.event) return false;

    // 如果事件定义了 triggerCondition 函数
    if (typeof this.event.triggerCondition === 'function') {
      try {
        return this.event.triggerCondition(this.runState);
      } catch (e) {
        console.error('[EventStateMachine] triggerCondition error:', e);
        return false;
      }
    }

    // 如果事件定义了 requireChapter
    if (this.event.requireChapter !== undefined) {
      if (this.runState.chapter !== this.event.requireChapter) return false;
    }

    // 如果事件定义了 requireMinKarma / requireMaxKarma
    if (this.event.requireMinKarma !== undefined) {
      if ((this.runState.karma || 0) < this.event.requireMinKarma) return false;
    }
    if (this.event.requireMaxKarma !== undefined) {
      if ((this.runState.karma || 0) > this.event.requireMaxKarma) return false;
    }

    return true;
  }

  // ==================== 阶段查询 ====================

  /**
   * 获取当前阶段数据
   * @returns {{ description: string, choices: Array, stageIndex: number, totalStages: number }}
   */
  getCurrentStage() {
    const stage = this._stages[this.currentStageIndex];
    if (!stage) return null;

    return {
      stageIndex: this.currentStageIndex,
      totalStages: this._stages.length,
      description: stage.description,
      choices: stage.choices.map((choice, idx) => ({
        index: idx,
        text: choice.text,
        tip: choice.tip || choice.desc || '',
        disabled: this._isChoiceDisabled(choice),
        disabledReason: this._getDisabledReason(choice)
      }))
    };
  }

  /**
   * 检查选项是否不可选
   */
  _isChoiceDisabled(choice) {
    if (typeof choice.disabled === 'function') {
      try {
        return choice.disabled(this.runState);
      } catch (e) {
        return false;
      }
    }
    if (choice.disabled === true) return true;

    // 检查金币需求
    if (choice.goldDelta !== undefined && choice.goldDelta < 0) {
      if ((this.runState.gold || 0) < Math.abs(choice.goldDelta)) return true;
    }

    // 检查气血需求
    if (choice.requireMinHp !== undefined) {
      if ((this.runState.hp || 0) < choice.requireMinHp) return true;
    }

    return false;
  }

  /**
   * 获取选项不可选的原因
   */
  _getDisabledReason(choice) {
    if (choice.disabledReason) return choice.disabledReason;
    if (choice.goldDelta !== undefined && choice.goldDelta < 0) {
      if ((this.runState.gold || 0) < Math.abs(choice.goldDelta)) return '铜钱不足';
    }
    if (choice.requireMinHp !== undefined && (this.runState.hp || 0) < choice.requireMinHp) {
      return '气血不足';
    }
    return '';
  }

  // ==================== 选择与推进 ====================

  /**
   * 选择当前阶段的某个选项
   * @param {number} choiceIndex 选项索引
   * @returns {{ success: boolean, resultText: string, gains: Array, hasNextStage: boolean }}
   */
  choose(choiceIndex) {
    if (this.resolved) {
      return { success: false, resultText: '', gains: [], hasNextStage: false, error: '事件已结算' };
    }

    const stage = this._stages[this.currentStageIndex];
    if (!stage) {
      return { success: false, resultText: '', gains: [], hasNextStage: false, error: '无当前阶段' };
    }

    const choice = stage.choices[choiceIndex];
    if (!choice) {
      return { success: false, resultText: '', gains: [], hasNextStage: false, error: '无效选项' };
    }

    if (this._isChoiceDisabled(choice)) {
      return { success: false, resultText: '', gains: [], hasNextStage: false, error: this._getDisabledReason(choice) || '选项不可选' };
    }

    this.selectedChoice = choice;
    this.resultText = choice.resultText || choice.text || '';

    // 记录应用效果前的 gains 长度，以便返回当前阶段新增的部分
    const gainsBefore = this.gains.length;

    // 应用选项效果
    this._applyChoiceEffects(choice);

    // 检查是否有下一阶段
    const hasNextStage = choice.nextStage !== undefined
      ? (choice.nextStage !== null && choice.nextStage < this._stages.length)
      : (stage.nextStage !== null && this.currentStageIndex + 1 < this._stages.length);

    if (!hasNextStage) {
      this.resolve();
    }

    // 只返回当前阶段新增的 gains
    const newGains = this.gains.slice(gainsBefore);

    return {
      success: true,
      resultText: this.resultText,
      gains: newGains,
      hasNextStage
    };
  }

  /**
   * 应用选项的效果到 runState
   */
  _applyChoiceEffects(choice) {
    const run = this.runState;

    // 因果变化
    if (choice.karmaDelta !== undefined && choice.karmaDelta !== 0) {
      run.karma = Math.max(-10, Math.min(10, (run.karma || 0) + choice.karmaDelta));
      if (choice.karmaDelta > 0) {
        this.gains.push({ text: `善念因果 +${choice.karmaDelta}`, icon: '善', color: '#2E6B46' });
      } else {
        this.gains.push({ text: `业障因果 ${choice.karmaDelta}`, icon: '孽', color: '#8C2A24' });
      }
    }

    // 金币变化
    if (choice.goldDelta !== undefined && choice.goldDelta !== 0) {
      run.gold = Math.max(0, (run.gold || 0) + choice.goldDelta);
      if (choice.goldDelta > 0) {
        this.gains.push({ text: `获得铜钱 +${choice.goldDelta}`, icon: '铜', color: '#C99A3A' });
      } else {
        this.gains.push({ text: `消耗铜钱 ${choice.goldDelta}`, icon: '铜', color: '#8C2A24' });
      }
    }

    // 气血变化
    if (choice.hpDelta !== undefined && choice.hpDelta !== 0) {
      if (choice.hpDelta > 0) {
        run.hp = Math.min(run.maxHp || 30, (run.hp || 30) + choice.hpDelta);
        this.gains.push({ text: `恢复气血 +${choice.hpDelta}`, icon: '血', color: '#2E6B46' });
      } else {
        run.hp = Math.max(1, (run.hp || 30) + choice.hpDelta);
        this.gains.push({ text: `道体受损 ${choice.hpDelta} 气血`, icon: '损', color: '#8C2A24' });
      }
    }

    // 特殊效果
    if (choice.customEffect === 'maxHpDec') {
      run.maxHp = Math.max(10, (run.maxHp || 30) - 4);
      run.hp = Math.min(run.hp, run.maxHp);
      this.gains.push({ text: `气血上限 -4 (煞气伤脉)`, icon: '损', color: '#8C2A24' });
    }

    // 因果归零（饮忘川水）
    if (choice.customEffect === 'karmaReset') {
      run.karma = 0;
      this.gains.push({ text: `因果归零 · 前尘两清`, icon: '忘', color: '#4A6B8A' });
    }

    // 鸣冤浩气（对鬼差伤害+2）
    if (choice.customEffect === 'mingyuanHaoqi') {
      if (!run.buffs) run.buffs = {};
      run.buffs.mingyuanHaoqi = true;
      this.gains.push({ text: `获得【鸣冤浩气】对鬼差伤害+2`, icon: '正', color: '#C99A3A' });
    }

    // ==================== 第三章剧情特殊遗物 ====================
    const chapter3Relics = {
      xiuniangJade: { id: 'relic_xiuniang_yupei', name: '绣娘玉佩', description: '兰若寺绣娘残魂所化，温润如玉' },
      zhilvMark: { id: 'relic_zhilv_yinji', name: '执律印记', description: '前世天庭执律仙官的身份印记' },
      qingqiuPearl: { id: 'relic_qingqiu_huzhu', name: '青丘狐珠', description: '青丘遗老所赠，蕴含九尾公主的一缕善念' },
      xuanmingEye: { id: 'relic_xuanming_zhiyan', name: '玄冥之眼', description: '窥见玄冥真身后获得的禁忌之眼，伤害+15%' },
      yuanliBoost: { id: 'relic_yuanli_qianghua', name: '怨力强化', description: '炼化万魂怨力所得，攻击伤害+3' },
      fengshenPage: { id: 'relic_fengshen_canye', name: '封神榜残页', description: '上古神将杀伐之道，永久攻击+1' }
    };

    if (choice.customEffect && chapter3Relics[choice.customEffect]) {
      const relic = chapter3Relics[choice.customEffect];
      this.gains.push({
        text: `收纳法宝【${relic.name}】`,
        icon: '宝',
        color: '#5C1D54',
        rewardRelic: relic
      });
    }

    // 修复六道轮回盘（善因果+2，恢复20HP）
    if (choice.customEffect === 'repairSamsara') {
      run.karma = Math.min(10, (run.karma || 0) + 2);
      run.hp = Math.min(run.maxHp || 30, (run.hp || 30) + 20);
      this.gains.push({ text: `修复轮回盘 · 善念+2 · 气血+20`, icon: '善', color: '#2E6B46' });
    }

    // 加速六道崩毁（恶因果-2，永久攻击+2）
    if (choice.customEffect === 'accelerateSamsara') {
      run.karma = Math.max(-10, (run.karma || 0) - 2);
      if (!run.buffs) run.buffs = {};
      run.buffs.attackBonus = (run.buffs.attackBonus || 0) + 2;
      this.gains.push({ text: `加速轮回崩毁 · 业障-2 · 永久攻击+2`, icon: '孽', color: '#8C2A24' });
    }

    // 奖励卡牌（由调用方处理 addCard）
    if (choice.rewardCard) {
      this.gains.push({
        text: `获得符箓【${choice.rewardCard.name}】`,
        icon: '符',
        color: '#8C2A24',
        rewardCard: choice.rewardCard
      });
    }

    // 升级卡牌（由调用方处理实际升级）
    if (choice.upgradeRandomCard || choice.upgradeCardElement || choice.upgradeCardName) {
      this.gains.push({
        text: '符箓精进',
        icon: '符',
        color: '#C99A3A',
        upgradeCard: {
          random: choice.upgradeRandomCard || false,
          element: choice.upgradeCardElement || null,
          name: choice.upgradeCardName || null
        }
      });
    }

    // 奖励遗物（由调用方处理 addRelic）
    if (choice.rewardRelic) {
      this.gains.push({
        text: `收纳法宝【${choice.rewardRelic.name}】`,
        icon: '宝',
        color: '#5C1D54',
        rewardRelic: choice.rewardRelic
      });
    }

    // 自定义 apply 函数（旧格式兼容）
    if (typeof choice.apply === 'function') {
      try {
        const customResult = choice.apply(run);
        if (typeof customResult === 'string' && customResult) {
          this.resultText = customResult;
        }
      } catch (e) {
        console.error('[EventStateMachine] choice.apply error:', e);
      }
    }
  }

  /**
   * 推进到下一阶段
   * @returns {boolean} 是否成功推进
   */
  advanceStage() {
    if (this.resolved) return false;

    const stage = this._stages[this.currentStageIndex];
    let nextIndex = this.currentStageIndex + 1;

    // 如果选项指定了 nextStage
    if (this.selectedChoice && this.selectedChoice.nextStage !== undefined) {
      if (this.selectedChoice.nextStage === null) return false;
      nextIndex = this.selectedChoice.nextStage;
    } else if (stage && stage.nextStage !== null && stage.nextStage !== undefined) {
      nextIndex = stage.nextStage;
    }

    if (nextIndex >= 0 && nextIndex < this._stages.length) {
      this.currentStageIndex = nextIndex;
      this.selectedChoice = null;
      return true;
    }

    return false;
  }

  // ==================== 结算 ====================

  /**
   * 结算事件
   * @returns {{ resolved: boolean, resultText: string, gains: Array }}
   */
  resolve() {
    if (this.resolved) {
      return { resolved: true, resultText: this.resultText, gains: this.gains };
    }

    this.resolved = true;
    return {
      resolved: true,
      resultText: this.resultText,
      gains: this.gains
    };
  }

  // ==================== 查询 ====================

  /** 事件是否已结算 */
  isResolved() {
    return this.resolved;
  }

  /** 获取结算收益 */
  getGains() {
    return [...this.gains];
  }

  /** 获取结果文本 */
  getResultText() {
    return this.resultText;
  }

  /** 获取事件ID */
  getEventId() {
    return this.event ? this.event.id : null;
  }

  /** 获取事件标题 */
  getEventTitle() {
    return this.event ? this.event.title : '';
  }

  /** 是否为多阶段事件 */
  isMultiStage() {
    return this._stages.length > 1;
  }
}
