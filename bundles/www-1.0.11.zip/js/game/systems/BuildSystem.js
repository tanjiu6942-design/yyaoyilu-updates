/**
 * BuildSystem — 流派构筑系统
 *
 * 根据玩家的出牌习惯、印记引爆、护盾状态等，自动识别并激活四大流派：
 * - 烈煞流（火）：火印→烈焰爆发→终结技闭环
 * - 寒渊流（水）：冻结→抽牌→低费→连续冻结
 * - 青藤流（木）：木印治疗→额外抽牌→续航
 * - 磐石流（土）：护盾资源化→破碎反伤→阈值增伤
 *
 * 数据结构：
 * {
 *   dominantElements: { 金:0, 木:0, 水:0, 火:0, 土:0 },
 *   buildTags: { flames:false, frost:false, vine:false, stone:false },
 *   buildLevel: { flames:0, frost:0, vine:0, stone:0 },
 *   buildBonuses: { ... }
 * }
 */

import { BATTLE } from '../../config/constants.js';
import { hasRelic } from '../effect-engine.js';

// 流派定义
export const BUILD_DEFS = {
  flames: {
    name: '烈煞流',
    element: '火',
    color: '#E85D3A',
    desc: '火印引爆后激活，烈焰爆发增伤，连续引爆触发终结技',
    triggerCondition: '火印引爆后追击火牌 或 连续3张火牌',
    maxLevel: 3
  },
  frost: {
    name: '寒渊流',
    element: '水',
    color: '#4A9FD8',
    desc: '水印引爆后激活，冻结联动抽牌，连续冻结回能',
    triggerCondition: '冻结敌人后出水牌 或 连续3张水牌',
    maxLevel: 3
  },
  vine: {
    name: '青藤流',
    element: '木',
    color: '#5BA84A',
    desc: '木印治疗后激活，治疗联动抽牌，低血量续航',
    triggerCondition: '低血量时出木牌 或 连续3张木牌',
    maxLevel: 3
  },
  stone: {
    name: '磐石流',
    element: '土',
    color: '#8B7355',
    desc: '高护盾激活，护盾破碎反伤，阈值增伤',
    triggerCondition: '有护盾时出土牌 或 连续3张土牌',
    maxLevel: 3
  },
  blade: {
    name: '锋锐流',
    element: '金',
    color: '#D4AF37',
    desc: '金印引爆后激活，破甲真伤，连续引爆提升暴击',
    triggerCondition: '金印引爆后追击金牌 或 连续3张金牌',
    maxLevel: 3
  }
};

// ★ P0-07：行为判定配置
// 行为进度达到阈值时激活流派
export const BEHAVIOR_TRIGGER_THRESHOLD = 2;
// 元素到流派的映射
const ELEMENT_TO_BUILD = { 火: 'flames', 水: 'frost', 木: 'vine', 土: 'stone', 金: 'blade' };

export class BuildSystem {
  constructor() {
    this.dominantElements = { 金: 0, 木: 0, 水: 0, 火: 0, 土: 0 };
    this.buildTags = { flames: false, frost: false, vine: false, stone: false, blade: false };
    this.buildLevel = { flames: 0, frost: 0, vine: 0, stone: 0, blade: 0 };
    this.buildBonuses = {
      flames: { nextFireBonus: 0, detonationCount: 0, finisherReady: false },
      frost: { freezeStreak: 0, nextWaterCostReduction: 0, extraDraw: 0 },
      vine: { healBonus: 0, extraDrawOnHeal: 0, lowHpShield: 0 },
      stone: { shieldThresholdBonus: 0, shieldBreakReflect: 0, earthShieldBonus: 0 },
      blade: { armorPenetration: 0, critChance: 0, detonationBonus: 0 }
    };
    this.turnHealTotal = 0;
    this.enemyFrozenLastTurn = false;
    this.listeners = [];

    // ★ P0-07：行为判定系统（替代纯数量判定）
    // 每个流派的行为进度，达到 BEHAVIOR_TRIGGER_THRESHOLD 时激活
    this.behaviorProgress = { flames: 0, frost: 0, vine: 0, stone: 0, blade: 0 };
    // 行为追踪状态
    this.behaviorState = {
      lastElement: null,           // 上一张打出的牌的元素
      lastDetonatedElement: null,  // 上一次印记引爆的元素
      enemyFrozen: false           // 敌人当前是否被冻结
    };
  }

  addListener(callback) {
    if (typeof callback === 'function') this.listeners.push(callback);
  }

  emit(eventType, payload) {
    this.listeners.forEach(fn => {
      try { fn(eventType, payload); } catch (e) { console.error('[BuildSystem] listener error:', e); }
    });
  }

  // ==================== 出牌统计 ====================

  onCardPlayed(card, battle) {
    if (!card || !card.element || card.element === '无') return '';
    this.dominantElements[card.element] = (this.dominantElements[card.element] || 0) + 1;

    let log = '';
    const buildKey = ELEMENT_TO_BUILD[card.element];
    if (!buildKey || this.buildTags[buildKey]) {
      // 已激活的流派不重复判定，但更新 lastElement
      this.behaviorState.lastElement = card.element;
      return log;
    }

    const player = battle?.player;
    let progressGain = 0;
    let behaviorDesc = '';

    // 行为1：连续出同元素牌（数量兜底）
    if (this.behaviorState.lastElement === card.element) {
      progressGain += 1;
      behaviorDesc = '连续出牌';
    }

    // 行为2：印记引爆后追击对应元素牌（烈煞/锋锐）
    if (this.behaviorState.lastDetonatedElement === card.element) {
      progressGain += 2;
      behaviorDesc = behaviorDesc ? behaviorDesc + '+引爆追击' : '引爆追击';
    }

    // 行为3：冻结敌人时出水牌（寒渊）
    if (card.element === '水' && this.behaviorState.enemyFrozen) {
      progressGain += 2;
      behaviorDesc = behaviorDesc ? behaviorDesc + '+冰封连击' : '冰封连击';
    }

    // 行为4：低血量时出木牌（青藤）
    if (card.element === '木' && player && player.hp < player.maxHp * 0.5) {
      progressGain += 2;
      behaviorDesc = behaviorDesc ? behaviorDesc + '+绝境逢生' : '绝境逢生';
    }

    // 行为5：有护盾时出土牌（磐石）
    if (card.element === '土' && player && player.shield > 5) {
      progressGain += 2;
      behaviorDesc = behaviorDesc ? behaviorDesc + '+坚壁反击' : '坚壁反击';
    }

    if (progressGain > 0) {
      this.behaviorProgress[buildKey] = (this.behaviorProgress[buildKey] || 0) + progressGain;
      if (this.behaviorProgress[buildKey] >= BEHAVIOR_TRIGGER_THRESHOLD) {
        log += this.activateBuild(buildKey, battle);
        this.behaviorProgress[buildKey] = 0;
      } else if (behaviorDesc) {
        log += ` 【${BUILD_DEFS[buildKey].name}·${behaviorDesc}】进度${this.behaviorProgress[buildKey]}/${BEHAVIOR_TRIGGER_THRESHOLD}`;
      }
    }

    this.behaviorState.lastElement = card.element;
    return log;
  }

  // ==================== 印记引爆回调 ====================

  onMarkDetonated(element, battle, detonationResult) {
    let log = '';
    // 记录引爆元素，用于"引爆后追击"行为判定
    this.behaviorState.lastDetonatedElement = element;
    // 记录冻结状态（用于寒渊流行为判定）
    if (detonationResult && detonationResult.frozen) {
      this.behaviorState.enemyFrozen = true;
    }

    switch (element) {
      case '火': log += this.onFireDetonation(battle); break;
      case '水': log += this.onWaterDetonation(battle, detonationResult); break;
      case '木': log += this.onWoodDetonation(battle, detonationResult); break;
      case '土': log += this.onEarthDetonation(battle, detonationResult); break;
      case '金': log += this.onMetalDetonation(battle, detonationResult); break;
    }
    return log;
  }

  /**
   * 统一的流派激活判定：通过行为进度激活
   * 未激活流派在引爆时获得行为进度，达到阈值则激活
   */
  tryActivateByDetonation(buildKey, battle) {
    if (this.buildTags[buildKey]) return '';
    this.behaviorProgress[buildKey] = (this.behaviorProgress[buildKey] || 0) + 2;
    if (this.behaviorProgress[buildKey] >= BEHAVIOR_TRIGGER_THRESHOLD) {
      this.behaviorProgress[buildKey] = 0;
      return this.activateBuild(buildKey, battle);
    }
    return ` 【${BUILD_DEFS[buildKey].name}·印记共鸣】进度${this.behaviorProgress[buildKey]}/${BEHAVIOR_TRIGGER_THRESHOLD}`;
  }

  // ==================== 烈煞流（火） ====================

  onFireDetonation(battle) {
    let log = '';
    const bonuses = this.buildBonuses.flames;

    log += this.tryActivateByDetonation('flames', battle);

    bonuses.detonationCount++;
    const level = this.buildLevel.flames;
    bonuses.nextFireBonus = 0.5 + level * 0.15;

    if (bonuses.detonationCount >= 3) {
      bonuses.finisherReady = true;
      bonuses.detonationCount = 0;
      log += ' 【烈煞·终结技】烈焰蓄积已满，下一张火牌将触发终结爆发！';
      this.emit('build_finisher_ready', { build: 'flames' });
    }

    if (bonuses.detonationCount % 2 === 0 && this.buildLevel.flames < BUILD_DEFS.flames.maxLevel) {
      this.buildLevel.flames++;
      log += ` 【烈煞流】升至 Lv${this.buildLevel.flames}！`;
      this.emit('build_level_up', { build: 'flames', level: this.buildLevel.flames });
    }

    return log;
  }

  applyFireDamageBonus(card, baseDamage) {
    if (card.element !== '火') return { damage: baseDamage, log: '', applyBurn: false };
    const bonuses = this.buildBonuses.flames;
    let damage = baseDamage;
    let log = '';

    if (bonuses.finisherReady) {
      damage = Math.floor(damage * 2);
      bonuses.finisherReady = false;
      bonuses.nextFireBonus = 0;
      log += ' 【烈煞终结技】伤害翻倍！';
      return { damage, log, applyBurn: true };
    }

    if (bonuses.nextFireBonus > 0) {
      const bonus = Math.floor(damage * bonuses.nextFireBonus);
      damage += bonus;
      log += ` 【烈焰爆发】+${bonus}伤害`;
      bonuses.nextFireBonus = 0;
    }

    return { damage, log, applyBurn: false };
  }

  // ==================== 寒渊流（水） ====================

  onWaterDetonation(battle, detonationResult) {
    let log = '';
    const bonuses = this.buildBonuses.frost;

    log += this.tryActivateByDetonation('frost', battle);

    bonuses.extraDraw = 1 + this.buildLevel.frost;
    log += ` 【寒渊】水印联动，额外抽${bonuses.extraDraw}张牌`;

    if (detonationResult && detonationResult.frozen) {
      bonuses.nextWaterCostReduction = 1 + this.buildLevel.frost;
      log += ` 【冰封】下一张水牌费用-${bonuses.nextWaterCostReduction}`;
    }

    if (this.enemyFrozenLastTurn && detonationResult && detonationResult.frozen) {
      bonuses.freezeStreak++;
      if (bonuses.freezeStreak >= 2) {
        battle.player.energy = Math.min(battle.player.maxEnergy, battle.player.energy + 1);
        log += ' 【寒渊·极寒】连续冻结！恢复1点灵气';
        bonuses.freezeStreak = 0;
        this.emit('build_combo', { build: 'frost', combo: 'freeze_streak' });
      }
    } else if (detonationResult && detonationResult.frozen) {
      bonuses.freezeStreak = 1;
    }

    return log;
  }

  applyWaterCostReduction(card) {
    if (card.element !== '水') return { costReduction: 0, log: '' };
    const bonuses = this.buildBonuses.frost;
    if (bonuses.nextWaterCostReduction > 0) {
      const reduction = bonuses.nextWaterCostReduction;
      bonuses.nextWaterCostReduction = 0;
      return { costReduction: reduction, log: ` 【冰封】费用-${reduction}` };
    }
    return { costReduction: 0, log: '' };
  }

  consumeFrostExtraDraw() {
    const bonuses = this.buildBonuses.frost;
    const draw = bonuses.extraDraw;
    bonuses.extraDraw = 0;
    return draw;
  }

  // ==================== 青藤流（木） ====================

  onWoodDetonation(battle, detonationResult) {
    let log = '';
    const bonuses = this.buildBonuses.vine;

    log += this.tryActivateByDetonation('vine', battle);

    bonuses.healBonus = 0.5 + this.buildLevel.vine * 0.2;
    bonuses.extraDrawOnHeal = 1 + Math.floor(this.buildLevel.vine / 2);
    log += ` 【青藤】生机涌动，额外抽${bonuses.extraDrawOnHeal}张牌`;

    return log;
  }

  applyVineHealBonus(healAmount) {
    const bonuses = this.buildBonuses.vine;
    if (bonuses.healBonus > 0) {
      const bonus = Math.floor(healAmount * bonuses.healBonus);
      bonuses.healBonus = 0;
      this.turnHealTotal += healAmount + bonus;
      return { heal: healAmount + bonus, log: ` 【青藤】治疗+${bonus}` };
    }
    this.turnHealTotal += healAmount;
    return { heal: healAmount, log: '' };
  }

  consumeVineExtraDraw() {
    const bonuses = this.buildBonuses.vine;
    const draw = bonuses.extraDrawOnHeal;
    bonuses.extraDrawOnHeal = 0;
    return draw;
  }

  // ==================== 磐石流（土） ====================

  onEarthDetonation(battle, detonationResult) {
    let log = '';
    const bonuses = this.buildBonuses.stone;

    log += this.tryActivateByDetonation('stone', battle);

    bonuses.earthShieldBonus = 0.5 + this.buildLevel.stone * 0.15;
    log += ` 【磐石】土印护盾强化`;

    return log;
  }

  applyStoneShieldBonus(shieldAmount) {
    const bonuses = this.buildBonuses.stone;
    if (bonuses.earthShieldBonus > 0) {
      const bonus = Math.floor(shieldAmount * bonuses.earthShieldBonus);
      bonuses.earthShieldBonus = 0;
      return { shield: shieldAmount + bonus, log: ` 【磐石】护盾+${bonus}` };
    }
    return { shield: shieldAmount, log: '' };
  }

  applyStoneThresholdBonus(player, baseDamage) {
    if (!this.buildTags.stone) return { damage: baseDamage, log: '' };
    const level = this.buildLevel.stone;
    const thresholds = [20, 15, 10];
    const bonuses = [3, 5, 8];
    const threshold = thresholds[Math.min(level, 2)];
    const bonus = bonuses[Math.min(level, 2)];

    if (player.shield >= threshold) {
      return { damage: baseDamage + bonus, log: ` 【磐石·厚积】护盾≥${threshold}，伤害+${bonus}` };
    }
    return { damage: baseDamage, log: '' };
  }

  onShieldBroken(battle, shieldBroken) {
    if (!this.buildTags.stone || shieldBroken <= 0) return '';
    const level = this.buildLevel.stone;
    const reflectRates = [0.25, 0.35, 0.5];
    let reflectRate = reflectRates[Math.min(level, 2)];
    // ★ 遗物：反伤甲 - 护盾破碎反伤 +25%
    if (battle.player && hasRelic(battle.player, 'relic_fanshang_jia')) {
      reflectRate += 0.25;
    }
    const reflectDmg = Math.floor(shieldBroken * reflectRate);

    if (reflectDmg > 0 && battle.enemy && battle.enemy.invulnerableTurns <= 0) {
      battle.enemy.hp = Math.max(0, battle.enemy.hp - reflectDmg);
      const relicTag = (battle.player && hasRelic(battle.player, 'relic_fanshang_jia')) ? '【反伤甲】' : '';
      return ` 【磐石·反震】${relicTag}护盾破碎，反震${reflectDmg}点伤害！`;
    }
    return '';
  }

  // ==================== 锋锐流（金） ====================

  onMetalDetonation(battle, detonationResult) {
    let log = '';
    const bonuses = this.buildBonuses.blade;

    log += this.tryActivateByDetonation('blade', battle);

    const level = this.buildLevel.blade;
    bonuses.detonationBonus = 0.3 + level * 0.15;
    bonuses.armorPenetration = 0.3 + level * 0.1;
    log += ` 【锋锐】金印破甲强化，下一张金牌无视${Math.floor(bonuses.armorPenetration * 100)}%护盾`;

    // 每2次引爆升一级
    bonuses._detonationCount = (bonuses._detonationCount || 0) + 1;
    if (bonuses._detonationCount >= 2 && this.buildLevel.blade < BUILD_DEFS.blade.maxLevel) {
      this.buildLevel.blade++;
      bonuses._detonationCount = 0;
      log += ` 【锋锐流】升至 Lv${this.buildLevel.blade}！`;
      this.emit('build_level_up', { build: 'blade', level: this.buildLevel.blade });
    }

    return log;
  }

  applyBladeDamageBonus(card, baseDamage, enemyShield) {
    if (card.element !== '金' || !this.buildTags.blade) return { damage: baseDamage, log: '', crit: false, armorPierced: 0 };
    const bonuses = this.buildBonuses.blade;
    let damage = baseDamage;
    let log = '';
    let armorPierced = 0;

    // 破甲：无视部分护盾
    if (bonuses.armorPenetration > 0 && enemyShield > 0) {
      armorPierced = Math.floor(enemyShield * bonuses.armorPenetration);
      log += ` 【锋锐·破甲】无视${armorPierced}点护盾`;
      bonuses.armorPenetration = 0;
    }

    // 暴击：Lv2+ 有几率双倍
    const level = this.buildLevel.blade;
    if (level >= 2) {
      const critChance = level >= 3 ? 0.35 : 0.2;
      if (Math.random() < critChance) {
        damage = Math.floor(damage * 2);
        log += ` 【锋锐·暴击】伤害翻倍！`;
        return { damage, log, crit: true, armorPierced };
      }
    }

    // 引爆增伤
    if (bonuses.detonationBonus > 0) {
      const bonus = Math.floor(baseDamage * bonuses.detonationBonus);
      damage += bonus;
      log += ` 【锋锐·利刃】伤害+${bonus}`;
      bonuses.detonationBonus = 0;
    }

    return { damage, log, crit: false, armorPierced };
  }

  // ==================== 通用：激活流派 ====================

  activateBuild(buildKey, battle) {
    if (this.buildTags[buildKey]) return '';
    this.buildTags[buildKey] = true;
    this.buildLevel[buildKey] = 1;
    const def = BUILD_DEFS[buildKey];
    this.emit('build_activated', { build: buildKey, name: def.name });
    return ` ★【${def.name}】流派激活！Lv1`;
  }

  // ==================== 回合生命周期 ====================

  onTurnStart(battle) {
    this.dominantElements = { 金: 0, 木: 0, 水: 0, 火: 0, 土: 0 };
    this.turnHealTotal = 0;

    let log = '';
    if (this.buildTags.vine && battle.player.hp < battle.player.maxHp * 0.5) {
      const level = this.buildLevel.vine;
      const shieldAmount = 2 + level * 2;
      battle.player.shield += shieldAmount;
      log += ` 【青藤·生生不息】气血低于50%，获得${shieldAmount}点护盾`;
    }

    this.enemyFrozenLastTurn = !!(battle.enemy && battle.enemy.skipTurn);
    return log;
  }

  onTurnEnd(battle) {
    let log = '';

    if (!this.buildTags.stone && battle.player.shield >= 15) {
      log += this.activateBuild('stone', battle);
    }

    if (!this.buildTags.vine && this.turnHealTotal > 10) {
      log += this.activateBuild('vine', battle);
    }

    this.buildBonuses.flames.nextFireBonus = 0;
    this.buildBonuses.frost.nextWaterCostReduction = 0;
    this.buildBonuses.vine.healBonus = 0;
    this.buildBonuses.stone.earthShieldBonus = 0;

    return log;
  }

  // ==================== 序列化 ====================
  // 只持久化流派激活状态和等级，临时战斗增益（buildBonuses等）每场战斗重置

  serialize() {
    return {
      buildTags: { ...this.buildTags },
      buildLevel: { ...this.buildLevel }
    };
  }

  deserialize(data) {
    if (!data) return;
    // 只恢复流派激活状态和等级
    this.buildTags = data.buildTags ? { ...data.buildTags } : { flames: false, frost: false, vine: false, stone: false, blade: false };
    this.buildLevel = data.buildLevel ? { ...data.buildLevel } : { flames: 0, frost: 0, vine: 0, stone: 0, blade: 0 };
    // 临时战斗状态全部重置
    this.dominantElements = { 金: 0, 木: 0, 水: 0, 火: 0, 土: 0 };
    this.buildBonuses = {
      flames: { nextFireBonus: 0, detonationCount: 0, finisherReady: false },
      frost: { freezeStreak: 0, nextWaterCostReduction: 0, extraDraw: 0 },
      vine: { healBonus: 0, extraDrawOnHeal: 0, lowHpShield: 0 },
      stone: { shieldThresholdBonus: 0, shieldBreakReflect: 0, earthShieldBonus: 0 },
      blade: { armorPenetration: 0, critChance: 0, detonationBonus: 0 }
    };
    this.turnHealTotal = 0;
    this.enemyFrozenLastTurn = false;
    this.behaviorProgress = { flames: 0, frost: 0, vine: 0, stone: 0, blade: 0 };
    this.behaviorState = { lastElement: null, lastDetonatedElement: null, enemyFrozen: false };
  }

  getActiveBuilds() {
    return Object.keys(this.buildTags)
      .filter(k => this.buildTags[k])
      .map(k => ({
        key: k,
        name: BUILD_DEFS[k].name,
        level: this.buildLevel[k],
        element: BUILD_DEFS[k].element,
        color: BUILD_DEFS[k].color
      }));
  }

  /**
   * 获取流派详细信息（用于长按弹窗）
   * @param {string} buildKey 流派key
   * @returns {object} 流派详情
   */
  getBuildDetail(buildKey) {
    const def = BUILD_DEFS[buildKey];
    if (!def) return null;
    const level = this.buildLevel[buildKey] || 0;
    const bonus = this.buildBonuses[buildKey] || {};

    let currentEffects = [];
    let nextEffects = [];

    if (buildKey === 'flames') {
      const fireBonus = 50 + level * 15; // Lv1:50% Lv2:65% Lv3:80%
      currentEffects = [
        `火印引爆后，下一张火牌伤害 +${fireBonus}%`,
        `连续引爆${level >= 2 ? '2' : '3'}次激活终结技（伤害翻倍+灼烧）`,
        level >= 3 ? '终结技触发后回复2点灵气' : 'Lv3解锁：终结技回能'
      ];
      nextEffects = level < 3 ? [
        `下一级：火牌增伤 +${(50 + (level + 1) * 15)}%`,
        level === 1 ? '下一级：连续引爆2次即可触发终结技' : '',
        level === 2 ? '下一级：终结技触发后回复2点灵气' : ''
      ].filter(Boolean) : ['已满级'];
    } else if (buildKey === 'frost') {
      const extraDraw = level; // Lv1:1张 Lv2:2张 Lv3:3张
      const costReduction = level; // Lv1:1费 Lv2:2费 Lv3:3费
      currentEffects = [
        `水印引爆后额外抽 ${extraDraw} 张牌`,
        `水系卡牌费用 -${costReduction}（最低0费）`,
        level >= 2 ? '连续冻结敌人2回合回复1灵气' : 'Lv2解锁：连续冻结回能',
        level >= 3 ? '冻结持续时间+1回合' : 'Lv3解锁：冻结延长'
      ];
      nextEffects = level < 3 ? [
        `下一级：额外抽牌 +${level + 1}张`,
        `下一级：水牌减费 -${level + 1}`,
        level === 1 ? '下一级解锁：连续冻结回能' : '',
        level === 2 ? '下一级解锁：冻结延长' : ''
      ].filter(Boolean) : ['已满级'];
    } else if (buildKey === 'vine') {
      const healBonus = 50 + level * 20; // Lv1:50% Lv2:70% Lv3:90%
      currentEffects = [
        `木印引爆后治疗效果 +${healBonus}%`,
        `治疗量超过10时额外抽 ${level} 张牌`,
        level >= 2 ? '血量低于50%时获得等量护盾' : 'Lv2解锁：低血护盾',
        level >= 3 ? '木系卡费用-1' : 'Lv3解锁：木牌减费'
      ];
      nextEffects = level < 3 ? [
        `下一级：治疗加成 +${50 + (level + 1) * 20}%`,
        `下一级：额外抽牌 +${level + 1}张`,
        level === 1 ? '下一级解锁：低血护盾' : '',
        level === 2 ? '下一级解锁：木牌减费' : ''
      ].filter(Boolean) : ['已满级'];
    } else if (buildKey === 'stone') {
      const shieldBonus = 50 + level * 15; // Lv1:50% Lv2:65% Lv3:80%
      const dmgBonus = level === 1 ? 3 : level === 2 ? 5 : 8;
      const reflect = 25 + level * 12; // Lv1:25% Lv2:37% Lv3:49%
      currentEffects = [
        `土印引爆获得护盾 +${shieldBonus}%`,
        `护盾>15时伤害 +${dmgBonus}`,
        `护盾破碎时反伤 ${reflect}%`,
        level >= 3 ? '每回合开始获得3点护盾' : 'Lv3解锁：回合护盾'
      ];
      nextEffects = level < 3 ? [
        `下一级：护盾加成 +${50 + (level + 1) * 15}%`,
        `下一级：阈值增伤 +${level === 1 ? 5 : 8}`,
        `下一级：破碎反伤 +${25 + (level + 1) * 12}%`,
        level === 2 ? '下一级解锁：回合护盾' : ''
      ].filter(Boolean) : ['已满级'];
    } else if (buildKey === 'blade') {
      const detBonus = 30 + level * 15; // Lv1:30% Lv2:45% Lv3:60%
      const armorPen = 30 + level * 10; // Lv1:30% Lv2:40% Lv3:50%
      const critChance = level >= 3 ? 35 : level >= 2 ? 20 : 0;
      currentEffects = [
        `金印引爆后，下一张金牌伤害 +${detBonus}%`,
        `金印引爆后，下一张金牌无视 ${armorPen}% 护盾`,
        level >= 2 ? `金系卡牌 ${critChance}% 几率暴击（双倍伤害）` : 'Lv2解锁：暴击几率',
        level >= 3 ? '暴击几率提升至35%' : 'Lv3解锁：暴击强化'
      ];
      nextEffects = level < 3 ? [
        `下一级：引爆增伤 +${30 + (level + 1) * 15}%`,
        `下一级：破甲无视 +${30 + (level + 1) * 10}%`,
        level === 1 ? '下一级解锁：20%暴击几率' : '',
        level === 2 ? '下一级：暴击几率提升至35%' : ''
      ].filter(Boolean) : ['已满级'];
    }

    return {
      key: buildKey,
      name: def.name,
      element: def.element,
      color: def.color,
      level,
      maxLevel: def.maxLevel,
      desc: def.desc,
      triggerCondition: def.triggerCondition,
      currentEffects,
      nextEffects
    };
  }
}
