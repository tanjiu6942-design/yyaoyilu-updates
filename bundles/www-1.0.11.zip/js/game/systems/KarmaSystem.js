/**
 * KarmaSystem — 因果系统世界响应
 *
 * 基于 KarmaModifiers 配置，提供游戏世界对因果阶位的动态响应：
 * - righteous（善念）：商店-15%、正道商品池、精英怪减少
 * - neutral（中立）：标准价格、标准商品池
 * - demonic（恶念）：商店+20%、商品锁定、妖魔敌人池
 *
 * 与 RunManager.karma 状态联动，通过 runManager.getKarmaTier() 获取当前阶位。
 */

import {
  KARMA_TIERS,
  KARMA_THRESHOLDS,
  KARMA_MODIFIERS,
  calculateKarmaTier,
  getKarmaModifier
} from '../../config/KarmaModifiers.js';

// ==================== 因果商品池定义 ====================

// 正道商品池：善因果时优先出现，偏向治疗/净化/防御/续航
const RIGHTEOUS_CARD_POOL = [
  '枯木逢春',   // 治疗+抽牌
  '净心咒',     // 净化诅咒
  '太极护体',   // 护盾
  '金钟罩',     // 高护盾
  '土墙术',     // 护盾+土印
  '木甲术',     // 护盾+蓄力
  '流水剑',     // 水伤+抽牌
  '两仪剑法',   // 伤害+护盾
  '白素贞',     // 大治疗+抽牌
];

// 妖魔商品池：恶因果时出现，偏向高攻击/诅咒/风险
const DEMONIC_CARD_POOL = [
  '三昧真火',   // 高伤+自损
  '万剑归宗',   // 高伤+金印
  '泰山压顶',   // 高伤+土印
  '九龙神火罩', // 护盾+灼烧
  '孙悟空',     // 高伤+定身
  '乾坤借法',   // 回能+抽牌（超模）
  '玄水狂潮',   // 伤害+抽牌
];

// 正道遗物池：善因果时优先出现
const RIGHTEOUS_RELIC_IDS = [
  'relic_gongde',   // 功德金莲
  'relic_qingmu',   // 青木珠
  'relic_taiji',    // 太极印
  'relic_panshi',   // 不灭磐石
  'relic_tianji',   // 天机册
];

// 妖魔遗物池：恶因果时出现
const DEMONIC_RELIC_IDS = [
  'relic_jiangyao',     // 降妖剑
  'relic_lihuoyu',      // 离火玉
  'relic_yinguojing',   // 因果镜
  'relic_jubao',        // 聚宝盆
  'relic_fuchen',       // 三清拂尘
];

// 恶因果时被锁定的商品（商人不敢售卖）
const DEMONIC_LOCKED_CARDS = [
  '白素贞',     // 传说级治疗卡
  '枯木逢春',   // 强力治疗
];

const DEMONIC_LOCKED_RELIC_IDS = [
  'relic_gongde',   // 功德金莲（正道专属）
  'relic_qingmu',   // 青木珠（治疗相关）
];

export class KarmaSystem {
  constructor(runManager) {
    this.runManager = runManager;
  }

  // ==================== 基础查询 ====================

  /** 获取当前因果值 */
  getKarma() {
    return this.runManager ? this.runManager.getKarma() : 0;
  }

  /** 获取当前因果阶位 */
  getTier() {
    return this.runManager ? this.runManager.getKarmaTier() : KARMA_TIERS.NEUTRAL;
  }

  /** 获取当前阶位的修饰器配置 */
  getModifier() {
    return getKarmaModifier(this.getTier());
  }

  /** 是否为善因果 */
  isRighteous() {
    return this.getTier() === KARMA_TIERS.RIGHTEOUS;
  }

  /** 是否为恶因果 */
  isDemonic() {
    return this.getTier() === KARMA_TIERS.DEMONIC;
  }

  // ==================== 地图与敌人池 ====================

  /** 获取精英怪生成率修饰（-0.15 ~ +0.15） */
  getEliteRateModifier() {
    return this.getModifier().eliteRateModifier || 0;
  }

  /** 获取敌人池偏向：'peaceful' | 'normal' | 'ferocious' */
  getEnemyPoolBias() {
    return this.getModifier().enemyPoolBias || 'normal';
  }

  /** 获取敌人伤害倍率 */
  getEnemyDamageMultiplier() {
    return this.getModifier().enemyDamageMultiplier || 1.0;
  }

  /** 获取玩家伤害倍率 */
  getPlayerDamageMultiplier() {
    return this.getModifier().playerDamageMultiplier || 1.0;
  }

  /** 获取世界状态提示文本（战斗开始时显示） */
  getWorldStatusText() {
    return this.getModifier().worldStatusText || '';
  }

  /** 获取世界状态主题色 */
  getThemeColor() {
    return this.getModifier().themeColor || '#DCDCDC';
  }

  // ==================== 商店价格 ====================

  /** 获取商店价格倍率 */
  getShopPriceMultiplier() {
    return this.getModifier().shopPriceMultiplier;
  }

  /**
   * 计算因果调整后的价格
   * @param {number} basePrice 基础价格
   * @returns {number} 调整后价格（取整）
   */
  adjustPrice(basePrice) {
    const multiplier = this.getShopPriceMultiplier();
    return Math.max(1, Math.round(basePrice * multiplier));
  }

  /** 获取价格调整描述（用于UI显示） */
  getPriceAdjustText() {
    const mult = this.getShopPriceMultiplier();
    if (mult < 1) return `商人特惠 -${Math.round((1 - mult) * 100)}%`;
    if (mult > 1) return `商贾戒备 +${Math.round((mult - 1) * 100)}%`;
    return '';
  }

  // ==================== 商品池过滤 ====================

  /**
   * 根据因果阶位过滤卡牌商品池
   * @param {Array} allCards 所有可用卡牌
   * @returns {Array} 过滤后的卡牌列表
   */
  filterCardPool(allCards) {
    const tier = this.getTier();

    if (tier === KARMA_TIERS.RIGHTEOUS) {
      // 善因果：正道商品优先，70%概率从正道池选取
      const righteousCards = allCards.filter(c => RIGHTEOUS_CARD_POOL.includes(c.name));
      const otherCards = allCards.filter(c => !RIGHTEOUS_CARD_POOL.includes(c.name));
      if (righteousCards.length > 0 && Math.random() < 0.7) {
        return [...righteousCards, ...otherCards];
      }
      return allCards;
    }

    if (tier === KARMA_TIERS.DEMONIC) {
      // 恶因果：妖魔商品混入，部分正道商品被锁定
      const demonicCards = allCards.filter(c => DEMONIC_CARD_POOL.includes(c.name));
      const availableCards = allCards.filter(c => !DEMONIC_LOCKED_CARDS.includes(c.name));
      if (demonicCards.length > 0 && Math.random() < 0.6) {
        // 妖魔商品优先排列
        return [...demonicCards, ...availableCards.filter(c => !DEMONIC_CARD_POOL.includes(c.name))];
      }
      return availableCards;
    }

    return allCards;
  }

  /**
   * 根据因果阶位过滤遗物商品池
   * @param {Array} allRelics 所有可用遗物
   * @returns {Array} 过滤后的遗物列表
   */
  filterRelicPool(allRelics) {
    const tier = this.getTier();

    if (tier === KARMA_TIERS.RIGHTEOUS) {
      // 善因果：正道遗物优先
      const righteousRelics = allRelics.filter(r => RIGHTEOUS_RELIC_IDS.includes(r.id));
      const otherRelics = allRelics.filter(r => !RIGHTEOUS_RELIC_IDS.includes(r.id));
      if (righteousRelics.length > 0 && Math.random() < 0.7) {
        return [...righteousRelics, ...otherRelics];
      }
      return allRelics;
    }

    if (tier === KARMA_TIERS.DEMONIC) {
      // 恶因果：锁定正道遗物，妖魔遗物优先
      const demonicRelics = allRelics.filter(r => DEMONIC_RELIC_IDS.includes(r.id));
      const availableRelics = allRelics.filter(r => !DEMONIC_LOCKED_RELIC_IDS.includes(r.id));
      if (demonicRelics.length > 0 && Math.random() < 0.6) {
        return [...demonicRelics, ...availableRelics.filter(r => !DEMONIC_RELIC_IDS.includes(r.id))];
      }
      return availableRelics;
    }

    return allRelics;
  }

  // ==================== 商品锁定 ====================

  /**
   * 判断卡牌是否被锁定（恶因果时商人不敢售卖）
   * @param {object} card 卡牌对象
   * @returns {boolean} 是否锁定
   */
  isCardLocked(card) {
    if (!this.isDemonic()) return false;
    return DEMONIC_LOCKED_CARDS.includes(card.name);
  }

  /**
   * 判断遗物是否被锁定
   * @param {object} relic 遗物对象
   * @returns {boolean} 是否锁定
   */
  isRelicLocked(relic) {
    if (!this.isDemonic()) return false;
    return DEMONIC_LOCKED_RELIC_IDS.includes(relic.id);
  }

  /** 获取锁定原因描述 */
  getLockedReason() {
    return '商贾畏惧你的煞气，此物不敢售';
  }

  // ==================== 敌人池调整 ====================

  /**
   * 获取精英怪生成率调整
   * @returns {number} 调整值（正=增加，负=减少）
   */
  getEliteRateModifier() {
    return this.getModifier().eliteRateModifier || 0;
  }

  /**
   * 获取玩家伤害倍率
   * @returns {number} 伤害倍率
   */
  getPlayerDamageMultiplier() {
    return this.getModifier().playerDamageMultiplier || 1;
  }

  /**
   * 获取敌人伤害倍率
   * @returns {number} 伤害倍率
   */
  getEnemyDamageMultiplier() {
    return this.getModifier().enemyDamageMultiplier || 1;
  }

  /**
   * 获取稀有掉落率加成
   * @returns {number} 加成值
   */
  getRelicDropRateBonus() {
    return this.getModifier().relicDropRateBonus || 0;
  }

  // ==================== UI 信息 ====================

  /** 获取当前因果阶位的显示信息 */
  getTierInfo() {
    const mod = this.getModifier();
    return {
      tier: this.getTier(),
      tierName: mod.tierName,
      karma: this.getKarma(),
      themeColor: mod.themeColor,
      description: mod.description,
      triggerDesc: mod.triggerDesc
    };
  }

  /** 获取因果进度描述（用于UI） */
  getKarmaProgressText() {
    const karma = this.getKarma();
    if (karma >= 5) return `善念鼎盛 (${karma}/10)`;
    if (karma >= 1) return `心存善念 (${karma}/10)`;
    if (karma <= -5) return `恶贯满盈 (${karma}/-10)`;
    if (karma <= -1) return `心生恶念 (${karma}/-10)`;
    return `因果中立 (${karma})`;
  }
}

// 导出常量供外部使用
export { KARMA_TIERS, KARMA_THRESHOLDS, KARMA_MODIFIERS, calculateKarmaTier, getKarmaModifier };
