﻿import { getAchievements, saveAchievements } from '../config/storage.js';
/**
 * @file 类型定义与枚举常量
 * 本文件是项目类型系统的唯一真源，所有状态模型、枚举、常量在此定义
 */

import { ACHIEVEMENT_CONFIG } from '../config/constants.js';

// ==================== 核心状态模型定义 ====================

/**
 * RunState — 单局游戏持久化状态
 * 存储于 localStorage，跨场景/跨战斗保留，是游戏进度的唯一真源
 * @typedef {Object} RunState
 * @property {number} chapter - 当前章节 (1/2/3)
 * @property {string} characterId - 角色ID
 * @property {number} hp - 当前气血
 * @property {number} maxHp - 气血上限
 * @property {number} gold - 铜钱
 * @property {number} karma - 因果值 (-10~10)
 * @property {string} karmaTier - 因果阶位 (righteous/neutral/demonic)
 * @property {Array} relics - 法宝/遗物列表
 * @property {Array} allCards - 卡组（所有卡牌）
 * @property {string|null} currentNodeId - 当前地图节点ID
 * @property {Array} map - 二维地图节点数组
 * @property {number} startTime - 开始时间戳
 * @property {number} turnCounter - 总回合数
 * @property {BuildState|null} buildState - 流派构筑状态（跨战斗持久化）
 */

/**
 * BuildState — 流派构筑状态（持久化子状态）
 * 存在 RunState.buildState 中，战斗创建时 deserialize，结束时 serialize
 * @typedef {Object} BuildState
 * @property {Object} dominantElements - 各元素出牌计数 {金,木,水,火,土}
 * @property {Object} buildTags - 流派激活状态 {flames,frost,vine,stone,blade}
 * @property {Object} buildLevel - 流派等级 {flames,frost,vine,stone,blade}
 * @property {Object} buildBonuses - 流派增益数值（各流派独立）
 * @property {number} turnHealTotal - 本回合治疗总量
 * @property {boolean} enemyFrozenLastTurn - 敌人上回合是否被冻结
 */

/**
 * BattleState — 战斗临时运行态
 * 每场战斗创建，战斗结束后销毁，不持久化
 * @typedef {Object} BattleState
 * @property {Object} player - 玩家战斗状态（手牌/牌堆/弃牌堆/护盾/能量等）
 * @property {Object} enemy - 敌人战斗状态（HP/攻击/意图/负面效果等）
 * @property {number} chapter - 当前章节
 * @property {string} phase - 战斗阶段 (player_action/enemy_turn/battle_end)
 * @property {MarkManager} markManager - 印记管理器（战斗内临时状态）
 * @property {BuildSystem} buildSystem - 流派系统（从 RunState.buildState 恢复）
 * @property {number} turnCount - 当前战斗回合数
 * @property {Array} log - 战斗日志
 * @property {boolean} win - 是否胜利（battle_end 时设置）
 */

/**
 * EventState — 事件状态机临时运行态
 * 每次进入事件创建，事件结束后销毁，不持久化
 * @typedef {Object} EventState
 * @property {Array} stages - 事件阶段列表
 * @property {number} currentStageIndex - 当前阶段索引
 * @property {Object} selectedChoice - 当前选中的选项
 * @property {Array} gains - 已获得的奖励列表
 * @property {boolean} resolved - 是否已结算
 */

export const ELEMENTS = ['金', '木', '水', '火', '土', '无'];

// 卡牌 UI 分类标签（仅用于界面展示/图标/类型判断，战斗逻辑由 effects 数组驱动）
// 与 data.js 中 CARD_TEMPLATES / SPECIAL_SHOP_CARDS 的 effectType 字段保持一致
export const CARD_EFFECT_TYPES = [
  'damage',           // 纯伤害
  'damage_draw',      // 伤害+抽牌
  'damage_skip',      // 伤害+定身
  'dual_damage_shield', // 双修伤害+护盾
  'extra_shield',     // 伤害+额外护盾
  'shield',           // 纯护盾
  'shield_burn',      // 护盾+灼烧
  'next_attack_bonus', // 护盾+蓄力
  'heal',             // 纯治疗
  'heal_draw',        // 治疗+抽牌
  'draw',             // 纯抽牌
  'gain_energy',      // 回能+抽牌
  'skip_enemy',       // 纯定身
  'clear_debuff',     // 净化+护盾
  'curse'             // 诅咒卡（负面）
];

// 地图节点类型（唯一真源，map.js re-export，所有场景通过此常量引用）
export const NODE_TYPES = {
  BATTLE: 'battle',
  ELITE: 'elite',
  EVENT: 'event',
  SHOP: 'shop',
  REST: 'rest',
  BOSS: 'boss'
};

// 地图节点状态（与 map.js / stepToNode 中使用的值保持一致）
export const NODE_STATUS = ['locked', 'available', 'visited'];

let cardIdCounter = 0;
export function generateCardId() { return 'card_' + (++cardIdCounter); }
let nodeIdCounter = 0;
export function generateNodeId() { return 'node_' + (++nodeIdCounter); }

// 在 CHARACTERS 对象中更新 nezha 配置
export const CHARACTERS = {
  taoist: {
    id: 'taoist',
    name: '游方道士',
    title: '玄门正宗',
    maxHp: 30,
    maxEnergy: 3,
    elementPreference: ['金', '木'],
    passive: '符咒与法术卡消耗灵气 -1',
    unlocked: true
  },
  fox_spirit: {
    id: 'fox_spirit',
    name: '青丘狐仙',
    title: '九尾幻化',
    maxHp: 25,
    maxEnergy: 3,
    elementPreference: ['水', '火'],
    passive: '使用水/木系符箓时额外抽取 1 张牌',
    unlocked: true
  },
  zhong_kui: {
    id: 'zhong_kui',
    name: '伏魔天师 · 钟馗',
    title: '判官赐福',
    maxHp: 35,
    maxEnergy: 3,
    elementPreference: ['火', '金'],
    passive: '对妖邪造成的攻击伤害额外 +2',
    unlocked: false,
    unlockCondition: '击败第一章魁首【黑山山魈王】解锁'
  },
  nezha: {
    id: 'nezha',
    name: '三坛海会 · 哪吒',
    title: '莲花化身',
    maxHp: 28,
    maxEnergy: 3,
    elementPreference: ['火', '木'],
    passive: '【莲花重生】每场战斗受到致命伤害时满血复活 1 次',
    unlocked: false,
    unlockCondition: '历经生死磨难（累计在战斗中阵亡 5 次）解锁'
  },
  bai_suzhen: {
    id: 'bai_suzhen',
    name: '千年蛇仙 · 白素贞',
    title: '灵蛇衔珠',
    maxHp: 26,
    maxEnergy: 3,
    elementPreference: ['水', '木'],
    passive: '【千年修为】剩余灵气可无限继承至下回合；每点当前灵气使卡牌伤害 +5%',
    unlocked: true,
    unlockCondition: '免费体验角色'
  }
};

// 可玩角色 ID 列表（自动从 CHARACTERS 派生，永远不会和实际配置脱节）
export const CHARACTER_IDS = Object.freeze(Object.keys(CHARACTERS));

export const RELIC_TEMPLATES = [
  { id: 'relic_taiji', name: '太极印', description: '每回合开始时，自动获得 2 点护盾', rarity: '普通', hook: 'on_turn_start', value: 2 },
  { id: 'relic_tianji', name: '天机册', description: '每回合开始时，额外抽取 1 张牌', rarity: '稀有', hook: 'on_turn_start', value: 1 },
  { id: 'relic_panshi', name: '不灭磐石', description: '每回合开始时，额外获得 3 点坚石护盾', rarity: '稀有', hook: 'on_turn_start', value: 3 },
  { id: 'relic_jiangyao', name: '降妖剑', description: '所有攻击卡牌造成的伤害额外 +2', rarity: '稀有', hook: 'on_damage', value: 2 },
  { id: 'relic_lihuoyu', name: '离火玉', description: '火系卡牌造成的伤害额外 +3', rarity: '稀有', hook: 'on_damage', value: 3 },
  { id: 'relic_qingmu', name: '青木珠', description: '所有气血恢复效果额外 +2', rarity: '普通', hook: 'on_heal', value: 2 },
  { id: 'relic_gongde', name: '功德金莲', description: '战斗开始时，依据当前【善因果×2】获得护盾', rarity: '史诗', hook: 'on_battle_start', value: 2 },
  { id: 'relic_fuchen', name: '三清拂尘', description: '道法自然，战斗初始灵气额外 +1', rarity: '传说', hook: 'on_battle_start', value: 1 },
  { id: 'relic_jubao', name: '聚宝盆', description: '降妖胜利后获得的铜钱数量提升 20%', rarity: '普通', hook: 'on_reward', value: 20 },
  // ★ 重写因果镜神效：因果反噬
  { id: 'relic_yinguojing', name: '因果镜', description: '【因果反噬】每次受到敌人出招攻击时，反弹 4 点真实伤害', rarity: '史诗', hook: 'on_damaged', value: 4 },
  // ★ 流派专属遗物
  { id: 'relic_zhuque_yu', name: '朱雀羽', description: '【烈煞】火印引爆后，本回合火属性伤害额外 +30%', rarity: '稀有', hook: 'on_mark_detonate', value: 0.3, buildTag: 'flames' },
  { id: 'relic_lianyao_hu', name: '炼妖壶碎片', description: '【烈煞】灼烧造成的伤害翻倍', rarity: '稀有', hook: 'on_burn', value: 2, buildTag: 'flames' },
  { id: 'relic_xuanbing_pei', name: '玄冰佩', description: '【寒渊】水印引爆后，敌人冻结持续 +1 回合', rarity: '稀有', hook: 'on_mark_detonate', value: 1, buildTag: 'frost' },
  { id: 'relic_ningshui_yu', name: '凝水玉', description: '【寒渊】水印引爆时额外抽取 1 张牌', rarity: '稀有', hook: 'on_mark_detonate', value: 1, buildTag: 'frost' },
  { id: 'relic_shenmu_zhongzi', name: '神木种子', description: '【青藤】木印治疗溢出的部分转化为护盾', rarity: '稀有', hook: 'on_mark_detonate', value: 1, buildTag: 'vine' },
  { id: 'relic_kumu_jie', name: '枯木戒', description: '【青藤】气血低于 50% 时，木系符箓费用 -1', rarity: '稀有', hook: 'on_card_cost', value: 1, buildTag: 'vine' },
  { id: 'relic_panshi_hexin', name: '磐石核心', description: '【磐石】护盾超过 20 点时，造成伤害 +20%', rarity: '稀有', hook: 'on_damage', value: 0.2, buildTag: 'stone' },
  { id: 'relic_fanshang_jia', name: '反伤甲', description: '【磐石】护盾破碎时反伤比例额外 +25%', rarity: '稀有', hook: 'on_shield_break', value: 0.25, buildTag: 'stone' },
  // ==================== 第三章剧情特殊遗物 ====================
  { id: 'relic_xiuniang_yupei', name: '绣娘玉佩', description: '【剧情】兰若寺绣娘残魂所化，温润如玉。持有可在九尾战中触发特殊对话', rarity: '史诗', hook: 'story', value: 1 },
  { id: 'relic_zhilv_yinji', name: '执律印记', description: '【剧情】前世天庭执律仙官的身份印记。持有可解锁隐藏结局【真相之眼】', rarity: '传说', hook: 'story', value: 1 },
  { id: 'relic_qingqiu_huzhu', name: '青丘狐珠', description: '【剧情】青丘遗老所赠，蕴含九尾公主的一缕善念。持有可解锁结局【以情动人】', rarity: '史诗', hook: 'story', value: 1 },
  { id: 'relic_xuanming_zhiyan', name: '玄冥之眼', description: '【剧情】窥见玄冥真身后获得的禁忌之眼。战斗开始时，所有伤害 +15%', rarity: '传说', hook: 'on_battle_start', value: 0.15 },
  { id: 'relic_yuanli_qianghua', name: '怨力强化', description: '炼化万魂怨力所得，周身黑气缭绕。所有攻击伤害 +3', rarity: '稀有', hook: 'on_damage', value: 3 },
  { id: 'relic_fengshen_canye', name: '封神榜残页', description: '封神台遗址出土的残页，记载着上古神将的杀伐之道。永久攻击 +1', rarity: '史诗', hook: 'on_damage', value: 1 },
  { id: 'relic_mingyuan_haoqi', name: '鸣冤浩气', description: '【第二章】枉死城老妪的血状所化浩然正气。对鬼差类敌人伤害 +2', rarity: '稀有', hook: 'on_damage', value: 2 }
];

export const SCENE_TYPES = { MENU: 'menu', MAP: 'map', BATTLE: 'battle', EVENT: 'event', SHOP: 'shop', REST: 'rest' };

// ★ 新增：成就系统图鉴
export const ACHIEVEMENTS = [
  { id: 'first_blood', name: '初露锋芒', desc: '首次战胜游荡的妖邪', icon: '斩' },
  { id: 'flawless', name: '道体无瑕', desc: '以毫发无损之姿赢下一场战斗', icon: '璧' },
  { id: 'chap1_clear', name: '破除黑风', desc: '击败黑山山魈王，平定兰若古刹', icon: '魁' },
  { id: 'rich', name: '腰缠万贯', desc: '单局内持有超过 150 铜钱', icon: '金' },
  { id: 'karma_max', name: '功德圆满', desc: '单局内善念因果达到极盛(10点)', icon: '善' },
  // ★ 新增第二章通关成就
  { id: 'chap2_clear', name: '大闹地府', desc: '击败阴阳判官，肃清枉死城', icon: '冥' },
  // ★ 新增第三章（终章）通关成就
  { id: 'chap3_clear', name: '封印归墟', desc: '击败九尾狐·归墟之门，道成圆满', icon: '归' }
];

// ★ 新增：成就解锁触发器
export function unlockAchievement(id) {
  const unlocked = getAchievements();
  if (!unlocked[id]) {
    unlocked[id] = true;
    saveAchievements(unlocked);

    const ach = ACHIEVEMENTS.find(a => a.id === id);
    if (ach) {
      wx.showToast({
        title: `成就达成: ${ach.name}`,
        icon: 'none',
        duration: ACHIEVEMENT_CONFIG.TOAST_DISPLAY_DURATION
      });
    }
  }
}