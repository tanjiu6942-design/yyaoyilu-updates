import { ELEMENTS, CHARACTERS } from './types.js';
import { BATTLE, STORAGE_KEYS } from '../config/constants.js';
import { safeGetStorage, safeSetStorage } from '../config/storage.js';
export { ELEMENTS };

// ==================== 五行流派标签枚举 ====================
export const BUILD_TAGS = {
  FIRE: 'fire',       // 烈煞流（火系爆发）
  WATER: 'water',     // 寒渊流（水系控制）
  WOOD: 'wood',       // 青藤流（木系续航）
  EARTH: 'earth',     // 磐石流（土系护盾反击）
  METAL: 'metal',     // 破甲流（金系真伤）
  NEUTRAL: 'neutral'  // 通用/中立/诅咒
};

// 内置自增卡牌 ID 生成器，防止外部依赖丢失
export function generateCardId() {
  return 'card_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
}

export function getElementRelation(attackerElement, defenderElement) {
  if (attackerElement === "无" || defenderElement === "无") return { multiplier: 1.0, relation: "普通" };
  if (BATTLE.ELEMENT_ADVANTAGE_MAP[attackerElement] === defenderElement) return { multiplier: BATTLE.ELEMENT_ADVANTAGE_MULTIPLIER, relation: "克制" };
  if (BATTLE.ELEMENT_ADVANTAGE_MAP[defenderElement] === attackerElement) return { multiplier: BATTLE.ELEMENT_DISADVANTAGE_MULTIPLIER, relation: "被克" };
  return { multiplier: 1.0, relation: "普通" };
}

export function calculateElementDamage(baseDamage, attackerElement, defenderElement) {
  const { multiplier, relation } = getElementRelation(attackerElement, defenderElement);
  let finalDamage = baseDamage;
  if (relation === "克制") finalDamage = Math.ceil(baseDamage * multiplier);
  else if (relation === "被克") finalDamage = Math.max(1, Math.floor(baseDamage * multiplier));
  return { finalDamage, relation };
}

export function applyElementMark(currentMarks, newElement, count = 1) {
  if (newElement === "无") {
    return { 
      nextMarks: { ...currentMarks }, 
      trigger: { triggered: false, element: "无", effectDesc: "" } 
    };
  }

  const nextMarks = { ...currentMarks };
  const totalCount = (nextMarks[newElement] || 0) + count;
  const threshold = BATTLE.MARK_TRIGGER_COUNT;

  if (totalCount < threshold) {
    nextMarks[newElement] = totalCount;
    return { 
      nextMarks, 
      trigger: { 
        triggered: false, 
        element: newElement, 
        effectDesc: `${newElement}印记: ${totalCount}/${threshold}` 
      } 
    };
  }

  // 达到阈值：触发引爆，保留剩余层数
  const remaining = totalCount - threshold;
  nextMarks[newElement] = remaining;

  const markConfig = BATTLE.MARK_EFFECTS[newElement] || {};
  let trigger = { 
    triggered: true, 
    element: newElement, 
    effectDesc: markConfig.description || "" 
  };

  if (newElement === "金") trigger.damageBonus = markConfig.damageBonus;
  else if (newElement === "木") trigger.healBonus = markConfig.healBonus;
  else if (newElement === "水") trigger.freezeEnemy = markConfig.freezeEnemy;
  else if (newElement === "火") trigger.doubleDamage = markConfig.doubleDamage;
  else if (newElement === "土") trigger.shieldBonus = markConfig.shieldBonus;

  return { nextMarks, trigger };
}

// ==================== 基础卡牌模板库（已注入 buildTag） ====================
export const CARD_TEMPLATES = [
  { key: "yu_jian_shu", name: "御剑术", type: "攻击", element: "金", buildTag: BUILD_TAGS.METAL, cost: 1, star: 0, effectType: "damage", description: "造成6点伤害，附带1层金印", effects: [{ type: "damage", value: 6 }] },
  { key: "heng_sao_qian_jun", name: "横扫千军", type: "攻击", element: "木", buildTag: BUILD_TAGS.WOOD, cost: 1, star: 0, effectType: "damage", description: "造成5点伤害，附带1层木印", effects: [{ type: "damage", value: 5 }] },
  { key: "liu_shui_jian", name: "流水剑", type: "攻击", element: "水", buildTag: BUILD_TAGS.WATER, cost: 1, star: 0, effectType: "damage_draw", description: "造成5点伤害，抽1张牌，附带1层水印", effects: [{ type: "damage", value: 5 }, { type: "draw", value: 1 }] },
  { key: "lie_huo_zhan", name: "烈火斩", type: "攻击", element: "火", buildTag: BUILD_TAGS.FIRE, cost: 1, star: 0, effectType: "damage", description: "造成7点伤害，附带1层火印", effects: [{ type: "damage", value: 7 }] },
  { key: "lie_di_quan", name: "裂地拳", type: "攻击", element: "土", buildTag: BUILD_TAGS.EARTH, cost: 1, star: 0, effectType: "extra_shield", description: "造成5点伤害，获得4点护盾，附带1层土印", effects: [{ type: "damage", value: 5 }, { type: "shield", value: 4 }] },
  { key: "wu_lei_zheng_fa", name: "五雷正法", type: "攻击", element: "金", buildTag: BUILD_TAGS.METAL, cost: 2, star: 0, markCount: 2, effectType: "damage", description: "造成10点金伤，直接附带2层金印", effects: [{ type: "damage", value: 10 }] },
  { key: "san_wei_zhen_huo", name: "三昧真火", type: "攻击", element: "火", buildTag: BUILD_TAGS.FIRE, cost: 2, star: 0, effectType: "damage", description: "造成12点火伤，自身扣除2点生命", effects: [{ type: "damage", value: 12 }, { type: "selfDamage", value: 2 }] },
  { key: "tai_ji_hu_ti", name: "太极护体", type: "防御", element: "水", buildTag: BUILD_TAGS.WATER, cost: 1, star: 0, effectType: "shield", description: "获得5点护盾，附带1层水印", effects: [{ type: "shield", value: 5 }] },
  { key: "jin_zhong_zhao", name: "金钟罩", type: "防御", element: "金", buildTag: BUILD_TAGS.EARTH, cost: 2, star: 0, effectType: "shield", description: "获得12点护盾，附带1层金印（金土联动）", effects: [{ type: "shield", value: 12 }] },
  { key: "mu_jia_shu", name: "木甲术", type: "防御", element: "木", buildTag: BUILD_TAGS.WOOD, cost: 1, star: 0, effectType: "next_attack_bonus", description: "获得5点护盾，下次攻击伤害+3", effects: [{ type: "shield", value: 5 }, { type: "nextAttackBonus", value: 3 }] },
  { key: "tu_qiang_shu", name: "土墙术", type: "防御", element: "土", buildTag: BUILD_TAGS.EARTH, cost: 1, star: 0, effectType: "shield", description: "获得7点护盾，附带1层土印", effects: [{ type: "shield", value: 7 }] },
  { key: "hui_chun_shu", name: "回春术", type: "法术", element: "木", buildTag: BUILD_TAGS.WOOD, cost: 1, star: 0, effectType: "heal", description: "恢复6点HP，附带1层木印", effects: [{ type: "heal", value: 6 }] },
  { key: "ding_shen_fu", name: "定身符", type: "法术", element: "土", buildTag: BUILD_TAGS.EARTH, cost: 2, star: 0, effectType: "skip_enemy", description: "敌人跳过下回合行动", effects: [{ type: "skip" }] },
  { key: "yin_ling_jue", name: "引灵诀", type: "法术", element: "木", buildTag: BUILD_TAGS.WOOD, cost: 1, star: 0, effectType: "draw", description: "抽取2张牌", effects: [{ type: "draw", value: 2 }] },
  { key: "jing_xin_zhou", name: "净心咒", type: "符咒", element: "水", buildTag: BUILD_TAGS.WATER, cost: 1, star: 0, effectType: "clear_debuff", description: "清除负面状态与诅咒，获得4点护盾", effects: [{ type: "clearDebuff" }, { type: "shield", value: 4 }] },
  { key: "zhong_kui_card", name: "钟馗", type: "人物", element: "火", buildTag: BUILD_TAGS.FIRE, cost: 3, star: 0, effectType: "damage", description: "出场造成6点群体火伤，附带1层火印", effects: [{ type: "damage", value: 6 }] },
  { key: "nezha_card", name: "哪吒", type: "人物", element: "火", buildTag: BUILD_TAGS.FIRE, cost: 3, star: 0, effectType: "damage_draw", description: "出场造成8点火伤并抽2张牌", effects: [{ type: "damage", value: 8 }, { type: "draw", value: 2 }] },
  { key: "suo_hun_zhou", name: "索魂咒", type: "诅咒", element: "无", buildTag: BUILD_TAGS.NEUTRAL, cost: 1, star: 0, effectType: "curse", isCurse: true, description: "【负面诅咒】占用手牌，消耗1点灵气将其化解焚毁", effects: [] }
];

// ==================== 商店特殊卡牌（已注入 buildTag） ====================
export const SPECIAL_SHOP_CARDS = [
  { key: "wan_jian_gui_zong", name: "万剑归宗", type: "攻击", element: "金", buildTag: BUILD_TAGS.METAL, cost: 2, star: 0, price: 65, markCount: 2, effectType: "damage", description: "祭出千柄飞剑，造成14点极巨金伤，附带2层金印", effects: [{ type: "damage", value: 14 }] },
  { key: "shen_mu_ling_jia", name: "神木灵甲", type: "防御", element: "木", buildTag: BUILD_TAGS.WOOD, cost: 1, star: 0, price: 45, effectType: "next_attack_bonus", description: "获得8点护盾，本回合下次攻击伤害额外+4", effects: [{ type: "shield", value: 8 }, { type: "nextAttackBonus", value: 4 }] },
  { key: "xuan_shui_kuang_chao", name: "玄水狂潮", type: "攻击", element: "水", buildTag: BUILD_TAGS.WATER, cost: 2, star: 0, price: 55, effectType: "damage_draw", description: "造成8点水伤并立即抽取2张牌，附带1层水印", effects: [{ type: "damage", value: 8 }, { type: "draw", value: 2 }] },
  { key: "jiu_long_shen_huo_zhao", name: "九龙神火罩", type: "防御", element: "火", buildTag: BUILD_TAGS.FIRE, cost: 2, star: 0, price: 60, effectType: "shield_burn", description: "获得10点烈焰护盾，使敌方陷入2回合灼烧", effects: [{ type: "shield", value: 10 }, { type: "burn", turns: 2, damage: 4 }] },
  { key: "tai_shan_ya_ding", name: "泰山压顶", type: "攻击", element: "土", buildTag: BUILD_TAGS.EARTH, cost: 3, star: 0, price: 70, markCount: 2, effectType: "damage", description: "造成16点破山重击，附带2层土印", effects: [{ type: "damage", value: 16 }] },
  { key: "qian_kun_jie_fa", name: "乾坤借法", type: "法术", element: "无", buildTag: BUILD_TAGS.NEUTRAL, cost: 0, star: 0, price: 80, effectType: "gain_energy", description: "消耗天命，立即恢复2点灵气并抽1张牌", effects: [{ type: "gainEnergy", value: 2 }, { type: "draw", value: 1 }] },
  { key: "ku_mu_feng_chun", name: "枯木逢春", type: "法术", element: "木", buildTag: BUILD_TAGS.WOOD, cost: 1, star: 0, price: 50, effectType: "heal_draw", description: "生生不息，恢复8点气血并抽1张牌", effects: [{ type: "heal", value: 8 }, { type: "draw", value: 1 }] },
  { key: "liang_yi_jian_fa", name: "两仪剑法", type: "攻击", element: "水", buildTag: BUILD_TAGS.WATER, cost: 2, star: 0, price: 75, dualElement: true, effectType: "dual_damage_shield", description: "水金双极：造成9点双修伤害，获得6点护盾", effects: [{ type: "damage", value: 9 }, { type: "shield", value: 6 }] },
  { key: "sun_wu_kong", name: "孙悟空", type: "人物", element: "金", buildTag: BUILD_TAGS.METAL, cost: 3, star: 0, price: 95, effectType: "damage_skip", description: "齐天大圣降临：造成12点伤害并直接定身敌方1回合", effects: [{ type: "damage", value: 12 }, { type: "skip" }] },
  { key: "bai_su_zhen", name: "白素贞", type: "人物", element: "水", buildTag: BUILD_TAGS.WATER, cost: 3, star: 0, price: 90, effectType: "heal_draw", description: "千年灵蛇护佑：恢复10点生命并抽取2张牌", effects: [{ type: "heal", value: 10 }, { type: "draw", value: 2 }] }
];

export function getCleanBaseName(name) {
  return (name || '').replace(/\++$/, '');
}

export function getUpgradedCard(card) {
  if (!card) return null;
  const currentStar = card.star !== undefined ? card.star : (card.isUpgraded ? 1 : 0);
  if (currentStar >= 2) return card;

  const nextStar = currentStar + 1;
  const baseName = getCleanBaseName(card.name);

  const upgraded = { 
    ...card, 
    id: generateCardId(), 
    name: baseName, 
    star: nextStar, 
    isUpgraded: true,
    buildTag: card.buildTag || BUILD_TAGS.NEUTRAL,
    effects: card.effects ? card.effects.map(e => ({ ...e })) : []
  };

  const starTag = nextStar === 2 ? '【二星·极】' : '【一星】';

  // 引灵诀特殊：升级降费，2星多抽1张
  if (baseName === '引灵诀') {
    upgraded.cost = 0;
    const drawEffect = upgraded.effects.find(e => e.type === 'draw');
    if (drawEffect) drawEffect.value = nextStar === 2 ? 3 : 2;
    upgraded.description = nextStar === 1 
      ? "【一星】消耗0灵气，抽取2张牌" 
      : "【二星·极】消耗0灵气，抽取3张牌";
    return upgraded;
  }

  const upgradeFactor = (val) => Math.round(val * 1.45 + (nextStar === 1 ? 2 : 3));
  let mainValue = 0;
  let mainType = '';

  upgraded.effects.forEach(effect => {
    if (effect.type === 'damage' || effect.type === 'shield' || effect.type === 'heal') {
      effect.value = upgradeFactor(effect.value);
      mainValue = effect.value;
      mainType = effect.type;
    }
  });

  if (card.cost >= 2 && nextStar === 2 && Math.random() > 0.4) {
    upgraded.cost = Math.max(1, card.cost - 1);
  }

  if (mainType === 'damage') {
    upgraded.description = `${starTag}造成${mainValue}点伤害，附带五行印记`;
  } else if (mainType === 'shield') {
    upgraded.description = `${starTag}获得${mainValue}点护盾，坚如磐石`;
  } else if (mainType === 'heal') {
    upgraded.description = `${starTag}恢复${mainValue}点生命值`;
  } else {
    upgraded.description = `${starTag}${(card.description || '').replace(/【.*?】/g, '')}（效能大幅提升）`;
  }

  return upgraded;
}

export function canCombineCards(cardA, cardB) {
  if (!cardA || !cardB || cardA.id === cardB.id) return false;
  const nameA = getCleanBaseName(cardA.name);
  const nameB = getCleanBaseName(cardB.name);
  const starA = cardA.star !== undefined ? cardA.star : (cardA.isUpgraded ? 1 : 0);
  const starB = cardB.star !== undefined ? cardB.star : (cardB.isUpgraded ? 1 : 0);
  return nameA === nameB && starA === starB && starA < 2;
}

export function combineTwoCards(cardA, cardB) {
  if (!canCombineCards(cardA, cardB)) return null;
  return getUpgradedCard(cardA);
}

export function getFilteredRewardPool(basePool, playerAllCards) {
  const upgradedBaseNames = new Set(
    (playerAllCards || [])
      .filter(c => (c.star && c.star >= 1) || c.isUpgraded)
      .map(c => getCleanBaseName(c.name))
  );

  return basePool.map(card => {
    const baseName = getCleanBaseName(card.name);
    if (upgradedBaseNames.has(baseName)) {
      const currentStar = card.star || 0;
      if (currentStar === 0) {
        return getUpgradedCard(card);
      }
    }
    return { ...card };
  });
}

export const ENEMY_TEMPLATES = [
  { 
    key: "you_dang_shan_xiao", name: "游荡山魈", hp: 40, maxHp: 40, element: "木", attack: 9, behavior: "balanced", 
    special: "山中妖雾化生的木魅，基础妖邪",
    skills: "出招攻伐(9伤) / 聚气化盾(+5~7盾) / 蓄势待发(攻+1)",
    background: "黑风岭深处常年弥漫的阴煞木气，经百年吞吐月华，渐生灵智。此类山魈性喜模仿人声，常于深夜模仿过路商旅的亲友呼唤，诱人深入密林后群起而攻之。虽为最低等妖邪，却胜在数量繁多，是初入妖域修士最先遭遇的阻碍。"
  },
  { 
    key: "jue_di_jiang_shi", name: "掘地僵尸", hp: 50, maxHp: 50, element: "土", attack: 9, behavior: "defensive", 
    special: "乱葬荒冢爬出的尸煞，铜皮铁骨",
    skills: "高概率【运功固守】(+6~9盾) / 伺机反击(9伤)",
    background: "前朝末年战乱频仍，无数尸骨草草掩埋于乱葬岗中。地脉阴煞渗入尸身，令部分死尸不腐反僵，破土而出。此类僵尸双目赤红、指甲如铁，因生前多为贫苦农人，死后仍保留着躬身掘地的姿态，故得名掘地僵尸。"
  },
  { 
    key: "hu_li_jing", name: "狐狸精", hp: 38, maxHp: 38, element: "火", attack: 10, behavior: "aggressive", 
    special: "火系幻术狡黠凶险，善于狂攻",
    skills: "凶煞扑杀(10伤) / 【煞气暴涌】(永久攻击力+2)",
    background: "修行未满百年的狐妖，尚未化为人形，却已通晓魅惑之术。常以妖火幻象迷惑路人心智，趁其失神时痛下杀手。性情暴烈，一旦发现幻术无效便会狂怒猛攻，不惜以自身妖力为代价发动暴涌一击。"
  },
  { 
    key: "mei_ying_hua_pi", name: "魅影画皮", hp: 48, maxHp: 48, element: "金", attack: 11, behavior: "aggressive", 
    special: "披美人皮囊的高爆发恶煞，攻势迅猛",
    skills: "凶煞扑杀(11伤) / 煞气暴涌(永久攻+2) / 妖雾遮体(+5盾)",
    background: "专食年轻女子容貌的厉鬼，将被害者的人皮完整剥下披在身上，化作绝色美人模样行走于市。待猎物放松警惕后，便露出狰狞本相以利爪剖心。其皮坚韧如金铁，寻常兵刃难以伤及内里鬼躯。"
  },
  { 
    key: "hei_bai_wu_chang", name: "黑白无常", hp: 90, maxHp: 90, element: "水", attack: 13, behavior: "balanced", 
    special: "【精英】阴司勾魂使者，水系锁魂",
    skills: "每2回合必施【锁魂幽冥盾】(+12盾) / 幽冥索命(13伤)",
    background: "本为阴司正统勾魂使者，黑无常范无救、白无常谢必安。阴司大乱后，部分无常被判官重画命簿，沦为只知执行勾魂命令的傀儡。二人联手时一攻一守，锁链可直接勾人生魂，极难对付。"
  },
  { 
    key: "hei_shan_shan_xiao_wang", name: "黑山山魈王", hp: 170, maxHp: 170, element: "木", attack: 18, behavior: "aggressive", 
    special: "【第一章魁首】枯木老尊，统御黑风岭",
    skills: "血量≤50%触发【枯木狂暴】(攻击永久+3并蓄势重击)",
    background: "黑风岭群妖之首，本体是一株修炼千年的枯木老妖。它以山中阴煞为食，麾下山魈、僵尸无数。据传曾有正道修士十人组队前来围剿，竟无一生还。其树皮坚硬如铁，唯有在暴怒露出树心破绽时方可重创。"
  },
  { 
    key: "gu_hun_ye_gui", name: "孤魂野鬼", hp: 65, maxHp: 65, element: "水", attack: 10, behavior: "balanced", 
    special: "枉死城游荡恶鬼，出招附带怨气侵蚀",
    skills: "怨魂扑杀(10伤) / 阴气凝盾(+8盾) / 【阴风扰魂】(塞入1张索魂咒)",
    background: "中原大旱荒年死于冰冷河滩的流民怨魂。死后未得安葬，魂魄飘落阴司，却因判官重画命簿，连自己的生辰名姓都被抹去，成为无法转世的阴司黑户。它们在忘川河畔徘徊，不断哀号着自己被遗忘的名字。"
  },
  { 
    key: "you_ming_gui_huo", name: "幽冥鬼火", hp: 58, maxHp: 58, element: "火", attack: 12, behavior: "aggressive", 
    special: "地府阴火所化，出招暴烈并压制灵气",
    skills: "阴火噬体(12伤) / 【煞火暴涌】(永久攻+3) / 【阴火封脉】(使玩家下回合灵气-1)",
    background: "地藏菩萨座前原本常明万年的引魂琉璃灯。阴司大乱、菩萨金身崩碎时，神灯倾覆落入九幽血池，吸纳了无数受刑罪魂的极阴痛苦，由神圣佛火异化为吞噬灵气的极寒魔焰。它仍保留着一丝佛性，被灭时会化作舍利灯芯。"
  },
  { 
    key: "zhi_zha_shi_pu", name: "纸扎尸仆", hp: 82, maxHp: 82, element: "木", attack: 10, behavior: "defensive", 
    special: "阴司坚固纸傀儡，叠盾极强并反震反弹",
    skills: "【铜皮纸铠】(+14盾) / 纸刀劈砍(10伤) / 【煞气附体】(攻+2)",
    background: "阳世不肖子孙为求阴宅风水与免除罪责，以重金勾结邪修执行活人替刑之术，将生人魂魄以竹篾朱砂活活封入纸人躯壳，充作阴司衙役。它们两颊涂着血红胭脂，胸口被铁丝密密麻麻缝合着活人白骨，是阴司最令人发指的造物之一。"
  },
  { 
    key: "niu_tou_a_bang", name: "牛头阿傍", hp: 140, maxHp: 140, element: "土", attack: 16, behavior: "aggressive", 
    special: "【精英】镇守鬼门巨煞，重劈极痛并塞入诅咒",
    skills: "每3回合发动【开山巨劈】(16点暴击+塞入1张索魂咒)",
    background: "阴司昔日最忠正勇猛的巡抚大将。阎罗遭难时，他率三千阴兵死战不退，力竭被擒后被判官以七枚索魂灭神钉贯穿泥丸宫，神智被彻底抹除，异化为仅知杀戮的守门恶煞。即便如此，被木符破煞时仍会短暂恢复清明，痛呼钟馗之名。"
  },
  { 
    key: "yin_yang_pan_guan", name: "阴阳判官", hp: 230, maxHp: 230, element: "金", attack: 17, behavior: "balanced", 
    special: "【第二章魁首】掌管生死簿，具备斩杀、免伤阵法与幽冥诅咒",
    skills: "每3回合催动【生死簿】(穿盾15点真伤) / 首次半血开启【生死冥界阵】(免伤1回合)",
    background: "地府首座掌案判官。千百年来冷眼旁观人间生老病死，目睹无数凡人善行得恶果、恶徒享荣华，愤恨天道不公，最终在归墟妖神的蛊惑下夺取生死簿。他妄图以己身意志重写乾坤，却不知自己已彻底沦为魔胎蚕食地府的棋子。"
  },
  // ==================== 第三章敌人：归墟深渊 ====================
  { 
    key: "gui_xu_yuan_hun", name: "归墟怨魂", hp: 88, maxHp: 88, element: "水", attack: 13, behavior: "balanced", 
    special: "归墟哭墙中渗出的扭曲魂体，执念不散",
    skills: "怨魂扑杀(13伤) / 阴气凝盾(+10盾) / 【万魂哭嚎】(塞入1张索魂咒)",
    background: "从万魂哭墙中渗出的无数扭曲魂体凝聚成形，面孔不断变幻，时而为妖，时而为人，时而为仙。它们被九尾吞噬，灵识已散，唯有执念不消，不断哀号着被遗忘的名字。"
  },
  { 
    key: "shi_ling_can_ke", name: "噬灵残壳", hp: 82, maxHp: 82, element: "金", attack: 15, behavior: "aggressive", 
    special: "被归墟吞噬的修士残壳，符咒已被混沌污染",
    skills: "残壳扑击(15伤) / 【混沌符咒】(塞入1张索魂咒) / 煞气暴涌(永久攻+3)",
    background: "一具披着残破道袍的干枯尸壳从哭墙底部爬出，眼眶中跳动着惨绿色的鬼火，手中还紧握着一卷被混沌污染的符咒。生前是青云观无尘道人，被归墟吞噬后灵识泯灭，只剩吞噬修士灵气的本能。"
  },
  { 
    key: "hun_dun_you_hun", name: "混沌游魂", hp: 76, maxHp: 76, element: "火", attack: 16, behavior: "aggressive", 
    special: "归墟混沌之力所化的游魂，攻势暴烈",
    skills: "混沌烈焰(16伤) / 【煞火暴涌】(永久攻+3) / 【混沌侵蚀】(使玩家下回合灵气-1)",
    background: "归墟深处的混沌之力凝聚而成的游魂，没有固定的形态，只有不断燃烧的幽蓝火焰。它们是被吞噬的神佛残念所化，攻势暴烈，能侵蚀修士的灵脉。"
  },
  { 
    key: "gui_xu_shi_kui", name: "归墟石傀", hp: 108, maxHp: 108, element: "土", attack: 12, behavior: "defensive", 
    special: "归墟法则凝聚的石质傀儡，坚不可摧",
    skills: "【归墟岩甲】(+16盾) / 石拳重击(12伤) / 【大地震动】(塞入1张索魂咒)",
    background: "归墟法则崩坏后，混沌之力凝聚成的石质傀儡。它们没有灵魂，只有维持归墟秩序的本能。身躯由亿万被吞噬的生灵残骨凝结而成，坚不可摧。"
  },
  { 
    key: "jiu_wei_shan_nian", name: "九尾·善念残响", hp: 180, maxHp: 180, element: "火", attack: 20, behavior: "balanced", 
    special: "【精英】九尾分离出的最后一丝善念，藏于青丘废墟",
    skills: "狐火燎原(20伤) / 【善念护盾】(+15盾) / 每3回合【九尾幻影】(攻击两次)",
    background: "九尾狐还未被归墟吞噬的那一部分。千万年前，她还是青丘公主时留下的最后一丝善念，被分离出来藏在青丘废墟最深处。她等待着主角的到来，只为问一句：如果天道本身是谎言，你会怎么做？"
  },
  { 
    key: "jiu_wei_hu", name: "九尾狐·归墟之门", hp: 320, maxHp: 320, element: "火", attack: 20, behavior: "balanced", 
    special: "【第三章魁首】归墟守护者，多阶段战斗，开门仪式",
    skills: "阶段1:狐火天袭(20伤) / 阶段2(HP≤60%):混沌之兽(攻+5,每回合塞1张诅咒) / 阶段3(HP≤30%):归墟之门(免伤1回合+开门进度条,进度满则玩家失败)",
    background: "天庭创造的归墟守护者，实为封印玄冥的活锁。千万年孤独吞噬了她的善良，如今她要打开归墟之门，释放玄冥，推翻天庭。她不是妖，不是神，是一个被背叛了千万年的、想要自由的灵魂。"
  }
];

// ==================== 已击败敌人记录（万妖异录解锁） ====================

/** 获取已击败敌人的 key 集合 */
export function getDefeatedEnemies() {
  const data = safeGetStorage(STORAGE_KEYS.META.DEFEATED_ENEMIES, {});
  return data || {};
}

/** 记录击败的敌人 */
export function recordEnemyDefeat(enemyKey) {
  if (!enemyKey) return;
  const defeated = getDefeatedEnemies();
  if (!defeated[enemyKey]) {
    defeated[enemyKey] = {
      firstDefeatedAt: Date.now(),
      defeatCount: 1
    };
  } else {
    defeated[enemyKey].defeatCount = (defeated[enemyKey].defeatCount || 0) + 1;
  }
  safeSetStorage(STORAGE_KEYS.META.DEFEATED_ENEMIES, defeated);
}

/** 检查某个敌人是否已被击败（解锁详细信息） */
export function isEnemyUnlocked(enemyKey) {
  const defeated = getDefeatedEnemies();
  return !!defeated[enemyKey];
}

export const CHAPTER_1_EVENTS = [
  {
    id: 'event_lanruo_lamp',
    title: '荒亭孤灯',
    location: '黑风岭 · 破败茶肆',
    description: '三更时分，暴雨倾盆。你在山道旁发现了一座半坍塌的茅草茶肆。昏暗的油灯下，一位白发苍苍、衣衫褴褛的老妇正就着如豆的火光，用一根生锈的铁针缝补一双小儿虎头红鞋。\n见你避雨走入，老妇缓缓抬头，眼角流下两行浑浊的血泪，颤声道：“道长……行行好。我那可怜的孙儿白日里追野兔，掉进了后院那口深不见底的枯井里……井里好冷，有好多骨头在抓他的脚……求求道长救救他吧……”',
    choices: [
      { 
        text: '【拔剑相助】应允相救，诵念安魂神咒', 
        tip: '善因果 +1 · 获 25 铜钱', 
        karmaDelta: 1, 
        goldDelta: 25, 
        hpDelta: 0, 
        resultText: '你来到茶肆后院，发现枯井早已被落石填死，井口隐隐有小儿怨魂低泣。你并未嫌弃污秽，解下道袍铺地，取朱砂黄纸，盘膝坐于暴雨中为枯井亡魂诵念整整三遍《太上洞玄灵宝救苦妙经》。随着金光微现，一道小小的魂魄自井底浮出，向老妇招手消散。老妇泪流满面，身形化作一阵温暖的清风而去。石桌上，留下了当年客商遗落的一小袋铜钱。' 
      },
      { 
        text: '【破除障眼】指掐雷诀，勘破缢死鬼障', 
        tip: '因果 0 · 随机金系符箓精进', 
        karmaDelta: 0, 
        goldDelta: 0, 
        hpDelta: 0, 
        upgradeCardElement: '金',
        resultText: '你双目凝神，运起天眼通，瞬间看穿那双虎头鞋乃是以生人头皮缝制，老妇脖颈上赫然套着一根碗口粗的吊死绳圈！此乃山中恶鬼布下的“替死引魂局”。你面无表情，右手并指如剑，一道天雷真火呼啸而出，瞬间将幻境撕得粉碎！雷火熄灭后，前代剑客遗落的剑意融入你的符箓之中，令一张金系符箓威力大进。' 
      },
      { 
        text: '【强夺灯油】横剑逼问，强取幽冥古灯', 
        tip: '恶因果 -1 · 扣 4 气血上限 · 获【天机册】', 
        karmaDelta: -1, 
        goldDelta: 0, 
        hpDelta: -4, 
        customEffect: 'maxHpDec',
        rewardRelic: { id: 'relic_tianji', name: '天机册', description: '每回合开始额外抽 1 张牌', rarity: '稀有', hook: 'on_turn_start', value: 1 }, 
        resultText: '你冷笑一声，抽出利刃架在老妇颈上：“区区山魈伥鬼，也敢在本座面前演戏？交出你维持魂体不灭的这盏阴司油灯！”你一把夺过古灯，吹灭鬼火，将灯芯中的万年阴煞强行炼化入口。极致的阴寒撕裂了你的经脉，但在痛苦之中，你的神识竟借由阴阳之眼，隐隐看透了冥冥中天机运化的规律。' 
      }
    ]
  },
  {
    id: 'event_monk_shrine',
    title: '废刹金光与镇魔残碑',
    location: '兰若寺 · 废弃山门',
    description: '在坍塌的山门阶梯前，斜卧着一块被荆棘与黑血包围的汉白玉残碑。碑身刻满了梵文金刚经，隐隐透出一股神圣纯净的佛光，将方圆三丈内的浓重妖雾死死逼退。然而，残碑底部已被地下渗透出的黑血侵蚀开裂，无数枯骨手臂正从石缝中拼命向上挣扎。',
    choices: [
      { 
        text: '【注入灵气】引动正道玄光涤荡死气', 
        tip: '善因果 +1 · 恢复 10 气血', 
        karmaDelta: 1, 
        goldDelta: 0, 
        hpDelta: 10, 
        resultText: '你不忍见佛门圣迹蒙尘，毅然将自身辛苦修持的纯阳灵气源源不断注入残碑。石碑爆发出万道炽烈金芒，如暖阳融雪般消融了地底伸出的枯骨与冤孽。残碑反馈出一股纯和温润的佛门生机反哺你的道体，令你连日激战积累的暗伤尽数愈合。' 
      },
      { 
        text: '【参悟碑文】剥离前朝高僧伏魔剑意', 
        tip: '因果 0 · 随机火系符箓精进', 
        karmaDelta: 0, 
        goldDelta: 0, 
        hpDelta: 0, 
        upgradeCardElement: '火',
        resultText: '你对佛魔争斗不置可否，而是盘膝坐于碑前，凝视残碑上历代高僧镇魔时留下的纵横指印与刀剑劈痕。冥冥之中，你仿佛看到了百年前那位金身罗汉舍身成仁、以烈火焚尽万妖的悲壮一幕，胸中顿生一股无匹霸道的刚烈真意！这股真意融入你的火系符箓，令其威力大进。' 
      }
    ]
  },
  {
    id: 'event_graveyard_treasure',
    title: '乱葬青木与痴念新坟',
    location: '乱葬岗 · 无名新坟',
    description: '荒烟蔓草的乱葬岗角落，赫然立着一座泥土尚新的无名荒冢。坟前未立墓碑，只插着半截断裂的锈铁剑。泥土中散发着阵阵奇异的兰麝幽香，扒开浮土，露出一口贴着三道朱砂镇尸符的紫檀木宝箱。',
    choices: [
      { 
        text: '【强破封印】开箱取财', 
        tip: '获 35 铜钱 · 扣 3 气血', 
        karmaDelta: 0, 
        goldDelta: 35, 
        hpDelta: -3, 
        resultText: '你一剑劈断镇邪符箓，撬开宝箱。箱内金光闪闪，整齐码放着大量陪葬的金锭与铜钱。然而箱盖弹起的刹那，三枚淬有九幽尸毒的透骨钉迎面射出，虽被你侧身避开要害，却依然划破了你的手臂，毒血顺着指尖滴落。' 
      },
      { 
        text: '【安魂度化】施法化解墓主执念', 
        tip: '善因果 +2 · 获法宝【青木珠】', 
        karmaDelta: 2, 
        goldDelta: 0, 
        hpDelta: 0, 
        rewardRelic: { id: 'relic_qingmu', name: '青木珠', description: '所有治疗效果额外 +2', rarity: '普通', hook: 'on_heal', value: 2 }, 
        resultText: '你看出此墓乃是一位痴情女子为战死的未婚夫所立之衣冠冢。你取出随身葫芦中的清泉洒于坟前，点燃三炷清香，轻声诵念度人经，抚平了徘徊在断剑上的千年思念与怨怼。清烟袅袅升空，泥土中缓缓浮现出一枚通体晶莹剔透、温润如脂的翡翠宝珠。' 
      }
    ]
  },
  // ==================== 多阶段事件 ====================
  {
    id: 'event_lanruo_night',
    title: '兰若寺夜宿',
    location: '兰若寺 · 残破大殿',
    stages: [
      {
        description: '暮色四合，你行至兰若寺山门前。这座百年古刹早已荒废，山门匾额半落，殿内隐隐有烛光摇曳。山风过处，传来阵阵女子低泣之声。\n寺外有一棵千年古槐，枝桠扭曲如鬼爪，树下散落着几具早已腐朽的旅人骸骨。',
        choices: [
          { text: '【入寺借宿】推门进入大殿', nextStage: 1, resultText: '你推开沉重的山门，殿内积灰寸许，佛龛前竟点着一盏长明灯。' },
          { text: '【树下打坐】在古槐下运功过夜', nextStage: 2, resultText: '你盘膝坐于古槐下，闭目运功。夜半时分，一阵刺骨寒意将你惊醒。' }
        ]
      },
      {
        description: '大殿深处，一位身着素白衣裙的女子正背对佛像，低声吟唱着不知名的挽歌。她周身环绕着浓重的阴气，脚下的青砖上凝结着层层寒霜。\n听到脚步声，女子缓缓转身，面容绝美却毫无血色，双眸如两点寒星：“道长……既然来了，不如陪奴家说说话？”',
        choices: [
          { text: '【温情交谈】询问女子身世', karmaDelta: 1, hpDelta: -2, nextStage: 3, resultText: '你收起法器，温言询问女子身世。女子含泪诉说自己乃是百年前被负心人害死在此的绣娘，怨气不散化为厉鬼。她感激你的尊重，临别时赠你一缕绣线。' },
          { text: '【拔剑斩鬼】以天雷正法诛灭', karmaDelta: 0, hpDelta: -5, upgradeCardElement: '火', resultText: '你大喝一声，掌心雷火迸发！女鬼惨叫一声，化作漫天飞灰。然而她临死前的怨念化为一道寒气刺入你的经脉，令你受了些内伤。雷火余烬融入你的火系符箓，令其威力大进。' },
          { text: '【悄然退走】不与纠缠，退出大殿', karmaDelta: 0, goldDelta: 0, resultText: '你不愿多生事端，悄然退出大殿。山门在身后轰然关闭，女子的歌声渐渐远去。' }
        ]
      },
      {
        description: '夜半三更，古槐的枝桠突然动了！无数根须如毒蛇般从地下钻出，将你团团围住。树洞中传来一个苍老沙哑的声音：“小道士……百年了……终于有人来陪老夫了……”\n这竟是一棵修炼成精的千年槐树妖！',
        choices: [
          { text: '【以火焚树】召出三昧真火烧之', karmaDelta: 0, hpDelta: -3, goldDelta: 30, resultText: '你咬破指尖，以血为引，召出三昧真火！槐树妖惨叫连连，千年修为付之一炬。大火熄灭后，树洞中掉落出它多年来吞噬的旅人财物。' },
          { text: '【谈判周旋】许诺为其超度', karmaDelta: 1, hpDelta: 0, rewardRelic: { id: 'relic_taiji', name: '太极印', description: '每回合开始获得 2 点护盾', rarity: '普通', hook: 'on_turn_start', value: 2 }, resultText: '你正色道：“你虽害人，但也是被天道所弃。我可为你诵经超度，助你入轮回。”槐树妖沉默良久，最终放下根须，将一枚守护多年的古印交给你，随后自行散去修为。' }
        ]
      },
      {
        description: '女子将一缕浸过她泪水的绣线交给你。这缕绣线看似普通，却蕴含着她百年的执念与哀怨。\n“道长……若你日后遇到负心之人，替奴家……问问他，可还记得兰若寺的绣娘？”',
        choices: [
          { text: '【收下绣线】答应她的请求', karmaDelta: 1, upgradeCardElement: '水', resultText: '你郑重收下绣线，答应了她的请求。绣线入手冰凉，百年的哀怨与执念竟丝丝缕缕融入你的水系符箓之中，令其威力大进。女子含笑消散于晨光之中。' }
        ]
      }
    ]
  },
  {
    id: 'event_caravan_attack',
    title: '黑风岭商队',
    location: '黑风岭 · 山道',
    stages: [
      {
        description: '行至黑风岭山道，你听到前方传来兵刃交击之声。循声望去，一队商旅正被十几个山魈围攻。商队护卫已死伤过半，货物散落一地。\n为首的是一个身披虎皮的壮汉，手持一柄开山斧，正与三只山魈缠斗。他看到你，高声喊道：“道长相助！王某必有重谢！”',
        choices: [
          { text: '【拔刀相助】冲入战圈救人', nextStage: 1, resultText: '你拔剑冲入战圈，符箓翻飞，山魈纷纷退避。' },
          { text: '【趁火打劫】等他们两败俱伤', nextStage: 2, resultText: '你隐于树后，静待时机。半个时辰后，商队护卫全部战死，山魈也死伤过半。' },
          { text: '【绕道而行】不卷入纷争', karmaDelta: 0, goldDelta: 0, resultText: '你不愿多管闲事，绕道而行。身后的厮杀声渐渐远去，你心中却隐隐有些不安。' }
        ]
      },
      {
        description: '在你的帮助下，山魈被尽数击退。虎皮壮汉王大锤抱拳致谢，他是往返于阴阳两界的行商。\n“道长救命之恩，王某没齿难忘！这有些许财物，还请道长收下。另外……王某有一事相求。”',
        choices: [
          { text: '【收下财物】接受谢礼后离去', karmaDelta: 1, goldDelta: 40, resultText: '你收下王大锤递来的钱袋，里面有四十枚铜钱。他再三道谢后，收拾残货继续上路。' },
          { text: '【询问何事】听听他的请求', karmaDelta: 1, goldDelta: 20, rewardRelic: { id: 'relic_jiangyao', name: '降妖剑', description: '对妖邪类敌人伤害 +3', rarity: '稀有', hook: 'on_damage_to_demon', value: 3 }, resultText: '王大锤面露难色：“王某有一柄祖传降妖剑，却在方才的混战中遗失在山魈巢穴。道长若能帮我取回，这剑便赠予道长！”你随他寻回宝剑，果然锋芒毕露，乃是不可多得的法器。' }
        ]
      },
      {
        description: '你从树后走出，开始搜刮战场。商队货物中有不少值钱物件，山魈身上也带着一些从其他旅人处抢来的财物。\n就在你翻找时，一只装死的山魈突然暴起！',
        choices: [
          { text: '【斩杀山魈】反手一剑', karmaDelta: -1, hpDelta: -4, goldDelta: 55, resultText: '你反应极快，反手一剑斩杀山魈，但还是被它的利爪划伤了手臂。你将战场搜刮一空，获得五十五枚铜钱。然而这种行为让你心中的道心蒙上了一层阴影。' },
          { text: '【心生悔意】放下财物离去', karmaDelta: 0, hpDelta: 0, goldDelta: 10, resultText: '看着满地尸体，你突然心生悔意。你只取了十枚铜钱作为路费，将其余财物放回商队残骸中，合十致歉后离去。' }
        ]
      }
    ]
  },
  {
    id: 'event_ancient_well',
    title: '古井探秘',
    location: '无名山谷 · 枯井',
    stages: [
      {
        description: '山谷深处，你发现一口被藤蔓覆盖的古井。井沿刻着模糊的篆文，依稀可辨“锁龙”二字。井口不时冒出丝丝寒气，井中深不见底。\n传闻百年前，有一条恶龙被仙人镇压于此井之中。井中或许藏有龙女的骸骨与宝藏，但也可能有未知的危险。',
        choices: [
          { text: '【系绳下井】深入探索', nextStage: 1, resultText: '你将绳索系于井沿，纵身跃入井中。下降约三十丈后，双脚终于踏到实地。' },
          { text: '【取符镇井】留下镇邪符后离去', karmaDelta: 1, goldDelta: 0, resultText: '你取出朱砂黄纸，画了一道镇邪符贴于井沿。符纸金光一闪，井中寒气顿时减弱了许多。你合十行礼后离去，虽未得宝物，却做了一件功德。' }
        ]
      },
      {
        description: '井底是一个巨大的地下溶洞，钟乳石林立，中央有一汪寒潭。潭边散落着无数金银珠宝，一具巨大的白色骸骨半浸在潭水中，头上生着残缺的龙角。\n骸骨旁，一个透明的女子虚影正坐在潭边梳头。她抬头看到你，微微一笑：“百年了……终于有人下来陪我了。”',
        choices: [
          { text: '【取宝即走】拿了财宝就走', karmaDelta: -1, hpDelta: -6, goldDelta: 60, resultText: '你不顾女子虚影，径直去拿财宝。就在你触碰珠宝的瞬间，寒潭突然翻涌，龙女骸骨发出一声悲鸣，一道寒气将你击飞。你带着伤和六十枚铜钱狼狈逃出古井。' },
          { text: '【询问身世】与龙女虚影交谈', nextStage: 2, resultText: '你收起飞剑，温言询问。女子虚影眼中闪过一丝惊讶，随后缓缓道出了自己的身世。' },
          { text: '【诵经超度】为龙女念度亡经', karmaDelta: 2, hpDelta: 0, rewardRelic: { id: 'relic_gongde', name: '功德金莲', description: '正因果时每回合开始获得 3 点护盾', rarity: '稀有', hook: 'on_turn_start_righteous', value: 3 }, resultText: '你盘膝坐于潭边，为龙女诵念《度亡经》。随着经文声声，龙女虚影渐渐变得透明，她含泪向你拜了三拜，将一朵伴随她百年的功德金莲交给你，随后化为点点金光消散。寒潭中的寒气也随之散去。' }
        ]
      },
      {
        description: '女子自称是东海龙王的小女儿，百年前因触犯天条被镇压于此。她的真身早已死去，只剩一缕残魂守护着龙骨。\n“道长……我在此枯等百年，只为有人能将我的龙骨送回东海。若你肯相助，我愿将毕生修炼的龙珠赠予你。”',
        choices: [
          { text: '【答应相助】承诺送龙骨归海', karmaDelta: 1, upgradeCardElement: '水', resultText: '你郑重答应了龙女的请求。她欣慰一笑，将一枚蕴含浩瀚水之力的龙珠打入你的体内，龙珠之力融入你的水系符箓，令其威力大进。龙骨化为一道流光，随你一同离开了古井。' },
          { text: '【婉言拒绝】无法承担此任', karmaDelta: 0, goldDelta: 25, resultText: '你坦言自己修为尚浅，无法承担送龙骨归海的重任。龙女虽感失望，但仍赠你二十五枚铜钱作为路费，随后黯然消散于潭水之中。' }
        ]
      }
    ]
  }
];

export const CHAPTER_2_EVENTS = [
  {
    id: 'event_sansheng_wangchuan',
    title: '三生忘川石',
    location: '幽冥界 · 奈何桥残墩',
    description: '断裂的奈何桥残墩旁，矗立着一块高逾两丈、通体殷红如凝血的奇异巨石。石面上波光粼粼，隐隐映照出你前世修行的残影与过往斩妖的业障。孟婆亭早已倾塌，断柱旁倚坐着一位看不清面容的执碗阴差，正默默舀起一碗清冽的泉水。\n执碗阴差缓缓抬头，空洞的眼眶中跳动着两簇青色磷火，声音宛如金石摩擦："入此界者，前尘皆苦。石上照见三生因果，水中能涤万劫魔障。饮下此水，前世恩仇一笔勾销；以血点碑，则浩然道心烙印九幽。道友，你要如何抉择？"',
    choices: [
      { 
        text: '【饮忘川水】洗涤前尘，因果两清', 
        tip: '气血恢复 15 点 · 因果值归零', 
        karmaDelta: 0, 
        goldDelta: 0, 
        hpDelta: 15, 
        customEffect: 'karmaReset',
        resultText: '你接过陶碗，将冰冷彻骨的忘川清泉一饮而尽。泉水入喉化作一股空灵之气直冲天灵，胸中连日厮杀积攒的躁狂与杂念被彻底涤除，道体暗伤奇迹般愈合。然而冥冥之中，你感到自己与前世的一丝因果纽带就此断裂。' 
      },
      { 
        text: '【以血点石】道心不昧，浩然长存', 
        tip: '善因果 +2 · 扣 8 气血 · 获 40 铜钱', 
        karmaDelta: 2, 
        goldDelta: 40, 
        hpDelta: -8, 
        resultText: '你冷笑一声，推开陶碗："前尘因果皆是我行之道，岂能一饮了之？！"你咬破右手中指，以纯阳道血在三生石上重重画下一道破煞符印！炽热金芒冲天而起，石上万千冤魂发出解脱的欢呼，震慑得奈何桥畔鬼差纷纷退避，并在石缝中显露出前朝香客遗落的阴司通宝。' 
      }
    ]
  },
  {
    id: 'event_xuezi_yuanzhuang',
    title: '血字冤状',
    location: '枉死城 · 鬼市死巷',
    description: '穿入枉死城街道，两侧黑瓦红柱鳞次栉比，鬼市之中阴差与鬼商穿梭往来，竟如人间闹市般繁华。但在背阴的死巷角落，一位衣衫褴褛的白发老妪正跪在粗糙的黑石板上，十指指甲尽脱，正蘸着自己眼角淌下的血泪，在一块白布上疯狂书写。\n老妪见生人气息靠近，猛地扑倒在你脚边，将那卷染满血泪的状纸高高举起："道长！救救我那孩儿！他本是阳间连中三元的状元郎，一生清正爱民，本该有七十阳寿。可判官为了讨好阴商邪修，生生将他的寿数抹去三十年，夺其文曲灵魄填补阵眼！老妇在此申冤三百年，状纸递上去八千次，尽皆被差役当场焚毁……求道长替老妇伸冤啊！"',
    choices: [
      { 
        text: '【接下血状】代民请命，剑指森罗', 
        tip: '善因果 +2 · 获【鸣冤浩气】(对鬼差伤害+2)', 
        karmaDelta: 2, 
        goldDelta: 0, 
        hpDelta: 0, 
        customEffect: 'mingyuanHaoqi',
        resultText: '你一把扶起老妪，将那卷沉甸甸的血字冤状收入怀中："老人家放心，贫道此去森罗殿，定要找那判官清算每一笔血账！"怀中因果镜爆发出炽热浩然之气，血状化作一道护体正气附着于桃木剑上。' 
      },
      { 
        text: '【婉言相劝】独木难支，莫惹祸端', 
        tip: '因果无变化 · 安然离开', 
        karmaDelta: 0, 
        goldDelta: 0, 
        hpDelta: 0, 
        resultText: '你长叹一声，深知前路凶险九死一生，无法给予老妪虚妄的承诺。你留下一张安魂符，轻声劝其躲入暗巷，默默离去。身后传来老妪压抑的啜泣声，在鬼市的喧嚣中渐渐消散。' 
      },
      { 
        text: '【强夺状纸】炼化阴怨，充盈道法', 
        tip: '恶因果 -2 · 扣 6 气血 · 获 60 铜钱 · 火系符箓精进', 
        karmaDelta: -2, 
        goldDelta: 60, 
        hpDelta: -6, 
        upgradeCardElement: '火',
        resultText: '你冷笑一声，抽出符剑一把夺过老妪凝聚三百年的精纯血泪："区区一介孤魂，也妄图翻案？不如将这三百年极阴之怨献于本座，助我修成无上神通！"你强行炼化血布，老妪凄厉惨叫化烟散去。极阴怨火融入你的火系符箓，令其威力大进。' 
      }
    ]
  },
  {
    id: 'event_tudishen',
    title: '阴司土地庙',
    location: '黄泉路 · 破庙残龛',
    description: '荒凉的土地庙内神像倒塌，香炉中尚有一柱未熄灭的返魂香。',
    choices: [
      { text: '【诚心上香】祈求庇护', tip: '恢复 12 点气血 · 护盾 +5', karmaDelta: 1, goldDelta: 0, hpDelta: 12, resultText: '返魂香烟袅袅升起，化作一层金光护体，伤势迅速复原。' },
      { text: '【搜寻供桌】寻找遗物', tip: '恶因果 -1 · 获 45 铜钱', karmaDelta: -1, goldDelta: 45, hpDelta: 0, resultText: '你在供桌暗格中搜出一个香油钱袋，里面装着满满的铜钱。' }
    ]
  }
];

// ==================== 第三章事件：归墟深渊 ====================
export const CHAPTER_3_EVENTS = [
  {
    id: 'event_wanhun_kuqiang',
    title: '万魂哭墙',
    location: '归墟边境 · 哭墙',
    description: '穿过怨魂群后，来到哭墙前，墙面上无数张扭曲的面孔在不断蠕动、哀嚎。突然，一张特别清晰的面孔引起了注意——那是兰若寺的绣娘。她被九尾吞噬了，但执念太强，在哭墙上保留了一丝自我。\n绣娘残魂从哭墙中浮现，面容苍白，眼中满是焦急和恐惧："道长……是你……你终于来了……快走……别去最深处……那里有……比九尾更可怕的……东西……她在开门……门后面的……不是妖……是神……被遗忘的神……"',
    choices: [
      { 
        text: '【超度亡魂】诵念救苦妙经，超度绣娘', 
        tip: '善因果 +2 · 获得【绣娘玉佩】', 
        karmaDelta: 2, 
        goldDelta: 0, 
        hpDelta: 0,
        customEffect: 'xiuniangJade',
        resultText: '你盘膝坐于哭墙前，取出朱砂黄纸，诵念《太上洞玄灵宝救苦妙经》。随着金光蔓延，绣娘的面容先是惊愕，随即流下两行清泪。周身漆黑怨水消融，化作无数透明如晶玉的纯净光点，面容转为安详。消散前，她留下最后一句话："道长……小心……九尾她……也只是个可怜人……"一块温润的玉佩缓缓浮现。' 
      },
      { 
        text: '【炼化怨力】将绣娘及怨魂炼化为精纯怨力', 
        tip: '恶因果 -2 · 扣 6 气血 · 获得【怨力强化】', 
        karmaDelta: -2, 
        goldDelta: 0, 
        hpDelta: -6,
        customEffect: 'yuanliBoost',
        resultText: '你冷笑一声，掌心黑气翻涌，将绣娘及周围无数怨魂强行炼化为精纯的怨力注入体内。绣娘在炼化中发出凄厉惨叫："你……你果然……和那时一样无情……你会后悔的……"浑身黑气缭绕，眼中闪过一丝猩红，因果镜上又多了一道裂纹。魔道？这天底下，正道魔道，又有什么区别？' 
      }
    ]
  },
  {
    id: 'event_qianshi_huilang',
    title: '前世回廊',
    location: '归墟深处 · 镜花水月',
    description: '穿过哭墙后，进入一片奇异的空间。这里没有地面，没有天空，只有无数面巨大的铜镜悬浮在虚空中。每一面镜子都映照出不同的画面。\n伏魔天师的声音从镜中传来："这里是前世回廊。归墟之力将你的三生三世都翻了出来。第一面镜照此生，第二面镜照前世，第三面镜……照的是被抹去的记忆。小道友，你确定要继续看吗？有些真相，知道了反而痛苦。"',
    choices: [
      { 
        text: '【观前世镜】唤醒天庭执律仙官的记忆', 
        tip: '获得【执律印记】· 解锁隐藏结局', 
        karmaDelta: 0, 
        goldDelta: 0, 
        hpDelta: 0,
        customEffect: 'zhilvMark',
        resultText: '你走到第二面镜子前，镜面开始碎裂、重组。画面中出现一个从未见过的自己——身着天庭官服，手持执律金鞭，站在归墟封印之前。你偷了天庭的蟠桃，榨成汁，送给了被封印的九尾。然后，你走到封印最深处，看到了那扇门——玄冥封印录。天兵天将从天而降，天帝的声音轰鸣："执律仙官，私通归墟妖物，窥探玄冥之秘，贬入轮回，世代为凡人，永世不得记忆前尘！"……原来如此。' 
      },
      { 
        text: '【观第三镜】强行唤醒被抹去的记忆', 
        tip: '扣 10 气血 · 获得【玄冥之眼】', 
        karmaDelta: 0, 
        goldDelta: 0, 
        hpDelta: -10,
        customEffect: 'xuanmingEye',
        resultText: '你走到第三面镜子前，伸手触碰镜面。画面骤然清晰——那扇刻满符文的门缓缓打开。门后是一片无尽的混沌，混沌中央，有一个巨大的、蜷缩着的身影。她的身体由无数轮回的灵魂组成，她的呼吸就是轮回本身。她睁开了一只眼睛，那只眼睛里没有恶意，只有无尽的、跨越了万亿年的疲惫。你跪在地上，大口喘息，冷汗浸透了道袍。……玄冥。她就是玄冥。' 
      }
    ]
  },
  {
    id: 'event_qingqiu_yilao',
    title: '青丘遗老',
    location: '青丘废墟 · 隐蔽洞穴',
    description: '善念分身消散后，在废墟深处发现一个隐蔽的洞穴。洞穴中，一位苍老的狐仙蜷缩在角落里，浑身是伤。\n青丘遗老浑浊的眼睛中闪过一丝光芒，声音沙哑而颤抖："你……你身上有公主的气息……还有天庭的味道……你是来救公主的，还是来杀她的？"',
    choices: [
      { 
        text: '【倾听真相】了解九尾与天庭的过往', 
        tip: '获得【青丘狐珠】· 解锁以情动人结局', 
        karmaDelta: 1, 
        goldDelta: 0, 
        hpDelta: 0,
        customEffect: 'qingqiuPearl',
        resultText: '青丘遗老缓缓开口："公主她不是妖神。她是天庭创造的归墟守护者。但那只是表面……实际上，归墟封印下还封印着玄冥——创世古神，掌管轮回与归寂。公主是天庭用来封印玄冥的活锁。青丘全族被屠，也是因为我们知道了这个秘密……老夫是唯一的幸存者。"他将一枚散发着柔和光芒的狐珠递给你："如果她还能认出这个，也许……能让她在最疯狂的时候，清醒一瞬间。"' 
      },
      { 
        text: '【搜寻宝物】在洞穴中寻找青丘遗宝', 
        tip: '恶因果 -1 · 获 60 铜钱', 
        karmaDelta: -1, 
        goldDelta: 60, 
        hpDelta: 0,
        resultText: '你没有耐心听一个老狐狸的絮叨，在洞穴中翻找起来。青丘遗老绝望地看着你："你……你和天庭一样无情……"你在洞穴深处找到了一个布满灰尘的宝箱，里面装着青丘族人当年积攒的财宝。' 
      }
    ]
  },
  {
    id: 'event_fengshentai_yizhi',
    title: '封神台遗址',
    location: '归墟深处 · 封神台',
    description: '一片巨大的石台废墟出现在归墟深处。石台上散落着断裂的兵器、破碎的甲胄、以及无数早已熄灭的法宝。在封神台遗址的角落，你发现一卷残破的金册——封神榜的残页。\n残页上记录着九尾狐被封为归墟守护者的真实记录、青丘灭族的天庭密令、玄冥被封印的简要记载……然后，你的目光停在了一个名字上。',
    choices: [
      { 
        text: '【翻阅残页】查看被抹去的封神真相', 
        tip: '永久攻击 +1 · 钟馗法相强化', 
        karmaDelta: 0, 
        goldDelta: 0, 
        hpDelta: 0,
        customEffect: 'fengshenPage',
        resultText: '你展开残页，声音低沉："天师。你的名字也在上面。钟馗，因巡察归墟时发现玄冥之秘，被天庭灭口，后册封为伏魔大神以掩人耳目。"因果镜剧烈震动，镜面上的裂纹又多了几道，镜中传来久久的沉默："……原来如此。老夫死得不冤，也冤。不冤的是，老夫知道了不该知道的秘密。冤的是，老夫到死都以为自己是为了正道而死……"残页化作一道金光融入桃木剑，剑身隐隐泛起天庭金纹。' 
      }
    ]
  },
  {
    id: 'event_liudao_lunhuipan',
    title: '六道轮回盘',
    location: '归墟最深处 · 轮回盘',
    description: '归墟最深处的外围，一个巨大到令人窒息的圆盘悬浮在虚空中。圆盘分为六个区域，分别刻着天道、人道、阿修罗道、畜生道、饿鬼道、地狱道的符文。但现在……它正在崩毁。六个区域的符文大多已经熄灭，圆盘边缘布满裂纹。\n轮回盘的正下方，就是玄冥封印的最外层。轮回盘的崩毁，正在一点点削弱玄冥的封印。',
    choices: [
      { 
        text: '【修复轮回盘】注入灵力，加固封印', 
        tip: '善因果 +2 · 恢复 20 气血', 
        customEffect: 'repairSamsara',
        resultText: '你盘膝坐于轮回盘前，将全身灵力注入其中。六道符文渐渐亮起，圆盘上的裂纹开始愈合。虽然无法完全修复，但至少延缓了玄冥封印的崩毁。伏魔天师的声音传来："好！小道友，你做了正确的选择。无论天庭做了什么，玄冥苏醒的后果，不是我们能承担的。"' 
      },
      { 
        text: '【加速崩毁】引导混沌之力，削弱封印', 
        tip: '恶因果 -2 · 永久攻击 +2', 
        hpDelta: -5,
        customEffect: 'accelerateSamsara',
        resultText: '你冷笑一声，将混沌之力引导入轮回盘。符文加速熄灭，裂纹迅速蔓延。封印的削弱让一股强大的力量反馈到你体内，攻击力永久提升。伏魔天师怒喝："你在做什么？！玄冥苏醒三界就完了！"你淡淡回答："三界？三界早就完了。从天庭背叛玄冥的那一天起，就已经完了。"' 
      }
    ]
  }
];

export function createPlayer(characterId = "taoist") {
  const charConfig = CHARACTERS[characterId] || CHARACTERS.taoist;
  const maxHp = charConfig.maxHp || 30;
  const maxEnergy = charConfig.maxEnergy || 3;

  let starterCardNames;
  if (characterId === 'bai_suzhen') {
    // 白素贞：水/木偏向，契合灵气积累玩法
    starterCardNames = [
      "流水剑", "流水剑",
      "太极护体", "太极护体",
      "横扫千军",
      "回春术",
      "引灵诀",
      "木甲术",
      "净心咒"
    ];
  } else {
    starterCardNames = [
      "御剑术", "御剑术",
      "横扫千军",
      "流水剑",
      "烈火斩",
      "裂地拳",
      "太极护体",
      "土墙术",
      "引灵诀"
    ];
  }

  const starterCards = starterCardNames
    .map(name => CARD_TEMPLATES.find(c => c.name === name))
    .filter(Boolean)
    .map(t => ({ ...t, id: generateCardId(), star: 0, isUpgraded: false }));

  for (let i = starterCards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [starterCards[i], starterCards[j]] = [starterCards[j], starterCards[i]];
  }

  return { 
    hp: maxHp, 
    maxHp, 
    shield: 0, 
    energy: maxEnergy, 
    maxEnergy, 
    immune: false, 
    nextDamageBonus: 0, 
    cards: [], 
    deck: starterCards, 
    discard: [], 
    relics: [], 
    characterId: charConfig.id 
  };
}

export function createEnemy(templateIndex = 0) {
  const template = ENEMY_TEMPLATES[templateIndex] || ENEMY_TEMPLATES[0];
  const baseAtk = template.attack || 4;
  return { 
    ...template, 
    id: "enemy_" + Math.random().toString(36).substring(2, 9), 
    shield: 0, 
    burnTurns: 0, 
    burnDamage: 0, 
    skipTurn: false,
    attackBuff: 0,
    enraged: false,
    invulnerableTurns: 0,
    barrierTriggered: false,
    nextAction: "伺机扑杀",
    nextActionType: "attack",
    nextActionValue: baseAtk,
    intentDesc: `准备出招 (造成 ${baseAtk} 点伤害)`
  };
}

// ==================== 新手教学关卡配置 ====================
export const TUTORIAL_BATTLE = {
  enemy: {
    key: "tutorial_dummy",
    name: "桃木傀儡",
    hp: 20,
    maxHp: 20,
    element: "木",
    attack: 3,
    behavior: "balanced",
    special: "师尊以桃木扎成的试手傀儡，专为新手演练而设",
    skills: "笨拙挥击(3伤)"
  },
  // 第一回合固定手牌
  startingHand: [
    { key: "yu_jian_shu", name: "御剑术", type: "攻击", element: "金", cost: 1, star: 0, effectType: "damage", description: "造成6点伤害，附带1层金印", effects: [{ type: "damage", value: 6 }] },
    { key: "jin_zhong_zhao", name: "金钟罩", type: "防御", element: "金", cost: 2, star: 0, effectType: "shield", description: "获得12点护盾，附带1层金印", effects: [{ type: "shield", value: 12 }] }
  ],
  playerHp: 30,
  playerEnergy: 3
};