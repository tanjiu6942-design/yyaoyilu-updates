﻿import InputHandler from './InputHandler.js';
import { PIXEL_RATIO } from '../render.js';

const ELEMENT_COLORS = {
  "金": "#F0D060",
  "木": "#6AAF5C",
  "水": "#4A90D9",
  "火": "#D94A4A",
  "土": "#C4A35A",
  "无": "#AAAAAA"
};

const RELATION_COLORS = {
  "克制": "#FFD700",
  "被克": "#888888",
  "普通": "#FFFFFF"
};

export const UI_COLORS = {
  ink: "#1C140E",          // 浓墨
  inkSoft: "#36261A",      // 焦墨/深棕
  paper: "#EAD7B0",        // 宣纸原色
  paperLight: "#F8EED9",   // 宣纸亮色
  paperDark: "#B88E56",    // 宣纸暗沉色
  cinnabar: "#962A1F",     // 朱砂红
  cinnabarDark: "#6E1B13", // 暗朱砂
  gold: "#C99A3A",         // 泥金
  goldLight: "#F3D37A",    // 流金
  jade: "#2B6B46",         // 墨玉绿
  shadow: "rgba(20, 12, 6, 0.45)"
};

export default class SceneManager {
  constructor(ctx, width, height) {
    this.ctx = ctx;
    this.width = width;
    this.height = height;
    this.scenes = {};
    this.currentSceneName = null;
    this.input = new InputHandler();
  }

  registerScene(name, scene) {
    this.scenes[name] = scene;
  }

  enterScene(name, data = {}) {
    const prevName = this.currentSceneName;
    if (prevName && prevName !== name && this.scenes[prevName] && this.scenes[prevName].exit) {
      try { this.scenes[prevName].exit(); } catch (e) {}
    }
    this.currentSceneName = name;
    if (this.scenes[name]) {
      this.input.clearButtons();
      this.scenes[name].enter(data);
      if (this.scenes[name].onEnter) this.scenes[name].onEnter(data);
    }
  }

  update() {
    if (this.scenes[this.currentSceneName] && this.scenes[this.currentSceneName].update) {
      this.scenes[this.currentSceneName].update();
    }
  }

  render() {
    if (this.scenes[this.currentSceneName] && this.scenes[this.currentSceneName].render) {
      this.scenes[this.currentSceneName].render(this.ctx);
    }
  }

  getScene(name) {
    return this.scenes[name];
  }

  getCurrentSceneName() {
    return this.currentSceneName;
  }
}

export function getElementColor(element) {
  return ELEMENT_COLORS[element] || "#AAAAAA";
}

export function getElementColorDark(element) {
  const colors = {
    "金": "#C9A820",
    "木": "#3D7A28",
    "水": "#2B5F9A",
    "火": "#9A2B2B",
    "土": "#8B7332",
    "无": "#666666"
  };
  return colors[element] || "#666666";
}

export function drawRoundedRect(ctx, x, y, w, h, r, fillColor, strokeColor, strokeWidth) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  if (fillColor) { ctx.fillStyle = fillColor; ctx.fill(); }
  if (strokeColor) { ctx.strokeStyle = strokeColor; ctx.lineWidth = strokeWidth || 1; ctx.stroke(); }
}

// ★ 全新重构：纯净水墨宣纸质感底纹（彻底移除所有死板横线）
// 静态宣纸背景离屏缓存：背景从不变化，缓存为一张图，每帧仅一次 drawImage
let _bgCache = null;
export function drawParchmentBackground(ctx, width, height) {
  const cw = Math.round(width);
  const ch = Math.round(height);
  if (!_bgCache || _bgCache.w !== cw || _bgCache.h !== ch) {
    try {
      let pr = 1;
      try {
        const wi = (typeof wx !== 'undefined' && wx.getWindowInfo) ? wx.getWindowInfo() : null;
        if (wi && wi.pixelRatio) pr = wi.pixelRatio;
      } catch (e) { pr = 1; }
      const off = wx.createCanvas();
      off.width = Math.round(cw * pr);
      off.height = Math.round(ch * pr);
      const octx = off.getContext('2d');
      if (pr > 1) octx.scale(pr, pr);
      _drawParchmentDirect(octx, cw, ch);
      _bgCache = { w: cw, h: ch, canvas: off };
    } catch (e) {
      _bgCache = null;
    }
  }
  if (_bgCache) {
    ctx.drawImage(_bgCache.canvas, 0, 0, cw, ch);
  } else {
    _drawParchmentDirect(ctx, cw, ch);
  }
}
function _drawParchmentDirect(ctx, width, height) {
  // 1. 宣纸底色渐变（中心柔光，四角微暗）
  const bgGrad = ctx.createRadialGradient(
    width / 2, height * 0.45, width * 0.2,
    width / 2, height * 0.5, width * 0.85
  );
  bgGrad.addColorStop(0, "#F7EDD5");
  bgGrad.addColorStop(0.5, "#E8D3A7");
  bgGrad.addColorStop(0.85, "#C49E65");
  bgGrad.addColorStop(1, "#8A6032");
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // 2. 宣纸自然斑驳与微细纤维
  ctx.fillStyle = "rgba(70, 45, 20, 0.04)";
  for (let i = 0; i < 28; i++) {
    const x = (i * 67 + 23) % width;
    const y = (i * 97 + 41) % height;
    ctx.beginPath();
    ctx.arc(x, y, (i % 3) + 1.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // 3. 四周水墨压暗（Vignette 电影感暗角）
  const topEdge = ctx.createLinearGradient(0, 0, 0, 90);
  topEdge.addColorStop(0, "rgba(28, 18, 10, 0.4)");
  topEdge.addColorStop(1, "rgba(28, 18, 10, 0)");
  ctx.fillStyle = topEdge;
  ctx.fillRect(0, 0, width, 90);

  const bottomEdge = ctx.createLinearGradient(0, height - 100, 0, height);
  bottomEdge.addColorStop(0, "rgba(28, 18, 10, 0)");
  bottomEdge.addColorStop(1, "rgba(28, 18, 10, 0.55)");
  ctx.fillStyle = bottomEdge;
  ctx.fillRect(0, height - 100, width, 100);

  // 4. 古卷双层精致暗金边框
  ctx.strokeStyle = "rgba(168, 126, 68, 0.35)";
  ctx.lineWidth = 1;
  ctx.strokeRect(8, 8, width - 16, height - 16);

  ctx.strokeStyle = "rgba(120, 80, 40, 0.2)";
  ctx.strokeRect(12, 12, width - 24, height - 24);
}

export function drawInkPanel(ctx, x, y, w, h, options = {}) {
  const radius = options.radius || 6;
  drawRoundedRect(ctx, x + 2, y + 3, w, h, radius, UI_COLORS.shadow, null);
  drawRoundedRect(ctx, x, y, w, h, radius, options.fill || "rgba(43, 30, 18, 0.9)", options.stroke || UI_COLORS.gold, options.strokeWidth || 1);
  ctx.strokeStyle = "rgba(246, 233, 200, 0.16)";
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 5, y + 5, Math.max(0, w - 10), Math.max(0, h - 10));
}

export function drawScrollPanel(ctx, x, y, w, h, options = {}) {
  drawRoundedRect(ctx, x + 3, y + 5, w, h, 6, UI_COLORS.shadow, null);
  drawRoundedRect(ctx, x, y, w, h, 6, options.fill || "rgba(248, 238, 216, 0.96)", options.stroke || "#8A5A2F", options.strokeWidth || 1);
  ctx.fillStyle = "rgba(127, 82, 41, 0.18)";
  ctx.fillRect(x + 8, y + 8, w - 16, 1);
  ctx.fillRect(x + 8, y + h - 9, w - 16, 1);
  ctx.fillStyle = "rgba(255, 250, 222, 0.26)";
  ctx.fillRect(x + 10, y + 10, w - 20, h - 20);
}

export function drawSealButton(ctx, btn) {
  const disabled = btn.disabled;
  const fill = disabled ? "#4A4036" : (btn.color || UI_COLORS.cinnabar);
  const stroke = disabled ? "#6A6055" : (btn.strokeColor || "#E4BC70");
  drawRoundedRect(ctx, btn.x + 2, btn.y + 3, btn.w, btn.h, 6, UI_COLORS.shadow, null);
  drawRoundedRect(ctx, btn.x, btn.y, btn.w, btn.h, 6, fill, stroke, 1.2);
  ctx.strokeStyle = disabled ? "rgba(255,255,255,0.06)" : "rgba(255,230,170,0.25)";
  ctx.strokeRect(btn.x + 4, btn.y + 4, btn.w - 8, btn.h - 8);
  drawTextCentered(ctx, btn.text, btn.x + btn.w / 2, btn.y + btn.h / 2, btn.textColor || "#FFF8DD", btn.fontSize || 14, "serif");
}

export function drawElementBadge(ctx, element, x, y, radius = 13) {
  const fill = getElementColorDark(element);
  const stroke = getElementColor(element);
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.strokeStyle = stroke;
  ctx.lineWidth = 2;
  ctx.stroke();
  drawTextCentered(ctx, element, x, y, "#FFF8DD", Math.max(12, radius - 1), "serif");
}

export function drawTextCentered(ctx, text, x, y, color, fontSize, font) {
  ctx.font = fontSize + "px " + (font || "serif");
  ctx.fillStyle = color || "#FFFFFF";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, x, y);
}

export function drawTextLeft(ctx, text, x, y, color, fontSize, font) {
  ctx.font = fontSize + "px " + (font || "serif");
  ctx.fillStyle = color || "#FFFFFF";
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText(text, x, y);
}

export function drawTextRight(ctx, text, x, y, color, fontSize, font) {
  ctx.font = fontSize + "px " + (font || "serif");
  ctx.fillStyle = color || "#FFFFFF";
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";
  ctx.fillText(text, x, y);
}

export function measureText(ctx, text, fontSize) {
  ctx.font = fontSize + "px serif";
  return ctx.measureText(text).width;
}

export function createButton(x, y, w, h, text, options = {}) {
  return {
    x, y, w, h, text,
    color: options.color || "#4A3728",
    textColor: options.textColor || "#F5F0E8",
    fontSize: options.fontSize || 16,
    tap: options.tap || null,
    hoverColor: options.hoverColor || "#6B5240"
  };
}