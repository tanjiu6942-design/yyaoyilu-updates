/**
 * js/game/battle/BattleDialogue.js
 * 战斗剧情对话数据（从 BattleScene 拆分）
 */

import { CHAPTER_3_DIALOGUES } from '../story/chapter3Dialogues.js';

export const CHAPTER_1_DIALOGUES = {
  TUTORIAL_INTRO: [
    {
      speaker: '师尊遗音',
      tag: '魂',
      side: 'left',
      avatarColor: '#C99A3A',
      text: '徒儿，初入道门，且随为师研习五行斗法之基。此乃为师以桃木扎成的傀儡，专供试手之用，不会真正伤你。'
    },
    {
      speaker: '桃木傀儡',
      tag: '傀',
      side: 'right',
      avatarColor: '#8B6914',
      text: '（关节发出竹木摩擦之声，缓缓摆出起手式）嗡……师尊有令，试炼开始。请道友出招。'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '多谢师尊指点。弟子这便以金行符箓开局，领教了！'
    }
  ],
  TUTORIAL_DEFEAT: [
    {
      speaker: '桃木傀儡',
      tag: '傀',
      side: 'right',
      avatarColor: '#8B6914',
      text: '（周身木甲裂开细密缝隙，缓缓收势）金锋锐利，盾法沉稳。道友已掌握五行斗法之基。'
    },
    {
      speaker: '师尊遗音',
      tag: '魂',
      side: 'left',
      avatarColor: '#C99A3A',
      text: '好！基础法门已成。前方兰若寺妖气冲天，正是你行道试炼的第一关。持剑前行吧，徒儿！'
    }
  ],

  PROLOGUE: [
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '（按住腰间剧烈震颤的因果镜）师尊所料不差，这黑风岭的阴煞之气，竟已浓郁到遮天蔽日的境地……'
    },
    {
      speaker: '师尊遗音',
      tag: '魂',
      side: 'right',
      avatarColor: '#C99A3A',
      text: '『徒儿，山中木石尽皆化煞，兰若寺地底灵穴已破。持此五行符囊，切记万物相生相克，莫堕魔障……』'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '弟子谨记。前方古道似有微弱啼哭之声，且容弟子前往一探！'
    }
  ],

  SHANXIAO_INTRO: [
    {
      speaker: '游荡山魈',
      tag: '魈',
      side: 'right',
      avatarColor: '#3D7A28',
      text: '（从枯树冠上倒挂而下，胸口黑木树瘤搏动）嘻嘻……活人！热腾腾的五脏六腑！老尊说了，抓够一百个生魂，就赏我一颗长生果！'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '身缠黑木死气，心窍已被浊煞腐蚀。金行正气，剑出如虹——斩！'
    }
  ],
  SHANXIAO_DEFEAT: [
    {
      speaker: '游荡山魈',
      tag: '魈',
      side: 'right',
      avatarColor: '#3D7A28',
      text: '（体内黑木瘤寸寸化为飞灰，眼中凶光散去）好冷啊……胸口的黑窟窿不疼了……娘亲……我想回家……（化烟散去）'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '草木本无罪，奈何地脉生煞。愿你来世得入清净灵山，莫再受恶世之苦。'
    }
  ],

  JIANGSHI_INTRO: [
    {
      speaker: '掘地僵尸',
      tag: '尸',
      side: 'right',
      avatarColor: '#8B7332',
      text: '（枯手破土死扣脚踝，喷吐黄色尸瘴）为何……扰我长眠……尘归尘，土归土……你也留在此地陪我吧！'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '古战场百战忠骨，竟被黄泉死瘴驱使成煞！木行生发，生克有度，给我破！'
    }
  ],
  JIANGSHI_DEFEAT: [
    {
      speaker: '掘地僵尸',
      tag: '尸',
      side: 'right',
      avatarColor: '#8B7332',
      text: '（身上坚硬泥甲崩解，铠甲缝隙中飘出一封泛黄染血的残破家书）……'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '『盼儿早归，麦已金黄』……百年征战骨，空留白发思。贫道以净土覆葬，且安息吧。'
    }
  ],

  HULI_INTRO: [
    {
      speaker: '红绡女子',
      tag: '狐',
      side: 'right',
      avatarColor: '#9A2B2B',
      text: '（绝壁朱门红灯高挂，斜倚软榻）妾身本是落难歌姬。夜深霜重，道长身子这般单薄，何不入内饮一杯温热的屠苏酒？'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '（法眼玄光暴涨）腐木作榻，血浆为酒，身后三条火尾狂乱！妖孽，休要障眼惑众！'
    },
    {
      speaker: '狐狸精',
      tag: '狐',
      side: 'right',
      avatarColor: '#9A2B2B',
      text: '敬酒不吃吃罚酒的小道士！既然勘破幻境，便拿你一身纯阳道血，来解这三昧阴火之寒！'
    }
  ],
  HULI_DEFEAT: [
    {
      speaker: '赤色灵狐',
      tag: '狐',
      side: 'right',
      avatarColor: '#9A2B2B',
      text: '（重伤蜷缩，瑟瑟发抖）道长饶命！小妖从未主动害人性命，实是黑风山极阴寒煞快要冻裂妖丹……才出此下策借阳气取暖啊！'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '念你灵智未泯且未染命案，削去你一身邪火。速速遁入深林潜心向善，莫再走偏门！'
    }
  ],

  HUAPI_INTRO: [
    {
      speaker: '画皮恶煞',
      tag: '煞',
      side: 'right',
      avatarColor: '#B8960F',
      text: '（端坐铜镜前以金线缝面，声音忽男忽女）道长你看，这具皮囊的眉眼像不像你曾心仪的师妹？还是说……你更喜欢清秀的书生皮相？'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '金线缝面，腐血流淌，剥人皮肉铸尔恶相！伤天害理，天理难容！'
    },
    {
      speaker: '画皮恶煞',
      tag: '煞',
      side: 'right',
      avatarColor: '#B8960F',
      text: '桀桀！道士的皮囊骨肉最是坚韧香甜，等我剥下你的脸皮，定能换得万世长存！'
    }
  ],
  HUAPI_DEFEAT: [
    {
      speaker: '怨魂虚影',
      tag: '魂',
      side: 'right',
      avatarColor: '#D4AF37',
      text: '（千层伪装化为烈焰飞灰，数名被夺皮少女的残魂盈盈一拜）多谢仙长救拔之恩，吾等终于得以解脱……'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '烈火焚尽万重魔，幽魂散尽见青天。去吧，往生轮回，莫恋红尘。'
    }
  ],

  ELITE_WU_CHANG_INTRO: [
    {
      speaker: '白无常',
      tag: '冥',
      side: 'right',
      avatarColor: '#5C1D54',
      text: '桀桀桀……一见生财！哪里来的游方生魂，竟敢擅闯阴阳边界？'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '无常二爷乃地府正神，为何在阳间拘押无辜生灵，截断六道轮回？！'
    },
    {
      speaker: '黑无常',
      tag: '煞',
      side: 'right',
      avatarColor: '#1C140E',
      text: '天下太平……生魂止步！生死簿已被判官重置，凡阻路者，同入幽冥！'
    },
    {
      speaker: '白无常',
      tag: '冥',
      side: 'right',
      avatarColor: '#5C1D54',
      text: '天庭不仁，地府崩溃，十殿阎罗皆被封禁！如今这阴阳两界，唯有判官大人的生死簿说了算！认命吧！'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '阎罗封禁，判官乱法？！今日贫道纵使粉身碎骨，也要斩断尔等手中的锁魂邪链！'
    }
  ],
  ELITE_WU_CHANG_DEFEAT: [
    {
      speaker: '黑白无常',
      tag: '冥',
      side: 'right',
      avatarColor: '#5C1D54',
      text: '（法身寸寸崩裂）地府枉死城……大阵已成……小道士，你阻止不了判官大人的……（化作黑白阴风遁入深渊）'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '阴风散处竟遗下上古法宝……地府到底发生了何等惨绝人寰的大变？'
    }
  ],

  BOSS_INTRO: [
    {
      speaker: '黑山山魈王',
      tag: '魁',
      side: 'right',
      avatarColor: '#8C2A24',
      text: '青城山的小道士……百年前，你的太师祖曾在此与老朽把酒论道。那时他说，天道无私，常与善人……'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '你受兰若寺百年香火化生神智，本应护持一方，为何吞噬生民血肉，自甘堕入魔道？！'
    },
    {
      speaker: '黑山山魈王',
      tag: '魁',
      side: 'right',
      avatarColor: '#8C2A24',
      text: '魔道？！地府阴泉倒灌、佛陀金身崩碎之时，天道在何处？！神明在何处？！唯有汲取万物血肉，老朽方能与幽冥同寿！'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '执迷不悟！今日便借三昧真火，焚尽你这颗污浊木心！'
    }
  ],
  BOSS_ENRAGE: [
    {
      speaker: '黑山山魈王',
      tag: '狂',
      side: 'right',
      avatarColor: '#9E2F24',
      text: '（胸膛树皮寸寸崩裂，黑色魔血喷涌）地府的黄泉啊……赐予我毁灭一切的力量吧！枯木逢煞，万物俱寂！！'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '（心头狂震）不好！它的木心竟直接插在幽冥地府的黄泉灵穴上，煞气暴涨了！'
    }
  ],
  BOSS_DEFEAT: [
    {
      speaker: '黑山山魈王',
      tag: '灭',
      side: 'right',
      avatarColor: '#555555',
      text: '地府的深渊已经裂开……判官大人……绝不会放过你们的……（庞大枯木化作漫天焦炭轰然崩塌）'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '呼……妖树终于伏诛！焦黑巨坑深处竟然露出一块刻着血字的【阴司判官令】？！'
    },
    {
      speaker: '伏魔天师·钟馗',
      tag: '馗',
      side: 'left',
      avatarColor: '#962A1F',
      text: '（怀中因果镜赤焰暴涌，现出威严法相）好一个狂悖无道的阴阳判官！私篡生死簿，祸乱人世！小道友，且随吾杀入幽冥枉死城！'
    }
  ]
};

// 第三章对话已从 chapter3Dialogues.js 导入
export { CHAPTER_3_DIALOGUES };

/**
 * 统一获取敌人进场/战败对话
 */
export function getEnemyDialogues(enemyKey, chapter = 1) {
  if (chapter === 3) {
    const map = {
      'gui_xu_yuan_hun': { intro: CHAPTER_3_DIALOGUES.GUIXU_YUANHUN_INTRO, defeat: CHAPTER_3_DIALOGUES.GUIXU_YUANHUN_DEFEAT },
      'shi_ling_can_ke': { intro: CHAPTER_3_DIALOGUES.SHILING_CANKE_INTRO, defeat: CHAPTER_3_DIALOGUES.SHILING_CANKE_DEFEAT },
      'jiu_wei_shan_nian': { intro: CHAPTER_3_DIALOGUES.JIUWEI_SHANNIAN_INTRO, defeat: CHAPTER_3_DIALOGUES.JIUWEI_SHANNIAN_DEFEAT },
      'jiu_wei_hu': { intro: CHAPTER_3_DIALOGUES.BOSS_INTRO, defeat: null, phase2: CHAPTER_3_DIALOGUES.BOSS_PHASE2, phase3: CHAPTER_3_DIALOGUES.BOSS_PHASE3 }
    };
    return map[enemyKey] || null;
  }
  return null;
}

