/**
 * js/game/battle/BattleAnimation.js
 * 战斗动画系统
 * 管理浮动文字、卡牌入场动画、震屏等视觉效果
 * 从 BattleScene 拆分，专注于动画状态的更新与渲染
 */

import { globalPool } from '../../base/pool.js';
import { soundManager } from '../../runtime/music.js';
import { CARD_LAYOUT } from '../../config/constants.js';
import { drawTextCentered } from '../scene.js';

const { CARD_W, CARD_H } = CARD_LAYOUT;

export class BattleAnimation {
  constructor(scene) {
    this.scene = scene;
    this.floaters = [];
  }

  /**
   * 添加浮动文字（伤害数字、治疗数字、状态提示等）
   */
  addFloater(text, x, y, color) {
    const f = globalPool.get('damageText', text, x, y, color);
    if (f) this.floaters.push(f);
  }

  /**
   * 应用抽牌入场动画
   * @param {number} startIndex 手牌中起始索引
   * @param {number} count 抽牌数量
   */
  applyDrawAnimation(startIndex, count) {
    const cards = this.scene.battle?.player?.cards || [];
    const height = this.scene.manager.height;
    const spawnX = -CARD_W - 20;
    const spawnY = height - CARD_H - 100;

    for (let i = 0; i < count; i++) {
      const card = cards[startIndex + i];
      if (card) {
        card._anim = {
          startX: spawnX,
          startY: spawnY,
          delay: i * 6,
          duration: 25,
          progress: 0,
          rotation: (Math.random() - 0.5) * 0.3
        };
      }
    }
  }

  /**
   * 每帧更新动画状态
   * - 卡牌入场动画推进
   * - 浮动文字上飘与淡出
   */
  update() {
    // 卡牌入场动画
    const cards = this.scene.battle?.player?.cards || [];
    for (const card of cards) {
      if (card._anim) {
        if (card._anim.delay > 0) {
          card._anim.delay--;
          continue;
        }
        card._anim.progress += 1 / card._anim.duration;
        if (card._anim.progress >= 1) {
          delete card._anim;
          soundManager.playSfx('card_play');
        }
      }
    }

    // 浮动文字上飘与淡出
    for (let i = this.floaters.length - 1; i >= 0; i--) {
      const f = this.floaters[i];
      f.y += f.vy;
      f.life--;
      f.alpha = Math.max(0, f.life / 35);
      if (f.life <= 0) {
        this.floaters.splice(i, 1);
        globalPool.recover('damageText', f);
      }
    }
  }

  /**
   * 渲染浮动文字层
   */
  renderFloaters(ctx) {
    for (const f of this.floaters) {
      ctx.save();
      ctx.globalAlpha = f.alpha;
      ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
      ctx.shadowBlur = 4;
      drawTextCentered(ctx, f.text, f.x, f.y, f.color, 16, 'serif');
      ctx.restore();
    }
  }

  /**
   * 清理所有动画状态（战斗结束时调用）
   */
  clear() {
    for (const f of this.floaters) {
      globalPool.recover('damageText', f);
    }
    this.floaters = [];
  }
}
