/**
 * js/game/battle/BattleInput.js
 * 战斗输入处理系统
 * 管理手牌触摸、卡牌拖拽出牌、背包滚动等所有用户输入
 * 从 BattleScene 拆分，专注于输入事件的解析与分发
 */

import { SAFE_TOP } from '../../render.js';
import { CARD_LAYOUT } from '../../config/constants.js';
import { hapticMedium } from '../../config/haptics.js';
import { TutorialManager } from '../tutorial/index.js';

const { CARD_W, CARD_H, CARD_GAP, TRAY_PADDING_X } = CARD_LAYOUT;

export class BattleInput {
  constructor(scene) {
    this.scene = scene;
    this.hasBound = false;
  }

  /**
   * 注册全局触摸事件监听
   * 对应原 initHandTouchListeners()
   */
  bind() {
    if (this.hasBound) return;
    this.hasBound = true;

    const isOverEnemyZone = (x, y) => {
      const ex = this.scene.manager.width / 2;
      const ey = SAFE_TOP + 46;
      return Math.hypot(x - ex, y - ey) < 100 || y < SAFE_TOP + 125;
    };

    wx.onTouchStart((e) => {
      if (this.scene.manager.getCurrentSceneName() !== 'battle') return;
      if (!e.touches || e.touches.length === 0) return;
      const touch = e.touches[0];

      if (this.scene.isDialogueActive) return;

      // 背包滚动
      if (this.scene.showBag) {
        this.scene.isDraggingBag = true;
        this.scene.bagTouchStartY = touch.clientY;
        this.scene.bagLastTouchY = touch.clientY;
        this.scene.bagDragDistance = 0;
        return;
      }

      this.scene.dragDistance = 0;
      const tutBlocksHand = TutorialManager.isActive && TutorialManager.getCurrentStep()?.actionId !== 'play_card';
      if (this.scene.showRelicReward || this.scene.showVictoryModal || this.scene.showChapterEndModal ||
          this.scene.showStoryIntro || this.scene.showHandFullModal || tutBlocksHand ||
          this.scene.isWaitingEnemyTurn) return;

      const HAND_Y = this.scene.manager.height - CARD_H - 58;
      if (touch.clientY >= HAND_Y - 40 && touch.clientY <= HAND_Y + CARD_H + 16) {
        this.scene.isDraggingHand = true;
        this.scene.touchStartX = touch.clientX;
        this.scene.touchStartY = touch.clientY;
        this.scene.lastTouchX = touch.clientX;

        // ★ 直接根据触摸坐标计算卡牌索引，不依赖 cardButtons
        const count = this.scene.battle?.player?.cards?.length || 0;
        let tappedIdx = -1;
        if (count > 0) {
          const totalCardsWidth = count * (CARD_W + CARD_GAP) - CARD_GAP;
          const trayWidth = this.scene.manager.width - TRAY_PADDING_X * 2;
          let startX = TRAY_PADDING_X;
          if (totalCardsWidth <= trayWidth) {
            startX = (this.scene.manager.width - totalCardsWidth) / 2;
          } else {
            startX = TRAY_PADDING_X + this.scene.handScrollX;
          }
          const relativeX = touch.clientX - startX;
          const idx = Math.floor(relativeX / (CARD_W + CARD_GAP));
          if (idx >= 0 && idx < count) {
            const cardX = startX + idx * (CARD_W + CARD_GAP);
            if (touch.clientX >= cardX && touch.clientX <= cardX + CARD_W) {
              tappedIdx = idx;
            }
          }
        }
        if (tappedIdx !== -1 && !this.scene.isDiscardMode) {
          const card = this.scene.battle?.player?.cards[tappedIdx];
          const totalCost = card ? (card.cost + (card.dualElement ? 1 : 0)) : 99;
          if (this.scene.battle.player.energy >= totalCost) {
            this.scene.candidateDragIndex = tappedIdx;
            this.scene.dragTouchStartX = touch.clientX;
            this.scene.dragTouchStartY = touch.clientY;
            this.scene.dragCurrentX = touch.clientX;
            this.scene.dragCurrentY = touch.clientY;
          }
        }
      }
    });

    wx.onTouchMove((e) => {
      if (!e.touches || e.touches.length === 0) return;
      const touch = e.touches[0];

      if (this.scene.isDialogueActive) return;

      // 背包滚动
      if (this.scene.showBag && this.scene.isDraggingBag) {
        const dy = touch.clientY - this.scene.bagLastTouchY;
        this.scene.bagLastTouchY = touch.clientY;
        this.scene.bagDragDistance += Math.abs(dy);
        this.scene.bagScrollY += dy;
        this.clampBagScroll();
        return;
      }

      const tutBlocksHand = TutorialManager.isActive && TutorialManager.getCurrentStep()?.actionId !== 'play_card';
      if (!this.scene.isDraggingHand || this.scene.showVictoryModal || this.scene.showChapterEndModal ||
          this.scene.showStoryIntro || this.scene.showHandFullModal || tutBlocksHand ||
          this.scene.isWaitingEnemyTurn) return;

      const upwardDist = this.scene.touchStartY - touch.clientY;
      if (this.scene.candidateDragIndex !== -1 && upwardDist > 18) {
        this.scene.draggingCardIndex = this.scene.candidateDragIndex;
        this.scene.previewCardIndex = -1;
        this.scene.dragCurrentX = touch.clientX;
        this.scene.dragCurrentY = touch.clientY;

        const wasLocked = this.scene.isTargetLocked;
        this.scene.isTargetLocked = isOverEnemyZone(touch.clientX, touch.clientY);

        if (!wasLocked && this.scene.isTargetLocked) {
          hapticMedium();
        }
        return;
      }

      if (this.scene.draggingCardIndex === -1) {
        const deltaX = touch.clientX - this.scene.lastTouchX;
        this.scene.lastTouchX = touch.clientX;
        this.scene.dragDistance += Math.abs(deltaX);
        this.scene.handScrollX += deltaX;
        this.clampHandScroll();
        this.updateCardPositions();
      }
    });

    const endTouch = () => {
      if (this.scene.isDraggingBag) {
        this.scene.isDraggingBag = false;
        this.clampBagScroll();
      }

      if (this.scene.draggingCardIndex !== -1) {
        const cardIdx = this.scene.draggingCardIndex;
        const wasLocked = this.scene.isTargetLocked;
        this.scene.draggingCardIndex = -1;
        this.scene.candidateDragIndex = -1;
        this.scene.isTargetLocked = false;

        if (wasLocked || this.scene.dragCurrentY < this.scene.manager.height * 0.52) {
          this.scene.isDraggingHand = false;
          this.scene.executePlayCard(cardIdx);
          return;
        }
      }

      this.scene.candidateDragIndex = -1;
      this.scene.isDraggingHand = false;
      this.clampHandScroll();
      this.updateCardPositions();
    };

    wx.onTouchEnd(endTouch);
    wx.onTouchCancel(endTouch);
  }

  /**
   * 限制手牌滚动范围
   */
  clampHandScroll() {
    if (!this.scene.battle?.player?.cards) return;
    const count = this.scene.battle.player.cards.length;
    const totalCardsWidth = count * (CARD_W + CARD_GAP) - CARD_GAP;
    const trayWidth = this.scene.manager.width - TRAY_PADDING_X * 2;
    if (totalCardsWidth <= trayWidth) {
      this.scene.handScrollX = 0;
      return;
    }
    const minScroll = trayWidth - totalCardsWidth;
    const maxScroll = 0;
    this.scene.handScrollX = Math.max(minScroll, Math.min(maxScroll, this.scene.handScrollX));
  }

  /**
   * 更新卡牌按钮位置（手牌滚动后）
   */
  updateCardPositions() {
    if (!this.scene.battle?.player?.cards) return;
    const count = this.scene.battle.player.cards.length;
    const totalCardsWidth = count * (CARD_W + CARD_GAP) - CARD_GAP;
    const trayWidth = this.scene.manager.width - TRAY_PADDING_X * 2;
    const HAND_Y = this.scene.manager.height - CARD_H - 58;
    let startX = TRAY_PADDING_X;
    if (totalCardsWidth <= trayWidth) {
      startX = (this.scene.manager.width - totalCardsWidth) / 2;
    } else {
      startX = TRAY_PADDING_X + this.scene.handScrollX;
    }
    this.scene.cardButtons.forEach((btn, i) => {
      btn.x = startX + i * (CARD_W + CARD_GAP);
      btn.y = HAND_Y - 26;
      btn.w = CARD_W;
      btn.h = CARD_H + 26;
    });
  }

  /**
   * 限制背包滚动范围
   */
  clampBagScroll() {
    const height = this.scene.manager.height;
    const panelH = Math.min(480, height - 80);
    const viewportH = panelH - 80;
    if (this.scene.bagContentHeight <= viewportH) {
      this.scene.bagScrollY = 0;
      return;
    }
    const minScroll = viewportH - this.scene.bagContentHeight;
    this.scene.bagScrollY = Math.max(minScroll, Math.min(0, this.scene.bagScrollY));
  }
}
