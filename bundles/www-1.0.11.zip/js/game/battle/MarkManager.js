/**
 * js/game/battle/MarkManager.js
 * 独立五行印记状态管理器
 * 职责：印记累计、引爆判定、多层溢出结算、五行专属效果派发与临时Buff生命周期
 */

import { BATTLE } from '../../config/constants.js';
import { hasRelic } from '../effect-engine.js';

export class MarkManager {
  constructor(initialMarks = null) {
    this.marks = initialMarks ? { ...initialMarks } : { 金: 0, 木: 0, 水: 0, 火: 0, 土: 0 };
    this.fireDoubleDamage = false; // 火印引爆产生的本回合后续翻倍标记
    this.fireDamageBonus = 0; // 朱雀羽：火印引爆后火属性伤害额外加成(0.3 = +30%)
    this.listeners = []; // 事件监听器 (用于 UI/飘字/特效)
  }

  /**
   * 注册引爆/状态变更事件监听
   * @param {Function} callback (eventType, payload) => void
   */
  addListener(callback) {
    if (typeof callback === 'function') {
      this.listeners.push(callback);
    }
  }

  /**
   * 派发内部事件
   */
  emit(eventType, payload) {
    this.listeners.forEach(fn => {
      try {
        fn(eventType, payload);
      } catch (err) {
        console.error(`[MarkManager] Listener error on ${eventType}:`, err);
      }
    });
  }

  /**
   * 获取当前印记快照
   */
  getMarks() {
    return { ...this.marks };
  }

  /**
   * 判断火系双倍伤害 Buff 是否激活
   */
  isFireDoubleDamage() {
    return this.fireDoubleDamage;
  }

  /**
   * 出牌时自动处理卡牌附带的印记
   * @param {object} card 当前卡牌
   * @param {object} battle 当前战斗上下文 (包含 player, enemy, log 等)
   * @returns {{ triggered: boolean, desc: string }}
   */
  processCardMark(card, battle) {
    const element = card.element;
    if (!element || element === '无') {
      return { triggered: false, desc: '' };
    }

    const count = card.markCount || 1;
    return this.addMark(element, count, battle);
  }

  /**
   * 增加印记并判断是否触发引爆
   * @param {string} element 五行属性 ('金'|'木'|'水'|'火'|'土')
   * @param {number} count 增加层数
   * @param {object} battle 战斗上下文
   */
  addMark(element, count = 1, battle = null) {
    if (element === '无' || !this.marks.hasOwnProperty(element)) {
      return { triggered: false, desc: '' };
    }

    const totalCount = (this.marks[element] || 0) + count;
    const threshold = BATTLE.MARK_TRIGGER_COUNT;

    // 未达到引爆阈值 (默认 3)
    if (totalCount < threshold) {
      this.marks[element] = totalCount;
      const desc = `${element}印记: ${totalCount}/${threshold}`;
      this.emit('mark_updated', { element, current: totalCount, threshold });
      return { triggered: false, desc };
    }

    // 达到阈值：引爆并保留多余层数 (例如 2+2=4 -> 触发后剩余 1)
    const remaining = totalCount - threshold;
    this.marks[element] = remaining;

    const triggerResult = this.executeDetonation(element, battle);
    this.emit('mark_detonated', { element, remaining, triggerResult });

    return {
      triggered: true,
      desc: triggerResult.desc,
      detail: triggerResult
    };
  }

  /**
   * 执行引爆效果逻辑
   */
  executeDetonation(element, battle) {
    const config = BATTLE.MARK_EFFECTS[element] || {};
    const baseDesc = config.description || `${element}行引爆！`;
    const result = { element, desc: baseDesc, damage: 0, heal: 0, shield: 0 };

    if (!battle) return result;

    const { player, enemy } = battle;

    switch (element) {
      case '金': {
        // 金印：破甲真实伤害 (无视护盾)
        const dmg = config.damageBonus || 8;
        if (enemy && enemy.invulnerableTurns <= 0) {
          enemy.hp = Math.max(0, enemy.hp - dmg);
          result.damage = dmg;
        }
        break;
      }
      case '木': {
        // 木印：生命恢复 (受青木珠法宝加成)
        let healVal = config.healBonus || 6;
        if (hasRelic(player, 'relic_qingmu')) {
          healVal += 2;
        }
        if (player) {
          const oldHp = player.hp;
          player.hp = Math.min(player.maxHp, player.hp + healVal);
          result.heal = player.hp - oldHp;
          // ★ 神木种子：治疗溢出转为护盾
          if (hasRelic(player, 'relic_shenmu_zhongzi')) {
            const overflow = healVal - result.heal;
            if (overflow > 0) {
              player.shield += overflow;
              result.shield = (result.shield || 0) + overflow;
              result.overflowShield = overflow;
            }
          }
        }
        break;
      }
      case '水': {
        // 水印：冰封冻结敌人，跳过下回合行动
        if (enemy) {
          // 免疫负面效果的敌人（如九尾狐阶段2后）不被冻结
          if (enemy.immuneToDebuff) {
            result.immune = true;
            result.log = `${enemy.name}免疫冰封！`;
          } else {
            enemy.skipTurn = true;
            result.frozen = true;
            // ★ 玄冰佩：冻结回合 +1
            if (hasRelic(player, 'relic_xuanbing_pei')) {
              enemy.frozenExtraTurns = (enemy.frozenExtraTurns || 0) + 1;
              result.extraFreeze = 1;
            }
          }
        }
        // ★ 凝水玉：水印引爆时额外抽1张牌
        if (hasRelic(player, 'relic_ningshui_yu') && player) {
          result.extraDraw = 1;
        }
        break;
      }
      case '火': {
        // 火印：本回合后续攻击伤害翻倍
        this.fireDoubleDamage = true;
        result.doubleDamage = true;
        // ★ 朱雀羽：火印引爆后火属性伤害额外 +30%
        if (hasRelic(player, 'relic_zhuque_yu')) {
          this.fireDamageBonus = 0.3;
          result.fireDamageBonus = 0.3;
        }
        break;
      }
      case '土': {
        // 土印：获得不灭护盾
        const shieldVal = config.shieldBonus || 10;
        if (player) {
          player.shield += shieldVal;
          result.shield = shieldVal;
        }
        break;
      }
      default:
        break;
    }

    return result;
  }

  /**
   * 回合结束重置临时状态
   */
  onTurnEnd() {
    this.fireDoubleDamage = false;
    this.fireDamageBonus = 0;
  }

  /**
   * 回合开始
   */
  onTurnStart() {
    this.fireDoubleDamage = false;
    this.fireDamageBonus = 0;
  }

  /**
   * 状态序列化 (用于存档与快照)
   */
  serialize() {
    return {
      marks: { ...this.marks },
      fireDoubleDamage: this.fireDoubleDamage,
      fireDamageBonus: this.fireDamageBonus
    };
  }

  /**
   * 从状态恢复
   */
  deserialize(data) {
    if (!data) return;
    this.marks = data.marks ? { ...data.marks } : { 金: 0, 木: 0, 水: 0, 火: 0, 土: 0 };
    this.fireDoubleDamage = !!data.fireDoubleDamage;
    this.fireDamageBonus = data.fireDamageBonus || 0;
  }
}