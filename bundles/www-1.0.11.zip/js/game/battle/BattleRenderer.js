﻿/**
 * js/game/battle/BattleRenderer.js
 * 战斗渲染系统
 * 集中管理战斗场景的所有 Canvas 2D 绘制逻辑
 */

import { globalPool } from '../../base/pool.js';
import {
  drawTextCentered, drawTextLeft, drawRoundedRect, drawScrollPanel,
  drawInkPanel, drawElementBadge, drawSealButton, UI_COLORS, getElementColor
} from '../scene.js';
import {
  drawInkGoldModal, drawNameplate, getWrappedLines, wrapDetailText
} from '../../config/ui-components.js';
import { SAFE_TOP } from '../../render.js';
import { drawCardTemplate, isCardTemplateReady, drawCardIcon } from '../cardFrame.js';
import { CHARACTERS } from '../types.js';
import { BATTLE, CARD_LAYOUT } from '../../config/constants.js';
import { isCurseCard } from '../effect-engine.js';

const { CARD_W, CARD_H, CARD_GAP, TRAY_PADDING_X } = CARD_LAYOUT;

const RARITY_COLORS = { 
  '普通': { fill: '#4A4036', stroke: '#8C7E6C', text: '#DDD4C4' }, 
  '稀有': { fill: '#1E3A5F', stroke: '#4A90D9', text: '#D8EBFF' }, 
  '史诗': { fill: '#5C1D54', stroke: '#BA43AA', text: '#FFD6FA' }, 
  '传说': { fill: '#664511', stroke: '#FFB834', text: '#FFF2C6' } 
};

const ELEMENT_CARD_STYLES = {
  "火": { bg: "#9D2D2D", border: "#C64747", ring: "#E25858" },
  "木": { bg: "#2A7737", border: "#48A257", ring: "#5CB36B" },
  "土": { bg: "#886F33", border: "#B0944F", ring: "#BF9E56" },
  "水": { bg: "#255F8F", border: "#4182BC", ring: "#539DE0" },
  "金": { bg: "#A67C28", border: "#CCA03F", ring: "#E2B84D" },
  "无": { bg: "#3D3734", border: "#5E5652", ring: "#807772" }
};

// 日志换行缓存：避免每帧重复 measureText
const _logCache = { lastLogKey: '', wrappedLines: [] };

function drawInkGoldScrollModal(ctx, x, y, w, h, isDialogue = false) {
  ctx.save();
  ctx.shadowColor = 'rgba(212, 175, 55, 0.22)';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetY = 10;
  drawRoundedRect(ctx, x, y, w, h, 14, '#1A0E08', '#0D0704', 3);
  ctx.restore();

  const goldGrad = ctx.createLinearGradient(x, y, x + w, y + h);
  goldGrad.addColorStop(0, '#E6C875');
  goldGrad.addColorStop(0.25, '#FFF6C2');
  goldGrad.addColorStop(0.5, '#C49838');
  goldGrad.addColorStop(0.75, '#FCE38A');
  goldGrad.addColorStop(1, '#8C6018');
  drawRoundedRect(ctx, x + 2, y + 2, w - 4, h - 4, 12, null, goldGrad, 2);

  const paperGrad = ctx.createRadialGradient(
    x + w / 2, y + h * 0.45, w * 0.15,
    x + w / 2, y + h * 0.5, w * 0.85
  );
  paperGrad.addColorStop(0, '#FFFDF8');
  paperGrad.addColorStop(0.35, '#F9EED9');
  paperGrad.addColorStop(0.75, '#EBD5AD');
  paperGrad.addColorStop(1, '#CFA968');
  drawRoundedRect(ctx, x + 5, y + 5, w - 10, h - 10, 10, paperGrad, '#8F6126', 1.5);

  ctx.save();
  const centerX = x + w / 2;
  const centerY = isDialogue ? y + h / 2 : y + h * 0.52;
  const wmR = Math.min(w, h) * 0.32;
  ctx.strokeStyle = 'rgba(184, 134, 40, 0.075)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(centerX, centerY, wmR, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(centerX, centerY, wmR * 0.85, 0, Math.PI * 2);
  ctx.setLineDash([8, 6]);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.beginPath();
  ctx.arc(centerX, centerY - wmR * 0.4, wmR * 0.4, Math.PI * 0.5, Math.PI * 1.5);
  ctx.arc(centerX, centerY + wmR * 0.4, wmR * 0.4, Math.PI * 1.5, Math.PI * 0.5);
  ctx.stroke();
  ctx.fillStyle = 'rgba(180, 120, 40, 0.04)';
  for (let i = 0; i < 28; i++) {
    const rx = x + 10 + ((i * 73 + 19) % (w - 20));
    const ry = y + 10 + ((i * 101 + 37) % (h - 20));
    ctx.beginPath();
    ctx.arc(rx, ry, (i % 3) + 1.2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  const innerMargin = 12;
  const ix = x + innerMargin;
  const iy = y + innerMargin;
  const iw = w - innerMargin * 2;
  const ih = h - innerMargin * 2;
  ctx.save();
  ctx.strokeStyle = 'rgba(150, 42, 31, 0.35)';
  ctx.lineWidth = 1;
  ctx.strokeRect(ix, iy, iw, ih);
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 1.2;
  ctx.strokeRect(ix + 3, iy + 3, iw - 6, ih - 6);

  const drawRoyalCorner = (cx, cy, dirX, dirY) => {
    ctx.save();
    ctx.strokeStyle = '#C99A3A';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(cx, cy + dirY * 18);
    ctx.lineTo(cx, cy);
    ctx.lineTo(cx + dirX * 18, cy);
    ctx.stroke();
    ctx.strokeStyle = '#EAD7A3';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(cx + dirX * 5, cy + dirY * 14);
    ctx.lineTo(cx + dirX * 5, cy + dirY * 5);
    ctx.lineTo(cx + dirX * 14, cy + dirY * 5);
    ctx.stroke();
    ctx.fillStyle = '#962A1F';
    ctx.beginPath();
    ctx.arc(cx + dirX * 7, cy + dirY * 7, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FFD700';
    ctx.fillRect(cx + dirX * 6, cy + dirY * 6, 2, 2);
    ctx.restore();
  };
  drawRoyalCorner(ix + 5, iy + 5, 1, 1);
  drawRoyalCorner(ix + iw - 5, iy + 5, -1, 1);
  drawRoyalCorner(ix + 5, iy + ih - 5, 1, -1);
  drawRoyalCorner(ix + iw - 5, iy + ih - 5, -1, -1);

  const drawCenterRuyi = (midX, midY, isFlip) => {
    ctx.save();
    ctx.translate(midX, midY);
    if (isFlip) ctx.scale(1, -1);
    ctx.strokeStyle = '#C99A3A';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(-10, 0, 4, Math.PI * 0.5, Math.PI * 2);
    ctx.arc(0, -2, 6, Math.PI, 0);
    ctx.arc(10, 0, 4, Math.PI, Math.PI * 0.5);
    ctx.stroke();
    ctx.fillStyle = '#962A1F';
    ctx.beginPath();
    ctx.arc(0, -2, 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };
  drawCenterRuyi(ix + iw / 2, iy + 3, false);
  drawCenterRuyi(ix + iw / 2, iy + ih - 3, true);
  ctx.restore();
}

export function renderEnemyArea(scene, ctx, width) {
  const b = scene.battle; 
  const ex = width / 2; 
  const ey = SAFE_TOP + 46; 
  const ew = Math.min(220, width - 40); 
  const eh = 114;

  drawInkPanel(ctx, ex - ew / 2, ey - eh / 2, ew, eh, { 
    fill: "rgba(45, 31, 22, 0.94)", 
    stroke: getElementColor(b.enemy.element), 
    strokeWidth: 2 
  });
  
  drawTextCentered(ctx, "— 妖 邪 —", ex, ey - 40, "#C99A3A", 10, "serif");
  drawTextCentered(ctx, b.enemy.name, ex, ey - 20, "#FFF3CA", 17, "serif");

  const badgeX = ex + ew / 2 - 24;
  const badgeY = ey - 22;
  drawElementBadge(ctx, b.enemy.element, badgeX, badgeY, 13);

  if (b.enemy.element && b.enemy.element !== '无') {
    const ELEMENT_ADVANTAGE = { "金": "木", "木": "土", "土": "水", "水": "火", "火": "金" };
    const ELEMENT_WEAKNESS = { "金": "火", "木": "金", "土": "木", "水": "土", "火": "水" };

    const weakElem = ELEMENT_WEAKNESS[b.enemy.element];
    const counterElem = ELEMENT_ADVANTAGE[b.enemy.element];

    const tagY = ey - 45;
    
    if (weakElem) {
      const weakColor = getElementColor(weakElem);
      const tagW = 40;
      const tagH = 17;
      const tagX = ex - ew / 2 + 10;
      
      drawRoundedRect(ctx, tagX, tagY, tagW, tagH, 3, "rgba(150, 42, 31, 0.92)", weakColor, 1.2);
      drawTextCentered(ctx, `弱·${weakElem}`, tagX + tagW / 2, tagY + tagH / 2, "#FFF8DD", 10, "serif");
    }

    if (counterElem) {
      const counterColor = getElementColor(counterElem);
      const tagW = 40;
      const tagH = 17;
      const tagX = ex - ew / 2 + 10;
      const tagY2 = tagY + tagH + 2;
      
      drawRoundedRect(ctx, tagX, tagY2, tagW, tagH, 3, "rgba(35, 26, 18, 0.92)", counterColor, 1.2);
      drawTextCentered(ctx, `克·${counterElem}`, tagX + tagW / 2, tagY2 + tagH / 2, "#EADBB8", 10, "serif");
    }
  }

  const hpBarW = ew - 28; 
  const hpBarH = 8; 
  const hpBarX = ex - hpBarW / 2; 
  const hpBarY = ey + 3;
  
  drawRoundedRect(ctx, hpBarX, hpBarY, hpBarW, hpBarH, 4, "#24160D", null);
  const hpRatio = Math.max(0, b.enemy.hp / b.enemy.maxHp);
  const hpColor = hpRatio > 0.3 ? UI_COLORS.cinnabar : "#D82F24";
  drawRoundedRect(ctx, hpBarX, hpBarY, hpBarW * hpRatio, hpBarH, 4, hpColor, null);
  
  let hpText = `${b.enemy.hp}/${b.enemy.maxHp}`;
  if (b.enemy.shield > 0) hpText += ` (盾: ${b.enemy.shield})`;
  drawTextCentered(ctx, hpText, ex, ey + 21, b.enemy.shield > 0 ? "#87CEEB" : "#EAD9B5", 11, "serif");

  const actionType = b.enemy.nextActionType || 'attack';
  let intentColor = "#FF7B7B";
  let intentIcon = "⚔";
  
  if (actionType === 'heavy_attack' || actionType === 'heavy_attack_curse') {
    intentColor = "#FF3333";
    intentIcon = "🪓";
  } else if (actionType === 'defend') {
    intentColor = "#4A90D9";
    intentIcon = "🛡";
  } else if (actionType === 'buff_attack' || actionType === 'buff_enrage') {
    intentColor = "#FFA500";
    intentIcon = "⚡";
  } else if (actionType === 'true_damage') {
    intentColor = "#D953D9";
    intentIcon = "📜";
  } else if (actionType === 'invulnerable_barrier') {
    intentColor = "#BA43AA";
    intentIcon = "🛡";
  } else if (actionType === 'debuff_energy') {
    intentColor = "#FF6600";
    intentIcon = "🔥";
  }

  let intentText = "";
  if (b.enemy.skipTurn) {
    intentText = "【定身】无法动弹";
    intentColor = "#87CEEB";
  } else {
    const valSuffix = (actionType === 'buff_attack' || actionType === 'buff_enrage' || actionType === 'invulnerable_barrier' || !b.enemy.nextActionValue) 
      ? '' 
      : ` (${b.enemy.nextActionValue})`;
    intentText = `${intentIcon} 意图: ${b.enemy.nextAction || '出招'}${valSuffix}`;
  }

  drawTextCentered(ctx, intentText, ex, ey + 38, intentColor, 12, "serif");

  if (b.enemy.burnTurns > 0) { 
    drawTextCentered(ctx, "燃烧 " + b.enemy.burnTurns, ex - ew / 2 + 25, ey - eh / 2 - 10, "#FF6600", 10, "serif"); 
  }
}

export function renderCardPreview(scene, ctx, width, height) {
  if (scene.previewCardIndex < 0) return;
  const card = scene.battle?.player?.cards[scene.previewCardIndex];
  if (!card) return;

  const logTop = SAFE_TOP + 104;
  const HAND_Y = height - CARD_H - 58;
  const trayY = HAND_Y - 24;
  const barY = trayY - 34;
  const logBottom = barY - 10;
  const logLeft = 10;
  const logRight = width - 10;

  drawRoundedRect(ctx, logLeft, logTop, logRight - logLeft, logBottom - logTop, 8, "rgba(15, 10, 5, 0.92)", "rgba(200, 149, 56, 0.5)", 1.5);

  const scale = 1.8;
  const cardW = CARD_W * scale;
  const cardH = CARD_H * scale;
  const cx = width / 2;
  const cy = (logTop + logBottom) / 2 - 8;

  ctx.save();
  ctx.shadowColor = 'rgba(212, 175, 55, 0.5)';
  ctx.shadowBlur = 18;
  const glowR = Math.round(cardW * 0.1);
  ctx.beginPath();
  ctx.moveTo(cx - cardW / 2 + glowR, cy - cardH / 2);
  ctx.lineTo(cx + cardW / 2 - glowR, cy - cardH / 2);
  ctx.quadraticCurveTo(cx + cardW / 2, cy - cardH / 2, cx + cardW / 2, cy - cardH / 2 + glowR);
  ctx.lineTo(cx + cardW / 2, cy + cardH / 2 - glowR);
  ctx.quadraticCurveTo(cx + cardW / 2, cy + cardH / 2, cx + cardW / 2 - glowR, cy + cardH / 2);
  ctx.lineTo(cx - cardW / 2 + glowR, cy + cardH / 2);
  ctx.quadraticCurveTo(cx - cardW / 2, cy + cardH / 2, cx - cardW / 2, cy + cardH / 2 - glowR);
  ctx.lineTo(cx - cardW / 2, cy - cardH / 2 + glowR);
  ctx.quadraticCurveTo(cx - cardW / 2, cy - cardH / 2, cx - cardW / 2 + glowR, cy - cardH / 2);
  ctx.closePath();
  ctx.fillStyle = 'rgba(212, 175, 55, 0.15)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.6)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);
  ctx.translate(-CARD_W / 2, -CARD_H / 2);

  const drawX = 0, drawY = 0;
  const totalCost = card.cost + (card.dualElement ? 1 : 0);
  const isCurse = isCurseCard(card);

  if (isCardTemplateReady()) {
    drawCardTemplate(ctx, drawX, drawY, CARD_W, CARD_H, isCurse ? '无' : card.element);
  }
  if (isCurse && isCardTemplateReady()) {
    ctx.fillStyle = "rgba(20, 15, 10, 0.4)";
    ctx.fillRect(drawX, drawY, CARD_W, CARD_H);
  }

  drawCardIcon(ctx, drawX + CARD_W / 2, drawY + 36, 44, card.name);

  const costBg = isCurse ? "#504743" : "#C89538";
  drawRoundedRect(ctx, drawX + 9, drawY + 9, 16, 18, 4, costBg, "#FFF3CA", 1.2);
  drawTextCentered(ctx, String(totalCost), drawX + 17, drawY + 19, "#1F1408", 11, "serif");

  const elemColor = getElementColor(card.element);
  ctx.save();
  if (card.element === '金') {
    ctx.shadowColor = '#FFD700';
    ctx.shadowBlur = 6;
  }
  ctx.beginPath();
  ctx.arc(drawX + CARD_W - 17, drawY + 17, 8, 0, Math.PI * 2);
  ctx.fillStyle = elemColor;
  ctx.fill();
  ctx.restore();
  ctx.strokeStyle = "#FFF3CA";
  ctx.lineWidth = 1.2;
  ctx.stroke();
  drawTextCentered(ctx, card.element, drawX + CARD_W - 17, drawY + 17, "#1F1408", 10, "serif");

  drawTextCentered(ctx, card.name, drawX + CARD_W / 2, drawY + 70, "#F5E6C8", 13, "serif");

  const desc = card.description || '';
  const starCount = card.star !== undefined ? card.star : (card.isUpgraded ? 1 : 0);
  if (desc) {
    drawTextCentered(ctx, card.type || "普通", drawX + CARD_W / 2, drawY + 93, "#D4AF37", 9, "serif");
    const maxChars = 9;
    const lineH = 10;
    const lines = [];
    let line = '';
    for (const ch of desc) {
      if (line.length >= maxChars) { lines.push(line); line = ch; }
      else { line += ch; }
    }
    if (line) lines.push(line);
    const startY = drawY + 104;
    for (let i = 0; i < Math.min(lines.length, 3); i++) {
      drawTextCentered(ctx, lines[i], drawX + CARD_W / 2, startY + i * lineH, "#D0C8B8", 8.5, "serif");
    }
    if (starCount > 0 && !isCurse) {
      const starText = starCount >= 2 ? '★★' : '★';
      drawTextCentered(ctx, starText, drawX + CARD_W / 2, drawY + 136, "#FFD700", starCount >= 2 ? 8 : 10, "serif");
    }
  } else {
    drawTextCentered(ctx, card.type || "普通", drawX + CARD_W / 2, drawY + 108, "#D0C8B8", 12, "serif");
    if (starCount > 0 && !isCurse) {
      const starText = starCount >= 2 ? '★★' : '★';
      drawTextCentered(ctx, starText, drawX + CARD_W / 2, drawY + 128, "#FFD700", starCount >= 2 ? 9 : 11, "serif");
    }
  }

  ctx.restore();

  if (!isCurse && card.element && BATTLE.MARK_EFFECTS[card.element]) {
    const effectDesc = BATTLE.MARK_EFFECTS[card.element].description;
    const triggerCount = BATTLE.MARK_TRIGGER_COUNT;
    const effectY = cy + cardH / 2 + 16;
    ctx.save();
    ctx.font = 'bold 11px "Songti SC", "SimSun", serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur = 4;
    ctx.fillStyle = '#E8C870';
    ctx.fillText(`叠${triggerCount}张同属性符箓触发印记`, cx, effectY);
    ctx.fillStyle = '#FFD700';
    ctx.fillText(`【${card.element}印】${effectDesc}`, cx, effectY + 16);
    ctx.restore();
  }
}

export function renderLogArea(scene, ctx, width, height) {
  const logTop = SAFE_TOP + 104; 
  const HAND_Y = height - CARD_H - 58; 
  const trayY = HAND_Y - 24;
  const barY = trayY - 34;
  const logHeight = Math.max(50, barY - 32 - logTop); 
  const logLeft = 10; 
  const logRight = width - 10;
  const maxWidth = logRight - logLeft - 24; 
  
  drawRoundedRect(ctx, logLeft, logTop, logRight - logLeft, logHeight, 6, "rgba(20, 15, 8, 0.85)", "rgba(160, 120, 70, 0.35)", 1.2);
  ctx.save(); 
  ctx.beginPath(); 
  ctx.rect(logLeft + 6, logTop + 6, logRight - logLeft - 12, logHeight - 12); 
  ctx.clip();
  
  ctx.font = "14px serif";

  // ★ 性能优化：日志换行缓存，只在日志变化时重新计算 measureText
  const logKey = scene.logs.length + '|' + (scene.logs[scene.logs.length - 1] || '');
  let wrappedLines;
  if (logKey === _logCache.lastLogKey) {
    wrappedLines = _logCache.wrappedLines;
  } else {
    wrappedLines = [];
    const logStart = Math.max(0, scene.logs.length - 30);
    for (let i = logStart; i < scene.logs.length; i++) {
      const log = scene.logs[i];
      let logColor = "#E6DEC8";
      if (log.includes("克制") || log.includes("因果镜")) logColor = "#FFD700";
      else if (log.includes("被克")) logColor = "#A09A8E";
      else if (log.includes("引爆")) logColor = "#FF7A28";
      else if (log.includes("击败") || log.includes("诛灭") || log.includes("降妖")) logColor = "#7AE392";
      else if (log.includes("败下阵") || log.includes("道消身陨")) logColor = "#FF6B6B";
      else if (log.includes("★")) logColor = "#FFD700";

      let currentLine = "";
      for (let c = 0; c < log.length; c++) {
        const char = log[c];
        const testLine = currentLine + char;
        if (ctx.measureText(testLine).width > maxWidth && currentLine !== "") {
          wrappedLines.push({ text: currentLine, color: logColor });
          currentLine = char;
        } else {
          currentLine = testLine;
        }
      }
      if (currentLine) {
        wrappedLines.push({ text: currentLine, color: logColor });
      }
    }
    _logCache.lastLogKey = logKey;
    _logCache.wrappedLines = wrappedLines;
  }

  const lineH = 20; 
  const maxVisibleLines = Math.floor((logHeight - 14) / lineH);
  const startIndex = Math.max(0, wrappedLines.length - maxVisibleLines);
  
  for (let i = startIndex; i < wrappedLines.length; i++) {
    const item = wrappedLines[i];
    drawTextLeft(ctx, item.text, logLeft + 12, logTop + 14 + (i - startIndex) * lineH, item.color, 14, "serif");
  }
  ctx.restore();
}

export function renderPlayerStatus(scene, ctx, width, height) {
  const b = scene.battle;
  const HAND_Y = height - CARD_H - 58;
  const trayY = HAND_Y - 24;
  const barH = 26;
  const barY = trayY - 34; 
  const totalW = width - 24;
  const startX = 12;
  const gap = 5;

  const hpW = Math.floor(totalW * 0.38);
  const shieldW = Math.floor(totalW * 0.18);
  const energyW = Math.floor(totalW * 0.22);
  const handW = totalW - hpW - shieldW - energyW - gap * 3;

  let curX = startX;

  drawRoundedRect(ctx, curX, barY, hpW, barH, 13, "rgba(28, 18, 10, 0.95)", "rgba(180, 45, 35, 0.7)", 1.2);
  drawRoundedRect(ctx, curX + 2, barY + 2, 22, 22, 11, UI_COLORS.cinnabar, "#FFD700", 1);
  drawTextCentered(ctx, "血", curX + 13, barY + 13, "#FFF8DD", 11, "serif");

  const hpRatio = Math.max(0, Math.min(1, b.player.hp / b.player.maxHp));
  const hpBarW = hpW - 28;
  const hpBarX = curX + 25;
  const hpBarY = barY + 8;
  const hpBarH = 10;
  
  drawRoundedRect(ctx, hpBarX, hpBarY, hpBarW, hpBarH, 4, "#140B06", "rgba(140, 80, 40, 0.5)", 1);
  if (hpRatio > 0) {
    const hpColor = hpRatio > 0.3 ? "#A8281E" : "#D63030";
    drawRoundedRect(ctx, hpBarX + 1, hpBarY + 1, Math.max(3, (hpBarW - 2) * hpRatio), hpBarH - 2, 3, hpColor, null);
  }
  ctx.save();
  ctx.shadowColor = "rgba(0, 0, 0, 0.95)";
  ctx.shadowBlur = 3;
  drawTextCentered(ctx, `${b.player.hp}/${b.player.maxHp}`, hpBarX + hpBarW / 2, barY + 13, "#FFFDF0", 10, "serif");
  ctx.restore();

  curX += hpW + gap;

  const hasShield = (b.player.shield || 0) > 0;
  const shieldBorder = hasShield ? "#4A90D9" : "rgba(100, 120, 150, 0.35)";
  drawRoundedRect(ctx, curX, barY, shieldW, barH, 13, "rgba(28, 18, 10, 0.95)", shieldBorder, 1.2);
  drawRoundedRect(ctx, curX + 2, barY + 2, 22, 22, 11, hasShield ? "#225287" : "#2E3842", hasShield ? "#87CEEB" : "#6A7B8C", 1);
  drawTextCentered(ctx, "盾", curX + 13, barY + 13, "#FFF8DD", 11, "serif");
  
  const shieldTextCol = hasShield ? "#87CEEB" : "#8A99A8";
  drawTextCentered(ctx, String(b.player.shield || 0), curX + 24 + (shieldW - 24) / 2, barY + 13, shieldTextCol, 12, "serif");

  curX += shieldW + gap;

  drawRoundedRect(ctx, curX, barY, energyW, barH, 13, "rgba(28, 18, 10, 0.95)", "rgba(201, 154, 58, 0.7)", 1.2);
  drawRoundedRect(ctx, curX + 2, barY + 2, 22, 22, 11, "#8C6A1E", "#FFD700", 1);
  drawTextCentered(ctx, "灵", curX + 13, barY + 13, "#FFF8DD", 11, "serif");
  
  const energyColor = b.player.energyDebuff ? "#FF6600" : "#FFD700";
  drawTextCentered(ctx, `${b.player.energy}/${b.player.maxEnergy}`, curX + 24 + (energyW - 24) / 2, barY + 13, energyColor, 12, "serif");

  curX += energyW + gap;

  const handCount = b.player.cards.length;
  const isHandFull = handCount >= BATTLE.MAX_HAND_LIMIT;
  const handBorder = isHandFull ? "#E74C3C" : "rgba(160, 120, 70, 0.45)";
  drawRoundedRect(ctx, curX, barY, handW, barH, 13, "rgba(28, 18, 10, 0.95)", handBorder, 1.2);
  drawRoundedRect(ctx, curX + 2, barY + 2, 22, 22, 11, isHandFull ? "#7A221B" : "#4A3728", isHandFull ? "#FFAAA6" : "#D4AF37", 1);
  drawTextCentered(ctx, "牌", curX + 13, barY + 13, "#FFF8DD", 11, "serif");
  drawTextCentered(ctx, `${handCount}/${BATTLE.MAX_HAND_LIMIT}`, curX + 24 + (handW - 24) / 2, barY + 13, isHandFull ? "#FF6B6B" : "#F0E2C8", 12, "serif");
}

export function renderHand(scene, ctx, width, height) {
  const b = scene.battle; 
  const HAND_Y = height - CARD_H - 58; 
  const trayX = TRAY_PADDING_X; 
  const trayW = width - TRAY_PADDING_X * 2; 
  const trayY = HAND_Y - 24;
  const trayH = CARD_H + 30; 
  const count = b.player.cards.length; 
  const totalCardsWidth = count * (CARD_W + CARD_GAP) - CARD_GAP;
  
  const trayBorder = scene.isDiscardMode ? "#E74C3C" : "rgba(160, 120, 70, 0.4)";
  drawRoundedRect(ctx, trayX, trayY, trayW, trayH, 8, "rgba(35, 24, 14, 0.65)", trayBorder, scene.isDiscardMode ? 2 : 1.5);

  if (scene.isDiscardMode) {
    drawTextCentered(ctx, "【弃牌状态：点击符箓弃置（索魂咒不可弃）】", width / 2, trayY + 10, "#E74C3C", 11, "serif");
  }

  let startX = TRAY_PADDING_X;
  if (totalCardsWidth <= trayW) { 
    startX = (width - totalCardsWidth) / 2; 
  } else { 
    startX = TRAY_PADDING_X + scene.handScrollX; 
  }

  ctx.save(); 
  ctx.beginPath(); 
  // 扩大裁剪区域，让发牌飞入动画可见
  ctx.rect(trayX - 60, trayY - 60, trayW + 120, trayH + 120); 
  ctx.clip();
  
  for (let i = 0; i < b.player.cards.length; i++) {
    const card = b.player.cards[i]; 
    const targetX = startX + i * (CARD_W + CARD_GAP);
    let targetY = HAND_Y;

    const isSelected = scene.selectedCardIndex === i;
    if (isSelected) {
      targetY -= 26; 
    }

    let drawX = targetX;
    let drawY = targetY;
    let drawScale = 1.0;
    let drawAlpha = 1.0;
    let drawRotate = 0;

    if (card._anim) {
      if (card._anim.delay > 0) continue;
      const t = Math.min(1, Math.max(0, card._anim.progress));
      const ease = 1 - Math.pow(1 - t, 3);

      drawX = card._anim.startX + (targetX - card._anim.startX) * ease;
      drawY = card._anim.startY + (targetY - card._anim.startY) * ease;
      drawScale = 0.6 + 0.4 * ease;
      drawAlpha = Math.min(1, ease * 2.0);
      drawRotate = card._anim.rotation * (1 - ease);

      if (Math.random() < 0.12 && scene.effects) {
        const p = globalPool.get('fx_particle', drawX + CARD_W / 2, drawY + CARD_H / 2, (Math.random() - 0.5) * 1.5, (Math.random() - 0.5) * 1.5, Math.random() * 2.5 + 1.5, '#FFD700', 10, 'star');
        if (p) scene.effects.particles.push(p);
      }
    } else if (isSelected) {
      drawY = targetY;
    }

    const totalCost = card.cost + (card.dualElement ? 1 : 0);
    const canAfford = b.player.energy >= totalCost;
    const isCurse = isCurseCard(card);

    const style = isCurse ? ELEMENT_CARD_STYLES["无"] : (ELEMENT_CARD_STYLES[card.element] || ELEMENT_CARD_STYLES["无"]);
    let cardColor = canAfford ? style.bg : "#2A2A2A";
    let borderColor = isSelected ? "#FFD700" : (canAfford ? style.border : "#444444");

    if (scene.isDiscardMode) {
      if (isCurse) {
        cardColor = "#262220";
        borderColor = "#555555";
      } else {
        cardColor = "#421815";
        borderColor = "#E74C3C";
      }
    }

    ctx.save();
    ctx.globalAlpha = drawAlpha;
    
    if (isSelected) {
      ctx.shadowColor = '#FFD700';
      ctx.shadowBlur = 14;
    }

    if (drawScale !== 1.0 || drawRotate !== 0) {
      ctx.translate(drawX + CARD_W / 2, drawY + CARD_H / 2);
      ctx.scale(drawScale, drawScale);
      ctx.rotate(drawRotate);
      ctx.translate(-(drawX + CARD_W / 2), -(drawY + CARD_H / 2));
    }

    if (isCardTemplateReady() && !scene.isDiscardMode) {
      drawCardTemplate(ctx, drawX, drawY, CARD_W, CARD_H, isCurse ? '无' : card.element);
    } else {
      drawRoundedRect(ctx, drawX, drawY, CARD_W, CARD_H, 8, cardColor, borderColor, isSelected ? 2.5 : 1.8);
    }

    if (isCurse && isCardTemplateReady()) {
      ctx.fillStyle = "rgba(20, 15, 10, 0.4)";
      ctx.fillRect(drawX, drawY, CARD_W, CARD_H);
    }

    if (!scene.isDiscardMode) {
      drawCardIcon(ctx, drawX + CARD_W / 2, drawY + 36, 44, card.name);
    }

    const costBg = isCurse ? "#504743" : "#C89538";
    drawRoundedRect(ctx, drawX + 9, drawY + 9, 16, 18, 4, costBg, "#FFF3CA", 1.2);
    drawTextCentered(ctx, String(totalCost), drawX + 17, drawY + 19, "#1F1408", 11, "serif");

    if (!scene.isDiscardMode) {
      const elemColor = getElementColor(card.element);
      ctx.save();
      if (card.element === '金') {
        ctx.shadowColor = '#FFD700';
        ctx.shadowBlur = 6;
      }
      ctx.beginPath();
      ctx.arc(drawX + CARD_W - 17, drawY + 17, 8, 0, Math.PI * 2);
      ctx.fillStyle = elemColor;
      ctx.fill();
      ctx.restore();
      ctx.strokeStyle = "#FFF3CA";
      ctx.lineWidth = 1.2;
      ctx.stroke();
      drawTextCentered(ctx, card.element, drawX + CARD_W - 17, drawY + 17, "#1F1408", 10, "serif");
    }

    if (scene.isDiscardMode) {
      if (isCurse) {
        drawRoundedRect(ctx, drawX + CARD_W - 32, drawY + 9, 24, 16, 4, "#444444", "#777777", 1);
        drawTextCentered(ctx, "禁弃", drawX + CARD_W - 20, drawY + 18, "#C0B4A0", 8, "serif");
      } else {
        drawRoundedRect(ctx, drawX + CARD_W - 26, drawY + 9, 16, 16, 4, "#E74C3C", "#FFFFFF", 1);
        drawTextCentered(ctx, "弃", drawX + CARD_W - 18, drawY + 18, "#FFFFFF", 9, "serif");
      }
    }

    drawTextCentered(ctx, card.name, drawX + CARD_W / 2, drawY + 70, "#F5E6C8", 13, "serif");

    const desc = card.description || '';
    const starCount = card.star !== undefined ? card.star : (card.isUpgraded ? 1 : 0);
    if (desc) {
      drawTextCentered(ctx, card.type || "普通", drawX + CARD_W / 2, drawY + 93, "#D4AF37", 9, "serif");
      const maxChars = 9;
      const lineH = 10;
      const lines = [];
      let line = '';
      for (const ch of desc) {
        if (line.length >= maxChars) { lines.push(line); line = ch; }
        else { line += ch; }
      }
      if (line) lines.push(line);
      const startY = drawY + 104;
      for (let i = 0; i < Math.min(lines.length, 3); i++) {
        drawTextCentered(ctx, lines[i], drawX + CARD_W / 2, startY + i * lineH, "#D0C8B8", 8.5, "serif");
      }
      if (starCount > 0 && !isCurse && !scene.isDiscardMode) {
        const starText = starCount >= 2 ? '★★' : '★';
        drawTextCentered(ctx, starText, drawX + CARD_W / 2, drawY + 136, "#FFD700", starCount >= 2 ? 8 : 10, "serif");
      }
    } else {
      drawTextCentered(ctx, card.type || "普通", drawX + CARD_W / 2, drawY + 108, "#D0C8B8", 12, "serif");
      if (starCount > 0 && !isCurse && !scene.isDiscardMode) {
        const starText = starCount >= 2 ? '★★' : '★';
        drawTextCentered(ctx, starText, drawX + CARD_W / 2, drawY + 128, "#FFD700", starCount >= 2 ? 9 : 11, "serif");
      }
    }

    if (!scene.isDiscardMode && !canAfford) { 
      ctx.fillStyle = "rgba(0, 0, 0, 0.45)"; 
      ctx.fillRect(drawX, drawY, CARD_W, CARD_H);
    }

    ctx.restore();
  }
  ctx.restore();

  if (totalCardsWidth > trayW) {
    if (scene.handScrollX < 0) drawTextCentered(ctx, "‹", trayX + 8, HAND_Y + CARD_H / 2, "rgba(255, 215, 0, 0.7)", 16);
    if (scene.handScrollX > trayW - totalCardsWidth) drawTextCentered(ctx, "›", trayX + trayW - 8, HAND_Y + CARD_H / 2, "rgba(255, 215, 0, 0.7)", 16);
  }
}

export function renderDialogueBox(scene, ctx, width, height) {
  const line = scene.dialogueQueue[scene.dialogueIndex];
  if (!line) return;

  ctx.fillStyle = 'rgba(6, 3, 1, 0.90)';
  ctx.fillRect(0, 0, width, height);

  const panelW = width - 20;
  const panelX = 10;
  const fontSize = 14;
  const lineHeight = 22;
  const textMaxW = panelW - 48;
  const wrapped = getWrappedLines(ctx, line.text, textMaxW, fontSize);
  const textH = wrapped.length * lineHeight;
  // 面板高度随文本行数自适应：顶部名牌40 + 文本 + 底部留白40，限制在屏幕内
  const panelH = Math.min(height - 40, Math.max(160, 40 + textH + 40));
  const panelY = height - panelH - 24;

  drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: true });

  const isLeft = line.side === 'left';
  drawNameplate(ctx, {
    speaker: line.speaker,
    tag: line.tag || '道',
    avatarColor: line.avatarColor || UI_COLORS.cinnabar,
    isLeft,
    panelX,
    panelY,
    panelW
  });

  ctx.save();
  ctx.font = fontSize + 'px "Songti SC", "SimSun", serif';
  ctx.fillStyle = '#120904';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  wrapped.forEach((text, i) => {
    ctx.fillText(text, panelX + 24, panelY + 40 + i * lineHeight);
  });
  ctx.restore();

  const alpha = Math.abs(Math.sin(Date.now() / 350));
  ctx.fillStyle = 'rgba(150, 42, 31, ' + (0.65 + 0.35 * alpha) + ')';
  ctx.font = '12px serif';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'bottom';
  ctx.fillText('轻触继续 ▾', panelX + panelW - 22, panelY + panelH - 12);
}

export function renderButtons(scene, ctx) {
  for (const btn of scene.buttons) {
    drawRoundedRect(ctx, btn.x, btn.y, btn.w, btn.h, 6, btn.color, null);
    drawTextCentered(ctx, btn.text, btn.x + btn.w / 2, btn.y + btn.h / 2, btn.textColor, btn.fontSize);
  }
}

export function renderHandFullModal(scene, ctx, width, height) {
  ctx.fillStyle = "rgba(10, 6, 2, 0.82)"; 
  ctx.fillRect(0, 0, width, height); 
  
  const panelW = Math.min(310, width - 40); 
  const panelH = 220; 
  const panelY = (height - panelH) / 2;
  
  drawScrollPanel(ctx, (width - panelW) / 2, panelY, panelW, panelH, { 
    fill: "rgba(252, 246, 230, 0.98)", 
    stroke: UI_COLORS.cinnabar, 
    strokeWidth: 2.5 
  }); 
  
  drawTextCentered(ctx, "【 牌 藏 充 盈 】", width / 2, panelY + 34, UI_COLORS.cinnabar, 20, "serif");
  
  ctx.strokeStyle = "rgba(180, 130, 70, 0.35)"; 
  ctx.lineWidth = 1; 
  ctx.beginPath(); 
  ctx.moveTo((width - panelW) / 2 + 24, panelY + 54); 
  ctx.lineTo((width - panelW) / 2 + panelW - 24, panelY + 54); 
  ctx.stroke();
  
  drawTextCentered(ctx, `当前手牌已达${BATTLE.MAX_HAND_LIMIT}张上限！`, width / 2, panelY + 84, UI_COLORS.ink, 15, "serif");
  drawTextCentered(ctx, "进入下回合将不再发牌（停止发牌）", width / 2, panelY + 110, "#8C2A24", 13, "serif");
  drawTextCentered(ctx, "道友确定要直接结束本回合吗？", width / 2, panelY + 136, "#6B4A2E", 12, "serif");

  for (const btn of scene.buttons) {
    drawSealButton(ctx, btn);
  }
}

export function renderChapterEndModal(scene, ctx, width, height) {
  ctx.fillStyle = "rgba(4, 2, 1, 0.94)"; 
  ctx.fillRect(0, 0, width, height);

  const panelW = Math.min(348, width - 20); 
  const panelH = 430; 
  const panelX = (width - panelW) / 2; 
  const panelY = (height - panelH) / 2 - 10;

  drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: false });
  
  const chapter = scene.runState?.chapter || 1;
  const isCh2 = chapter === 2;
  const isCh3 = chapter === 3;

  let title, subTitle;
  if (isCh3) {
    title = "【 终章 · 归墟封印 】";
    subTitle = "「九尾伏诛 · 三界灵脉重归清明」";
  } else if (isCh2) {
    title = "【 第二章 · 幽冥荡平 】";
    subTitle = "「枉死城六道重开 · 阴阳判官伏法」";
  } else {
    title = "【 第一章 · 功德圆满 】";
    subTitle = "「兰若古刹妖氛尽散 · 枯木老尊伏诛」";
  }
  
  ctx.font = 'bold 18px "Songti SC", "SimSun", serif';
  ctx.fillStyle = UI_COLORS.cinnabar;
  ctx.textAlign = 'center';
  ctx.fillText(title, width / 2, panelY + 32);

  ctx.font = '12px serif';
  ctx.fillStyle = '#6B4A2E';
  ctx.fillText(subTitle, width / 2, panelY + 52);

  ctx.strokeStyle = "#D4AF37"; 
  ctx.lineWidth = 1.2; 
  ctx.beginPath(); 
  ctx.moveTo(panelX + 28, panelY + 64); 
  ctx.lineTo(panelX + panelW - 28, panelY + 64); 
  ctx.stroke();
  
  let epilogueP1, epilogueP2, epilogueP3, achievementText, unlockText;
  
  if (isCh3) {
    epilogueP1 = "九尾巨妖仰天长啸，九道幽红妖尾寸寸崩解成漫天流火，归墟血海自中央裂开一道通往人间的生路。混沌怨气如退潮般消散，被吞噬千年的三界灵脉终于重见天光。";
    epilogueP2 = "你立在封印之门的废墟之上，怀中因果镜映出万千生笑脸。钟馗按剑大笑：「小道友，从兰若古刹到枉死幽冥，再入归墟死地——这一路降妖伏魔，功德已照彻山河！」";
    epilogueP3 = "风起云开，第一缕朝阳穿过归墟云层洒落人间。《妖异录》这一页，由你亲手写下圆满终章。前路漫漫，志怪人间仍有新的传说等待翻开。";
    achievementText = "★ 达成成就：封印归墟 · 道成圆满 ★";
    unlockText = "【 妖异录 · 全卷通关 】 感谢道友一路走来";
  } else if (isCh2) {
    epilogueP1 = "判官笔折断，生死簿万千残页化作金蝶归位各方。暴烈的忘川之水渐渐止息，千万受缚生魂重见清明，得以踏上重塑的轮回坦途。";
    epilogueP2 = "然而，森罗殿深处的万丈黑玉台阶轰然塌陷，地底极渊之中，浮现出一口深不见底的归墟血海。九道遮天蔽日的幽红妖尾在深渊暗影中狂乱狂舞，上古封印已然破碎！";
    epilogueP3 = "钟馗按剑立于深渊之畔，沉声道：「判官不过是受人摆布的提线木偶……归墟已破，混沌九尾即将吞噬三界灵脉！小道友，持此莲花化身之引，速随吾杀入九幽最深处，决战乾坤！！」";
    achievementText = "★ 达成成就：大闹地府 · 肃清枉死深渊 ★";
    unlockText = "解锁新道统：【三坛海会 · 哪吒】";
  } else {
    epilogueP1 = "晨曦初破，万道金色的朝阳终于穿透了黑风岭笼罩百年的重重阴霾。漫山枯木崩解化灰，被禁锢的无辜冤魂化作漫天流萤，得入往生。";
    epilogueP2 = "在巨树深处，赫然出现了一道宽达百丈的深渊，黄泉死水咆哮，隐见幽冥枉死城！你在焦土中拾得一枚血字令牌——「阴司判官·改命绝判」。";
    epilogueP3 = "怀中【因果镜】烈火狂涌，钟馗天师怒吼：「狂悖判官私篡生死簿！小道友，且随吾杀入幽冥枉死城，荡平这万世邪祟！！」";
    achievementText = "★ 达成成就：破除黑风 · 荡平古刹妖瘴 ★";
    unlockText = "解锁新道统：【伏魔天师 · 钟馗】";
  }

  let curY = panelY + 78;
  [epilogueP1, epilogueP2, epilogueP3].forEach(p => {
    wrapDetailText(ctx, p, panelX + 24, curY, panelW - 48, 20, '#120904', 12);
    const lCount = getWrappedLines(ctx, p, panelW - 48, 12).length;
    curY += lCount * 20 + 8;
  });

  drawRoundedRect(ctx, panelX + 20, panelY + 316, panelW - 40, 48, 6, "rgba(244, 235, 212, 0.96)", "#2E6B46", 1.2);
  
  drawTextCentered(ctx, achievementText, width / 2, panelY + 332, "#2E6B46", 12, "serif");
  drawTextCentered(ctx, unlockText, width / 2, panelY + 350, "#8C2A24", 12, "serif");

  const btn = scene.buttons[0]; 
  if (btn) { 
    drawRoundedRect(ctx, btn.x, btn.y, btn.w, btn.h, 19, btn.color, "#FFD700", 1.5); 
    drawTextCentered(ctx, btn.text, btn.x + btn.w / 2, btn.y + btn.h / 2, btn.textColor, btn.fontSize, "serif"); 
  }
}

export function renderVictoryRewardModal(scene, ctx, width, height) {
  const data = scene.victoryRewardData; 
  if (!data) return;
  ctx.fillStyle = "rgba(10, 6, 2, 0.82)"; 
  ctx.fillRect(0, 0, width, height); 
  const panelW = Math.min(320, width - 36); 
  const panelH = 346; 
  const panelX = (width - panelW) / 2; 
  const panelY = (height - panelH) / 2;
  drawInkGoldScrollModal(ctx, panelX, panelY, panelW, panelH, true);
  drawTextCentered(ctx, "降 妖 功 成", width / 2, panelY + 32, UI_COLORS.cinnabar, 22, "serif"); 
  const subTitle = data.isFlawless ? "★ 气血毫发未损 · 触发【无伤完胜】★" : `斩除妖邪「${data.enemyName}」· 结算战利`; 
  const subTitleColor = data.isFlawless ? "#9A731F" : "#6B4A2E"; 
  drawTextCentered(ctx, subTitle, width / 2, panelY + 54, subTitleColor, 11, "serif"); 
  ctx.strokeStyle = "rgba(180, 130, 70, 0.35)"; 
  ctx.lineWidth = 1; 
  ctx.beginPath(); 
  ctx.moveTo(panelX + 20, panelY + 68); 
  ctx.lineTo(panelX + panelW - 20, panelY + 68); 
  ctx.stroke();

  const itemX = panelX + 16; 
  const itemW = panelW - 32; 
  let curY = panelY + 80; 
  const goldStroke = data.isFlawless ? "#D4AF37" : "#C99A3A"; 
  drawRoundedRect(ctx, itemX, curY, itemW, 44, 6, "rgba(244, 235, 212, 0.95)", goldStroke, data.isFlawless ? 2 : 1.2); 
  drawRoundedRect(ctx, itemX + 8, curY + 9, 26, 26, 13, "#9A731F", "#FFE599", 1); 
  drawTextCentered(ctx, "铜", itemX + 21, curY + 22, "#FFF8DD", 12, "serif"); 
  drawTextLeft(ctx, `本次获铜: +${data.totalGold}`, itemX + 42, curY + 22, UI_COLORS.ink, 14, "serif"); 
  
  if (data.isFlawless) { 
    drawRoundedRect(ctx, itemX + 138, curY + 11, 56, 22, 11, "#9A731F", "#FFE599", 1); 
    drawTextCentered(ctx, "无伤 ×2", itemX + 166, curY + 22, "#FFF8DD", 10, "serif"); 
  } 
  drawTextLeft(ctx, `总计: ${data.finalTotalGold}`, itemX + itemW - 76, curY + 22, "#C99A3A", 13, "serif"); 
  curY += 52;

  drawRoundedRect(ctx, itemX, curY, itemW, 44, 6, "rgba(244, 235, 212, 0.95)", "#2E6B46", 1.2); 
  drawRoundedRect(ctx, itemX + 8, curY + 9, 26, 26, 13, "#2B6B46", "#A3E4D7", 1); 
  drawTextCentered(ctx, "因", itemX + 21, curY + 22, "#FFF8DD", 12, "serif"); 
  drawTextLeft(ctx, `善业因果 +${data.karma}`, itemX + 42, curY + 22, UI_COLORS.ink, 14, "serif"); 
  curY += 52;
  
  const isElite = (scene.enemyIndex === 4 || scene.enemyIndex === 9 || scene.enemyIndex === 15);
  const isBoss = (scene.enemyIndex === 5 || scene.enemyIndex === 10 || scene.enemyIndex === 16);
  
  if (isElite || isBoss) { 
    drawRoundedRect(ctx, itemX, curY, itemW, 44, 6, "rgba(244, 235, 212, 0.95)", "#BA43AA", 1.2); 
    drawRoundedRect(ctx, itemX + 8, curY + 9, 26, 26, 13, "#5C1D54", "#FFD6FA", 1); 
    drawTextCentered(ctx, "宝", itemX + 21, curY + 22, "#FFF8DD", 12, "serif"); 
    drawTextLeft(ctx, "感应到上古法宝现世！", itemX + 42, curY + 22, "#5C1D54", 13, "serif"); 
  } else { 
    drawRoundedRect(ctx, itemX, curY, itemW, 44, 6, "rgba(244, 235, 212, 0.95)", "#8C2A24", 1.2); 
    drawRoundedRect(ctx, itemX + 8, curY + 9, 26, 26, 13, UI_COLORS.cinnabar, "#FFD700", 1); 
    drawTextCentered(ctx, "血", itemX + 21, curY + 22, "#FFF8DD", 12, "serif"); 
    const hpDesc = data.isFlawless ? `气血 ${data.hp}/${data.maxHp}（完好无损）` : `道体气血 ${data.hp} / ${data.maxHp}`; 
    drawTextLeft(ctx, hpDesc, itemX + 42, curY + 22, UI_COLORS.ink, 13, "serif"); 
  }

  const btn = scene.buttons[0]; 
  if (btn) { 
    drawRoundedRect(ctx, btn.x, btn.y, btn.w, btn.h, 19, btn.color, "#FFD700", 1.5); 
    drawTextCentered(ctx, btn.text, btn.x + btn.w / 2, btn.y + btn.h / 2, btn.textColor, btn.fontSize, "serif"); 
  }
}

export function renderRelicReward(scene, ctx, width, height) {
  ctx.fillStyle = "rgba(10, 6, 2, 0.85)"; 
  ctx.fillRect(0, 0, width, height); 
  
  const panelW = Math.min(320, width - 32); 
  const panelH = 390; 
  const panelX = (width - panelW) / 2; 
  const panelY = (height - panelH) / 2 - 10;
  
  drawScrollPanel(ctx, panelX, panelY, panelW, panelH, { 
    fill: "rgba(252, 246, 230, 0.98)", 
    stroke: UI_COLORS.gold, 
    strokeWidth: 2.5 
  }); 
  
  drawTextCentered(ctx, "法 宝 现 世", width / 2, panelY + 34, UI_COLORS.cinnabar, 22, "serif"); 
  drawTextCentered(ctx, "斩除强敌天降机缘 · 请择一纳为己用", width / 2, panelY + 58, "#6B4A2E", 11, "serif");
  
  ctx.strokeStyle = "rgba(180, 130, 70, 0.35)"; 
  ctx.lineWidth = 1; 
  ctx.beginPath(); 
  ctx.moveTo(panelX + 24, panelY + 72); 
  ctx.lineTo(panelX + panelW - 24, panelY + 72); 
  ctx.stroke();
  
  for (let i = 0; i < scene.relicCards.length; i++) {
    const card = scene.relicCards[i];
    const { x, y, w, h, relic } = card; 
    if (!relic) continue;
    const rarity = relic.rarity || '普通';
    const rStyle = RARITY_COLORS[rarity] || RARITY_COLORS['普通'];
    const isSelected = scene.selectedRelicIndex === i;
    
    const borderColor = isSelected ? '#FFD700' : rStyle.stroke;
    const borderWidth = isSelected ? 3 : 1.5;
    const fillColor = isSelected ? 'rgba(255, 248, 220, 0.98)' : "rgba(242, 232, 206, 0.95)";
    
    drawRoundedRect(ctx, x, y, w, h, 6, fillColor, borderColor, borderWidth); 
    drawRoundedRect(ctx, x + 8, y + 10, 36, 18, 3, rStyle.fill, rStyle.stroke, 1); 
    drawTextCentered(ctx, rarity, x + 26, y + 19, rStyle.text, 10, "serif"); 
    drawTextLeft(ctx, relic.name || '神秘法宝', x + 50, y + 19, UI_COLORS.ink, 15, "serif"); 
    
    const btnText = isSelected ? '再次点击确认' : '收纳';
    const btnColor = isSelected ? UI_COLORS.gold : UI_COLORS.cinnabar;
    drawRoundedRect(ctx, x + w - 64, y + 8, 56, 22, 11, btnColor, "#FFD700", 1); 
    drawTextCentered(ctx, btnText, x + w - 36, y + 19, "#FFF8DD", 10, "serif"); 
    
    const descText = relic.description || relic.desc || '蕴含无上灵力的上古秘宝。';
    wrapDetailText(ctx, descText, x + 10, y + 36, w - 20, 15, "#543825", 11); 
  }
  
  const skipBtn = scene.buttons[scene.buttons.length - 1]; 
  if (skipBtn && skipBtn.text) { 
    drawRoundedRect(ctx, skipBtn.x, skipBtn.y, skipBtn.w, skipBtn.h, 18, UI_COLORS.inkSoft, "#8C7E6C", 1); 
    drawTextCentered(ctx, skipBtn.text, skipBtn.x + skipBtn.w / 2, skipBtn.y + skipBtn.h / 2, skipBtn.textColor, skipBtn.fontSize, "serif"); 
  }
}

/**
 * 渲染卡牌奖励选择弹窗
 */
export function renderCardReward(scene, ctx, width, height) {
  ctx.fillStyle = "rgba(10, 6, 2, 0.85)";
  ctx.fillRect(0, 0, width, height);

  const panelW = Math.min(340, width - 32);
  const panelH = 420;
  const panelX = (width - panelW) / 2;
  const panelY = (height - panelH) / 2 - 10;

  drawScrollPanel(ctx, panelX, panelY, panelW, panelH, {
    fill: "rgba(252, 246, 230, 0.98)",
    stroke: UI_COLORS.gold,
    strokeWidth: 2.5
  });

  drawTextCentered(ctx, "符 箓 现 世", width / 2, panelY + 34, UI_COLORS.cinnabar, 22, "serif");
  drawTextCentered(ctx, "降妖功成天赐机缘 · 请择一纳入卡组", width / 2, panelY + 58, "#6B4A2E", 11, "serif");

  ctx.strokeStyle = "rgba(180, 130, 70, 0.35)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(panelX + 24, panelY + 72);
  ctx.lineTo(panelX + panelW - 24, panelY + 72);
  ctx.stroke();

  const elementColors = { '金': '#D4AF37', '木': '#5BA84A', '水': '#4A9FD8', '火': '#E85D3A', '土': '#8B7355', '无': '#888' };

  if (scene.rewardCardButtons) {
    for (let i = 0; i < scene.rewardCardButtons.length; i++) {
      const item = scene.rewardCardButtons[i];
      const { x, y, w, h, card } = item;
      if (!card) continue;
      const elemColor = elementColors[card.element] || '#888';
      const isSelected = scene.selectedRewardCardIndex === i;

      const borderColor = isSelected ? '#FFD700' : elemColor;
      const borderWidth = isSelected ? 3 : 1.5;
      const fillColor = isSelected ? 'rgba(255, 248, 220, 0.98)' : "rgba(242, 232, 206, 0.95)";

      drawRoundedRect(ctx, x, y, w, h, 6, fillColor, borderColor, borderWidth);

      // 费用
      drawRoundedRect(ctx, x + 8, y + 10, 28, 28, 14, '#1a3a5c', '#4A9FD8', 1.5);
      drawTextCentered(ctx, card.cost, x + 22, y + 27, '#FFF', 16, 'serif');

      // 卡名
      drawTextLeft(ctx, card.name || '神秘符箓', x + 44, y + 22, UI_COLORS.ink, 15, "serif");

      // 元素标签 / 确认提示
      if (isSelected) {
        drawRoundedRect(ctx, x + w - 70, y + 10, 60, 20, 10, UI_COLORS.gold, '#FFD700', 1);
        drawTextCentered(ctx, '再次点击确认', x + w - 40, y + 22, '#FFF8DD', 9, 'serif');
      } else if (card.element && card.element !== '无') {
        drawRoundedRect(ctx, x + w - 50, y + 10, 38, 20, 10, elemColor, '#FFF', 1);
        drawTextCentered(ctx, card.element, x + w - 31, y + 22, '#FFF', 11, 'serif');
      }

      // 描述
      const descText = card.description || '蕴含无上灵力的符箓。';
      wrapDetailText(ctx, descText, x + 10, y + 42, w - 20, 15, "#543825", 11);
    }
  }

  // 放弃按钮
  const skipBtn = scene.buttons[scene.buttons.length - 1];
  if (skipBtn && skipBtn.text) {
    drawRoundedRect(ctx, skipBtn.x, skipBtn.y, skipBtn.w, skipBtn.h, 17, UI_COLORS.inkSoft, "#8C7E6C", 1);
    drawTextCentered(ctx, skipBtn.text, skipBtn.x + skipBtn.w / 2, skipBtn.y + skipBtn.h / 2, skipBtn.textColor, skipBtn.fontSize, "serif");
  }
}

export function renderBagModal(scene, ctx, width, height) {
  ctx.fillStyle = 'rgba(10, 6, 2, 0.78)'; 
  ctx.fillRect(0, 0, width, height); 
  const panelW = Math.min(320, width - 36); 
  const panelH = Math.min(480, height - 80); 
  const panelX = (width - panelW) / 2; 
  const panelY = (height - panelH) / 2;
  
  drawInkGoldScrollModal(ctx, panelX, panelY, panelW, panelH, false); 
  drawTextCentered(ctx, "修 真 锦 囊", width / 2, panelY + 28, UI_COLORS.cinnabar, 20, "serif");
  
  ctx.strokeStyle = '#D4AF37'; 
  ctx.lineWidth = 1; 
  ctx.beginPath(); 
  ctx.moveTo(panelX + 20, panelY + 46); 
  ctx.lineTo(panelX + panelW - 20, panelY + 46); 
  ctx.stroke();

  const clipY = panelY + 48;
  const clipH = panelH - 74;
  ctx.save();
  ctx.beginPath();
  ctx.rect(panelX + 4, clipY, panelW - 8, clipH);
  ctx.clip();
  
  let curY = clipY + 8 + scene.bagScrollY;

  drawTextLeft(ctx, "【 道 体 资 产 】", panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
  curY += 16;
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, 34, 5, 'rgba(238, 226, 198, 0.75)', 'rgba(160, 120, 70, 0.3)', 1);
  drawTextLeft(ctx, `铜钱: ${scene.runState ? scene.runState.gold : 0} 文`, panelX + 28, curY + 17, "#C99A3A", 13, "serif"); 
  drawTextLeft(ctx, `因果善业: ${(scene.runState?.karma || 0) > 0 ? '+' : ''}${scene.runState?.karma || 0}`, panelX + 155, curY + 17, "#2B6B46", 13, "serif");
  curY += 44;

  const charConfig = CHARACTERS[scene.battle?.characterId || scene.runState?.characterId] || CHARACTERS.taoist;
  drawTextLeft(ctx, "【 道 统 传 承 】", panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
  curY += 16;
  const passiveText = `【${charConfig.name}】 被动：${charConfig.passive}`;
  const passiveLines = getWrappedLines(ctx, passiveText, panelW - 48, 11);
  const passiveBoxH = Math.max(34, 12 + passiveLines.length * 16);
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, passiveBoxH, 5, 'rgba(238, 226, 198, 0.75)', 'rgba(160, 120, 70, 0.3)', 1);
  ctx.font = '11px serif'; 
  ctx.fillStyle = '#2B6B46'; 
  ctx.textAlign = 'left'; 
  ctx.textBaseline = 'top';
  passiveLines.forEach((l, i) => {
    ctx.fillText(l, panelX + 24, curY + 8 + i * 16);
  });
  curY += passiveBoxH + 12;

  const allCards = scene.battle?.player?.deck 
    ? [...scene.battle.player.deck, ...scene.battle.player.cards, ...scene.battle.player.discard] 
    : (scene.runState?.allCards || []);
  const star2Cards = allCards.filter(c => c.star === 2);
  const star1Cards = allCards.filter(c => c.star === 1 || (c.isUpgraded && c.star !== 2));
  const shopBoughtCards = allCards.filter(c => c.price !== undefined || c.isPermanentSupply);
  
  drawTextLeft(ctx, `【 道 藏 牌 库 一 览 】 (共 ${allCards.length} 张)`, panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
  curY += 16;

  const star2Str = star2Cards.length > 0 ? star2Cards.map(c => c.name.replace(/\+*$/, '★★极')).join('、') : '暂无二星极品符箓';
  const star2Lines = getWrappedLines(ctx, star2Str, panelW - 48, 11);
  const star2BoxH = 22 + star2Lines.length * 16 + 6;
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, star2BoxH, 5, 'rgba(244, 235, 212, 0.88)', '#BA43AA', 1.2);
  ctx.font = '11px serif'; 
  ctx.fillStyle = '#5C1D54'; 
  ctx.textAlign = 'left'; 
  ctx.textBaseline = 'top';
  ctx.fillText(`二星·极阶符箓 (${star2Cards.length}张):`, panelX + 24, curY + 6);
  star2Lines.forEach((l, i) => {
    ctx.fillText(l, panelX + 24, curY + 22 + i * 16);
  });
  curY += star2BoxH + 8;

  const star1Str = star1Cards.length > 0 ? star1Cards.map(c => c.name.replace(/\+*$/, '★')).join('、') : '暂无一星进阶符箓';
  const star1Lines = getWrappedLines(ctx, star1Str, panelW - 48, 11);
  const star1BoxH = 22 + star1Lines.length * 16 + 6;
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, star1BoxH, 5, 'rgba(244, 235, 212, 0.88)', '#2B6B46', 1.2);
  ctx.font = '11px serif'; 
  ctx.fillStyle = '#2B6B46'; 
  ctx.textAlign = 'left'; 
  ctx.textBaseline = 'top';
  ctx.fillText(`一星·进阶符箓 (${star1Cards.length}张):`, panelX + 24, curY + 6);
  star1Lines.forEach((l, i) => {
    ctx.fillText(l, panelX + 24, curY + 22 + i * 16);
  });
  curY += star1BoxH + 8;

  const shopStr = shopBoughtCards.length > 0 ? shopBoughtCards.map(c => c.name).join('、') : '暂无';
  const shopLines = getWrappedLines(ctx, shopStr, panelW - 48, 11);
  const shopBoxH = 22 + shopLines.length * 16 + 6;
  drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, shopBoxH, 5, 'rgba(244, 235, 212, 0.88)', '#C99A3A', 1.2);
  ctx.font = '11px serif'; 
  ctx.fillStyle = '#8C6212'; 
  ctx.textAlign = 'left'; 
  ctx.textBaseline = 'top';
  ctx.fillText(`货郎坊市购得 (${shopBoughtCards.length}张):`, panelX + 24, curY + 6);
  shopLines.forEach((l, i) => {
    ctx.fillText(l, panelX + 24, curY + 22 + i * 16);
  });
  curY += shopBoxH + 12;

  const relics = scene.battle?.player?.relics || scene.runState?.relics || []; 
  drawTextLeft(ctx, `【 已 纳 法 宝 】 (${relics.length} 件)`, panelX + 18, curY, UI_COLORS.inkSoft, 13, "serif");
  curY += 16;
  
  if (relics.length === 0) { 
    drawTextCentered(ctx, "行囊空空，尚未寻得法宝机缘", width / 2, curY + 16, "#888888", 12, "serif"); 
    curY += 36;
  } else { 
    relics.forEach((relic) => { 
      const relicDesc = relic.description || relic.desc || '蕴含灵力的随身秘宝。';
      const relicLines = getWrappedLines(ctx, relicDesc, panelW - 52, 11);
      const relicBoxH = Math.max(46, 20 + relicLines.length * 15 + 6);
      drawRoundedRect(ctx, panelX + 16, curY, panelW - 32, relicBoxH, 5, 'rgba(244, 235, 212, 0.9)', '#C99A3A', 1); 
      drawTextLeft(ctx, relic.name, panelX + 26, curY + 12, UI_COLORS.ink, 13, "serif"); 
      ctx.font = '11px serif'; 
      ctx.fillStyle = '#543825'; 
      ctx.textAlign = 'left'; 
      ctx.textBaseline = 'top';
      relicLines.forEach((l, i) => {
        ctx.fillText(l, panelX + 26, curY + 24 + i * 15);
      });
      curY += relicBoxH + 8; 
    }); 
  }

  scene.bagContentHeight = curY - (clipY + 8 + scene.bagScrollY) + 12;
  ctx.restore();

  drawTextCentered(ctx, "— 上下滑动浏览 · 点击任意处收拢 —", width / 2, panelY + panelH - 14, "#8A6D4B", 11, "serif");
}

/**
 * 渲染当前激活的流派状态
 * 显示在玩家状态栏上方，每个流派为一个彩色胶囊标签
 */
export function renderBuildStatus(scene, ctx, width, height) {
  const b = scene.battle;
  if (!b || !b.buildSystem) return;

  const activeBuilds = b.buildSystem.getActiveBuilds();
  if (activeBuilds.length === 0) return;

  const HAND_Y = height - CARD_H - 58;
  const trayY = HAND_Y - 24;
  const barY = trayY - 34;

  // 流派标签显示在状态栏上方，左对齐排列
  const tagY = barY - 26;
  const tagH = 20;
  const tagPadding = 12;
  const gap = 6;

  // 从左侧开始排列
  let curX = 12;

  // 记录标签位置，用于长按检测
  scene.buildTagAreas = [];

  activeBuilds.forEach((build, i) => {
    ctx.font = '11px serif';
    const text = `${build.name} Lv${build.level}`;
    const w = ctx.measureText(text).width + tagPadding * 2;
    const x = curX;

    // 记录标签区域
    scene.buildTagAreas.push({
      x, y: tagY, w, h: tagH,
      buildKey: build.key
    });

    // 背景
    ctx.save();
    ctx.shadowColor = build.color;
    ctx.shadowBlur = 8;
    drawRoundedRect(ctx, x, tagY, w, tagH, 10, 'rgba(20, 12, 6, 0.92)', build.color, 1.5);
    ctx.restore();

    // 左侧元素色点
    ctx.fillStyle = build.color;
    ctx.beginPath();
    ctx.arc(x + 10, tagY + tagH / 2, 3, 0, Math.PI * 2);
    ctx.fill();

    // 文字
    drawTextCentered(ctx, text, x + w / 2 + 3, tagY + tagH / 2 + 1, build.color, 11, 'serif');

    curX += w + gap;
  });
}

/**
 * 渲染流派详情弹窗（长按流派标签触发）
 */
export function renderBuildDetailModal(scene, ctx, width, height) {
  const detail = scene.selectedBuildDetail;
  if (!detail) return;

  // 半透明遮罩
  ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
  ctx.fillRect(0, 0, width, height);

  const panelW = Math.min(340, width - 40);
  const panelX = (width - panelW) / 2;
  const panelY = height * 0.18;

  // 计算面板高度
  const effects = detail.currentEffects || [];
  const nextEffects = detail.nextEffects || [];
  const contentH = 60 + effects.length * 22 + (nextEffects.length > 0 ? 30 + nextEffects.length * 20 : 0) + 50;
  const panelH = Math.min(contentH, height * 0.65);

  // 面板背景
  ctx.save();
  ctx.shadowColor = detail.color;
  ctx.shadowBlur = 20;
  drawRoundedRect(ctx, panelX, panelY, panelW, panelH, 12, 'rgba(22, 14, 8, 0.97)', detail.color, 2);
  ctx.restore();

  let curY = panelY + 20;

  // 标题
  ctx.font = 'bold 18px serif';
  ctx.fillStyle = detail.color;
  ctx.textAlign = 'center';
  ctx.fillText(`${detail.name}  Lv${detail.level}/${detail.maxLevel}`, width / 2, curY);
  curY += 10;

  // 等级进度条
  const barW = panelW - 60;
  const barX = panelX + 30;
  const barH = 6;
  ctx.fillStyle = 'rgba(255,255,255,0.1)';
  drawRoundedRect(ctx, barX, curY + 8, barW, barH, 3, 'rgba(255,255,255,0.1)', null, 0);
  ctx.fillStyle = detail.color;
  const fillW = (barW * detail.level) / detail.maxLevel;
  drawRoundedRect(ctx, barX, curY + 8, fillW, barH, 3, detail.color, null, 0);
  curY += 28;

  // 描述
  ctx.font = '12px serif';
  ctx.fillStyle = '#B8A890';
  ctx.textAlign = 'center';
  const descLines = wrapText(ctx, detail.desc, panelW - 40);
  descLines.forEach(line => {
    ctx.fillText(line, width / 2, curY);
    curY += 16;
  });
  curY += 8;

  // 触发条件
  ctx.font = '11px serif';
  ctx.fillStyle = '#8C7A60';
  ctx.fillText(`激活条件：${detail.triggerCondition}`, width / 2, curY);
  curY += 20;

  // 分割线
  ctx.strokeStyle = 'rgba(255,255,255,0.1)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(panelX + 20, curY);
  ctx.lineTo(panelX + panelW - 20, curY);
  ctx.stroke();
  curY += 14;

  // 当前增益
  ctx.font = 'bold 13px serif';
  ctx.fillStyle = detail.color;
  ctx.textAlign = 'left';
  ctx.fillText('◆ 当前增益', panelX + 20, curY);
  curY += 18;

  ctx.font = '11px serif';
  ctx.fillStyle = '#D4C4A8';
  effects.forEach(effect => {
    const lines = wrapText(ctx, '  ' + effect, panelW - 50);
    lines.forEach(line => {
      ctx.fillText(line, panelX + 25, curY);
      curY += 15;
    });
  });

  // 下一级预览
  if (nextEffects.length > 0 && detail.level < detail.maxLevel) {
    curY += 6;
    ctx.font = 'bold 12px serif';
    ctx.fillStyle = '#8C7A60';
    ctx.textAlign = 'left';
    ctx.fillText('◇ 下一级', panelX + 20, curY);
    curY += 16;

    ctx.font = '10px serif';
    ctx.fillStyle = '#7A6A50';
    nextEffects.forEach(effect => {
      const lines = wrapText(ctx, '  ' + effect, panelW - 50);
      lines.forEach(line => {
        ctx.fillText(line, panelX + 25, curY);
        curY += 14;
      });
    });
  }

  // 提示关闭
  curY = panelY + panelH - 20;
  ctx.font = '10px serif';
  ctx.fillStyle = '#6A5A40';
  ctx.textAlign = 'center';
  ctx.fillText('点击任意处关闭', width / 2, curY);

  ctx.textAlign = 'left';
}

/**
 * 文字换行辅助函数
 */
function wrapText(ctx, text, maxWidth) {
  const lines = [];
  let currentLine = '';
  for (const char of text) {
    const testLine = currentLine + char;
    if (ctx.measureText(testLine).width > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = char;
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine) lines.push(currentLine);
  return lines;
}
export function renderFinalChoiceModal(scene, ctx, width, height) {
  ctx.fillStyle = "rgba(4, 2, 1, 0.96)";
  ctx.fillRect(0, 0, width, height);

  const panelW = Math.min(348, width - 20);
  const panelH = 430;
  const panelX = (width - panelW) / 2;
  const panelY = (height - panelH) / 2 - 10;

  drawInkGoldModal(ctx, panelX, panelY, panelW, panelH, { isDialogue: false });

  ctx.font = 'bold 18px "Songti SC", "SimSun", serif';
  ctx.fillStyle = UI_COLORS.cinnabar;
  ctx.textAlign = 'center';
  ctx.fillText("【 最终抉择 · 归墟门前 】", width / 2, panelY + 34);

  ctx.font = '12px serif';
  ctx.fillStyle = '#6B4A2E';
  ctx.fillText("「门已开缝，玄冥之眼将睁。你的选择，决定三界走向。」", width / 2, panelY + 56);

  ctx.strokeStyle = "#D4AF37";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(panelX + 28, panelY + 70);
  ctx.lineTo(panelX + panelW - 28, panelY + 70);
  ctx.stroke();

  const choices = scene.finalChoices || [];
  scene.buttons.forEach((btn, i) => {
    const choice = choices[i];
    if (!choice) return;
    drawRoundedRect(ctx, btn.x, btn.y, btn.w, btn.h, 10, btn.color, choice.locked ? '#8A7A6A' : '#FFD700', choice.locked ? 1 : 1.5);
    ctx.textAlign = 'left';
    ctx.font = 'bold 15px "Songti SC", "SimSun", serif';
    ctx.fillStyle = btn.textColor;
    ctx.fillText(choice.title, btn.x + 14, btn.y + 24);
    ctx.font = '11px serif';
    ctx.fillStyle = choice.locked ? '#C8B8A0' : '#F0E8D0';
    const wrapped = getWrappedLines(ctx, choice.desc, btn.w - 28, 11);
    wrapped.forEach((line, li) => {
      ctx.fillText(line, btn.x + 14, btn.y + 44 + li * 14);
    });
  });
}