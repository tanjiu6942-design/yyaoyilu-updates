﻿/**
 * js/game/battle/BattleReward.js
 * 战斗奖励系统（从 BattleScene 拆分）
 * 处理胜利奖励计算、领取、遗物选择、章节结束
 * 渲染部分仍由 BattleScene 负责
 */

import { stepToNode, generateChapterMap } from '../map.js';
import { RELIC_TEMPLATES, CHARACTERS, unlockAchievement } from '../types.js';
import { CARD_TEMPLATES, SPECIAL_SHOP_CARDS } from '../data.js';
import { ECONOMY, randomRangeInt } from '../../config/constants.js';
import { unlockZhongKui, unlockNezha, unlockBaiSuzhen } from '../../config/storage.js';
import { runManager } from '../RunManager.js';
import { soundManager } from '../../runtime/music.js';
import { hapticLight, hapticMedium } from '../../config/haptics.js';
import { createButton, UI_COLORS } from '../scene.js';

/**
 * 计算战斗胜利奖励数据
 */
export function calculateVictoryReward(scene) {
  // 精英：4=黑白无常(章1)、9=牛头阿傍(章2)、15=九尾·善念残响(章3)
  const isElite = (scene.enemyIndex === 4 || scene.enemyIndex === 9 || scene.enemyIndex === 15);
  // BOSS：5=黑山山魈王(章1)、10=阴阳判官(章2)、16=九尾狐·归墟之门(章3)
  const isBoss = (scene.enemyIndex === 5 || scene.enemyIndex === 10 || scene.enemyIndex === 16);

  let baseGold = 0;
  if (isBoss) {
    baseGold = randomRangeInt(ECONOMY.REWARD_BOSS_MIN, ECONOMY.REWARD_BOSS_MAX);
  } else if (isElite) {
    baseGold = randomRangeInt(ECONOMY.REWARD_ELITE_MIN, ECONOMY.REWARD_ELITE_MAX);
  } else {
    baseGold = randomRangeInt(ECONOMY.REWARD_NORMAL_MIN, ECONOMY.REWARD_NORMAL_MAX);
  }

  const hasJubao = (scene.battle.player.relics || []).some(r => r.id === 'relic_jubao' || r.name === '聚宝盆');
  const goldBonus = hasJubao ? Math.round(baseGold * ECONOMY.JUBAO_BONUS_RATE) : 0;
  const earnedGold = baseGold + goldBonus;
  const entryHp = scene.entrySnapshot ? scene.entrySnapshot.hp : scene.battle.player.maxHp;
  const isFlawless = scene.battle.player.hp >= entryHp;
  const totalGold = isFlawless ? earnedGold * 2 : earnedGold;
  const finalTotalGold = (scene.runState?.gold || 0) + totalGold;

  scene.victoryRewardData = {
    baseGold,
    goldBonus,
    isFlawless,
    totalGold,
    finalTotalGold,
    karma: 1,
    hp: scene.battle.player.hp,
    maxHp: scene.battle.player.maxHp,
    enemyName: scene.battle.enemy.name,
    isElite,
    isBoss
  };
  scene.showVictoryModal = true;
  buildVictoryRewardUI(scene);
}

/**
 * 构建胜利奖励UI
 */
export function buildVictoryRewardUI(scene) {
  const { width, height } = scene.manager;
  scene.manager.input.clearButtons();
  scene.buttons = [];
  const panelH = 346;
  const panelY = (height - panelH) / 2;
  const isElite = (scene.enemyIndex === 4 || scene.enemyIndex === 9 || scene.enemyIndex === 15);
  const isBoss = (scene.enemyIndex === 5 || scene.enemyIndex === 10 || scene.enemyIndex === 16);
  let btnText = "收纳战利品";
  if (isBoss) btnText = "终结妖氛";
  else if (isElite) btnText = "挑选法宝";

  const claimBtn = createButton(width / 2 - 75, panelY + panelH - 50, 150, 38, btnText, {
    fontSize: 16,
    color: UI_COLORS.cinnabar,
    textColor: "#FFF8DD",
    tap: () => {
      onClaimVictoryRewards(scene);
    }
  });
  scene.buttons = [claimBtn];
  scene.manager.input.addTouchButton(claimBtn);
}

/**
 * 领取胜利奖励核心逻辑
 */
export function onClaimVictoryRewards(scene) {
  const data = scene.victoryRewardData;
  if (!data || !scene.runState) return;
  scene.runState.hp = Math.max(1, scene.battle.player.hp);
  scene.runState.maxHp = scene.battle.player.maxHp;
  scene.runState.gold = (scene.runState.gold || 0) + data.totalGold;
  scene.runState.karma = Math.min(10, (scene.runState.karma || 0) + data.karma);

  soundManager.playSfx('coin');
  hapticLight();
  unlockAchievement('first_blood');
  if (data.isFlawless) unlockAchievement('flawless');
  if (scene.runState.gold >= 150) unlockAchievement('rich');
  if (scene.runState.karma >= 10) unlockAchievement('karma_max');

  if (scene.runState.currentNodeId) scene.runState.map = stepToNode(scene.runState.map, scene.runState.currentNodeId);
  scene.saveRunState();
  scene.showVictoryModal = false;

  if (data.isBoss) {
    const chapter = scene.runState.chapter || 1;
    if (chapter === 1) {
      unlockAchievement('chap1_clear');
      CHARACTERS.zhong_kui.unlocked = true;
      unlockZhongKui();
    } else if (chapter === 2) {
      unlockAchievement('chap2_clear');
      CHARACTERS.nezha.unlocked = true;
      unlockNezha();
    } else {
      // 第三章最终 BOSS：九尾狐·归墟之门，通关即终局
      unlockAchievement('chap3_clear');
    }
    scene.showChapterEndModal = true;
    scene.buildUI();
    return;
  }

  if (data.isElite) {
    const ownedIds = (scene.runState?.relics || []).map(r => r.id);
    const available = RELIC_TEMPLATES.filter(r => !ownedIds.includes(r.id));
    if (available.length > 0) {
      const shuffled = [...available].sort(() => 0.5 - Math.random());
      scene.rewardRelics = shuffled.slice(0, Math.min(3, shuffled.length));
      scene.selectedRelicIndex = -1;
      scene.showRelicReward = true;
      buildRelicRewardUI(scene);
      return;
    }
  }

  // ★ 普通战斗：无伤通关才给卡牌三选一奖励
  if (!data.isBoss && !data.isElite && data.isFlawless) {
    const allCards = [...CARD_TEMPLATES, ...SPECIAL_SHOP_CARDS].filter(c => !c.isCurse);
    const shuffled = [...allCards].sort(() => 0.5 - Math.random());
    scene.rewardCards = shuffled.slice(0, 3);
    scene.selectedRewardCardIndex = -1;
    scene.showCardReward = true;
    buildCardRewardUI(scene);
    return;
  }

  scene.manager.enterScene('map', { chapter: scene.runState.chapter || 1 });
}

/**
 * 构建遗物奖励选择UI
 */
export function buildRelicRewardUI(scene) {
  const { width, height } = scene.manager;
  scene.manager.input.clearButtons();
  scene.relicCards = [];
  scene.buttons = [];
  const panelW = Math.min(320, width - 32);
  const cardW = panelW - 32;
  const cardH = 74;
  const startX = (width - panelW) / 2 + 16;
  const startY = height / 2 - 130;
  const gap = 12;

  scene.rewardRelics.forEach((relic, i) => {
    const cy = startY + i * (cardH + gap);
    const cardArea = { x: startX, y: cy, w: cardW, h: cardH, relic };
    scene.relicCards.push(cardArea);
    scene.buttons.push(createButton(startX, cy, cardW, cardH, '', {
      tap: () => {
        // 二次点击确认：第一次选中，第二次确认
        if (scene.selectedRelicIndex === i) {
          selectRewardRelic(scene, relic);
        } else {
          scene.selectedRelicIndex = i;
          soundManager.playSfx('btn_click');
          hapticLight();
          buildRelicRewardUI(scene); // 重建UI以高亮选中项
        }
      }
    }));
  });
  scene.buttons.push(createButton(width / 2 - 60, startY + 3 * (cardH + gap) + 12, 120, 36, "放弃机缘", {
    fontSize: 14,
    color: UI_COLORS.inkSoft,
    textColor: "#D0C8B8",
    tap: () => {
      skipRewardRelic(scene);
    }
  }));
  scene.buttons.forEach(btn => scene.manager.input.addTouchButton(btn));
}

/**
 * 选择遗物奖励
 */
export function selectRewardRelic(scene, relic) {
  if (!scene.runState) return;
  const result = runManager.addRelic(relic);
  if (!result.success) {
    soundManager.playSfx('btn_click');
    wx.showToast({ title: result.reason, icon: 'none', duration: 1500 });
    return;
  }
  scene.showRelicReward = false;
  soundManager.playSfx('coin');
  hapticMedium();
  wx.showToast({ title: `获得法宝：${relic.name}`, icon: 'success', duration: 1500 });
  setTimeout(() => { scene.manager.enterScene('map', { chapter: scene.runState.chapter || 1 }); }, 500);
}

/**
 * 放弃遗物奖励
 */
export function skipRewardRelic(scene) {
  scene.showRelicReward = false;
  hapticLight();
  scene.manager.enterScene('map', { chapter: scene.runState.chapter || 1 });
}

/**
 * 构建卡牌奖励选择UI
 */
export function buildCardRewardUI(scene) {
  const { width, height } = scene.manager;
  scene.manager.input.clearButtons();
  scene.rewardCardButtons = [];
  scene.buttons = [];
  const panelW = Math.min(340, width - 32);
  const cardW = panelW - 32;
  const cardH = 80;
  const startX = (width - panelW) / 2 + 16;
  const startY = height / 2 - 140;
  const gap = 12;

  scene.rewardCards.forEach((card, i) => {
    const cy = startY + i * (cardH + gap);
    const btn = createButton(startX, cy, cardW, cardH, '', {
      tap: () => {
        // 二次点击确认：第一次选中，第二次确认
        if (scene.selectedRewardCardIndex === i) {
          selectRewardCard(scene, card);
        } else {
          scene.selectedRewardCardIndex = i;
          soundManager.playSfx('btn_click');
          hapticLight();
          buildCardRewardUI(scene); // 重建UI以高亮选中项
        }
      }
    });
    scene.rewardCardButtons.push({ x: startX, y: cy, w: cardW, h: cardH, card });
    scene.buttons.push(btn);
    scene.manager.input.addTouchButton(btn);
  });

  const skipBtn = createButton(width / 2 - 60, startY + 3 * (cardH + gap) + 8, 120, 34, '放弃符箓', {
    fontSize: 13,
    color: UI_COLORS.inkSoft,
    textColor: "#B8A890",
    tap: () => {
      skipRewardCard(scene);
    }
  });
  scene.buttons.push(skipBtn);
  scene.manager.input.addTouchButton(skipBtn);
}

/**
 * 选择卡牌奖励
 */
export function selectRewardCard(scene, card) {
  if (!scene.runState) return;
  if (!scene.runState.allCards) scene.runState.allCards = [];
  const newCard = { ...card, id: 'card_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6) };
  scene.runState.allCards.push(newCard);
  scene.saveRunState();
  scene.showCardReward = false;
  scene.selectedRewardCardIndex = -1;
  soundManager.playSfx('victory');
  hapticMedium();
  wx.showToast({ title: `获得符箓：${card.name}`, icon: 'success', duration: 1500 });
  setTimeout(() => { scene.manager.enterScene('map', { chapter: scene.runState.chapter || 1 }); }, 500);
}

/**
 * 放弃卡牌奖励
 */
export function skipRewardCard(scene) {
  scene.showCardReward = false;
  scene.selectedRewardCardIndex = -1;
  hapticLight();
  scene.manager.enterScene('map', { chapter: scene.runState.chapter || 1 });
}

/**
 * 构建章节结束模态框UI
 */
export function buildChapterEndModalUI(scene) {
  const { width, height } = scene.manager;
  scene.manager.input.clearButtons();
  scene.buttons = [];
  const chapter = scene.runState?.chapter || 1;
  let btnText;
  if (chapter === 1) btnText = "踏入幽冥(第二章)";
  else if (chapter === 2) btnText = "杀入归墟(第三章)";
  else btnText = "功德圆满(返回首页)";
  const confirmBtn = createButton(width / 2 - 75, height / 2 + 155, 150, 40, btnText, {
    fontSize: 16,
    color: UI_COLORS.cinnabar,
    textColor: "#FFF8DD",
    tap: () => {
      onChapterEndConfirm(scene);
    }
  });
  scene.buttons = [confirmBtn];
  scene.manager.input.addTouchButton(confirmBtn);
}

/**
 * 章节结束确认处理
 */
export function onChapterEndConfirm(scene) {
  const chapter = scene.runState?.chapter || 1;
  scene.showChapterEndModal = false;
  if (chapter === 1) {
    scene.runState.chapter = 2;
    scene.runState.currentNodeId = null;
    scene.runState.map = generateChapterMap(2, 8, scene.runState.karma || 0);
    scene.saveRunState();
    scene.manager.enterScene('map', { chapter: 2 });
  } else if (chapter === 2) {
    // ★ 善因果通关第二章解锁白素贞
    const karma = scene.runState?.karma || 0;
    if (karma >= 5) {
      unlockBaiSuzhen();
      wx.showToast({ title: '解锁新角色：白素贞', icon: 'success', duration: 2000 });
    }
    scene.runState.chapter = 3;
    scene.runState.currentNodeId = null;
    scene.runState.map = generateChapterMap(3, 8, scene.runState.karma || 0);
    scene.saveRunState();
    scene.manager.enterScene('map', { chapter: 3 });
  } else {
    runManager.clearRun();
    scene.manager.enterScene('menu');
  }
}

/**
 * 构建第三章最终选择界面UI
 * 根据因果值和遗物条件解锁不同选项
 */
export function buildFinalChoiceUI(scene) {
  const { width, height } = scene.manager;
  scene.manager.input.clearButtons();
  scene.buttons = [];

  const karma = scene.runState?.karma || 0;
  const relicIds = (scene.runState?.relics || []).map(r => r.id);
  const hasHuzhu = relicIds.includes('relic_qingqiu_huzhu');
  const hasZhilv = relicIds.includes('relic_zhilv_yinji');

  const choices = [
    { key: 'fight',    title: '【以死相搏】', desc: '用尽最后力量阻止九尾开门', locked: false },
    { key: 'join',     title: '【暂时联手】', desc: '与九尾联手推翻天庭（需恶因果≤-5）', locked: karma > -5 },
    { key: 'persuade', title: '【以情动人】', desc: '用青丘狐珠唤醒九尾善念（需青丘狐珠+善因果≥3）', locked: !(hasHuzhu && karma >= 3) },
    { key: 'truth',    title: '【真相之眼】', desc: '以前世记忆看穿玄冥真相（需执律印记+因果=0）', locked: !(hasZhilv && karma === 0) }
  ];
  scene.finalChoices = choices;

  const panelW = Math.min(348, width - 20);
  const panelH = 430;
  const panelX = (width - panelW) / 2;
  const panelY = (height - panelH) / 2 - 10;
  const btnW = panelW - 48;
  const btnH = 68;
  const gap = 10;
  const rowStartY = panelY + 88;

  choices.forEach((choice, i) => {
    const btnY = rowStartY + i * (btnH + gap);
    const btn = createButton(panelX + 24, btnY, btnW, btnH, '', {
      color: choice.locked ? '#6B5A4A' : UI_COLORS.cinnabar,
      textColor: choice.locked ? '#B8A890' : '#FFF8DD',
      tap: () => {
        if (choice.locked) {
          hapticLight();
          wx.showToast({ title: '条件未满足', icon: 'none', duration: 1000 });
          return;
        }
        scene.handleFinalChoice(choice.key);
      }
    });
    scene.buttons.push(btn);
    scene.manager.input.addTouchButton(btn);
  });
}