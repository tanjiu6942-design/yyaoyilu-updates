/**
 * 第一章【荒冢古刹】多幕对话剧本
 * side: 'left' (主角方) | 'right' (敌方/NPC)
 */
export const CHAPTER_1_DIALOGUES = {
  // 1. 序幕：踏入黑风岭
  PROLOGUE: [
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '（按住腰间剧烈震颤的因果镜）师尊所料不差，这黑风岭的阴煞之气，竟已浓郁到遮天蔽日的境地……'
    },
    {
      speaker: '师尊遗音',
      tag: '魂',
      side: 'right',
      avatarColor: '#C99A3A',
      text: '『徒儿，山中木石尽皆化煞，兰若寺地底灵穴已破。持此五行符囊，切记万物相生相克，莫堕魔障……』'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '弟子谨记。前方古道似有微弱哭声，且容弟子前往一探！'
    }
  ],

  // 2. 精英遭遇：黑白无常
  ELITE_WU_CHANG: [
    {
      speaker: '白无常',
      tag: '冥',
      side: 'right',
      avatarColor: '#5C1D54',
      text: '桀桀桀……一见生财！哪里来的游方生魂，竟敢擅闯阴阳边界？'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '无常二爷乃地府正神，为何在阳间拘押无辜生灵，截断六道轮回？！'
    },
    {
      speaker: '黑无常',
      tag: '煞',
      side: 'right',
      avatarColor: '#1C140E',
      text: '天下太平……生魂止步！生死簿已被判官重置，凡阻路者，同入幽冥！'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '生死簿有异？看来今日必须以雷法震散你们周身的阴煞锁链了！'
    }
  ],

  // 3. 首领战前：黑山山魈王
  BOSS_INTRO: [
    {
      speaker: '黑山山魈王',
      tag: '魁',
      side: 'right',
      avatarColor: '#8C2A24',
      text: '青城山的小道士……百年前，你的太师祖曾在此与老朽把酒论道。那时他说，天道无私，常与善人……'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '你受兰若寺百年香火化生神智，本应护持一方，为何吞噬生民血肉，自甘堕入魔道？！'
    },
    {
      speaker: '黑山山魈王',
      tag: '魁',
      side: 'right',
      avatarColor: '#8C2A24',
      text: '魔道？！地府阴泉倒灌、佛陀金身崩碎之时，天道在何处？！神明在何处？！唯有汲取万物血肉，老朽方能与幽冥同寿！'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '执迷不悟！今日便借三昧真火，焚尽你这颗污浊木心！'
    }
  ],

  // 4. 首领半血狂暴：枯木逢煞
  BOSS_ENRAGE: [
    {
      speaker: '黑山山魈王',
      tag: '狂',
      side: 'right',
      avatarColor: '#9E2F24',
      text: '（胸膛树皮寸寸崩裂，黑色魔血喷涌）啊啊啊……幽冥黄泉啊！赐予老朽撕碎一切的力量吧！'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '不好！它的木心与地底阴脉彻底相连，煞气暴涨了！'
    }
  ],

  // 5. 战后终结与钟馗残魂觉醒
  BOSS_DEFEAT: [
    {
      speaker: '黑山山魈王',
      tag: '灭',
      side: 'right',
      avatarColor: '#555555',
      text: '地府的深渊已经裂开……判官大人……绝不会放过你们的……（化作漫天飞灰）'
    },
    {
      speaker: '游方道士',
      tag: '道',
      side: 'left',
      avatarColor: '#2B6B46',
      text: '呼……妖树已灭，但这焦黑坑底为何留有一块【阴司判官令】？'
    },
    {
      speaker: '伏魔天师·钟馗',
      tag: '馗',
      side: 'left',
      avatarColor: '#962A1F',
      text: '（因果镜中烈火喷涌，现出威严法相）好一个狂悖无道的阴阳判官！私篡生死簿，祸乱人世！小道友，且借你道身一用，随吾杀入幽冥枉死城！'
    }
  ]
};