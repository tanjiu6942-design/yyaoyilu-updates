/**
 * 古风水墨卡牌模板加载与绘制
 * 使用 assets/card_template.jpg（生成的水墨卡牌模板：金边+上半水墨区+下半宣纸区）
 */

const TEMPLATE_PATH = 'assets/card_template.jpg';
const ICON_DIR = 'assets/card_icons';

// 卡牌名称 → 图标文件名映射（ASCII 文件名避免中文路径问题）
const CARD_ICON_MAP = {
  '御剑术': 'icon_01.png',
  '横扫千军': 'icon_02.png',
  '流水剑': 'icon_03.png',
  '烈火斩': 'icon_04.png',
  '裂地拳': 'icon_05.png',
  '五雷正法': 'icon_06.png',
  '三昧真火': 'icon_07.png',
  '太极护体': 'icon_08.png',
  '金钟罩': 'icon_09.png',
  '木甲术': 'icon_10.png',
  '土墙术': 'icon_11.png',
  '回春术': 'icon_12.png',
  '定身符': 'icon_13.png',
  '引灵诀': 'icon_14.png',
  '净心咒': 'icon_15.png',
  '钟馗': 'icon_16.png',
  '哪吒': 'icon_17.png',
  '索魂咒': 'icon_18.png',
  '万剑归宗': 'icon_19.png',
  '神木灵甲': 'icon_20.png',
  '玄水狂潮': 'icon_21.png',
  '九龙神火罩': 'icon_22.png',
  '泰山压顶': 'icon_23.png',
  '乾坤借法': 'icon_24.png',
  '枯木逢春': 'icon_25.png',
  '两仪剑法': 'icon_26.png',
  '孙悟空': 'icon_27.png',
  '白素贞': 'icon_28.png'
};

// 五行元素主题色（与 scene.js getElementColorDark 一致，multiply 染色更明显）
const ELEMENT_COLORS = {
  '金': '#F0D060',
  '木': '#3D7A28',
  '水': '#2B5F9A',
  '火': '#9A2B2B',
  '土': '#8B7332',
  '无': '#666666'
};

let templateImg = null;
let loaded = false;
let loadFailed = false;

// 卡牌图标缓存
const iconCache = {};
let iconsLoaded = false;

export function loadCardTemplate() {
  if (loaded || loadFailed) return;
  try {
    templateImg = wx.createImage();
    templateImg.onload = () => { loaded = true; };
    templateImg.onerror = () => { loadFailed = true; };
    templateImg.src = TEMPLATE_PATH;
  } catch (e) {
    loadFailed = true;
  }
}

export function loadCardIcons() {
  if (iconsLoaded) return;
  iconsLoaded = true;
  for (const name in CARD_ICON_MAP) {
    try {
      const img = wx.createImage();
      img.onload = () => { iconCache[name] = img; };
      img.onerror = () => { /* 静默失败 */ };
      img.src = `${ICON_DIR}/${CARD_ICON_MAP[name]}`;
    } catch (e) { /* ignore */ }
  }
}

export function getCardIcon(name) {
  return iconCache[name] || null;
}

export function isCardTemplateReady() {
  return loaded && templateImg && templateImg.width > 0;
}

export function getElementColor(element) {
  return ELEMENT_COLORS[element] || ELEMENT_COLORS['无'];
}

/**
 * 绘制卡牌技能图标（深墨徽章底+金边，图标居中）
 */
export function drawCardIcon(ctx, cx, cy, size, name) {
  const img = getCardIcon(name);
  const r = size / 2;

  ctx.save();
  // 深墨色圆形底板
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(28, 18, 10, 0.88)';
  ctx.fill();
  // 金色细边框
  ctx.strokeStyle = '#C89538';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  if (img && img.width > 0) {
    // 图标略缩小，留出金边
    const inner = size - 6;
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, inner / 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(img, cx - inner / 2, cy - inner / 2, inner, inner);
    ctx.restore();
  }
  ctx.restore();
}

/**
 * 绘制卡牌模板背景（含元素染色）
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x - 卡牌左上角 X
 * @param {number} y - 卡牌左上角 Y
 * @param {number} w - 卡牌宽度
 * @param {number} h - 卡牌高度
 * @param {string} element - 五行元素
 */
export function drawCardTemplate(ctx, x, y, w, h, element) {
  if (!isCardTemplateReady()) return;

  // 模板图片已预先裁剪掉白边，直接绘制
  const overflow = 0;
  const cornerR = Math.round(w * 0.1);

  ctx.save();
  // 圆角裁剪，去掉JPG圆角外的黑边
  ctx.beginPath();
  ctx.moveTo(x + cornerR, y);
  ctx.lineTo(x + w - cornerR, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + cornerR);
  ctx.lineTo(x + w, y + h - cornerR);
  ctx.quadraticCurveTo(x + w, y + h, x + w - cornerR, y + h);
  ctx.lineTo(x + cornerR, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - cornerR);
  ctx.lineTo(x, y + cornerR);
  ctx.quadraticCurveTo(x, y, x + cornerR, y);
  ctx.closePath();
  ctx.clip();

  // 放大绘制模板，金边对齐卡牌边缘，白边溢出被裁掉
  ctx.drawImage(templateImg, x - overflow, y - overflow, w + overflow * 2, h + overflow * 2);

  // 元素染色：只染内容区（避开金边），multiply 模式低透明度
  const color = getElementColor(element);
  const pad = Math.max(6, Math.round(w * 0.08));
  ctx.globalCompositeOperation = 'multiply';
  ctx.globalAlpha = 0.18;
  ctx.fillStyle = color;
  ctx.fillRect(x + pad, y + pad, w - pad * 2, h - pad * 2);
  ctx.restore();
}
