import { soundManager } from '../runtime/music.js';

const TAP_MIN_DIST = 8;
const TAP_MAX_TIME = 500;
const LONG_PRESS_TIME = 400;
// 拖拽判定阈值：移动超过此距离才认为是拖拽（避免轻微移动导致点击失效）
const DRAG_THRESHOLD = 12;

export default class InputHandler {
  constructor() {
    this.touchStartX = 0;
    this.touchStartY = 0;
    this.touchStartTime = 0;
    this.touchCurrentX = 0;
    this.touchCurrentY = 0;
    this.isDragging = false;
    this.heldButtons = [];
    this.tapHandlers = [];
    this.longPressCallback = null;
    // 自定义触摸回调（供 BattleInput 等模块注册，避免直接覆盖 wx 事件）
    this.touchStartListeners = [];
    this.touchMoveListeners = [];
    this.touchEndListeners = [];
    this.registerListeners();
  }

  registerListeners() {
    wx.onTouchStart((e) => {
      if (e.touches.length > 0) {
        this.touchStartX = e.touches[0].clientX;
        this.touchStartY = e.touches[0].clientY;
        this.touchStartTime = Date.now();
        this.touchCurrentX = this.touchStartX;
        this.touchCurrentY = this.touchStartY;
        this.isDragging = false;

        if (this.longPressTimer) clearTimeout(this.longPressTimer);
        this.longPressTimer = setTimeout(() => {
          if (this.longPressCallback) {
            this.longPressCallback(this.touchStartX, this.touchStartY);
          }
          this.longPressTimer = null;
        }, LONG_PRESS_TIME);

        // 调用自定义触摸开始回调
        this.touchStartListeners.forEach(fn => {
          try { fn(e); } catch (err) { console.error('[InputHandler] touchStart listener error:', err); }
        });
      }
    });

    wx.onTouchMove((e) => {
      if (e.touches.length > 0) {
        this.touchCurrentX = e.touches[0].clientX;
        this.touchCurrentY = e.touches[0].clientY;
        const dist = Math.sqrt(
          Math.pow(this.touchCurrentX - this.touchStartX, 2) +
          Math.pow(this.touchCurrentY - this.touchStartY, 2)
        );
        if (dist > DRAG_THRESHOLD) {
          this.isDragging = true;
          if (this.longPressTimer) {
            clearTimeout(this.longPressTimer);
            this.longPressTimer = null;
          }
        }

        // 调用自定义触摸移动回调
        this.touchMoveListeners.forEach(fn => {
          try { fn(e); } catch (err) { console.error('[InputHandler] touchMove listener error:', err); }
        });
      }
    });

    wx.onTouchEnd((e) => {
      if (this.longPressTimer) {
        clearTimeout(this.longPressTimer);
        this.longPressTimer = null;
      }

      // 调用自定义触摸结束回调
      this.touchEndListeners.forEach(fn => {
        try { fn(e); } catch (err) { console.error('[InputHandler] touchEnd listener error:', err); }
      });

      if (this.isDragging) return;
      const timeElapsed = Date.now() - this.touchStartTime;
      const distMoved = Math.sqrt(
        Math.pow(this.touchCurrentX - this.touchStartX, 2) +
        Math.pow(this.touchCurrentY - this.touchStartY, 2)
      );
      if (distMoved < TAP_MIN_DIST && timeElapsed < TAP_MAX_TIME) {
        this.handleTap(this.touchStartX, this.touchStartY);
      }
    });

    wx.onTouchCancel(() => {
      this.touchStartX = 0;
      this.touchStartY = 0;
      this.touchCurrentX = 0;
      this.touchCurrentY = 0;
      this.isDragging = false;
      if (this.longPressTimer) {
        clearTimeout(this.longPressTimer);
        this.longPressTimer = null;
      }
    });
  }

  handleTap(x, y) {
    let buttonClicked = false;

    // 优先判定普通按键点击
    if (this.heldButtons.length > 0) {
      for (const btn of this.heldButtons) {
        if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) {
          soundManager.playSfx('btn_click');
          buttonClicked = true;
          if (btn.tap) {
            btn.tap();
          }
          break;
        }
      }
    }

    // 若未点中独立按键，则分发通用场景点击（如地图节点、关闭弹窗等）
    if (!buttonClicked) {
      for (const handler of this.tapHandlers) {
        handler(x, y);
      }
    }
  }

  addTouchButton(btn) {
    this.heldButtons.push(btn);
  }

  removeTouchButton(btn) {
    const index = this.heldButtons.indexOf(btn);
    if (index !== -1) this.heldButtons.splice(index, 1);
  }

  clearButtons() {
    this.heldButtons = [];
    this.tapHandlers = [];
  }

  addTapHandler(cb) {
    this.tapHandlers.push(cb);
  }

  /**
   * 注册自定义触摸开始回调（供 BattleInput 等模块使用，避免直接覆盖 wx 事件）
   */
  addTouchStartListener(fn) {
    if (typeof fn === 'function') this.touchStartListeners.push(fn);
  }

  /**
   * 注册自定义触摸移动回调
   */
  addTouchMoveListener(fn) {
    if (typeof fn === 'function') this.touchMoveListeners.push(fn);
  }

  /**
   * 注册自定义触摸结束回调
   */
  addTouchEndListener(fn) {
    if (typeof fn === 'function') this.touchEndListeners.push(fn);
  }

  setLongPressHandler(cb) {
    this.longPressCallback = cb;
  }
}