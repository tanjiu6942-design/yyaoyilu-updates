/**
 * EffectEngine — 真正的数据驱动效果处理器
 *
 * 卡牌不再依赖 effectType 单值 + if/else 分支，而是通过 effects 数组声明效果：
 * { type: "damage", value: 8 }, { type: "draw", value: 2 }, ...
 *
 * 新增卡牌只需在数据中声明 effects，无需修改战斗逻辑。
 */

import { calculateElementDamage } from './data.js';

// 鬼差类敌人：黑白无常、牛头阿傍（鸣冤浩气对其伤害+2）
const GUICHAI_KEYS = new Set(['hei_bai_wu_chang', 'niu_tou_a_bang']);

// ==================== 通用工具函数 ====================

export function hasRelic(player, relicId) {
  return (player.relics || []).some(r => r.id === relicId || r.name === relicId);
}

/**
 * 统一判断卡牌是否为诅咒卡
 * 替代各处散落的 effectType === 'curse' || type === '诅咒' || name === '索魂咒' 判断
 */
export function isCurseCard(card) {
  return !!(card && (
    card.isCurse === true ||
    card.effectType === 'curse' ||
    card.type === '诅咒' ||
    card.name === '索魂咒'
  ));
}

export function applyCharacterCostPassive(player) {
  if (player.characterId === 'taoist') {
    player.cards.forEach(c => {
      if ((c.type === '符咒' || c.type === '法术') && !c._taoistDiscounted) {
        c.cost = Math.max(0, c.cost - 1);
        c._taoistDiscounted = true;
      }
    });
  }
}

function drawCards(player, count) {
  let drawn = 0;
  for (let i = 0; i < count; i++) {
    if (player.cards.length >= 7) break;
    if (player.deck.length === 0) {
      if (player.discard.length === 0) break;
      player.deck = player.discard;
      player.discard = [];
      for (let j = player.deck.length - 1; j > 0; j--) {
        const k = Math.floor(Math.random() * (j + 1));
        [player.deck[j], player.deck[k]] = [player.deck[k], player.deck[j]];
      }
    }
    const card = player.deck.shift();
    if (card) {
      player.cards.push(card);
      drawn++;
    }
  }
  return drawn;
}

// ==================== 效果处理器 ====================
// 每个处理器接收 (battle, card, effect)，返回日志片段字符串

export const EffectEngine = {

  /** 造成伤害（含五行相克、遗物加成、护盾抵消、流派加成） */
  damage(battle, card, effect) {
    const { player, enemy } = battle;
    if (enemy.invulnerableTurns > 0) {
      return `【${enemy.name}】身处冥界法阵之中，免疫了本次所有伤害！`;
    }

    let baseDmg = effect.value || 0;
    let buildLog = '';

    if (player.characterId === 'zhong_kui') baseDmg += 2;
    if (hasRelic(player, 'relic_jiangyao')) baseDmg += 2;
    if (card.element === '火' && hasRelic(player, 'relic_lihuoyu')) baseDmg += 3;

    // ★ 第三章遗物：怨力强化(攻击伤害+3)、封神榜残页(攻击伤害+1)
    if (hasRelic(player, 'relic_yuanli_qianghua')) baseDmg += 3;
    if (hasRelic(player, 'relic_fengshen_canye')) baseDmg += 1;

    // ★ 白素贞：千年修为 - 每点当前灵气使卡牌伤害 +5%
    if (player.characterId === 'bai_suzhen' && player.energy > 0) {
      const bonusPct = player.energy * 0.05;
      const bonus = Math.round(baseDmg * bonusPct);
      baseDmg += bonus;
      buildLog += ` [灵蛇+${bonus}]`;
    }

    // ★ 第三章遗物：玄冥之眼，所有伤害 +15%
    if (hasRelic(player, 'relic_xuanming_zhiyan')) {
      baseDmg = Math.round(baseDmg * 1.15);
    }

    // ★ 事件永久 buff：攻击加成（attackBonus）、鸣冤浩气（对鬼差+2）
    if (player.attackBonus) baseDmg += player.attackBonus;
    if (player.mingyuanHaoqi && GUICHAI_KEYS.has(enemy.key)) baseDmg += 2;

    // ★ 因果系统：玩家伤害倍率（正因果+10%，负因果+15%）
    if (player.damageMultiplier && player.damageMultiplier > 1) {
      baseDmg = Math.round(baseDmg * player.damageMultiplier);
    }

    if (player.nextDamageBonus > 0) {
      baseDmg += player.nextDamageBonus;
      player.nextDamageBonus = 0;
    }

    if (battle.fireDoubleDamage) {
      baseDmg *= 2;
    }

    // ★ 流派系统：烈煞流火牌伤害加成

    // ★ 遗物：朱雀羽 - 火印引爆后火属性伤害额外 +30%
    if (card.element === '火' && battle.markManager && battle.markManager.fireDamageBonus > 0) {
      const bonus = Math.round(baseDmg * battle.markManager.fireDamageBonus);
      baseDmg += bonus;
      buildLog += ` [朱雀羽+${bonus}]`;
    }

    if (battle.buildSystem) {
      const fireResult = battle.buildSystem.applyFireDamageBonus(card, baseDmg);
      baseDmg = fireResult.damage;
      buildLog += fireResult.log;

      // 烈煞终结技：附加灼烧
      if (fireResult.applyBurn) {
        enemy.burnTurns = Math.max(enemy.burnTurns || 0, 2);
        enemy.burnDamage = enemy.burnDamage || 4;
      }

      // ★ 流派系统：磐石流阈值增伤
      const stoneResult = battle.buildSystem.applyStoneThresholdBonus(player, baseDmg);
      baseDmg = stoneResult.damage;
      buildLog += stoneResult.log;

      // ★ 流派系统：锋锐流（金）破甲+暴击
      const bladeResult = battle.buildSystem.applyBladeDamageBonus(card, baseDmg, enemy.shield || 0);
      baseDmg = bladeResult.damage;
      buildLog += bladeResult.log;
      // 锋锐破甲：临时降低敌人护盾（在后续护盾计算中生效）
      if (bladeResult.armorPierced > 0) {
        enemy.shield = Math.max(0, (enemy.shield || 0) - bladeResult.armorPierced);
      }
    }

    // ★ 遗物：磐石核心 - 护盾>20时伤害 +20%
    if (hasRelic(player, 'relic_panshi_hexin') && player.shield > 20) {
      const bonus = Math.round(baseDmg * 0.2);
      baseDmg += bonus;
      buildLog += ` [磐石核心+${bonus}]`;
    }

    const { finalDamage, relation } = calculateElementDamage(baseDmg, card.element, enemy.element);

    let actualDmg = finalDamage;
    if (enemy.shield > 0) {
      if (enemy.shield >= actualDmg) {
        enemy.shield -= actualDmg;
        actualDmg = 0;
      } else {
        actualDmg -= enemy.shield;
        enemy.shield = 0;
      }
    }
    enemy.hp = Math.max(0, enemy.hp - actualDmg);

    let log = `造成 ${finalDamage} 点伤害（${relation}）`;
    if (actualDmg > 0) log += ` [破体 -${actualDmg}]`;
    log += buildLog;
    return log;
  },

  /** 获得护盾 */
  shield(battle, card, effect) {
    const { player } = battle;
    const shieldGain = effect.value || 0;
    player.shield += shieldGain;
    return ` 获得护盾 ${shieldGain}`;
  },

  /** 恢复生命 */
  heal(battle, card, effect) {
    const { player } = battle;
    let healVal = effect.value || 4;
    if (hasRelic(player, 'relic_qingmu')) healVal += 2;

    // ★ 流派系统：青藤流治疗加成
    let buildLog = '';
    if (battle.buildSystem) {
      const vineResult = battle.buildSystem.applyVineHealBonus(healVal);
      healVal = vineResult.heal;
      buildLog = vineResult.log;
    }

    player.hp = Math.min(player.maxHp, player.hp + healVal);
    return ` 恢复气血 ${healVal}${buildLog}`;
  },

  /** 抽牌 */
  draw(battle, card, effect) {
    const { player } = battle;
    const drawNum = effect.value || 1;
    drawCards(player, drawNum);
    applyCharacterCostPassive(player);
    return ` 抽取 ${drawNum} 张牌`;
  },

  /** 施加灼烧 */
  burn(battle, card, effect) {
    const { enemy } = battle;
    enemy.burnTurns = effect.turns || 2;
    enemy.burnDamage = effect.damage || 4;
    return ` 施加灼烧状态`;
  },

  /** 定身敌人（跳过下回合） */
  skip(battle, card, effect) {
    if (battle.enemy.immuneToDebuff) {
      return ` 【${battle.enemy.name}】免疫定身！`;
    }
    battle.enemy.skipTurn = true;
    return ` 【定身】妖邪下回合无法动弹！`;
  },

  /** 恢复灵气 */
  gainEnergy(battle, card, effect) {
    const { player } = battle;
    const amount = effect.value || 2;
    player.energy += amount;
    return ` 恢复${amount}点灵气`;
  },

  /** 自身受到反噬伤害 */
  selfDamage(battle, card, effect) {
    const { player } = battle;
    const dmg = effect.value || 0;
    player.hp = Math.max(1, player.hp - dmg);
    return ` (自身受反噬 -${dmg}血)`;
  },

  /** 净化负面状态与诅咒 */
  clearDebuff(battle, card, effect) {
    const { player } = battle;
    player.immune = true;
    player.energyDebuff = 0;
    const beforeCount = player.cards.length;
    player.cards = player.cards.filter(c => !isCurseCard(c));
    const clearedCurses = beforeCount - player.cards.length;
    return ` 祛除妖障${clearedCurses > 0 ? ` (净化了${clearedCurses}张索魂咒)` : ''}`;
  },

  /** 蓄力：强化下次攻击 */
  nextAttackBonus(battle, card, effect) {
    const { player } = battle;
    const bonus = effect.value || 2;
    player.nextDamageBonus = (player.nextDamageBonus || 0) + bonus;
    return ` 蓄力强化下次攻击 +${bonus}`;
  },

};

/**
 * 执行卡牌的所有效果，返回拼接后的日志
 */
export function executeCardEffects(battle, card) {
  if (!card.effects || !Array.isArray(card.effects) || card.effects.length === 0) {
    return '';
  }

  let log = '';
  for (const effect of card.effects) {
    const handler = EffectEngine[effect.type];
    if (handler) {
      log += handler(battle, card, effect);
    } else {
      console.warn(`[EffectEngine] 未知效果类型: ${effect.type}`);
    }
    // 检查敌人是否在效果执行中死亡
    if (battle.enemy && battle.enemy.hp <= 0) break;
  }
  return log;
}
