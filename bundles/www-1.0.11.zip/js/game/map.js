import { CHAPTER_1_EVENTS, CHAPTER_2_EVENTS, CHAPTER_3_EVENTS } from './data.js';
import { NODE_TYPES } from './types.js';
import { getKarmaModifier } from '../config/KarmaModifiers.js';

// re-export 供场景使用（唯一真源在 types.js）
export { NODE_TYPES };

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * 根据因果偏向获取随机敌人索引
 * @param {number} chapter 章节
 * @param {boolean} isElite 是否精英
 * @param {string} bias 敌人池偏向 'peaceful'|'normal'|'ferocious'
 */
function getRandomEnemyIndex(chapter, isElite = false, bias = 'normal') {
  if (chapter === 1) {
    if (isElite) return 4;
    // 第一章普通敌人：0=游荡山魈(低攻), 1=掘地僵尸(低攻), 2=狐狸精(高攻), 3=魅影画皮(高攻)
    if (bias === 'peaceful') {
      // 正因果：70%概率选低攻击敌人(0,1)
      return Math.random() < 0.7 ? getRandomInt(0, 1) : getRandomInt(2, 3);
    } else if (bias === 'ferocious') {
      // 负因果：70%概率选高攻击敌人(2,3)
      return Math.random() < 0.7 ? getRandomInt(2, 3) : getRandomInt(0, 1);
    }
    return getRandomInt(0, 3);
  } else if (chapter === 2) {
    if (isElite) return 9;
    // 第二章普通敌人：6=孤魂野鬼, 7=幽冥鬼火, 8=纸扎尸仆
    if (bias === 'peaceful') {
      return Math.random() < 0.7 ? 6 : getRandomInt(7, 8);
    } else if (bias === 'ferocious') {
      return Math.random() < 0.7 ? getRandomInt(7, 8) : 6;
    }
    return getRandomInt(6, 8);
  } else {
    // 第三章普通敌人：11=归墟怨魂, 12=噬灵残壳, 13=混沌游魂, 14=归墟石傀
    if (isElite) return 15;
    if (bias === 'peaceful') {
      return Math.random() < 0.6 ? getRandomInt(11, 12) : getRandomInt(13, 14);
    } else if (bias === 'ferocious') {
      return Math.random() < 0.6 ? getRandomInt(12, 13) : getRandomInt(11, 14);
    }
    return getRandomInt(11, 14);
  }
}

function getRandomEvent(chapter) {
  if (chapter === 1) return CHAPTER_1_EVENTS[Math.floor(Math.random() * CHAPTER_1_EVENTS.length)];
  if (chapter === 2) return CHAPTER_2_EVENTS[Math.floor(Math.random() * CHAPTER_2_EVENTS.length)];
  return CHAPTER_3_EVENTS[Math.floor(Math.random() * CHAPTER_3_EVENTS.length)];
}

export function generateChapterMap(chapter = 1, totalRows = 8, karma = 0) {
  const map = [];
  const karmaMod = getKarmaModifier(karma);
  const eliteRateMod = karmaMod.eliteRateModifier || 0;
  const enemyBias = karmaMod.enemyPoolBias || 'normal';

  // 辅助：根据因果精英率修饰，判断一个普通战斗是否升级为精英
  function shouldUpgradeToElite(baseChance = 0) {
    const chance = Math.max(0, Math.min(0.5, baseChance + eliteRateMod));
    return Math.random() < chance;
  }

  // 辅助：根据因果精英率修饰，判断一个固定精英是否降级为普通
  function shouldDowngradeElite() {
    if (eliteRateMod >= 0) return false;
    return Math.random() < Math.abs(eliteRateMod);
  }

  // 事件队列：洗牌后依次分配，避免同章节事件重复
  const eventPool = chapter === 3 ? CHAPTER_3_EVENTS : (chapter === 2 ? CHAPTER_2_EVENTS : CHAPTER_1_EVENTS);
  let eventQueue = shuffleArray(eventPool);
  function getNextEvent() {
    if (eventQueue.length === 0) eventQueue = shuffleArray(eventPool);
    return eventQueue.shift();
  }

  for (let row = 0; row < totalRows; row++) {
    const rowNodes = [];

    // 第 0 层：起点战斗
    if (row === 0) {
      const startCount = 2;
      for (let col = 0; col < startCount; col++) {
        rowNodes.push({
          id: `node_${row}_${col}`,
          row,
          col,
          type: NODE_TYPES.BATTLE,
          name: '小妖拦截',
          enemyIndex: getRandomEnemyIndex(chapter, false, enemyBias),
          status: 'available',
          next: []
        });
      }
    }
    // 最后一层：首领战
    else if (row === totalRows - 1) {
      let bossEnemyIndex, bossName;
      if (chapter === 1) { bossEnemyIndex = 5; bossName = '黑山山魈王 (首领)'; }
      else if (chapter === 2) { bossEnemyIndex = 10; bossName = '阴阳判官 (终局魁首)'; }
      else { bossEnemyIndex = 16; bossName = '九尾狐·归墟之门 (终局魁首)'; }
      rowNodes.push({
        id: `node_${row}_0`,
        row,
        col: 0,
        type: NODE_TYPES.BOSS,
        name: bossName,
        enemyIndex: bossEnemyIndex,
        status: 'locked',
        next: []
      });
    }
    // 中间推进层
    else {
      const colsCount = (row === totalRows - 2) ? 2 : (Math.random() > 0.4 ? 3 : 2);

      for (let col = 0; col < colsCount; col++) {
        let nodeType = NODE_TYPES.BATTLE;
        let nodeName = '妖雾阻路';
        let enemyIndex = undefined;
        let eventData = null;

        if (chapter === 3) {
          // 第三章专属布局：归墟深渊
          if (row === 1) {
            // 第1行：事件(万魂哭墙) + 普通战斗
            nodeType = (col === 0) ? NODE_TYPES.EVENT : NODE_TYPES.BATTLE;
          } else if (row === 2) {
            // 第2行：商店 + 事件(前世回廊)
            nodeType = (col === 0) ? NODE_TYPES.SHOP : NODE_TYPES.EVENT;
          } else if (row === 3) {
            // 第3行：精英(九尾善念) + 普通战斗
            const isElite = col === 0 ? !shouldDowngradeElite() : shouldUpgradeToElite(0.3);
            nodeType = isElite ? NODE_TYPES.ELITE : NODE_TYPES.BATTLE;
          } else if (row === 4) {
            // 第4行：事件(青丘遗老) + 休息
            nodeType = (col === 0) ? NODE_TYPES.EVENT : NODE_TYPES.REST;
          } else if (row === 5) {
            // 第5行：普通战斗 + 事件(封神台)
            nodeType = (col === 0) ? NODE_TYPES.BATTLE : NODE_TYPES.EVENT;
          } else if (row === totalRows - 2) {
            // 倒数第2行：休息 + 事件(轮回盘)
            nodeType = (col === 0) ? NODE_TYPES.REST : NODE_TYPES.EVENT;
          } else {
            const roll = Math.random();
            if (roll < 0.55) nodeType = NODE_TYPES.BATTLE;
            else if (roll < 0.8) nodeType = NODE_TYPES.EVENT;
            else nodeType = NODE_TYPES.REST;
          }
        } else if (chapter === 2) {
          if (row === 3 || row === 5) {
            const baseEliteChance = (col === 0) ? 1.0 : 0.6;
            const isElite = col === 0 ? !shouldDowngradeElite() : shouldUpgradeToElite(0.6);
            nodeType = isElite ? NODE_TYPES.ELITE : NODE_TYPES.BATTLE;
          } else if (row === totalRows - 2) {
            nodeType = (col === 0) ? NODE_TYPES.REST : NODE_TYPES.BATTLE;
          } else if (row === 2) {
            nodeType = (col === 0) ? NODE_TYPES.SHOP : NODE_TYPES.EVENT;
          } else {
            const roll = Math.random();
            if (roll < 0.6) nodeType = NODE_TYPES.BATTLE;
            else if (roll < 0.85) nodeType = NODE_TYPES.EVENT;
            else nodeType = NODE_TYPES.BATTLE;
          }
        } else {
          if (row === 4) {
            // 固定精英层：正因果有概率降级，负因果保持
            const isElite = col === 0 ? !shouldDowngradeElite() : false;
            nodeType = isElite ? NODE_TYPES.ELITE : NODE_TYPES.BATTLE;
            // 负因果时，非精英位也有概率升级为精英
            if (col > 0 && shouldUpgradeToElite(0.2)) {
              nodeType = NODE_TYPES.ELITE;
            }
          } else if (row === totalRows - 2) {
            nodeType = (col === 0) ? NODE_TYPES.REST : NODE_TYPES.SHOP;
          } else if (row === 2) {
            nodeType = (col === 0) ? NODE_TYPES.SHOP : NODE_TYPES.EVENT;
          } else {
            const roll = Math.random();
            if (roll < 0.45) nodeType = NODE_TYPES.BATTLE;
            else if (roll < 0.75) nodeType = NODE_TYPES.EVENT;
            else if (roll < 0.9) nodeType = NODE_TYPES.REST;
            else nodeType = NODE_TYPES.BATTLE;
            // 普通战斗节点根据因果有概率升级为精英
            if (nodeType === NODE_TYPES.BATTLE && shouldUpgradeToElite(0.05)) {
              nodeType = NODE_TYPES.ELITE;
            }
          }
        }

        if (nodeType === NODE_TYPES.BATTLE) {
          enemyIndex = getRandomEnemyIndex(chapter, false, enemyBias);
          if (chapter === 3) nodeName = '归墟怨魂';
          else if (chapter === 2) nodeName = '阴魂阻路';
          else nodeName = '山间小妖';
        } else if (nodeType === NODE_TYPES.ELITE) {
          enemyIndex = getRandomEnemyIndex(chapter, true, enemyBias);
          if (chapter === 3) nodeName = '九尾善念 (精英)';
          else if (chapter === 2) nodeName = '鬼门凶煞 (精英)';
          else nodeName = '阴司使者 (精英)';
        } else if (nodeType === NODE_TYPES.EVENT) {
          eventData = getNextEvent();
          if (chapter === 3) nodeName = '归墟异事';
          else if (chapter === 2) nodeName = '幽冥异事';
          else nodeName = '机缘奇遇';
        } else if (nodeType === NODE_TYPES.SHOP) {
          if (chapter === 3) nodeName = '归墟旧货摊';
          else if (chapter === 2) nodeName = '枉死鬼市';
          else nodeName = '山路货郎';
        } else if (nodeType === NODE_TYPES.REST) {
          if (chapter === 3) nodeName = '混沌裂隙';
          else if (chapter === 2) nodeName = '还魂残龛';
          else nodeName = '静室调息';
        }

        rowNodes.push({
          id: `node_${row}_${col}`,
          row,
          col,
          type: nodeType,
          name: nodeName,
          enemyIndex,
          eventData,
          status: 'locked',
          next: []
        });
      }
    }

    map.push(rowNodes);
  }

  // 构建层与层之间的前向连线
  for (let r = 0; r < map.length - 1; r++) {
    const currentNodes = map[r];
    const nextNodes = map[r + 1];

    if (nextNodes.length === 1) {
      currentNodes.forEach(node => {
        node.next.push(nextNodes[0].id);
      });
    } else if (currentNodes.length === 1) {
      nextNodes.forEach(nextNode => {
        currentNodes[0].next.push(nextNode.id);
      });
    } else {
      currentNodes.forEach((node, idx) => {
        if (nextNodes[idx]) {
          node.next.push(nextNodes[idx].id);
        }
        if (idx === 0 && nextNodes[1]) {
          node.next.push(nextNodes[1].id);
        } else if (idx === currentNodes.length - 1 && nextNodes[nextNodes.length - 1]) {
          if (!node.next.includes(nextNodes[nextNodes.length - 1].id)) {
            node.next.push(nextNodes[nextNodes.length - 1].id);
          }
        } else {
          if (nextNodes[idx - 1] && !node.next.includes(nextNodes[idx - 1].id)) {
            node.next.push(nextNodes[idx - 1].id);
          }
          if (nextNodes[idx + 1] && !node.next.includes(nextNodes[idx + 1].id)) {
            node.next.push(nextNodes[idx + 1].id);
          }
        }
      });
    }
  }

  return map;
}

export function stepToNode(map, targetNodeId) {
  if (!map || !targetNodeId) return map;

  let targetNode = null;
  const newMap = JSON.parse(JSON.stringify(map));

  for (const row of newMap) {
    for (const node of row) {
      if (node.id === targetNodeId) {
        node.status = 'visited';
        targetNode = node;
      }
    }
  }

  if (!targetNode) return newMap;

  for (const row of newMap) {
    for (const node of row) {
      if (node.row === targetNode.row && node.id !== targetNode.id) {
        node.status = 'locked';
      }
      if (node.row < targetNode.row && node.status !== 'visited') {
        node.status = 'locked';
      }
    }
  }

  if (targetNode.next && targetNode.next.length > 0) {
    for (const row of newMap) {
      for (const node of row) {
        if (targetNode.next.includes(node.id)) {
          node.status = 'available';
        }
      }
    }
  }

  return newMap;
}

/**
 * 根据 nodeId 在地图中查找节点
 * @param {Array} map - 二维地图数组
 * @param {string} nodeId - 节点ID
 * @returns {Object|null} 节点对象或 null
 */
export function findNodeById(map, nodeId) {
  if (!map || !nodeId) return null;
  for (const row of map) {
    for (const node of row) {
      if (node.id === nodeId) return node;
    }
  }
  return null;
}