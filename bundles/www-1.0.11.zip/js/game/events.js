export const EVENT_POOL = [
  {
    id: 'lost_child',
    title: '迷途幼童',
    typeTag: '机缘',
    story: '荒山古道旁，一个幼童独坐枯木上哭泣。近前细看，眉眼间隐有妖气。',
    options: [
      {
        text: '出资引路',
        desc: '花费 20 铜钱，送其回村。因果 +2',
        disabled: run => run.gold < 20,
        apply: run => {
          run.gold -= 20;
          run.karma = Math.min(10, run.karma + 2);
          return '幼童破涕为笑，化作一缕青烟归家。因果 +2。';
        }
      },
      {
        text: '画符度化',
        desc: '消耗 5 气血，洗去妖气。因果 +1',
        apply: run => {
          run.hp = Math.max(1, run.hp - 5);
          run.karma = Math.min(10, run.karma + 1);
          return '符水入喉，妖气散尽。你损失 5 气血，因果 +1。';
        }
      },
      {
        text: '横剑逼问',
        desc: '夺取随身财物。获得 35 铜钱，因果 -2',
        apply: run => {
          run.gold += 35;
          run.karma = Math.max(-10, run.karma - 2);
          return '幼童惊惧显出狐形遁走，遗落一包铜钱。因果 -2。';
        }
      }
    ]
  },
  {
    id: 'ancient_stele',
    title: '残破古碑',
    typeTag: '古迹',
    story: '乱石堆中立着一尊古碑，碑文记着道门调息法，也夹杂着邪修秘咒。',
    options: [
      {
        text: '参悟正法',
        desc: '恢复 30% 最大气血。因果 +1',
        apply: run => {
          const heal = Math.floor(run.maxHp * 0.3);
          run.hp = Math.min(run.maxHp, run.hp + heal);
          run.karma = Math.min(10, run.karma + 1);
          return '灵气灌体，气血恢复 ' + heal + ' 点，因果 +1。';
        }
      },
      {
        text: '研习邪咒',
        desc: '损失 8 气血，获得 60 铜钱。因果 -2',
        apply: run => {
          run.hp = Math.max(1, run.hp - 8);
          run.gold += 60;
          run.karma = Math.max(-10, run.karma - 2);
          return '邪气反噬扣除 8 点气血，但炼出 60 铜钱，因果 -2。';
        }
      }
    ]
  },
  {
    id: 'ghost_toll',
    title: '冥差借道',
    typeTag: '幽冥',
    story: '浓雾中阴风惨淡，一位手持锁链的冥差拦在去路上，要你留下买路财。',
    options: [
      {
        text: '焚钱买路',
        desc: '花费 30 铜钱。因果 +1',
        disabled: run => run.gold < 30,
        apply: run => {
          run.gold -= 30;
          run.karma = Math.min(10, run.karma + 1);
          return '冥差收下铜钱，隐入雾中放行。因果 +1。';
        }
      },
      {
        text: '祭符亮剑',
        desc: '损失 10 气血强行闯关。因果 -1',
        apply: run => {
          run.hp = Math.max(1, run.hp - 10);
          run.karma = Math.max(-10, run.karma - 1);
          return '一番恶斗震退冥差，你损失 10 气血，因果 -1。';
        }
      }
    ]
  }
];

export function getRandomStoryEvent() {
  return EVENT_POOL[Math.floor(Math.random() * EVENT_POOL.length)];
}
