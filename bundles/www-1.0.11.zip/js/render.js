GameGlobal.canvas = wx.createCanvas();

const windowInfo = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();

// 高分屏缩放：canvas 内部像素 = 逻辑像素 × 像素比，绘制时所有坐标/字体自动放大
const pixelRatio = windowInfo.pixelRatio || 1;
canvas.width = Math.round(windowInfo.screenWidth * pixelRatio);
canvas.height = Math.round(windowInfo.screenHeight * pixelRatio);

export const SCREEN_WIDTH = windowInfo.screenWidth;
export const SCREEN_HEIGHT = windowInfo.screenHeight;
export const PIXEL_RATIO = pixelRatio;

// 异形屏与微信右上角胶囊按钮安全区动态计算
const menuInfo = (typeof wx !== 'undefined' && wx.getMenuButtonBoundingClientRect)
  ? wx.getMenuButtonBoundingClientRect()
  : null;

// 安全取值：menuInfo 可能是空对象 {}（开发者工具常见），需逐个属性校验有限性
const _safeTop = windowInfo.safeArea && isFinite(windowInfo.safeArea.top) ? windowInfo.safeArea.top : 24;
const _mTop = menuInfo && isFinite(menuInfo.top) ? menuInfo.top : _safeTop;
const _mHeight = menuInfo && isFinite(menuInfo.height) ? menuInfo.height : 32;
const _mBottom = menuInfo && isFinite(menuInfo.bottom) ? menuInfo.bottom : (_mTop + _mHeight);
const _mLeft = menuInfo && isFinite(menuInfo.left) ? menuInfo.left : (SCREEN_WIDTH - 96);

// 顶部栏按钮 Y 坐标（与胶囊垂直对齐）
export const TOP_BAR_Y = _mTop;

// 顶部栏按钮标准高度（与胶囊等高）
export const TOP_BAR_H = _mHeight;

// 顶部内容安全下沿（所有核心内容需绘制在该高度下方，避免遮挡）
export const SAFE_TOP = _mBottom + 10;

// 胶囊左边缘 X 坐标（右上角按钮避免超出此位置）
export const CAPSULE_LEFT = _mLeft;