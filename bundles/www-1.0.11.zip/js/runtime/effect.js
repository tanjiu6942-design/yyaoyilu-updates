﻿import { globalPool } from '../base/pool.js';
import { drawRoundedRect, UI_COLORS } from '../game/scene.js';

// 注册通用特效粒子池
globalPool.register(
  'fx_particle',
  () => ({ x: 0, y: 0, vx: 0, vy: 0, size: 4, color: '#FFF', alpha: 1, life: 30, maxLife: 30, shape: 'circle', rot: 0, vRot: 0 }),
  (p, x, y, vx, vy, size, color, life = 30, shape = 'circle', vRot = 0) => {
    p.x = x;
    p.y = y;
    p.vx = vx;
    p.vy = vy;
    p.size = size;
    p.color = color;
    p.alpha = 1.0;
    p.life = life;
    p.maxLife = life;
    p.shape = shape;
    p.rot = Math.random() * Math.PI * 2;
    p.vRot = vRot;
  }
);

export default class EffectEngine {
  constructor() {
    this.particles = [];
    this.shakeDuration = 0;
    this.shakeIntensity = 0;
    this.shakeOffsetX = 0;
    this.shakeOffsetY = 0;

    // 全屏滤镜瞬态（印记引爆画面变色闪光）
    this.flashColor = null;
    this.flashAlpha = 0;

    // 冲击光环
    this.rings = [];
  }

  triggerShake(duration = 10, intensity = 5) {
    this.shakeDuration = duration;
    this.shakeIntensity = intensity;
  }

  triggerFlash(color, alpha = 0.35) {
    this.flashColor = color;
    this.flashAlpha = alpha;
  }

  triggerRing(x, y, color, maxRadius = 80, lineWidth = 4) {
    this.rings.push({ x, y, color, radius: 10, maxRadius, lineWidth, alpha: 1.0 });
  }

  // ==================== 五行印记引爆专属特效 ====================

  /**
   * 金印引爆：千芒剑煞（金光瞬闪 + 放射金针破甲粒子）
   */
  triggerGoldSlash(x, y) {
    this.triggerShake(14, 8);
    this.triggerFlash('rgba(255, 215, 0, 0.4)', 0.4);
    this.triggerRing(x, y, '#FFD700', 100, 5);

    for (let i = 0; i < 36; i++) {
      const angle = (Math.PI * 2 * i) / 36 + (Math.random() - 0.5) * 0.2;
      const speed = Math.random() * 7 + 4;
      const vx = Math.cos(angle) * speed;
      const vy = Math.sin(angle) * speed;
      const size = Math.random() * 8 + 6;
      const p = globalPool.get('fx_particle', x, y, vx, vy, size, '#FFDF70', 25, 'spark', (Math.random() - 0.5) * 0.4);
      if (p) this.particles.push(p);
    }
  }

  /**
   * 木印引爆：乙木回春（翠绿莲瓣旋升 + 润脉光晕）
   */
  triggerWoodHeal(x, y) {
    this.triggerFlash('rgba(106, 175, 92, 0.3)', 0.3);
    this.triggerRing(x, y, '#6AAF5C', 70, 4);

    for (let i = 0; i < 28; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 3 + 1.5;
      const vx = Math.cos(angle) * speed;
      const vy = -Math.abs(Math.sin(angle) * speed) - 1.5; // 向上飘升
      const size = Math.random() * 5 + 3;
      const color = Math.random() > 0.4 ? '#6AAF5C' : '#A3E4D7';
      const p = globalPool.get('fx_particle', x + (Math.random() * 40 - 20), y + (Math.random() * 20 - 10), vx, vy, size, color, 35, 'leaf', 0.08);
      if (p) this.particles.push(p);
    }
  }

  /**
   * 水印引爆：寒霜九幽（玄冰碎裂 + 冻结冰华扩散）
   */
  triggerWaterFreeze(x, y) {
    this.triggerShake(10, 5);
    this.triggerFlash('rgba(74, 144, 217, 0.35)', 0.35);
    this.triggerRing(x, y, '#87CEEB', 90, 6);

    for (let i = 0; i < 32; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 5 + 2;
      const vx = Math.cos(angle) * speed;
      const vy = Math.sin(angle) * speed;
      const size = Math.random() * 6 + 4;
      const color = Math.random() > 0.3 ? '#87CEEB' : '#FFFFFF';
      const p = globalPool.get('fx_particle', x, y, vx, vy, size, color, 30, 'ice', (Math.random() - 0.5) * 0.3);
      if (p) this.particles.push(p);
    }
  }

  /**
   * 火印引爆：三昧爆燃（烈焰飞溅 + 灼热火球震波）
   */
  triggerFireBurst(x, y) {
    this.triggerShake(16, 9);
    this.triggerFlash('rgba(217, 74, 74, 0.45)', 0.45);
    this.triggerRing(x, y, '#FF4500', 110, 6);

    for (let i = 0; i < 40; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 8 + 3;
      const vx = Math.cos(angle) * speed;
      const vy = Math.sin(angle) * speed;
      const size = Math.random() * 7 + 4;
      const color = Math.random() > 0.5 ? '#FF4500' : (Math.random() > 0.5 ? '#FFA500' : '#FFD700');
      const p = globalPool.get('fx_particle', x, y, vx, vy, size, color, 28, 'flame', (Math.random() - 0.5) * 0.5);
      if (p) this.particles.push(p);
    }
  }

  /**
   * 土印引爆：息壤固岳（金岩结界 + 不灭符印聚合）
   */
  triggerEarthShield(x, y) {
    this.triggerFlash('rgba(196, 163, 90, 0.35)', 0.35);
    this.triggerRing(x, y, '#D4AF37', 80, 5);

    for (let i = 0; i < 26; i++) {
      const angle = Math.random() * Math.PI * 2;
      const dist = 60 + Math.random() * 20;
      const startX = x + Math.cos(angle) * dist;
      const startY = y + Math.sin(angle) * dist;
      // 向中心汇聚的岩石粒子
      const vx = -Math.cos(angle) * 3.5;
      const vy = -Math.sin(angle) * 3.5;
      const size = Math.random() * 6 + 4;
      const color = Math.random() > 0.4 ? '#C4A35A' : '#8B7332';
      const p = globalPool.get('fx_particle', startX, startY, vx, vy, size, color, 24, 'rock', (Math.random() - 0.5) * 0.2);
      if (p) this.particles.push(p);
    }
  }

  // ==================== 拖拽飞剑出牌曲线与准星渲染 ====================

  /**
   * 绘制出牌贝塞尔飞剑轨迹与八卦锁定准星
   * @param {CanvasRenderingContext2D} ctx 
   * @param {number} startX 起点（卡牌位置）
   * @param {number} startY 起点（卡牌位置）
   * @param {number} currX 当前手指触摸位置
   * @param {number} currY 当前手指触摸位置
   * @param {number} targetX 目标位置（敌人中心）
   * @param {number} targetY 目标位置（敌人中心）
   * @param {boolean} isLocked 是否已锁定敌人目标
   */
  renderDragTrajectory(ctx, startX, startY, currX, currY, targetX, targetY, isLocked) {
    const endX = isLocked ? targetX : currX;
    const endY = isLocked ? targetY : currY;

    // 二次贝塞尔曲线控制点（形成优雅的向上弧拱）
    const ctrlX = (startX + endX) / 2 + (currX - startX) * 0.2;
    const ctrlY = Math.min(startY, endY) - 60;

    ctx.save();

    // 1. 发光飞剑剑气主轨迹
    const grad = ctx.createLinearGradient(startX, startY, endX, endY);
    if (isLocked) {
      grad.addColorStop(0, 'rgba(212, 175, 55, 0.4)');
      grad.addColorStop(0.5, 'rgba(255, 215, 0, 0.9)');
      grad.addColorStop(1, '#FF3333');
    } else {
      grad.addColorStop(0, 'rgba(201, 154, 58, 0.3)');
      grad.addColorStop(0.7, 'rgba(243, 211, 122, 0.8)');
      grad.addColorStop(1, '#FFFDF8');
    }

    ctx.strokeStyle = grad;
    ctx.lineWidth = isLocked ? 4 : 2.5;
    ctx.lineCap = 'round';
    ctx.shadowColor = isLocked ? '#FF4500' : '#FFD700';
    ctx.shadowBlur = isLocked ? 12 : 6;

    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.quadraticCurveTo(ctrlX, ctrlY, endX, endY);
    ctx.stroke();

    // 2. 沿曲线流动的符文节点光点
    const now = Date.now() / 250;
    const nodeCount = 7;
    for (let i = 0; i <= nodeCount; i++) {
      const t = ((i / nodeCount) + (now % 1)) % 1;
      // 二次贝塞尔插值公式
      const px = Math.pow(1 - t, 2) * startX + 2 * (1 - t) * t * ctrlX + Math.pow(t, 2) * endX;
      const py = Math.pow(1 - t, 2) * startY + 2 * (1 - t) * t * ctrlY + Math.pow(t, 2) * endY;
      const r = isLocked ? (3.5 * t + 1.5) : (2.5 * t + 1);

      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fillStyle = isLocked ? '#FFE599' : '#FFF8DD';
      ctx.fill();
    }

    // 3. 终点：八卦封魔锁定准星 或 灵气触点
    if (isLocked) {
      const rot = (Date.now() / 400) % (Math.PI * 2);
      const reticleR = 34 + Math.sin(Date.now() / 150) * 3;

      ctx.save();
      ctx.translate(targetX, targetY);
      ctx.rotate(rot);

      // 八卦外环
      ctx.strokeStyle = '#FFD700';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, reticleR, 0, Math.PI * 2);
      ctx.stroke();

      // 八方剑芒刻度
      for (let k = 0; k < 4; k++) {
        ctx.rotate(Math.PI / 2);
        ctx.beginPath();
        ctx.moveTo(reticleR - 6, 0);
        ctx.lineTo(reticleR + 6, 0);
        ctx.stroke();
      }

      // 锁定中心朱砂印记
      ctx.fillStyle = 'rgba(150, 42, 31, 0.85)';
      ctx.beginPath();
      ctx.arc(0, 0, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#FFE599';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#FFF8DD';
      ctx.font = 'bold 10px serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('斩', 0, 0);

      ctx.restore();
    } else {
      // 未锁定时显示光标灵晕
      ctx.beginPath();
      ctx.arc(currX, currY, 8, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 215, 0, 0.8)';
      ctx.fill();
      ctx.strokeStyle = '#FFF';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    ctx.restore();
  }

  update() {
    // 震屏衰减
    if (this.shakeDuration > 0) {
      this.shakeDuration--;
      this.shakeOffsetX = (Math.random() - 0.5) * this.shakeIntensity * (this.shakeDuration / 10);
      this.shakeOffsetY = (Math.random() - 0.5) * this.shakeIntensity * (this.shakeDuration / 10);
    } else {
      this.shakeOffsetX = 0;
      this.shakeOffsetY = 0;
    }

    // 全屏闪光淡出
    if (this.flashAlpha > 0) {
      this.flashAlpha = Math.max(0, this.flashAlpha - 0.035);
      if (this.flashAlpha <= 0) this.flashColor = null;
    }

    // 光环扩展与淡出
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i];
      r.radius += (r.maxRadius - r.radius) * 0.2;
      r.alpha -= 0.05;
      if (r.alpha <= 0 || r.radius >= r.maxRadius - 2) {
        this.rings.splice(i, 1);
      }
    }

    // 粒子物理运算与回收
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vx *= 0.95;
      p.vy *= 0.95;
      p.rot += p.vRot;
      p.life--;
      p.alpha = Math.max(0, p.life / p.maxLife);

      if (p.life <= 0) {
        this.particles.splice(i, 1);
        globalPool.recover('fx_particle', p);
      }
    }
  }

  render(ctx, width, height) {
    // 1. 绘制全屏引爆瞬态滤镜
    if (this.flashColor && this.flashAlpha > 0) {
      ctx.save();
      ctx.globalAlpha = this.flashAlpha;
      ctx.fillStyle = this.flashColor;
      ctx.fillRect(0, 0, width, height);
      ctx.restore();
    }

    // 2. 绘制冲击光环
    for (const r of this.rings) {
      ctx.save();
      ctx.globalAlpha = r.alpha;
      ctx.strokeStyle = r.color;
      ctx.lineWidth = r.lineWidth;
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // 3. 绘制粒子
    for (const p of this.particles) {
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);

      if (p.shape === 'spark') {
        // 金系菱形剑气
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.moveTo(0, -p.size);
        ctx.lineTo(p.size / 3, 0);
        ctx.lineTo(0, p.size);
        ctx.lineTo(-p.size / 3, 0);
        ctx.closePath();
        ctx.fill();
      } else if (p.shape === 'leaf') {
        // 木系叶片
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size, p.size / 2, 0, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.shape === 'ice') {
        // 水系六角冰晶
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-p.size / 2, -p.size / 2, p.size, p.size);
      } else if (p.shape === 'flame') {
        // 火系火星
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(0, 0, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.shape === 'rock') {
        // 土系不规则岩石
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      } else {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(0, 0, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }
}