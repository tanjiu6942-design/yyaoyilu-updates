// 九尾狐 3D 闪卡全屏覆盖层（Canvas 2D 游戏内叠加 WebGL）
// 用法：window.openHoloCard() 打开，window.closeHoloCard() 关闭
// THREE 由 vendor/three.global.js 以传统 script 全局加载（避免真机 ESM 二级 import 断链）
const THREE = window.THREE;

let overlay = null;

const vertex = `
varying vec2 vUv;
void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
`;

const shared = `
precision highp float;
varying vec2 vUv;
uniform float uTime, uFoil, uScale, uDepth, uBgDepth, uSafeScale;
uniform vec2 uSafeOffset;
uniform vec3 uView;
float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y); }
vec3 spectrum(float t){ t=fract(t); vec3 pink=vec3(1.,.32,.62), yellow=vec3(1.,.85,.32), blue=vec3(.22,.62,1.); if(t<.35)return mix(pink,yellow,t/.35); if(t<.7)return mix(yellow,blue,(t-.35)/.35); return mix(blue,vec3(1.),(t-.7)/.3); }
vec3 overlay(vec3 b, vec3 f){ return mix(2.*b*f, 1.-2.*(1.-b)*(1.-f), step(vec3(.5),b)); }
float inside(vec2 p){ return step(0.,p.x)*step(0.,p.y)*step(p.x,1.)*step(p.y,1.); }
vec2 parallax(vec2 p, float s, float d){ return (p-.5)*s+.5 + uView.xy/max(abs(uView.z),.35)*d*.14; }
float wave(vec2 p){ vec2 a=p+uView.xy*2.4; return .5+.5*sin((a.x*.848-a.y*.530)*6.283*.55+7.*noise(a*1.5)); }
float star(vec2 p){ vec2 q=p*105., id=floor(q), f=fract(q); float first=9., second=9.; for(int y=-1;y<=1;y++){ for(int x=-1;x<=1;x++){ vec2 g=vec2(float(x),float(y)); vec2 o=vec2(hash(id+g),hash(id+g+43.3)); float d=length(g+o-f); if(d<first){ second=first; first=d; } else second=min(second,d); } } float edge=1.-smoothstep(.01,.035,second-first); float sparse=step(.90,hash(id+8.8)); float twinkle=pow(.5+.5*sin(uTime*1.8+hash(id)*30.+uView.x*27.+uView.y*21.),6.); return edge*sparse*twinkle; }
`;

const fragment = shared + `
uniform sampler2D tSubject, tBackground, tText, tLine;
void main(){
  vec2 uv = vUv;
  vec2 su = parallax(uv, uScale, uDepth) * uSafeScale + uSafeOffset;
  vec2 bu = parallax(uv, 1., uBgDepth);
  vec4 sub = texture2D(tSubject, clamp(su, 0., 1.)); sub.a *= inside(su);
  vec3 bg = texture2D(tBackground, clamp(bu, 0., 1.)).rgb;
  float w = wave(uv); vec3 foil = spectrum(w*.8 + noise(uv*5.)*.12);
  vec3 subject = mix(sub.rgb, overlay(sub.rgb, foil), uFoil*.28);
  bg = mix(bg, overlay(bg, foil), uFoil*.36);
  vec3 col = mix(bg, subject, sub.a);
  float sweep = pow(max(0., sin((uv.x*.83+uv.y*.35+uView.x*1.8+uView.y*.9)*6.283)), 12.);
  col += foil * sweep * uFoil * .28;
  float line = 1. - smoothstep(.06, .25, texture2D(tLine, clamp(su, 0., 1.)).r);
  col += vec3(1.,.94,.78) * line * inside(su) * sub.a * sweep * uFoil * .22;
  col += vec3(.66,.86,1.) * star(bu) * uFoil * .65 * (1. - sub.a*.7);
  vec4 text = texture2D(tText, uv); col = mix(col, text.rgb, text.a);
  // ===== 古风金边：跟随卡片转动、参与镭射，黑红金一体 =====
  float fAsp = 6.3 / 9.45;
  vec2 fDist;
  fDist.x = min(uv.x, 1.0 - uv.x) * fAsp;
  fDist.y = min(uv.y, 1.0 - uv.y);
  float fEdge = min(fDist.x, fDist.y);
  float fOuter = 1.0 - smoothstep(0.016, 0.022, fEdge);
  float fInner = smoothstep(0.038, 0.042, fEdge) * (1.0 - smoothstep(0.042, 0.048, fEdge));
  vec3 fGold = vec3(0.80, 0.60, 0.23);
  vec3 fGoldHi = vec3(1.0, 0.85, 0.48);
  vec3 fCol = mix(fGold, fGoldHi, clamp(sweep, 0., 1.));
  fCol = mix(fCol, foil, 0.22);
  float fMask = clamp(fOuter + fInner * 0.85, 0., 1.);
  col = mix(col, fCol, fMask);
  gl_FragColor = vec4(pow(max(col, vec3(0.)), vec3(1.0)), 1.);
}
`;

async function initHolo() {
  // 配置直接内联（避免真机 fetch 相对路径问题）
  const config = {
    parameters: { subjectScale: 1.3, subjectDepth: 0.45, backgroundDepth: -0.25, foil: 1.0 },
    safeArea: { scale: 1.12, offset: [-0.06, -0.085] }
  };

  // ---- DOM 覆盖层 ----
  overlay = document.createElement('div');
  overlay.id = 'holo-overlay';
  Object.assign(overlay.style, {
    position: 'fixed', inset: '0', zIndex: '100000',
    background: '#0a0e16', touchAction: 'none',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  });
  const canvas = document.createElement('canvas');
  Object.assign(canvas.style, { width: '100%', height: '100%', display: 'block', touchAction: 'none' });
  overlay.appendChild(canvas);

  // 关闭按钮
  const closeBtn = document.createElement('div');
  closeBtn.textContent = '✕ 关闭';
  Object.assign(closeBtn.style, {
    position: 'absolute', top: 'env(safe-area-inset-top, 12px)', right: '16px',
    padding: '8px 16px', borderRadius: '20px',
    background: 'rgba(40,26,16,.7)', color: '#E8D5A3',
    font: '14px sans-serif', zIndex: '100001', cursor: 'pointer',
    border: '1px solid rgba(201,154,58,.6)',
  });
  closeBtn.onclick = closeHoloCard;
  overlay.appendChild(closeBtn);

  // 提示
  const hint = document.createElement('div');
  hint.textContent = '拖动卡片 · 左右转动看流光';
  Object.assign(hint.style, {
    position: 'absolute', bottom: 'env(safe-area-inset-bottom, 16px)', left: '0', right: '0',
    textAlign: 'center', color: 'rgba(232,213,163,.7)', font: '13px sans-serif', zIndex: '100001',
  });
  overlay.appendChild(hint);

  document.body.appendChild(overlay);

  // ---- Three.js ----
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(-5, 5, 5.65, -5.65, .1, 100);
  camera.position.set(0, 0, 20);

  const loader = new THREE.TextureLoader();
  const load = (n) => loader.loadAsync('/holo-card/assets/' + n + '.png');
  const [subject, background, text, lineart] = await Promise.all(
    ['subject', 'background', 'text', 'lineart'].map(load)
  );
  [subject, background, text, lineart].forEach(t => {
    t.colorSpace = THREE.NoColorSpace;
    t.anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 8);
  });

  const prm = config.parameters || {};
  const uniforms = {
    tSubject: { value: subject }, tBackground: { value: background },
    tText: { value: text }, tLine: { value: lineart },
    uTime: { value: 0 }, uView: { value: new THREE.Vector3(0, 0, 1) },
    uFoil: { value: prm.foil ?? 1.0 }, uScale: { value: prm.subjectScale ?? 1.25 },
    uDepth: { value: prm.subjectDepth ?? .4 }, uBgDepth: { value: prm.backgroundDepth ?? -.25 },
    uSafeScale: { value: config.safeArea?.scale ?? 1.12 },
    uSafeOffset: { value: new THREE.Vector2(...(config.safeArea?.offset ?? [-.06, -.085])) },
  };

  const mat = new THREE.ShaderMaterial({ uniforms, vertexShader: vertex, fragmentShader: fragment });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(6.3, 9.45), mat);
  const root = new THREE.Group();
  root.add(mesh);
  scene.add(root);

  // ---- 尺寸：卡牌完整居中进屏（contain），不裁切、上下留对称边距 ----
  const CARD_W = 6.3, CARD_H = 9.45;
  function resize() {
    const w = overlay.clientWidth, h = overlay.clientHeight;
    const aspect = w / h;
    // 视野同时覆盖卡牌宽和高，取需要的最大半高
    const halfH = Math.max(CARD_H / 2, CARD_W / (2 * aspect));
    camera.left = -halfH * aspect; camera.right = halfH * aspect;
    camera.top = halfH; camera.bottom = -halfH;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  }
  resize();
  window.addEventListener('resize', resize);

  // ---- 拖动 ----
  let dragging = false, lastX = 0, lastY = 0;
  let targetX = 0.025, targetY = -0.13, rotX = targetX, rotY = targetY;
  function down(e) {
    dragging = true;
    const p = e.touches ? e.touches[0] : e;
    lastX = p.clientX; lastY = p.clientY;
  }
  function move(e) {
    if (!dragging) return;
    const p = e.touches ? e.touches[0] : e;
    targetY = THREE.MathUtils.clamp(targetY + (p.clientX - lastX) * .006, -.65, .65);
    targetX = THREE.MathUtils.clamp(targetX + (p.clientY - lastY) * .005, -.43, .43);
    lastX = p.clientX; lastY = p.clientY;
    if (e.cancelable) e.preventDefault();
  }
  function up() { dragging = false; }
  canvas.addEventListener('pointerdown', down);
  canvas.addEventListener('pointermove', move);
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);

  // ---- 动画 ----
  let running = true, last = performance.now();
  function animate(now) {
    if (!running) return;
    requestAnimationFrame(animate);
    const dt = Math.min((now - last) / 1000, .1); last = now;
    uniforms.uTime.value += dt;
    const ease = 1 - Math.exp(-dt * 8);
    rotX += (targetX - rotX) * ease;
    rotY += (targetY - rotY) * ease;
    root.rotation.set(rotX, rotY, 0);
    root.updateMatrixWorld(true);
    uniforms.uView.value.copy(camera.position)
      .applyMatrix4(new THREE.Matrix4().copy(root.matrixWorld).invert()).normalize();
    renderer.render(scene, camera);
  }
  requestAnimationFrame(animate);

  overlay._cleanup = () => {
    running = false;
    window.removeEventListener('resize', resize);
    canvas.removeEventListener('pointerdown', down);
    canvas.removeEventListener('pointermove', move);
    canvas.removeEventListener('pointerup', up);
    canvas.removeEventListener('pointercancel', up);
    renderer.dispose();
    [subject, background, text, lineart].forEach(t => t.dispose());
    mat.dispose(); mesh.geometry.dispose();
  };
}

window.__holoThreeLoaded = true;

window.openHoloCard = function () {
  try {
    if (typeof wx !== 'undefined' && wx.showToast) wx.showToast({ title: '正在打开闪卡...', icon: 'none', duration: 1200 });
  } catch (e) {}
  if (overlay) return;
  initHolo().catch(err => {
    console.error('holo card init failed', err);
    try {
      if (typeof wx !== 'undefined' && wx.showToast) wx.showToast({ title: '闪卡错误: ' + String(err && err.message || err).slice(0, 40), icon: 'none', duration: 4000 });
    } catch (e) {}
    closeHoloCard();
  });
};

window.closeHoloCard = function () {
  if (overlay) {
    if (overlay._cleanup) overlay._cleanup();
    overlay.remove();
    overlay = null;
  }
};
