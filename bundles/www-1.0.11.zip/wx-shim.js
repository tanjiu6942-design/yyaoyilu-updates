/**
 * wx API 兼容层（Web / 安卓版）
 * 
 * 把微信小游戏的 wx.* API 映射到标准 Web API。
 * 这个文件必须在所有游戏代码之前加载。
 */

(function () {
  'use strict';

  // ========== 1. 创建主 Canvas ==========
  // 微信小游戏里 canvas 是全局变量，Web 里从 DOM 获取
  const canvas = document.getElementById('gameCanvas');
  if (!canvas) {
    console.error('[wx-shim] 找不到 id="gameCanvas" 的 canvas 元素');
    return;
  }

  // 设置全局变量（微信小游戏里 GameGlobal 和 this/window 是同一个东西）
  window.canvas = canvas;
  window.GameGlobal = window;
  window.GameGlobal.canvas = canvas;

  // ========== 2. 屏幕信息 ==========
  function getWindowInfo() {
    return {
      pixelRatio: window.devicePixelRatio || 1,
      screenWidth: window.innerWidth,
      screenHeight: window.innerHeight,
      windowWidth: window.innerWidth,
      windowHeight: window.innerHeight,
      statusBarHeight: 0,
      safeArea: {
        top: 0,
        left: 0,
        right: window.innerWidth,
        bottom: window.innerHeight,
        width: window.innerWidth,
        height: window.innerHeight
      }
    };
  }

  function getSystemInfoSync() {
    return getWindowInfo();
  }

  // 微信胶囊按钮位置（安卓没有，返回空对象，代码里有兜底）
  function getMenuButtonBoundingClientRect() {
    return {};
  }

  // ========== 3. Canvas ==========
  // 微信 wx.createCanvas() 第一次调用返回主 canvas，后续调用创建离屏 canvas
  function createCanvas() {
    // 第一次调用返回主 canvas（从 DOM 获取的那个）
    if (!createCanvas._mainCanvas) {
      createCanvas._mainCanvas = canvas;
      return canvas;
    }
    // 后续调用创建离屏 canvas
    return document.createElement('canvas');
  }

  // ========== 3. 图片 ==========
  function createImage() {
    return new Image();
  }

  // ========== 4. 音频 ==========
  // 微信 InnerAudioContext 和 Web Audio 对象的 API 有差异，包一层
  function createInnerAudioContext() {
    const audio = new Audio();

    // 包装成微信 InnerAudioContext 的接口
    const wrapper = {
      _audio: audio,

      // 属性
      get src() { return audio.src; },
      set src(val) { audio.src = val; },
      get loop() { return audio.loop; },
      set loop(val) { audio.loop = val; },
      get volume() { return audio.volume; },
      set volume(val) { audio.volume = val; },
      get obeyMuteSwitch() { return true; },
      set obeyMuteSwitch(val) { /* Web 无此概念，忽略 */ },
      get paused() { return audio.paused; },
      get ended() { return audio.ended; },
      get currentTime() { return audio.currentTime; },
      set currentTime(val) { audio.currentTime = val; },

      // 方法
      play() {
        // Web 里 play() 返回 Promise，需要 catch 避免报错
        const p = audio.play();
        if (p && p.catch) p.catch(e => { /* 自动播放被阻止时静默 */ });
      },
      pause() {
        audio.pause();
      },
      stop() {
        audio.pause();
        audio.currentTime = 0;
      },
      seek(val) {
        audio.currentTime = val;
      },

      // 事件回调（微信用 onXxx(fn)，Web 用 addEventListener）
      onPlay(fn) { audio.addEventListener('play', fn); },
      onPause(fn) { audio.addEventListener('pause', fn); },
      onStop(fn) { /* Web 没有 stop 事件，用 pause 代替 */ audio.addEventListener('pause', fn); },
      onEnded(fn) { audio.addEventListener('ended', fn); },
      onError(fn) { audio.addEventListener('error', fn); },
      onCanplay(fn) { audio.addEventListener('canplay', fn); },
      onTimeUpdate(fn) { audio.addEventListener('timeupdate', fn); }
    };

    return wrapper;
  }

  // ========== 5. 本地存储 ==========
  // 注意：业务层 storage.js 自己做了 JSON.stringify/parse，
  // 这里只做简单的字符串存取，不要二次序列化。
  // 微信行为：key 不存在时返回空字符串 ''
  function setStorageSync(key, data) {
    try {
      localStorage.setItem(key, String(data));
    } catch (e) {
      console.warn('[wx-shim] setStorageSync 失败:', e);
    }
  }

  function getStorageSync(key) {
    try {
      const val = localStorage.getItem(key);
      return val === null ? '' : val;
    } catch (e) {
      return '';
    }
  }

  function removeStorageSync(key) {
    localStorage.removeItem(key);
  }

  // ========== 6. 触摸事件 ==========
  // 微信是全局 wx.onTouchXxx，Web 是 canvas.addEventListener
  // 同时支持触摸（手机）和鼠标（桌面浏览器测试）
  function normalizeTouchEvent(e) {
    if (!e.touches) e.touches = [];
    if (!e.changedTouches) e.changedTouches = [];
    return e;
  }

  // 把鼠标事件包装成触摸事件格式（桌面浏览器测试用）
  function mouseToTouchEvent(e) {
    const touch = {
      clientX: e.clientX,
      clientY: e.clientY,
      pageX: e.pageX,
      pageY: e.pageY
    };
    return {
      touches: [touch],
      changedTouches: [touch],
      timeStamp: e.timeStamp,
      preventDefault: () => e.preventDefault()
    };
  }

  function onTouchStart(fn) {
    canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      fn(normalizeTouchEvent(e));
    }, { passive: false });
    // 鼠标支持（桌面测试）
    canvas.addEventListener('mousedown', (e) => {
      e.preventDefault();
      fn(mouseToTouchEvent(e));
    });
  }

  function onTouchMove(fn) {
    canvas.addEventListener('touchmove', (e) => {
      e.preventDefault();
      fn(normalizeTouchEvent(e));
    }, { passive: false });
    canvas.addEventListener('mousemove', (e) => {
      if (e.buttons > 0) {  // 鼠标按下时才触发移动（模拟拖拽）
        e.preventDefault();
        fn(mouseToTouchEvent(e));
      }
    });
  }

  function onTouchEnd(fn) {
    canvas.addEventListener('touchend', (e) => {
      e.preventDefault();
      fn(normalizeTouchEvent(e));
    }, { passive: false });
    canvas.addEventListener('mouseup', (e) => {
      e.preventDefault();
      fn(mouseToTouchEvent(e));
    });
  }

  function onTouchCancel(fn) {
    canvas.addEventListener('touchcancel', (e) => {
      fn(normalizeTouchEvent(e));
    });
    canvas.addEventListener('mouseleave', (e) => {
      fn(mouseToTouchEvent(e));
    });
  }

  // ========== 7. Toast 提示 ==========
  // 微信有内置 toast，Web 需要自己实现
  // 用 DOM 浮层实现
  let toastEl = null;
  let toastTimer = null;

  function showToast({ title = '', icon = 'none', duration = 2000 } = {}) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.style.cssText = `
        position: fixed;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0, 0, 0, 0.75);
        color: #fff;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        font-family: serif;
        z-index: 99999;
        pointer-events: none;
        max-width: 80%;
        text-align: center;
        line-height: 1.5;
      `;
      document.body.appendChild(toastEl);
    }

    toastEl.textContent = title;
    toastEl.style.display = 'block';

    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      if (toastEl) toastEl.style.display = 'none';
    }, duration);
  }

  // ========== 8. 震动反馈 ==========
  function vibrateShort({ type = 'light' } = {}) {
    if (navigator.vibrate) {
      navigator.vibrate(50); // 短震 50ms
    }
  }

  // ========== 9. 帧率设置 ==========
  // Web 的 requestAnimationFrame 自动同步刷新率，不需要设置
  function setPreferredFramesPerSecond(fps) {
    // 空操作
  }

  // ========== 10. 其他空操作 ==========
  function showModal() { /* 暂不支持 */ }
  function showActionSheet() { /* 暂不支持 */ }
  function navigateTo() { /* 空操作 */ }
  function redirectTo() { /* 空操作 */ }
  function navigateBack() { /* 空操作 */ }
  function switchTab() { /* 空操作 */ }
  function reLaunch() { /* 空操作 */ }

  // ========== 导出 wx 对象 ==========
  window.wx = {
    // Canvas
    createCanvas: createCanvas,

    // 屏幕信息
    getWindowInfo: getWindowInfo,
    getSystemInfoSync: getSystemInfoSync,
    getMenuButtonBoundingClientRect: getMenuButtonBoundingClientRect,

    // 图片
    createImage: createImage,

    // 音频
    createInnerAudioContext: createInnerAudioContext,

    // 存储
    setStorageSync: setStorageSync,
    getStorageSync: getStorageSync,
    removeStorageSync: removeStorageSync,

    // 触摸
    onTouchStart: onTouchStart,
    onTouchMove: onTouchMove,
    onTouchEnd: onTouchEnd,
    onTouchCancel: onTouchCancel,

    // UI
    showToast: showToast,
    showModal: showModal,
    showActionSheet: showActionSheet,

    // 震动
    vibrateShort: vibrateShort,

    // 帧率
    setPreferredFramesPerSecond: setPreferredFramesPerSecond,

    // 导航（空操作）
    navigateTo: navigateTo,
    redirectTo: redirectTo,
    navigateBack: navigateBack,
    switchTab: switchTab,
    reLaunch: reLaunch
  };

  console.log('[wx-shim] 兼容层加载完成，运行环境：Web/Android');
})();
