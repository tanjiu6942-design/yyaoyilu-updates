import { recordCodexSeen } from '../../config/storage.js';
import { 
  drawParchmentBackground, drawScrollPanel, drawSealButton, drawRoundedRect, drawTextCentered, drawTextLeft, createButton, UI_COLORS 
} from '../scene.js';
import { CHAPTER_1_EVENTS, CHAPTER_2_EVENTS, CHAPTER_3_EVENTS, getUpgradedCard } from '../data.js';
import { stepToNode } from '../map.js';
import { soundManager } from '../../runtime/music.js';
import { TutorialManager, renderTutorial, isSkipButtonTapped, EVENT_STEPS } from '../tutorial/index.js';
import { runManager } from '../RunManager.js';
import { EventStateMachine } from '../systems/EventStateMachine.js';

// 墨金重工华彩框体
function drawInkGoldScrollModal(ctx, x, y, w, h) {
  ctx.save();
  ctx.shadowColor = 'rgba(212, 175, 55, 0.22)';
  ctx.shadowBlur = 20;
  ctx.shadowOffsetY = 8;
  drawRoundedRect(ctx, x, y, w, h, 14, '#1A0E08', '#0D0704', 3);
  ctx.restore();

  const goldGrad = ctx.createLinearGradient(x, y, x + w, y + h);
  goldGrad.addColorStop(0, '#E6C875');
  goldGrad.addColorStop(0.5, '#C49838');
  goldGrad.addColorStop(1, '#8C6018');
  drawRoundedRect(ctx, x + 2, y + 2, w - 4, h - 4, 12, null, goldGrad, 2);

  const paperGrad = ctx.createRadialGradient(x + w / 2, y + h * 0.45, w * 0.15, x + w / 2, y + h * 0.5, w * 0.85);
  paperGrad.addColorStop(0, '#FFFDF8');
  paperGrad.addColorStop(0.35, '#F9EED9');
  paperGrad.addColorStop(0.75, '#EBD5AD');
  paperGrad.addColorStop(1, '#CFA968');
  drawRoundedRect(ctx, x + 5, y + 5, w - 10, h - 10, 10, paperGrad, '#8F6126', 1.5);

  const innerMargin = 12;
  const ix = x + innerMargin;
  const iy = y + innerMargin;
  const iw = w - innerMargin * 2;
  const ih = h - innerMargin * 2;

  ctx.save();
  ctx.strokeStyle = 'rgba(150, 42, 31, 0.35)';
  ctx.lineWidth = 1;
  ctx.strokeRect(ix, iy, iw, ih);
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 1.2;
  ctx.strokeRect(ix + 3, iy + 3, iw - 6, ih - 6);

  const drawRoyalCorner = (cx, cy, dirX, dirY) => {
    ctx.strokeStyle = '#C99A3A';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(cx, cy + dirY * 16);
    ctx.lineTo(cx, cy);
    ctx.lineTo(cx + dirX * 16, cy);
    ctx.stroke();

    ctx.fillStyle = '#962A1F';
    ctx.fillRect(cx + dirX * 5, cy + dirY * 5, 3, 3);
  };

  drawRoyalCorner(ix + 5, iy + 5, 1, 1);
  drawRoyalCorner(ix + iw - 5, iy + 5, -1, 1);
  drawRoyalCorner(ix + 5, iy + ih - 5, 1, -1);
  drawRoyalCorner(ix + iw - 5, iy + ih - 5, -1, -1);
  ctx.restore();
}

function getWrappedLines(ctx, text, maxWidth, fontSize) {
  ctx.font = `${fontSize}px "Songti SC", "SimSun", "STSong", serif`;
  const str = text ? String(text) : '';
  if (!str) return [];
  const lines = [];
  let line = '';
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    const testLine = line + char;
    if (ctx.measureText(testLine).width > maxWidth && line !== '') {
      lines.push(line);
      line = char;
    } else {
      line = testLine;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function wrapDetailText(ctx, text, x, y, maxWidth, lineHeight, color, fontSize) {
  ctx.font = `500 ${fontSize}px "Songti SC", "SimSun", "STSong", serif`; 
  ctx.fillStyle = color || '#120904'; 
  ctx.textAlign = 'left'; 
  ctx.textBaseline = 'top';
  const lines = getWrappedLines(ctx, text, maxWidth, fontSize);
  lines.forEach((l, idx) => {
    ctx.fillText(l, x, y + idx * lineHeight);
  });
}

export function createEventScene(manager) {
  return {
    manager, 
    runState: null, 
    currentEvent: null, 
    stateMachine: null,
    buttons: [], 
    resolved: false, 
    resultText: '', 
    gains: [],
    pendingNextStage: false,

    enter(data) {
      soundManager.stopAllSfx();
      soundManager.playBgm('shop');

      if (data?.runState) runManager.setState(data.runState);
      else runManager.load();
      this.runState = runManager.state;
      this.resolved = false;
      this.resultText = '';
      this.gains = [];
      this.pendingNextStage = false;

      const chapter = this.runState?.chapter || 1;
      // 优先使用地图节点传入的事件数据，否则随机选择
      if (data?.eventData) {
        this.currentEvent = data.eventData;
      } else {
        let eventPool;
        if (chapter === 3) eventPool = CHAPTER_3_EVENTS;
        else if (chapter === 2) eventPool = CHAPTER_2_EVENTS;
        else eventPool = CHAPTER_1_EVENTS;
        this.currentEvent = eventPool[Math.floor(Math.random() * eventPool.length)] || eventPool[0];
      }

      // 创建事件状态机
      if (this.currentEvent) {
        this.stateMachine = new EventStateMachine(this.currentEvent, this.runState);
      } else {
        this.stateMachine = null;
      }

      this.buildUI();

      // 已移除事件新手引导
      // const activated = TutorialManager.enterScene('event', EVENT_STEPS, {
      //   onStepChange: () => { this.buildUI(); },
      //   onComplete: () => { this.buildUI(); }
      // });
      // if (activated) this.buildUI();
    },

    buildUI() {
      const { width, height } = this.manager;
      this.manager.input.clearButtons();
      this.buttons = [];
      this._tutorialBlockTaps = false;

      // 新手教程触摸拦截
      if (TutorialManager.isActive && !this.resolved) {
        const step = TutorialManager.getCurrentStep();
        this.manager.input.addTapHandler((x, y) => {
          if (isSkipButtonTapped(x, y, width)) {
            TutorialManager.skipAll();
            this.buildUI();
          }
        });
        if (!step || step.type !== 'action') {
          this._tutorialBlockTaps = true;
        }
      }

      if (!this.resolved && this.stateMachine) {
        const stage = this.stateMachine.getCurrentStage();
        if (stage && stage.choices && stage.choices.length > 0) {
          const startY = height - 190;
          const btnH = 44; 
          const gap = 10;
          
          stage.choices.forEach((choice) => {
            const isDisabled = choice.disabled;
            const btn = createButton(20, startY + choice.index * (btnH + gap), width - 40, btnH, choice.text, {
              fontSize: 13, 
              color: isDisabled ? 'rgba(80, 60, 40, 0.6)' : 'rgba(38, 24, 14, 0.94)', 
              strokeColor: isDisabled ? '#888' : '#D4AF37',
              textColor: isDisabled ? '#999' : '#FFF3CA',
              tap: () => {
                if (isDisabled) {
                  soundManager.playSfx('btn_click');
                  wx.showToast({ title: choice.disabledReason || '不可选择', icon: 'none' });
                  return;
                }
                this.selectChoiceIndex(choice.index);
              }
            });
            btn.disabled = isDisabled;
            this.buttons.push(btn);
          });
        }
      } else {
        const btnW = 160; 
        const btnH = 42;
        const btn = createButton(width / 2 - btnW / 2, height - 68, btnW, btnH, '收拢机缘 · 启程', {
          fontSize: 15, 
          color: UI_COLORS.cinnabar, 
          strokeColor: '#FFD700',
          textColor: '#FFF8DD',
          tap: () => this.proceedToMap()
        });
        this.buttons.push(btn);
      }

      if (this._tutorialBlockTaps) {
        this.manager.input.addTapHandler((x, y) => {
          if (isSkipButtonTapped(x, y, width)) return;
          const advanced = TutorialManager.advance();
          if (advanced) {
            soundManager.playSfx('btn_click');
            this.buildUI();
          }
        });
        this._tutorialBlockTaps = false;
      } else {
        this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
      }
    },

    selectChoiceIndex(choiceIndex) {
      if (this.resolved || !this.runState || !this.stateMachine) return;

      // 新手引导：完成"做出抉择"操作
      TutorialManager.completeAction('make_choice');

      const result = this.stateMachine.choose(choiceIndex);
      if (!result.success) {
        soundManager.playSfx('btn_click');
        if (result.error) wx.showToast({ title: result.error, icon: 'none' });
        return;
      }

      // 累积本阶段收益
      const stageGains = result.gains || [];
      this.gains = this.gains.concat(stageGains);

      // 处理需要实际添加的奖励（卡牌/遗物）
      this._processGains(stageGains);

      // 播放音效
      this._playGainSounds(stageGains);

      if (result.hasNextStage) {
        // 多阶段事件：直接推进到下一阶段，显示新选项
        const advanced = this.stateMachine.advanceStage();
        if (advanced) {
          this.resultText = '';
          this.pendingNextStage = false;
        } else {
          // 推进失败，直接结算
          this.resolved = true;
          this.resultText = result.resultText || '机缘已了。';
        }
      } else {
        // 单阶段或最终阶段：标记为已结算
        this.resolved = true;
        this.resultText = result.resultText || '机缘已了。';
        this.pendingNextStage = false;
      }

      runManager.save();
      this.buildUI();
    },

    advanceToNextStage() {
      if (!this.stateMachine || !this.pendingNextStage) return;

      soundManager.playSfx('btn_click');
      const advanced = this.stateMachine.advanceStage();
      if (advanced) {
        this.pendingNextStage = false;
        this.resultText = '';
        this.gains = [];
        this.buildUI();
      } else {
        // 推进失败，直接结算
        this.pendingNextStage = false;
        this.resolved = true;
        this.buildUI();
      }
    },

    /**
     * 处理 gains 中的卡牌和遗物奖励（stateMachine只收集，实际添加在这里）
     */
    _processGains(gains) {
      gains.forEach((gain) => {
        if (gain.rewardCard) {
          if (!this.runState.allCards) this.runState.allCards = [];
          const newCard = { ...gain.rewardCard, id: 'card_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6) };
          this.runState.allCards.push(newCard);
          recordCodexSeen('card', newCard.name);
          gain.text = `获得符箓【${newCard.name}】`;
        }
        if (gain.rewardRelic) {
          const result = runManager.addRelic(gain.rewardRelic);
          if (!result.success) {
            gain.text = `法宝获取失败：${result.reason}`;
            gain.color = '#8C2A24';
          }
        }
        if (gain.upgradeCard) {
          const upgraded = this._upgradeRandomCard(gain.upgradeCard);
          if (upgraded) {
            const starText = upgraded.star === 1 ? '一星' : '二星·极';
            gain.text = `符箓精进【${upgraded.name}】升至${starText}`;
            gain.color = '#C99A3A';
          } else {
            gain.text = '符箓精进失败（无可升级符箓）';
            gain.color = '#8C2A24';
          }
        }
      });
    },

    /**
     * 随机升级一张符合条件的卡牌
     * @param {object} config { random, element, name }
     * @returns {object|null} 升级后的卡牌
     */
    _upgradeRandomCard(config) {
      if (!this.runState.allCards || this.runState.allCards.length === 0) return null;

      // 筛选可升级的卡牌（star < 2）
      let candidates = this.runState.allCards.filter(card => {
        const star = card.star !== undefined ? card.star : (card.isUpgraded ? 1 : 0);
        return star < 2 && !card.isCurse;
      });

      if (candidates.length === 0) return null;

      // 按条件筛选
      if (config.name) {
        const nameMatches = candidates.filter(c => c.name === config.name || c.name.includes(config.name));
        if (nameMatches.length > 0) candidates = nameMatches;
      }
      if (config.element) {
        const elementMatches = candidates.filter(c => c.element === config.element);
        if (elementMatches.length > 0) candidates = elementMatches;
      }

      if (candidates.length === 0) return null;

      // 随机选择一张
      const targetCard = candidates[Math.floor(Math.random() * candidates.length)];
      const upgraded = getUpgradedCard(targetCard);

      // 替换原卡牌
      const idx = this.runState.allCards.indexOf(targetCard);
      if (idx >= 0) {
        this.runState.allCards[idx] = upgraded;
      }

      return upgraded;
    },

    /**
     * 根据 gains 播放对应音效
     */
    _playGainSounds(gains) {
      let hasCoin = false, hasHeal = false, hasHit = false, hasVictory = false;
      gains.forEach((gain) => {
        if (gain.text?.includes('铜钱') && !gain.text.includes('消耗')) hasCoin = true;
        if (gain.text?.includes('恢复气血')) hasHeal = true;
        if (gain.text?.includes('受损') || gain.text?.includes('上限')) hasHit = true;
        if (gain.text?.includes('符箓') || gain.text?.includes('法宝')) hasVictory = true;
      });
      if (hasCoin) soundManager.playSfx('coin');
      if (hasHeal) soundManager.playSfx('heal');
      if (hasHit) soundManager.playSfx('hit');
      if (hasVictory) soundManager.playSfx('victory');
    },

    proceedToMap() {
      if (this.runState && this.runState.currentNodeId && this.runState.map) {
         this.runState.map = stepToNode(this.runState.map, this.runState.currentNodeId);
         runManager.save();
      }
      this.manager.enterScene('map');
    },

    render(ctx) {
      const { width, height } = this.manager;
      ctx.clearRect(0, 0, width, height);
      drawParchmentBackground(ctx, width, height);

      if (!this.runState || !this.currentEvent) return;

      const panelW = width - 20;
      const panelX = 10;

      // 显示结果的情况：已结算
      const showResult = this.resolved;

      if (!showResult) {
        // 未做出选择时的长篇铺叙画卷
        const panelH = height - 240;
        const panelY = 36;
        drawInkGoldScrollModal(ctx, panelX, panelY, panelW, panelH);

        // 题额与地标
        ctx.font = 'bold 18px "Songti SC", "SimSun", serif';
        ctx.fillStyle = UI_COLORS.cinnabar;
        ctx.textAlign = 'center';
        ctx.fillText(`【 奇 遇 · ${this.currentEvent.title} 】`, width / 2, panelY + 32);

        ctx.font = '12px serif';
        ctx.fillStyle = '#6B4A2E';
        ctx.fillText(`◆ ${this.currentEvent.location || '未知秘境'} ◆`, width / 2, panelY + 52);

        // 多阶段事件显示阶段进度
        if (this.stateMachine && this.stateMachine.isMultiStage()) {
          const stage = this.stateMachine.getCurrentStage();
          if (stage) {
            ctx.fillStyle = '#8B6914';
            ctx.fillText(`第 ${stage.stageIndex + 1} / ${stage.totalStages} 阶段`, width / 2, panelY + 68);
          }
        }

        ctx.strokeStyle = '#D4AF37';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(panelX + 32, panelY + 78);
        ctx.lineTo(panelX + panelW - 32, panelY + 78);
        ctx.stroke();

        // 完整情境正文（从 stateMachine 获取当前阶段描述）
        let description = this.currentEvent.description;
        if (this.stateMachine) {
          const stage = this.stateMachine.getCurrentStage();
          if (stage && stage.description) description = stage.description;
        }
        wrapDetailText(ctx, description, panelX + 24, panelY + 92, panelW - 48, 22, '#120904', 13);
      } else {
        // 抉择后的终局因果结算画卷
        const panelH = height - 120;
        const panelY = 36;
        drawInkGoldScrollModal(ctx, panelX, panelY, panelW, panelH);

        ctx.font = 'bold 18px "Songti SC", "SimSun", serif';
        ctx.fillStyle = UI_COLORS.cinnabar;
        ctx.textAlign = 'center';
        ctx.fillText('【 尘 埃 落 定 · 因 果 已 结 】', width / 2, panelY + 34);

        ctx.strokeStyle = '#D4AF37';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(panelX + 32, panelY + 54);
        ctx.lineTo(panelX + panelW - 32, panelY + 54);
        ctx.stroke();

        // 剧情展开结果
        wrapDetailText(ctx, this.resultText, panelX + 24, panelY + 70, panelW - 48, 22, '#120904', 13);

        // 分隔线
        const dividerY = panelY + 220;
        ctx.strokeStyle = 'rgba(180, 130, 70, 0.4)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(panelX + 24, dividerY);
        ctx.lineTo(panelX + panelW - 24, dividerY);
        ctx.stroke();

        // 获得的机缘与损耗
        drawTextCentered(ctx, '◆ 获 得 机 缘 增 益 ◆', width / 2, dividerY + 18, '#2B6B46', 13, 'serif');

        let itemY = dividerY + 36;
        const itemH = 38;
        const itemGap = 8;

        this.gains.forEach((gain) => {
          const itemX = panelX + 20;
          const itemW = panelW - 40;

          drawRoundedRect(ctx, itemX, itemY, itemW, itemH, 6, 'rgba(244, 235, 212, 0.94)', gain.stroke || '#C99A3A', 1);
          drawRoundedRect(ctx, itemX + 8, itemY + 8, 22, 22, 11, gain.fill || UI_COLORS.cinnabar, '#FFE599', 1);
          drawTextCentered(ctx, gain.icon || '机', itemX + 19, itemY + 19, '#FFF8DD', 11, 'serif');
          drawTextLeft(ctx, gain.text, itemX + 38, itemY + 19, gain.color || UI_COLORS.ink, 13, 'serif');

          itemY += itemH + itemGap;
        });
      }

      this.buttons.forEach(btn => {
        // 禁用按钮灰显
        if (btn.disabled) {
          ctx.globalAlpha = 0.5;
        }
        drawSealButton(ctx, btn);
        ctx.globalAlpha = 1;
      });

      // 新手引导层
      if (TutorialManager.isActive && !this.resolved) {
        const step = TutorialManager.getCurrentStep();
        const idx = TutorialManager.currentStepIndex;
        const total = TutorialManager.currentSteps.length;
        renderTutorial(ctx, step, width, height, idx, total);
      }
    },

    exit() {
      TutorialManager.exitScene();
    }
  };
}