/**
 * js/game/RunManager.js
 * 单局游戏状态管理器 (Singleton)
 * 统一管理单局生命周期、卡组、法宝、资源、因果世界回调与地图进度
 */

import { safeGetStorage, safeSetStorage, safeRemoveStorage, recordCodexSeen } from '../config/storage.js';
import { STORAGE_KEYS, ECONOMY } from '../config/constants.js';
import { KARMA_TIERS, KARMA_MODIFIERS, calculateKarmaTier } from '../config/KarmaModifiers.js';
import { CHARACTERS } from './types.js';
import { 
  createPlayer, 
  generateCardId, 
  getUpgradedCard
} from './data.js';
import { generateChapterMap, stepToNode, findNodeById } from './map.js';

const RUN_STORAGE_KEY = STORAGE_KEYS.RUN.STATE;

class RunManager {
  constructor() {
    this.state = null;
    this.snapshot = null;
    this.karmaListeners = [];
  }

  // ==================== 因果监听器注册与派发 ====================

  addKarmaListener(callback) {
    if (typeof callback === 'function') {
      this.karmaListeners.push(callback);
    }
  }

  removeKarmaListener(callback) {
    this.karmaListeners = this.karmaListeners.filter(fn => fn !== callback);
  }

  // 委托给 KarmaModifiers.calculateKarmaTier，保留方法名兼容外部调用
  calculateKarmaTier(karmaValue) {
    return calculateKarmaTier(karmaValue);
  }

  triggerKarmaEffects(oldKarma, newKarma, oldTier, newTier) {
    const tierChanged = oldTier !== newTier;
    const currentModifier = KARMA_MODIFIERS[newTier];

    const payload = {
      oldKarma,
      newKarma,
      oldTier,
      newTier,
      tierChanged,
      modifier: currentModifier
    };

    this.karmaListeners.forEach(fn => {
      try {
        fn(payload);
      } catch (err) {
        console.error('[RunManager] Karma listener error:', err);
      }
    });
  }

  // ==================== 单局生命周期 ====================

  initRun(characterId = 'taoist', chapter = 1) {
    const charConfig = CHARACTERS[characterId] || CHARACTERS.taoist;
    const starterPlayer = createPlayer(charConfig.id);
    const initialKarma = 0;

    this.state = {
      chapter,
      characterId: charConfig.id,
      hp: starterPlayer.hp,
      maxHp: starterPlayer.maxHp,
      gold: ECONOMY.INITIAL_GOLD,
      karma: initialKarma,
      karmaTier: this.calculateKarmaTier(initialKarma),
      relics: [],
      allCards: JSON.parse(JSON.stringify(starterPlayer.deck)),
      currentNodeId: null,
      map: generateChapterMap(chapter, 8, initialKarma),
      startTime: Date.now(),
      turnCounter: 0,
      // 流派构筑状态：跨战斗持久化，战斗创建时 deserialize，结束时 serialize
      buildState: null
    };

    this.snapshot = null;
    this.save();
    return this.state;
  }

  load() {
    const saved = safeGetStorage(RUN_STORAGE_KEY, null);
    if (saved && typeof saved === 'object' && saved.characterId) {
      if (Array.isArray(saved.map)) {
        for (const row of saved.map) {
          for (const node of row) {
            if (node.type === 'fight') node.type = 'battle';
          }
        }
      }
      if (!saved.karmaTier) {
        saved.karmaTier = this.calculateKarmaTier(saved.karma || 0);
      }
      // 兼容旧存档：没有 buildState 字段则初始化为 null
      if (saved.buildState === undefined) {
        saved.buildState = null;
      }
      this.state = saved;
      return this.state;
    }
    return null;
  }

  loadOrInit(characterId = 'taoist') {
    const loaded = this.load();
    if (loaded) return loaded;
    return this.initRun(characterId);
  }

  setState(state) {
    if (state && typeof state === 'object') {
      if (!state.karmaTier) {
        state.karmaTier = this.calculateKarmaTier(state.karma || 0);
      }
      this.state = state;
      this.save();
    }
    return this.state;
  }

  save() {
    if (!this.state) return false;
    return safeSetStorage(RUN_STORAGE_KEY, this.state);
  }

  hasActiveRun() {
    if (this.state && this.state.hp > 0) return true;
    const loaded = this.load();
    return !!(loaded && loaded.hp > 0);
  }

  clearRun() {
    this.state = null;
    this.snapshot = null;
    safeRemoveStorage(RUN_STORAGE_KEY);
  }

  saveSnapshot() {
    if (!this.state) return;
    this.snapshot = JSON.parse(JSON.stringify(this.state));
  }

  restoreSnapshot() {
    if (!this.snapshot) return null;
    this.state = JSON.parse(JSON.stringify(this.snapshot));
    this.save();
    return this.state;
  }

  // ==================== 资源、属性与因果分发 ====================

  getGold() {
    return this.state ? (this.state.gold || 0) : 0;
  }

  modifyGold(delta) {
    if (!this.state) return 0;
    this.state.gold = Math.max(0, (this.state.gold || 0) + delta);
    this.save();
    return this.state.gold;
  }

  getKarma() {
    return this.state ? (this.state.karma || 0) : 0;
  }

  modifyKarma(delta) {
    if (!this.state) return 0;

    const oldKarma = this.state.karma || 0;
    const oldTier = this.state.karmaTier || this.calculateKarmaTier(oldKarma);

    const newKarma = Math.max(-10, Math.min(10, oldKarma + delta));
    const newTier = this.calculateKarmaTier(newKarma);

    this.state.karma = newKarma;
    this.state.karmaTier = newTier;

    if (oldKarma !== newKarma) {
      this.triggerKarmaEffects(oldKarma, newKarma, oldTier, newTier);
    }

    this.save();
    return this.state.karma;
  }

  getKarmaTier() {
    if (!this.state) return KARMA_TIERS.NEUTRAL;
    return this.state.karmaTier || this.calculateKarmaTier(this.state.karma || 0);
  }

  getKarmaModifiers() {
    const tier = this.getKarmaTier();
    return KARMA_MODIFIERS[tier] || KARMA_MODIFIERS[KARMA_TIERS.NEUTRAL];
  }

  getShopPriceMultiplier() {
    return this.getKarmaModifiers().shopPriceMultiplier;
  }

  getPlayerDamageMultiplier() {
    return this.getKarmaModifiers().playerDamageMultiplier;
  }

  getEnemyDamageMultiplier() {
    return this.getKarmaModifiers().enemyDamageMultiplier;
  }

  getEliteRateModifier() {
    return this.getKarmaModifiers().eliteRateModifier;
  }

  getHp() {
    return this.state ? this.state.hp : 0;
  }

  getMaxHp() {
    return this.state ? this.state.maxHp : 30;
  }

  modifyHp(delta) {
    if (!this.state) return 0;
    this.state.hp = Math.max(0, Math.min(this.state.maxHp, (this.state.hp || 0) + delta));
    this.save();
    return this.state.hp;
  }

  modifyMaxHp(delta) {
    if (!this.state) return 0;
    this.state.maxHp = Math.max(10, (this.state.maxHp || 30) + delta);
    if (this.state.hp > this.state.maxHp) {
      this.state.hp = this.state.maxHp;
    }
    this.save();
    return this.state.maxHp;
  }

  // ==================== 卡牌构筑操作 ====================

  getDeck() {
    return this.state ? (this.state.allCards || []) : [];
  }

  addCard(card) {
    if (!this.state) return null;
    if (!this.state.allCards) this.state.allCards = [];
    const newCard = {
      ...card,
      id: card.id || generateCardId()
    };
    this.state.allCards.push(newCard);
    recordCodexSeen('card', card.name);
    this.save();
    return newCard;
  }

  removeCard(cardId) {
    if (!this.state || !this.state.allCards) return false;
    const idx = this.state.allCards.findIndex(c => c.id === cardId);
    if (idx !== -1) {
      this.state.allCards.splice(idx, 1);
      this.save();
      return true;
    }
    return false;
  }

  upgradeCard(cardId) {
    if (!this.state || !this.state.allCards) return null;
    const idx = this.state.allCards.findIndex(c => c.id === cardId);
    if (idx !== -1) {
      const upgraded = getUpgradedCard(this.state.allCards[idx]);
      this.state.allCards[idx] = upgraded;
      this.save();
      return upgraded;
    }
    return null;
  }

  // ==================== 法宝/遗物操作 ====================

  getRelics() {
    return this.state ? (this.state.relics || []) : [];
  }

  hasRelic(relicId) {
    if (!this.state || !this.state.relics) return false;
    return this.state.relics.some(r => r.id === relicId || r.name === relicId);
  }

  /**
   * 统一遗物增加入口
   * 检查唯一性和上限，所有场景（事件/商店/战斗奖励）必须走此方法
   * @param {object} relic 遗物对象（需包含 id 或 name）
   * @returns {{ success: boolean, reason: string, relic: object|null }}
   */
  addRelic(relic) {
    if (!this.state) return { success: false, reason: '无运行状态', relic: null };
    if (!relic) return { success: false, reason: '遗物为空', relic: null };
    if (!this.state.relics) this.state.relics = [];

    // 唯一性检查：同 id 或同 name 不可重复
    const relicId = relic.id || relic.name;
    const exists = this.state.relics.some(r =>
      (r.id && r.id === relic.id) || (r.name && r.name === relic.name)
    );
    if (exists) {
      return { success: false, reason: '已拥有此法宝', relic: null };
    }

    // 上限检查
    if (this.state.relics.length >= ECONOMY.MAX_RELICS_PER_RUN) {
      return { success: false, reason: `法宝已满（${ECONOMY.MAX_RELICS_PER_RUN}件）`, relic: null };
    }

    this.state.relics.push(relic);
    recordCodexSeen('relic', relic.id || relic.name);
    this.save();
    return { success: true, reason: '', relic };
  }

  // ==================== 地图与节点探索 ====================

  getMap() {
    return this.state ? this.state.map : [];
  }

  getCurrentNode() {
    if (!this.state || !this.state.currentNodeId) return null;
    return findNodeById(this.state.map, this.state.currentNodeId);
  }

  setCurrentNode(node) {
    if (!this.state || !node) return;
    this.state.currentNodeId = node.id;
    this.save();
  }

  stepTo(targetNodeId) {
    if (!this.state || !this.state.map) return;
    this.state.map = stepToNode(this.state.map, targetNodeId);
    this.save();
  }

  getChapter() {
    return this.state ? (this.state.chapter || 1) : 1;
  }

  advanceChapter(nextChapter = 2) {
    if (!this.state) return;
    this.state.chapter = nextChapter;
    this.state.currentNodeId = null;
    this.state.map = generateChapterMap(nextChapter, 8, this.state.karma || 0);
    this.save();
  }

  getState() {
    return this.state;
  }
}

export const runManager = new RunManager();
export default runManager;