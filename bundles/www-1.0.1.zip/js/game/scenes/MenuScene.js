import { 
  drawParchmentBackground, 
  drawScrollPanel, 
  drawRoundedRect, 
  drawElementBadge, 
  drawTextCentered, 
  drawTextLeft, 
  drawTextRight, 
  createButton, 
  drawSealButton, 
  getElementColor,
  getElementColorDark,
  UI_COLORS 
} from '../scene.js';
import { CHARACTERS, ACHIEVEMENTS, RELIC_TEMPLATES } from '../types.js';
import { CARD_TEMPLATES, SPECIAL_SHOP_CARDS, ENEMY_TEMPLATES, isEnemyUnlocked } from '../data.js';
import { soundManager } from '../../runtime/music.js';
import { TutorialManager } from '../tutorial/index.js';
import { getSelectedChar, saveSelectedChar, wipeRunData, isCharacterUnlocked, getAchievements } from '../../config/storage.js';
import { runManager } from '../RunManager.js';

const RARITY_COLORS = {
  '普通': { fill: '#4A4036', stroke: '#8C7E6C', text: '#DDD4C4' },
  '稀有': { fill: '#1E3A5F', stroke: '#4A90D9', text: '#D8EBFF' },
  '史诗': { fill: '#5C1D54', stroke: '#BA43AA', text: '#FFD6FA' },
  '传说': { fill: '#664511', stroke: '#FFB834', text: '#FFF2C6' }
};

// wrapText 换行缓存：静态文本只计算一次 measureText，后续帧直接复用
const _wrapCache = new Map();

function computeWrapLines(ctx, text, maxWidth, fontSize) {
  const cacheKey = fontSize + '|' + maxWidth + '|' + text;
  let lines = _wrapCache.get(cacheKey);
  if (!lines) {
    ctx.font = fontSize + 'px serif';
    lines = [];
    let line = '';
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const testLine = line + char;
      if (ctx.measureText(testLine).width > maxWidth && line !== '') {
        lines.push(line);
        line = char;
      } else { line = testLine; }
    }
    if (line) lines.push(line);
    if (_wrapCache.size > 500) _wrapCache.clear();
    _wrapCache.set(cacheKey, lines);
  }
  return lines;
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight, color, fontSize) {
  const lines = computeWrapLines(ctx, text, maxWidth, fontSize);
  ctx.font = fontSize + 'px serif';
  ctx.fillStyle = color || '#3B2518';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  for (let i = 0; i < lines.length; i++) {
    ctx.fillText(lines[i], x, y + i * lineHeight);
  }
  return lines;
}

export function createMenuScene(manager) {
  return {
    manager,
    view: 'main', 
    codexTab: 'cards', 
    selectedCharId: 'taoist',
    buttons: [],
    modalButtons: [],
    charCards: [],
    
    scrollY: 0,
    isDragging: false,
    lastTouchY: 0,
    contentHeight: 0,
    hasBoundTouch: false,
    showResetModal: false,

    // 漂浮灵气光尘
    embers: [],

    enter() {
      soundManager.stopAllSfx();
      soundManager.playBgm('menu');

      this.selectedCharId = this.loadSelectedChar();

      if (isCharacterUnlocked('zhong_kui')) {
        CHARACTERS.zhong_kui.unlocked = true;
      }

      this.view = 'main';
      this.codexTab = 'cards';
      this.scrollY = 0;
      this.showResetModal = false;

      this.embers = [];
      for (let i = 0; i < 18; i++) {
        this.embers.push({
          x: Math.random() * this.manager.width,
          y: Math.random() * this.manager.height,
          r: Math.random() * 2 + 1,
          vy: -(Math.random() * 0.4 + 0.2),
          alpha: Math.random() * 0.6 + 0.2
        });
      }

      this.initTouchListeners();
      this.buildUI();
    },

    loadSelectedChar() {
      const saved = getSelectedChar();
      return saved && CHARACTERS[saved] ? saved : 'taoist';
    },

    saveSelectedChar(charId) {
      this.selectedCharId = charId;
      saveSelectedChar(charId);
    },

    // ★ 升级版重置：彻底清除存档、开篇长卷剧情状态、新手教程状态
    wipeRunData() {
      wipeRunData();
      runManager.clearRun();

      if (this.manager && this.manager.scenes) {
        ['map', 'battle', 'shop', 'event', 'rest'].forEach(sceneName => {
           if (this.manager.scenes[sceneName]) {
               this.manager.scenes[sceneName].runState = null;
           }
        });
      }
    },

    // ★ 调试：模拟通关上一章的随机状态
    applySimulatedClearState(targetChapter) {      const state = runManager.state;
      if (!state) return;

      // 可随机获得的卡牌池（排除初始卡组已有的）
      const cardPool = CARD_TEMPLATES.filter(c =>
        !state.allCards.some(init => init.name === c.name) &&
        c.rarity !== '传说'
      );

      // 可随机获得的遗物池
      const relicPool = Object.values(RELIC_TEMPLATES).filter(r => !r.starter);

      const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
      const pick = (arr, n) => {
        const shuffled = [...arr].sort(() => Math.random() - 0.5);
        return shuffled.slice(0, n);
      };

      if (targetChapter === 2) {
        // 模拟通关第一章：1-3张额外卡，0-2个遗物，血量50-90%，钱30-100，因果-3~+3
        const extraCards = pick(cardPool, rand(1, 3));
        extraCards.forEach(c => {
          const card = { ...JSON.parse(JSON.stringify(c)), id: 'card_' + Math.random().toString(36).substr(2, 9), star: 0, isUpgraded: false };
          // 模拟来源：50%商店购买（有price），30%升级到一星，20%普通获得
          const src = Math.random();
          if (src < 0.5) card.price = c.price || rand(40, 80);
          else if (src < 0.8) { card.star = 1; card.isUpgraded = true; }
          state.allCards.push(card);
        });

        const relics = pick(relicPool, rand(0, 2));
        relics.forEach(r => state.relics.push(JSON.parse(JSON.stringify(r))));

        state.hp = Math.floor(state.maxHp * (0.5 + Math.random() * 0.4));
        state.gold = rand(30, 100);
        state.karma = rand(-3, 3);
      } else if (targetChapter === 3) {
        // 模拟通关前两章：3-6张额外卡，1-3个遗物，血量40-80%，钱50-150，因果-5~+5
        const extraCards = pick(cardPool, rand(3, 6));
        extraCards.forEach(c => {
          const card = { ...JSON.parse(JSON.stringify(c)), id: 'card_' + Math.random().toString(36).substr(2, 9), star: 0, isUpgraded: false };
          // 模拟来源：40%商店购买，35%升级到一星，15%升级到二星，10%普通
          const src = Math.random();
          if (src < 0.4) card.price = c.price || rand(45, 95);
          else if (src < 0.75) { card.star = 1; card.isUpgraded = true; }
          else if (src < 0.9) { card.star = 2; card.isUpgraded = true; }
          state.allCards.push(card);
        });

        const relics = pick(relicPool, rand(1, 3));
        relics.forEach(r => state.relics.push(JSON.parse(JSON.stringify(r))));

        state.hp = Math.floor(state.maxHp * (0.4 + Math.random() * 0.4));
        state.gold = rand(50, 150);
        state.karma = rand(-5, 5);
      }

      // 重新计算因果阶位
      state.karmaTier = runManager.calculateKarmaTier(state.karma);
    },
    // ★ 调试：第三章BOSS战满配（全卡2星 + 全遗物 + 满状态）
    applyMaxedBossState() {
      const state = runManager.state;
      if (!state) return;

      // 初始卡组全部升到2星
      state.allCards.forEach(card => {
        card.star = 2;
        card.isUpgraded = true;
      });

      // 补充10张额外强力卡，全部2星
      const ownedNames = state.allCards.map(c => c.name);
      const extraPool = CARD_TEMPLATES.filter(c =>
        !ownedNames.includes(c.name) && !c.isCurse
      );
      const shuffled = [...extraPool].sort(() => Math.random() - 0.5);
      shuffled.slice(0, 10).forEach(cardTpl => {
        state.allCards.push({
          ...JSON.parse(JSON.stringify(cardTpl)),
          id: 'card_' + Math.random().toString(36).substr(2, 9),
          star: 2,
          isUpgraded: true
        });
      });

      // 全部非初始遗物（含剧情遗物，方便测试4个选择分支）
      state.relics = [];
      Object.values(RELIC_TEMPLATES).filter(r => !r.starter).forEach(r => {
        state.relics.push(JSON.parse(JSON.stringify(r)));
      });

      // 满血满状态
      state.maxHp = 80;
      state.hp = 80;
      state.gold = 300;
      state.karma = 0;
      state.karmaTier = runManager.calculateKarmaTier(0);
    },

    initTouchListeners() {
      if (this.hasBoundTouch) return;
      this.hasBoundTouch = true;
      wx.onTouchStart((e) => {
        if (this.manager.getCurrentSceneName() !== 'menu') return;
        if (this.view === 'main' || this.view === 'settings' || this.showResetModal) return;
        if (!e.touches || e.touches.length === 0) return;
        const touch = e.touches[0];
        const topLimit = this.view === 'codex' ? 120 : 80;
        if (touch.clientY > topLimit && touch.clientY < this.manager.height - 75) {
          this.isDragging = true;
          this.lastTouchY = touch.clientY;
        }
      });
      wx.onTouchMove((e) => {
        if (!this.isDragging || !e.touches || e.touches.length === 0 || this.showResetModal) return;
        const touch = e.touches[0];
        const dy = touch.clientY - this.lastTouchY;
        this.lastTouchY = touch.clientY;
        this.scrollY += dy;
        this.clampScroll();
      });
      const endDrag = () => {
        this.isDragging = false;
        this.clampScroll();
      };
      wx.onTouchEnd(endDrag);
      wx.onTouchCancel(endDrag);
    },

    clampScroll() {
      const { height } = this.manager;
      const topLimit = this.view === 'codex' ? 120 : 80;
      const viewportH = height - topLimit - 75; 
      if (this.contentHeight <= viewportH) { this.scrollY = 0; return; }
      const minScroll = viewportH - this.contentHeight;
      this.scrollY = Math.max(minScroll, Math.min(0, this.scrollY));
    },

    buildUI() {
      const { width, height } = this.manager;
      this.manager.input.clearButtons();
      this.buttons = [];
      this.modalButtons = [];
      this.charCards = [];

      if (this.view === 'main') {
        let hasRun = runManager.hasActiveRun();

        const playBtnW = 216;
        const playBtnH = 52;
        const playBtnX = width / 2 - playBtnW / 2;
        const playBtnY = height / 2 + 28;
        const playBtnText = hasRun ? '继 续 降 妖' : '入 卷 启 程';

        const playBtn = createButton(playBtnX, playBtnY, playBtnW, playBtnH, playBtnText, {
          fontSize: 18, 
          tap: () => {
            soundManager.playSfx('btn_click');
            if (!hasRun) {
              this.wipeRunData();
              // 第一次玩：先进入教学关卡
              this.manager.enterScene('battle', { isTutorial: true });
            } else {
              this.manager.enterScene('map', { reset: false, charId: this.selectedCharId });
            }
          }, 
          color: UI_COLORS.cinnabar, 
          textColor: '#FFF8DD'
        });
        playBtn.btnType = 'primary';
        this.buttons.push(playBtn);

        // 新手教学入口
        const tutBtnW = 160;
        const tutBtnH = 32;
        const tutBtnX = width / 2 - tutBtnW / 2;
        const tutBtnY = playBtnY + playBtnH + 10;
        const tutBtn = createButton(tutBtnX, tutBtnY, tutBtnW, tutBtnH, '新手教学', {
          fontSize: 12,
          tap: () => {
            soundManager.playSfx('btn_click');
            this.manager.enterScene('battle', { isTutorial: true });
          },
          color: 'rgba(40, 26, 16, 0.7)',
          textColor: '#C9A96E'
        });
        tutBtn.btnType = 'tutorial';
        this.buttons.push(tutBtn);

        const charBarW = 224;
        const charBarH = 36;
        const charBarX = width / 2 - charBarW / 2;
        const charBarY = tutBtnY + tutBtnH + 12;
        const currentChar = CHARACTERS[this.selectedCharId] || CHARACTERS.taoist;

        const charBtn = createButton(charBarX, charBarY, charBarW, charBarH, `道统 · ${currentChar.name} ▾`, {
          fontSize: 13,
          tap: () => {
            soundManager.playSfx('btn_click');
            this.view = 'char_select';
            this.scrollY = 0;
            this.buildUI();
          },
          color: 'rgba(40, 26, 16, 0.88)',
          textColor: '#E8D5A3'
        });
        charBtn.btnType = 'char_bar';
        this.buttons.push(charBtn);

        const iconSize = 48;
        const totalBottomW = iconSize * 4 + 14 * 3;
        const startIconX = (width - totalBottomW) / 2;
        const bottomIconY = height - 92;

        const bottomMenus = [
          { text: '道统', icon: '道', view: 'char_select' },
          { text: '藏经', icon: '经', view: 'codex', tab: 'cards' },
          { text: '功德', icon: '德', view: 'achievements' },
          { text: '洞府', icon: '设', view: 'settings' }
        ];

        bottomMenus.forEach((m, i) => {
          const bx = startIconX + i * (iconSize + 14);
          const btn = createButton(bx, bottomIconY, iconSize, iconSize + 18, '', {
            tap: () => {
              soundManager.playSfx('btn_click');
              this.view = m.view;
              if (m.tab) this.codexTab = m.tab;
              this.scrollY = 0;
              this.buildUI();
            }
          });
          btn.btnType = 'menu_icon';
          btn.menuData = m;
          this.buttons.push(btn);
        });

        if (hasRun) {
          const resetBtnW = 100;
          const resetBtnH = 28;
          const resetBtn = createButton(width - resetBtnW - 14, height - 34, resetBtnW, resetBtnH, '重入轮回', {
            fontSize: 12,
            tap: () => {
              soundManager.playSfx('btn_click');
              this.showResetModal = true;
              this.buildUI();
            },
            color: 'rgba(45, 32, 22, 0.9)',
            textColor: '#E2CEB0'
          });
          resetBtn.btnType = 'reset';
          this.buttons.push(resetBtn);
        }

      } else if (this.view === 'settings') {
        const panelW = Math.min(320, width - 36);
        const panelX = (width - panelW) / 2;
        const panelY = height / 2 - 130;
        const btnW = 76;
        const btnH = 32;
        const btnX = panelX + panelW - 20 - btnW;

        const bgmBtnText = soundManager.isBgmMuted ? '静音 ✕' : '开启 ✓';
        const sfxBtnText = soundManager.isSfxMuted ? '静音 ✕' : '开启 ✓';
        const fpsOn = typeof window !== 'undefined' && window.gameConfig && window.gameConfig.showFps;
        const fpsBtnText = fpsOn ? '显示 ✓' : '隐藏 ✕';

        this.buttons = [
          createButton(btnX, panelY + 80, btnW, btnH, bgmBtnText, {
            fontSize: 13,
            color: soundManager.isBgmMuted ? '#4A4036' : UI_COLORS.cinnabar,
            textColor: soundManager.isBgmMuted ? '#C0B4A0' : '#FFF8DD',
            tap: () => {
              soundManager.playSfx('btn_click');
              soundManager.toggleBgm();
              this.buildUI();
            }
          }),
          createButton(btnX, panelY + 144, btnW, btnH, sfxBtnText, {
            fontSize: 13,
            color: soundManager.isSfxMuted ? '#4A4036' : UI_COLORS.cinnabar,
            textColor: soundManager.isSfxMuted ? '#C0B4A0' : '#FFF8DD',
            tap: () => {
              soundManager.toggleSfx();
              soundManager.playSfx('btn_click');
              this.buildUI();
            }
          }),
          // 调试模式：FPS 显示开关
          createButton(btnX, panelY + 208, btnW, btnH, fpsBtnText, {
            fontSize: 13,
            color: fpsOn ? UI_COLORS.cinnabar : '#4A4036',
            textColor: fpsOn ? '#FFF8DD' : '#C0B4A0',
            tap: () => {
              soundManager.playSfx('btn_click');
              if (typeof window !== 'undefined') {
                window.gameConfig = window.gameConfig || {};
                window.gameConfig.showFps = !window.gameConfig.showFps;
              }
              this.buildUI();
            }
          }),
          // 调试模式：章节直达
          createButton(panelX + 20, panelY + 264, panelW - 40, 36, '⚙ 章节直达（调试）', {
            fontSize: 13,
            color: '#5C1D54',
            textColor: '#FFD6FA',
            tap: () => {
              soundManager.playSfx('btn_click');
              this.view = 'debug_chapter';
              this.scrollY = 0;
              this.buildUI();
            }
          }),
          createButton(panelX + 20, panelY + 310, panelW - 40, 36, '重置新手引导（重玩教程）', {
            fontSize: 13,
            color: '#5C3A21',
            textColor: '#E8D5A3',
            tap: () => {
              soundManager.playSfx('btn_click');
              TutorialManager.resetAll();
              wx.showToast({ title: '新手引导已重置，下次进入将重新播放', icon: 'none', duration: 2000 });
            }
          }),
          createButton(width / 2 - 80, height - 60, 160, 38, '返回首页', {
            fontSize: 15,
            tap: () => {
              soundManager.playSfx('btn_click');
              this.view = 'main';
              this.buildUI();
            },
            color: UI_COLORS.cinnabar,
            textColor: '#FFF3CA'
          })
        ];
      } else if (this.view === 'char_select') {
        const cardW = width - 48; const gap = 12;
        const chars = Object.values(CHARACTERS);
        let totalHeight = 0;
        chars.forEach((char, index) => {
          const isUnlocked = isCharacterUnlocked(char.id);
          const detailText = isUnlocked
            ? '被动：' + char.passive
            : '解锁条件：' + (char.unlockCondition || '机缘未到');
          const detailLines = computeWrapLines(this.manager.ctx, detailText, cardW - 40, 11);
          const cardH = 66 + detailLines.length * 15 + 10;
          this.charCards.push({ index, w: cardW, h: cardH, char });
          totalHeight += cardH + gap;
        });
        this.contentHeight = totalHeight;

        this.buttons = [
          createButton(width / 2 - 80, height - 60, 160, 38, '确认并返回', {
            fontSize: 15, 
            tap: () => { 
              soundManager.playSfx('btn_click');
              this.view = 'main'; 
              this.buildUI(); 
            }, 
            color: UI_COLORS.cinnabar, 
            textColor: '#FFF3CA'
          })
        ];

        this.manager.input.addTapHandler((x, y) => {
          if (this.view !== 'char_select' || this.showResetModal) return;
          if (y > height - 75) return; 
          
          const startY = 86 + this.scrollY;
          for (const card of this.charCards) {
            const cy = startY + card.index * (card.h + 12);
            if (x >= 24 && x <= 24 + card.w && y >= cy && y <= cy + card.h) {
              soundManager.playSfx('btn_click');
              if (isCharacterUnlocked(card.char.id)) {
                this.saveSelectedChar(card.char.id);
                this.wipeRunData();
                wx.showToast({ title: `已选择 ${card.char.name}`, icon: 'none' });
                this.buildUI(); 
              } else {
                wx.showToast({ title: card.char.unlockCondition || '机缘未到，暂未解锁', icon: 'none' });
              }
              break;
            }
          }
        });
      } else if (this.view === 'debug_chapter') {
        // 调试：章节直达
        const btnW = 220;
        const btnH = 52;
        const startY = height / 2 - 135;
        const chapters = [
          { id: 1, name: '第一章 · 兰若寺', desc: '黑山山魈王' },
          { id: 2, name: '第二章 · 枉死城', desc: '阴阳判官（模拟通关第一章状态）' },
          { id: 3, name: '第三章 · 归墟', desc: '九尾狐（模拟通关前两章状态）' }
        ];
        this.buttons = [];
        chapters.forEach((ch, i) => {
          const btn = createButton(width / 2 - btnW / 2, startY + i * (btnH + 18), btnW, btnH, `${ch.name}`, {
            fontSize: 15,
            tap: () => {
              soundManager.playSfx('btn_click');
              this.wipeRunData();
              runManager.initRun(this.selectedCharId, ch.id);
              // 模拟通关上一章的随机状态
              this.applySimulatedClearState(ch.id);
              runManager.save();
              wx.showToast({ title: `直达${ch.name}`, icon: 'none' });
              this.manager.enterScene('map', { reset: true, charId: this.selectedCharId });
            },
            color: UI_COLORS.cinnabar,
            textColor: '#FFF3CA'
          });
          this.buttons.push(btn);
        });
        // 直接进入第三章BOSS战（满配）
        const bossBtn = createButton(width / 2 - btnW / 2, startY + 3 * (btnH + 18), btnW, btnH, '第三章 · BOSS战(满配)', {
          fontSize: 15,
          tap: () => {
            soundManager.playSfx('btn_click');
            this.wipeRunData();
            runManager.initRun(this.selectedCharId, 3);
            this.applyMaxedBossState();
            runManager.save();
            wx.showToast({ title: '九尾狐·归墟之门', icon: 'none' });
            this.manager.enterScene('battle', { enemyIndex: 16 });
          },
          color: '#5C1D54',
          textColor: '#FFD6FA'
        });
        this.buttons.push(bossBtn);
        // 返回按钮
        this.buttons.push(createButton(width / 2 - 80, height - 60, 160, 38, '返回', {
          fontSize: 15,
          tap: () => {
            soundManager.playSfx('btn_click');
            this.view = 'main';
            this.buildUI();
          },
          color: 'rgba(40, 26, 16, 0.88)',
          textColor: '#E8D5A3'
        }));
      } else if (this.view === 'codex') {
        const tabW = (width - 48 - 16) / 3;
        const tabY = 80;

        this.buttons = [
          createButton(24, tabY, tabW, 30, '符箓宝典', {
            fontSize: 12,
            color: this.codexTab === 'cards' ? UI_COLORS.cinnabar : UI_COLORS.inkSoft,
            textColor: this.codexTab === 'cards' ? '#FFF3CA' : '#D0C8B8',
            tap: () => { 
              soundManager.playSfx('btn_click');
              this.codexTab = 'cards'; 
              this.scrollY = 0; 
              this.buildUI(); 
            }
          }),
          createButton(24 + tabW + 8, tabY, tabW, 30, '稀世法宝', {
            fontSize: 12,
            color: this.codexTab === 'relics' ? UI_COLORS.cinnabar : UI_COLORS.inkSoft,
            textColor: this.codexTab === 'relics' ? '#FFF3CA' : '#D0C8B8',
            tap: () => { 
              soundManager.playSfx('btn_click');
              this.codexTab = 'relics'; 
              this.scrollY = 0; 
              this.buildUI(); 
            }
          }),
          createButton(24 + (tabW + 8) * 2, tabY, tabW, 30, '万妖异录', {
            fontSize: 12,
            color: this.codexTab === 'monsters' ? UI_COLORS.cinnabar : UI_COLORS.inkSoft,
            textColor: this.codexTab === 'monsters' ? '#FFF3CA' : '#D0C8B8',
            tap: () => { 
              soundManager.playSfx('btn_click');
              this.codexTab = 'monsters'; 
              this.scrollY = 0; 
              this.buildUI(); 
            }
          }),
          createButton(width / 2 - 80, height - 60, 160, 38, '返回首页', {
            fontSize: 15, 
            tap: () => { 
              soundManager.playSfx('btn_click');
              this.view = 'main'; 
              this.buildUI(); 
            }, 
            color: UI_COLORS.inkSoft, 
            textColor: '#FFF3CA'
          })
        ];

        if (this.codexTab === 'cards') {
          const allCards = [...CARD_TEMPLATES, ...SPECIAL_SHOP_CARDS];
          this.contentHeight = allCards.length * (80 + 12) + 20;
        } else if (this.codexTab === 'relics') {
          this.contentHeight = RELIC_TEMPLATES.length * (74 + 12) + 20;
        } else {
          this.contentHeight = ENEMY_TEMPLATES.length * (160 + 12) + 20;
          // 点击九尾狐卡片 → 打开 3D 全息闪卡
          this.manager.input.addTapHandler((x, y) => {
            if (this.view !== 'codex' || this.codexTab !== 'monsters') return;
            if (y < 120) return;
            const foxIdx = ENEMY_TEMPLATES.findIndex(e => e.key === 'jiu_wei_hu');
            const cardW = width - 48, cardH = 160, itemH = cardH + 12;
            const cy = 120 + 6 + this.scrollY + foxIdx * itemH;
            if (x >= 24 && x <= 24 + cardW && y >= cy && y <= cy + cardH) {
              const t = typeof window.openHoloCard;
              const r = typeof window.__holoThreeLoaded;
              wx.showToast({ title: `openHolo=${t} holoLoaded=${r}`, icon: 'none', duration: 3500 });
              if (t === 'function') window.openHoloCard();
            }
          });
        }
      } else if (this.view === 'achievements') {
        this.contentHeight = ACHIEVEMENTS.length * (68 + 12) + 20;
        this.buttons = [
          createButton(width / 2 - 80, height - 60, 160, 38, '返回首页', {
            fontSize: 15, 
            tap: () => { 
              soundManager.playSfx('btn_click');
              this.view = 'main'; 
              this.buildUI(); 
            }, 
            color: UI_COLORS.inkSoft, 
            textColor: '#FFF3CA'
          })
        ];
      }

      if (this.showResetModal) {
        this.manager.input.clearButtons();
        
        const panelW = Math.min(310, width - 40); 
        const panelH = 220; 
        const panelY = (height - panelH) / 2;
        const btnW = 110; const btnH = 38; 
        const btnY = panelY + panelH - 52;
        
        const cancelBtn = createButton(width / 2 - btnW - 10, btnY, btnW, btnH, '暂且作罢', { 
          fontSize: 14, color: UI_COLORS.inkSoft, textColor: '#D0C8B8', 
          tap: () => { 
            soundManager.playSfx('btn_click');
            this.showResetModal = false; 
            this.buildUI(); 
          } 
        });
        const confirmBtn = createButton(width / 2 + 10, btnY, btnW, btnH, '执意重置', { 
          fontSize: 14, color: UI_COLORS.cinnabar, textColor: '#FFF3CA', 
          tap: () => { 
            soundManager.playSfx('btn_click');
            this.showResetModal = false;
            this.wipeRunData();
            wx.showToast({ title: '往世与剧情已重置', icon: 'success' });
            this.view = 'main';
            this.scrollY = 0;
            this.buildUI();
          } 
        });
        
        this.modalButtons = [cancelBtn, confirmBtn];
        this.modalButtons.forEach(btn => this.manager.input.addTouchButton(btn));
      } else {
        this.buttons.forEach(btn => this.manager.input.addTouchButton(btn));
      }

      this.clampScroll();
    },

    update() {
      for (const e of this.embers) {
        e.y += e.vy;
        if (e.y < -10) {
          e.y = this.manager.height + 10;
          e.x = Math.random() * this.manager.width;
        }
      }
    },

    render(ctx) {
      const { width, height } = this.manager;
      ctx.clearRect(0, 0, width, height);
      
      drawParchmentBackground(ctx, width, height);

      ctx.save();
      for (const e of this.embers) {
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(201, 154, 58, ${e.alpha})`;
        ctx.shadowColor = '#FFD700';
        ctx.shadowBlur = 4;
        ctx.fill();
      }
      ctx.restore();

      if (this.view === 'main') {
        this.renderMainView(ctx, width, height);
      } else if (this.view === 'settings') {
        this.renderSettingsView(ctx, width, height);
      } else if (this.view === 'char_select') {
        this.renderCharSelectView(ctx, width, height);
      } else if (this.view === 'debug_chapter') {
        // 调试章节选择视图
        ctx.fillStyle = '#8B0000';
        ctx.font = 'bold 22px serif';
        ctx.textAlign = 'center';
        ctx.fillText('【调试模式】章节直达', width / 2, 70);
        ctx.fillStyle = '#666';
        ctx.font = '12px serif';
        ctx.fillText('选择章节直接进入（随机模拟通关上一章状态）', width / 2, 96);
        ctx.fillStyle = '#999';
        ctx.font = '11px serif';
        ctx.fillText('第二章：随机1-3张卡 + 0-2遗物 + 50-90%血量', width / 2, height - 100);
        ctx.fillText('第三章：随机3-6张卡 + 1-3遗物 + 40-80%血量', width / 2, height - 84);
      } else if (this.view === 'codex') {
        this.renderCodexView(ctx, width, height);
      } else if (this.view === 'achievements') {
        this.renderAchievementsView(ctx, width, height);
      }

      for (const btn of this.buttons) {
        if (this.view === 'main') {
          if (btn.btnType === 'primary') {
            const alpha = 0.5 + 0.5 * Math.sin(Date.now() / 320);
            
            drawRoundedRect(ctx, btn.x + 3, btn.y + 4, btn.w, btn.h, 8, UI_COLORS.shadow, null);
            ctx.save();
            ctx.shadowColor = '#FFD700';
            ctx.shadowBlur = 14 * alpha;
            drawRoundedRect(ctx, btn.x, btn.y, btn.w, btn.h, 8, UI_COLORS.cinnabar, '#FFD700', 2);
            ctx.restore();

            ctx.strokeStyle = 'rgba(255, 235, 170, 0.4)';
            ctx.lineWidth = 1;
            ctx.strokeRect(btn.x + 4, btn.y + 4, btn.w - 8, btn.h - 8);

            const cl = 7;
            ctx.strokeStyle = '#FFE8A3';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(btn.x + 7, btn.y + 7 + cl); ctx.lineTo(btn.x + 7, btn.y + 7); ctx.lineTo(btn.x + 7 + cl, btn.y + 7);
            ctx.moveTo(btn.x + btn.w - 7 - cl, btn.y + 7); ctx.lineTo(btn.x + btn.w - 7, btn.y + 7); ctx.lineTo(btn.x + btn.w - 7, btn.y + 7 + cl);
            ctx.moveTo(btn.x + 7, btn.y + btn.h - 7 - cl); ctx.lineTo(btn.x + 7, btn.y + btn.h - 7); ctx.lineTo(btn.x + 7 + cl, btn.y + btn.h - 7);
            ctx.moveTo(btn.x + btn.w - 7 - cl, btn.y + btn.h - 7); ctx.lineTo(btn.x + btn.w - 7, btn.y + btn.h - 7); ctx.lineTo(btn.x + btn.w - 7, btn.y + btn.h - 7 - cl);
            ctx.stroke();

            ctx.save();
            ctx.shadowColor = 'rgba(20, 5, 2, 0.85)';
            ctx.shadowBlur = 4;
            drawTextCentered(ctx, btn.text, btn.x + btn.w / 2, btn.y + btn.h / 2, '#FFF8DD', btn.fontSize || 18, 'serif');
            ctx.restore();

          } else if (btn.btnType === 'char_bar') {
            drawRoundedRect(ctx, btn.x + 2, btn.y + 3, btn.w, btn.h, 18, UI_COLORS.shadow, null);
            drawRoundedRect(ctx, btn.x, btn.y, btn.w, btn.h, 18, 'rgba(40, 26, 16, 0.9)', 'rgba(201, 154, 58, 0.7)', 1.2);
            drawRoundedRect(ctx, btn.x + 3, btn.y + 3, btn.w - 6, btn.h - 6, 15, null, 'rgba(255, 230, 160, 0.18)', 1);
            
            drawRoundedRect(ctx, btn.x + 8, btn.y + btn.h / 2 - 3, 6, 6, 3, UI_COLORS.gold, '#FFE599', 1);
            drawRoundedRect(ctx, btn.x + btn.w - 14, btn.y + btn.h / 2 - 3, 6, 6, 3, UI_COLORS.gold, '#FFE599', 1);
            
            drawTextCentered(ctx, btn.text, btn.x + btn.w / 2, btn.y + btn.h / 2, '#F0E2C8', 13, 'serif');

          } else if (btn.btnType === 'menu_icon') {
            const m = btn.menuData;
            const x = btn.x;
            const y = btn.y;
            const size = btn.w;
            
            drawRoundedRect(ctx, x + 2, y + 3, size, size, 8, UI_COLORS.shadow, null);
            drawRoundedRect(ctx, x, y, size, size, 8, 'rgba(40, 28, 18, 0.92)', '#C99A3A', 1.5);
            drawRoundedRect(ctx, x + 3, y + 3, size - 6, size - 6, 6, null, 'rgba(255, 235, 170, 0.2)', 1);
            drawTextCentered(ctx, m.icon, x + size / 2, y + size / 2 - 1, '#FFE8B5', 20, 'serif');
            drawTextCentered(ctx, m.text, x + size / 2, y + size + 11, '#4B321C', 11, 'serif');

          } else if (btn.btnType === 'reset') {
            drawRoundedRect(ctx, btn.x + 2, btn.y + 2, btn.w, btn.h, 14, UI_COLORS.shadow, null);
            drawRoundedRect(ctx, btn.x, btn.y, btn.w, btn.h, 14, 'rgba(48, 30, 18, 0.92)', 'rgba(201, 154, 58, 0.75)', 1.2);
            
            drawRoundedRect(ctx, btn.x + 4, btn.y + 4, 20, 20, 10, '#8C2A24', '#FFD700', 1);
            drawTextCentered(ctx, '↺', btn.x + 14, btn.y + 14, '#FFF8DD', 12);
            
            drawTextLeft(ctx, btn.text, btn.x + 28, btn.y + btn.h / 2, '#EADBCE', 12, 'serif');
          }
        } else {
          drawSealButton(ctx, btn);
        }
      }

      if (this.showResetModal) {
        this.renderResetModal(ctx, width, height);
        for (const btn of this.modalButtons) {
          drawSealButton(ctx, btn);
        }
      }
    },

    renderMainView(ctx, width, height) {
      const centerX = width / 2;
      const titleY = height / 2 - 130;

      ctx.save();
      ctx.strokeStyle = 'rgba(180, 130, 70, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(centerX, titleY - 15, 82, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(centerX, titleY - 15, 74, 0, Math.PI * 2);
      ctx.setLineDash([8, 6]);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.strokeStyle = 'rgba(140, 95, 45, 0.2)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(centerX, titleY - 15 - 28, 28, Math.PI * 0.5, Math.PI * 1.5);
      ctx.arc(centerX, titleY - 15 + 28, 28, Math.PI * 1.5, Math.PI * 0.5);
      ctx.stroke();
      ctx.restore();

      ctx.save();
      ctx.shadowColor = 'rgba(150, 42, 31, 0.35)';
      ctx.shadowBlur = 12;
      drawTextCentered(ctx, '妖 异 录', centerX, titleY - 35, UI_COLORS.ink, 44, 'serif');
      ctx.restore();

      drawRoundedRect(ctx, centerX - 92, titleY + 2, 184, 24, 12, 'rgba(150, 42, 31, 0.12)', 'rgba(150, 42, 31, 0.45)', 1);
      drawTextCentered(ctx, '五行符箓 · 因果轮回', centerX, titleY + 14, UI_COLORS.cinnabar, 12, 'serif');
      drawTextCentered(ctx, '— 妖异入卷 · 唯道独尊 —', centerX, titleY + 44, '#6B492B', 12, 'serif');
    },

    renderSettingsView(ctx, width, height) {
      drawTextCentered(ctx, '洞 府 设 置', width / 2, 40, UI_COLORS.ink, 24, 'serif');
      drawTextCentered(ctx, '调理琴音妙律 · 掌控万物音效', width / 2, 66, '#6B4A2E', 12, 'serif');

      const panelW = Math.min(320, width - 36);
      const panelH = 360;
      const panelX = (width - panelW) / 2;
      const panelY = height / 2 - 180;

      drawScrollPanel(ctx, panelX, panelY, panelW, panelH, { 
        fill: 'rgba(252, 246, 230, 0.98)', 
        stroke: UI_COLORS.gold, 
        strokeWidth: 2 
      });

      drawTextCentered(ctx, '【 音 律 调 和 】', width / 2, panelY + 30, UI_COLORS.cinnabar, 17, 'serif');
      ctx.strokeStyle = 'rgba(180, 130, 70, 0.35)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(panelX + 24, panelY + 52);
      ctx.lineTo(panelX + panelW - 24, panelY + 52);
      ctx.stroke();

      const row1Y = panelY + 70;
      drawRoundedRect(ctx, panelX + 16, row1Y, panelW - 32, 52, 6, 'rgba(244, 235, 212, 0.92)', 'rgba(160, 120, 70, 0.35)', 1);
      drawRoundedRect(ctx, panelX + 24, row1Y + 12, 28, 28, 14, UI_COLORS.inkSoft, UI_COLORS.gold, 1);
      drawTextCentered(ctx, '琴', panelX + 38, row1Y + 26, '#FFF8DD', 13, 'serif');
      drawTextLeft(ctx, '背景音乐', panelX + 60, row1Y + 18, UI_COLORS.ink, 15, 'serif');
      drawTextLeft(ctx, '仙音绕梁 · 伴随修真', panelX + 60, row1Y + 36, '#7A5531', 11, 'serif');

      const row2Y = panelY + 134;
      drawRoundedRect(ctx, panelX + 16, row2Y, panelW - 32, 52, 6, 'rgba(244, 235, 212, 0.92)', 'rgba(160, 120, 70, 0.35)', 1);
      drawRoundedRect(ctx, panelX + 24, row2Y + 12, 28, 28, 14, UI_COLORS.inkSoft, UI_COLORS.gold, 1);
      drawTextCentered(ctx, '鸣', panelX + 38, row2Y + 26, '#FFF8DD', 13, 'serif');
      drawTextLeft(ctx, '战斗音效', panelX + 60, row2Y + 18, UI_COLORS.ink, 15, 'serif');
      drawTextLeft(ctx, '剑气破空 · 金石交错', panelX + 60, row2Y + 36, '#7A5531', 11, 'serif');

      drawTextCentered(ctx, '— 点击右侧印章即可即时生效 —', width / 2, panelY + 212, '#8A6D4B', 11, 'serif');

      // 调试模式区块
      ctx.strokeStyle = 'rgba(180, 130, 70, 0.35)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(panelX + 24, panelY + 248);
      ctx.lineTo(panelX + panelW - 24, panelY + 248);
      ctx.stroke();

      drawTextCentered(ctx, '【 调 试 模 式 】', width / 2, panelY + 268, '#8B0000', 15, 'serif');

      // FPS 显示行
      const fpsRowY = panelY + 290;
      drawRoundedRect(ctx, panelX + 16, fpsRowY, panelW - 32, 44, 6, 'rgba(244, 235, 212, 0.92)', 'rgba(160, 120, 70, 0.35)', 1);
      drawRoundedRect(ctx, panelX + 24, fpsRowY + 8, 28, 28, 14, '#8B0000', '#FF6B6B', 1);
      drawTextCentered(ctx, 'FPS', panelX + 38, fpsRowY + 22, '#FFF8DD', 11, 'serif');
      drawTextLeft(ctx, '帧率显示', panelX + 60, fpsRowY + 13, UI_COLORS.ink, 14, 'serif');
      drawTextLeft(ctx, '左上角显示当前 FPS 数值', panelX + 60, fpsRowY + 29, '#7A5531', 10, 'serif');
    },

    renderResetModal(ctx, width, height) {
      ctx.fillStyle = 'rgba(6, 3, 1, 0.90)'; 
      ctx.fillRect(0, 0, width, height);
      
      const panelW = Math.min(310, width - 40); 
      const panelH = 220; 
      const panelY = (height - panelH) / 2;
      
      drawScrollPanel(ctx, (width - panelW)/2, panelY, panelW, panelH, { fill: 'rgba(252, 246, 230, 0.98)', stroke: UI_COLORS.cinnabar, strokeWidth: 2.5 });
      drawTextCentered(ctx, '重 入 轮 回', width / 2, panelY + 34, UI_COLORS.cinnabar, 20, 'serif');
      
      ctx.strokeStyle = 'rgba(180, 130, 70, 0.35)'; ctx.lineWidth = 1; ctx.beginPath(); 
      ctx.moveTo((width - panelW)/2 + 24, panelY + 54); 
      ctx.lineTo((width - panelW)/2 + panelW - 24, panelY + 54); 
      ctx.stroke();
      
      drawTextCentered(ctx, '此举将清空当前妖卷的游玩进度与剧情记忆', width / 2, panelY + 86, UI_COLORS.ink, 14, 'serif');
      drawTextCentered(ctx, '（开篇史诗画卷与新手指引将重新触发）', width / 2, panelY + 112, '#2B6B46', 12, 'serif');
      drawTextCentered(ctx, '道友确定要斩断因果，重塑对局吗？', width / 2, panelY + 140, '#8C2A24', 13, 'serif');
    },

    renderCharSelectView(ctx, width, height) {
      drawTextCentered(ctx, '选择道统', width / 2, 38, UI_COLORS.ink, 24, 'serif');
      drawTextCentered(ctx, '不同道统具备专属气血、被动与五行亲和', width / 2, 64, '#6B4A2E', 12, 'serif');

      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 80, width, height - 80 - 75);
      ctx.clip();

      let runningY = 86 + this.scrollY;
      const gap = 12;

      for (const item of this.charCards) {
        const { index, w, h, char } = item;
        const x = 24;
        const y = runningY;

        const isSelected = this.selectedCharId === char.id;
        const isUnlocked = isCharacterUnlocked(char.id);

        const strokeColor = isSelected ? '#C99A3A' : (isUnlocked ? 'rgba(120, 85, 50, 0.35)' : 'rgba(80, 80, 80, 0.3)');
        const fillColor = isSelected ? 'rgba(255, 248, 225, 0.98)' : (isUnlocked ? 'rgba(247, 235, 205, 0.88)' : 'rgba(210, 200, 185, 0.6)');
        drawRoundedRect(ctx, x, y, w, h, 8, fillColor, strokeColor, isSelected ? 2.5 : 1);

        if (isSelected) {
          drawRoundedRect(ctx, x + w - 48, y + 6, 42, 20, 4, UI_COLORS.cinnabar, '#FFD700', 1);
          drawTextCentered(ctx, '出战', x + w - 27, y + 16, '#FFF8DD', 11, 'serif');
        }

        drawElementBadge(ctx, char.elementPreference[0] || '无', x + 24, y + 26, 14);

        const nameText = char.name || '';
        const titleText = char.title ? `「${char.title}」` : '';
        
        ctx.font = '16px serif';
        const nameWidth = ctx.measureText(nameText).width;
        
        drawTextLeft(ctx, nameText, x + 46, y + 24, isUnlocked ? UI_COLORS.ink : '#555555', 16, 'serif');
        if (titleText) {
          drawTextLeft(ctx, titleText, x + 46 + nameWidth + 8, y + 25, isUnlocked ? '#7A5531' : '#777777', 12, 'serif');
        }

        drawTextLeft(ctx, `气血上限 ${char.maxHp}  |  初始灵气 ${char.maxEnergy}`, x + 20, y + 48, isUnlocked ? '#8C2A24' : '#666666', 12, 'serif');
        
        if (isUnlocked) {
          wrapText(ctx, '被动：' + char.passive, x + 20, y + 66, w - 40, 15, '#2E6B46', 11);
        } else {
          wrapText(ctx, '解锁条件：' + (char.unlockCondition || '机缘未到'), x + 20, y + 66, w - 40, 15, '#7A221B', 11);
          ctx.fillStyle = 'rgba(0, 0, 0, 0.08)'; 
          ctx.fillRect(x + 2, y + 2, w - 4, h - 4);
        }
        runningY += h + gap;
      }
      ctx.restore();
    },

    renderCodexView(ctx, width, height) {
      drawTextCentered(ctx, '藏 经 阁', width / 2, 36, UI_COLORS.ink, 24, 'serif');
      drawTextCentered(ctx, '天地符箓 · 万千至宝 · 诸界妖邪皆入画卷', width / 2, 60, '#6B4A2E', 12, 'serif');

      const topLimit = 120;
      const viewportH = height - topLimit - 75;

      ctx.save();
      ctx.beginPath();
      ctx.rect(0, topLimit, width, viewportH);
      ctx.clip();

      const cardW = width - 48;
      const gap = 12;

      if (this.codexTab === 'cards') {
        const allCards = this._codexAllCards || (this._codexAllCards = [...CARD_TEMPLATES, ...SPECIAL_SHOP_CARDS]);
        const cardH = 80;
        const startY = topLimit + 6 + this.scrollY;
        const itemH = cardH + gap;

        // ★ 视口裁剪：只渲染可见区域内的卡牌
        const firstVisible = Math.max(0, Math.floor((-this.scrollY - 6) / itemH) - 1);
        const lastVisible = Math.min(allCards.length - 1, Math.ceil((-this.scrollY + viewportH - 6) / itemH) + 1);

        for (let idx = firstVisible; idx <= lastVisible; idx++) {
          const card = allCards[idx];
          if (!card) continue;
          const cy = startY + idx * itemH;
          const colorDark = getElementColorDark(card.element);
          
          drawRoundedRect(ctx, 24, cy, cardW, cardH, 6, 'rgba(247, 235, 205, 0.92)', getElementColor(card.element), 1.5);
          
          drawElementBadge(ctx, card.element, 44, cy + 22, 13);
          drawTextLeft(ctx, card.name, 66, cy + 20, UI_COLORS.ink, 15, 'serif');

          const costDesc = `灵气: ${card.cost + (card.dualElement ? 1 : 0)}`;
          drawTextLeft(ctx, `${costDesc}  |  ${card.type || '普通'}`, 150, cy + 20, '#7A5531', 11, 'serif');

          if (SPECIAL_SHOP_CARDS.some(sc => sc.name === card.name)) {
            drawRoundedRect(ctx, 24 + cardW - 48, cy + 8, 40, 18, 4, '#5C1D54', '#FFD6FA', 1);
            drawTextCentered(ctx, '神通', 24 + cardW - 28, cy + 17, '#FFF8DD', 10, 'serif');
          }

          wrapText(ctx, card.description || '暂无详细描述', 34, cy + 44, cardW - 48, 16, colorDark, 11);
        }
      } else if (this.codexTab === 'relics') {
        const cardH = 74;
        const startY = topLimit + 6 + this.scrollY;
        const itemH = cardH + gap;

        const firstVisible = Math.max(0, Math.floor((-this.scrollY - 6) / itemH) - 1);
        const lastVisible = Math.min(RELIC_TEMPLATES.length - 1, Math.ceil((-this.scrollY + viewportH - 6) / itemH) + 1);

        for (let idx = firstVisible; idx <= lastVisible; idx++) {
          const relic = RELIC_TEMPLATES[idx];
          if (!relic) continue;
          const cy = startY + idx * itemH;
          const rStyle = RARITY_COLORS[relic.rarity] || RARITY_COLORS['普通'];

          drawRoundedRect(ctx, 24, cy, cardW, cardH, 6, 'rgba(247, 235, 205, 0.92)', rStyle.stroke, 1.5);

          drawRoundedRect(ctx, 34, cy + 12, 34, 18, 3, rStyle.fill, rStyle.stroke, 1);
          drawTextCentered(ctx, relic.rarity, 51, cy + 21, rStyle.text, 10, 'serif');

          drawTextLeft(ctx, relic.name, 76, cy + 20, UI_COLORS.ink, 15, 'serif');
          wrapText(ctx, relic.description || '暂无法宝描述', 34, cy + 42, cardW - 48, 16, '#543825', 11);
        }
      } else {
        const cardH = 160;
        const startY = topLimit + 6 + this.scrollY;
        const itemH = cardH + gap;

        const firstVisible = Math.max(0, Math.floor((-this.scrollY - 6) / itemH) - 1);
        const lastVisible = Math.min(ENEMY_TEMPLATES.length - 1, Math.ceil((-this.scrollY + viewportH - 6) / itemH) + 1);

        for (let idx = firstVisible; idx <= lastVisible; idx++) {
          const enemy = ENEMY_TEMPLATES[idx];
          if (!enemy) continue;
          const cy = startY + idx * itemH;
          const isBoss = enemy.special.includes('魁首');
          const isElite = enemy.special.includes('精英');
          const unlocked = isEnemyUnlocked(enemy.key);

          const strokeColor = isBoss ? '#9E2F24' : (isElite ? '#BA43AA' : getElementColor(enemy.element));
          const strokeWidth = isBoss ? 2 : (isElite ? 1.8 : 1.2);

          // 未解锁时卡片半透明
          const fillColor = unlocked ? 'rgba(247, 235, 205, 0.92)' : 'rgba(220, 210, 190, 0.6)';
          drawRoundedRect(ctx, 24, cy, cardW, cardH, 6, fillColor, strokeColor, strokeWidth);

          drawElementBadge(ctx, enemy.element, 44, cy + 22, 13);
          drawTextLeft(ctx, enemy.name, 64, cy + 20, isBoss ? '#8C2A24' : UI_COLORS.ink, 15, 'serif');

          const tagText = isBoss ? '魁首' : (isElite ? '精英' : '妖邪');
          const tagFill = isBoss ? UI_COLORS.cinnabar : (isElite ? '#5C1D54' : '#4A4036');
          const tagStroke = isBoss ? '#FFD700' : (isElite ? '#FFD6FA' : '#8C7E6C');
          drawRoundedRect(ctx, 24 + cardW - 46, cy + 8, 38, 18, 3, tagFill, tagStroke, 1);
          drawTextCentered(ctx, tagText, 24 + cardW - 27, cy + 17, '#FFF8DD', 10, 'serif');

          if (unlocked) {
            // 已解锁：显示数值、特性、技能
            const behaviorTag = enemy.behavior === 'defensive' ? '防守型' : (enemy.behavior === 'aggressive' ? '激进型' : '平衡型');
            drawTextLeft(ctx, `气血 ${enemy.hp} | 攻 ${enemy.attack} | ${behaviorTag}`, 155, cy + 20, '#7A5531', 11, 'serif');

            wrapText(ctx, `【特性】${enemy.special}`, 32, cy + 42, cardW - 48, 14, '#543825', 11);
            wrapText(ctx, `【技能】${enemy.skills || '普通攻防'}`, 32, cy + 70, cardW - 48, 14, isBoss ? '#8C2A24' : (isElite ? '#5C1D54' : '#2B6B46'), 11);
            // 背景故事
            wrapText(ctx, `【志怪】${enemy.background || '暂无记载'}`, 32, cy + 100, cardW - 48, 15, '#6B5A42', 10);
          } else {
            // 未解锁：只显示背景故事，数值和技能显示未解锁
            drawTextLeft(ctx, '气血 ??? | 攻 ??? | 未知', 155, cy + 20, '#999999', 11, 'serif');

            wrapText(ctx, `【特性】未解锁`, 32, cy + 42, cardW - 48, 14, '#999999', 11);
            wrapText(ctx, `【技能】未解锁`, 32, cy + 62, cardW - 48, 14, '#999999', 11);
            // 背景故事（始终显示）
            wrapText(ctx, `【志怪】${enemy.background || '暂无记载'}`, 32, cy + 88, cardW - 48, 15, '#543825', 10);

            // 右下角提示
            drawTextRight(ctx, '击败后解锁详情', 24 + cardW - 12, cy + cardH - 10, '#AA9988', 9, 'serif');
          }
        }
      }

      ctx.restore();
    },

    renderAchievementsView(ctx, width, height) {
      drawTextCentered(ctx, '功 德 碑', width / 2, 38, UI_COLORS.ink, 24, 'serif');
      drawTextCentered(ctx, '铭记修真岁月中的不世之功', width / 2, 64, '#6B4A2E', 12, 'serif');

      let unlockedData = getAchievements();

      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 80, width, height - 80 - 75);
      ctx.clip();

      const startY = 86 + this.scrollY;
      const cardW = width - 48;
      const cardH = 68;
      const gap = 12;
      const itemH = cardH + gap;
      const viewportTop = 80;
      const viewportH = height - 80 - 75;

      // ★ 视口裁剪
      const firstVisible = Math.max(0, Math.floor((-this.scrollY - 6) / itemH) - 1);
      const lastVisible = Math.min(ACHIEVEMENTS.length - 1, Math.ceil((-this.scrollY + viewportH - 6) / itemH) + 1);

      for (let index = firstVisible; index <= lastVisible; index++) {
        const ach = ACHIEVEMENTS[index];
        if (!ach) continue;
        const isUnlocked = !!unlockedData[ach.id];
        const cy = startY + index * itemH;

        const strokeColor = isUnlocked ? '#C99A3A' : 'rgba(80, 80, 80, 0.3)';
        const fillColor = isUnlocked ? 'rgba(255, 248, 225, 0.98)' : 'rgba(210, 200, 185, 0.4)';
        drawRoundedRect(ctx, 24, cy, cardW, cardH, 8, fillColor, strokeColor, isUnlocked ? 1.5 : 1);

        drawRoundedRect(ctx, 36, cy + 14, 40, 40, 6, isUnlocked ? UI_COLORS.cinnabar : '#888888', isUnlocked ? '#FFD700' : '#666666', 1.5);
        drawTextCentered(ctx, ach.icon, 56, cy + 34, isUnlocked ? '#FFF8DD' : '#DDDDDD', 18, 'serif');

        drawTextLeft(ctx, ach.name, 90, cy + 22, isUnlocked ? UI_COLORS.ink : '#666666', 16, 'serif');
        drawTextLeft(ctx, ach.desc, 90, cy + 46, isUnlocked ? '#543825' : '#888888', 11, 'serif');

        if (isUnlocked) {
          drawTextCentered(ctx, '已达成', 24 + cardW - 36, cy + 34, '#C99A3A', 12, 'serif');
        } else {
          drawTextCentered(ctx, '未达成', 24 + cardW - 36, cy + 34, '#999999', 12, 'serif');
        }
      }
      
      ctx.restore();
    }
  };
}
