/**
 * 全局音效与音乐管理器 (修复版)
 */
import { isBgmMuted, setBgmMuted, isSfxMuted, setSfxMuted } from '../config/storage.js';

class SoundManager {
  constructor() {
    this.bgmAudio = null;
    this.currentBgm = null;
    this.isBgmMuted = false;
    this.isSfxMuted = false;
    this.sfxPool = {};
    this.poolSize = 4;

    this.audioPaths = {
      // 本地 BGM 部署
      bgm_menu: 'audio/bgm_menu.mp3',
      bgm_map: 'audio/bgm_menu.mp3',      // ★ 补齐地图探索 BGM 注册
      bgm_battle1: 'audio/bgm_battle1.mp3',
      bgm_battle2: 'audio/bgm_battle2.mp3',
      bgm_shop: 'audio/bgm_shop.mp3',
      bgm_rest: 'audio/bgm_shop.mp3',      // ★ 补齐静室调息 BGM 注册
      
      // 本地动作与界面音效
      btn_click: 'audio/btn_click.mp3',
      card_play: 'audio/card_play.mp3',
      hit: 'audio/hit.mp3',
      crit: 'audio/crit.mp3',
      shield_block: 'audio/shield_block.mp3',
      shield_break: 'audio/shield_break.mp3',
      coin: 'audio/coin.mp3',
      heal: 'audio/heal.mp3',
      mark_gold: 'audio/mark_gold.mp3',
      mark_fire: 'audio/mark_fire.mp3',
      mark_water: 'audio/mark_water.mp3',
      mark_wood: 'audio/mark_wood.mp3',
      mark_earth: 'audio/mark_earth.mp3',
      victory: 'audio/victory.mp3',
      defeat: 'audio/defeat.mp3'
    };

    this.init();
  }

  init() {
    this.isBgmMuted = isBgmMuted();
    this.isSfxMuted = isSfxMuted();

    if (typeof wx !== 'undefined' && wx.createInnerAudioContext) {
      this.bgmAudio = wx.createInnerAudioContext();
      this.bgmAudio.loop = true;
      this.bgmAudio.obeyMuteSwitch = false;
      this.bgmAudio.volume = 0.6;
    }
  }

  playBgm(bgmKey) {
    if (!this.bgmAudio) return;
    const fullKey = `bgm_${bgmKey}`;
    // 智能兜底：若未指定则回退至主菜单仙音
    const src = this.audioPaths[fullKey] || this.audioPaths['bgm_menu'];
    if (!src || this.currentBgm === fullKey) return;

    this.currentBgm = fullKey;
    this.bgmAudio.stop();
    this.bgmAudio.src = src;

    if (!this.isBgmMuted) {
      this.bgmAudio.play();
    }
  }

  stopBgm() {
    if (this.bgmAudio) {
      this.bgmAudio.stop();
      this.currentBgm = null;
    }
  }

  toggleBgm() {
    this.isBgmMuted = !this.isBgmMuted;
    setBgmMuted(this.isBgmMuted);

    if (this.isBgmMuted) {
      if (this.bgmAudio) this.bgmAudio.pause();
    } else {
      if (this.bgmAudio) {
        if (this.currentBgm) {
          this.bgmAudio.play();
        } else {
          this.playBgm('menu');
        }
      }
    }
    return !this.isBgmMuted;
  }

  toggleSfx() {
    this.isSfxMuted = !this.isSfxMuted;
    setSfxMuted(this.isSfxMuted);

    if (this.isSfxMuted) {
      this.stopAllSfx(true);
    }
    return !this.isSfxMuted;
  }

  stopAllSfx(includeUI = false) {
    Object.keys(this.sfxPool).forEach(key => {
      if (!includeUI && (key === 'btn_click' || key === 'coin' || key === 'victory')) {
        return;
      }
      this.sfxPool[key].forEach(audio => {
        if (audio) audio.stop();
      });
    });
  }

  playSfx(sfxKey) {
    if (this.isSfxMuted || !this.audioPaths[sfxKey]) return;

    if (!this.sfxPool[sfxKey]) {
      this.sfxPool[sfxKey] = [];
    }

    const pool = this.sfxPool[sfxKey];
    let audio = pool.find(a => a.paused || a.ended);

    if (!audio && pool.length < this.poolSize) {
      audio = wx.createInnerAudioContext();
      audio.src = this.audioPaths[sfxKey];
      audio.obeyMuteSwitch = false;
      audio.volume = 1.0;
      audio.onError(() => {});
      pool.push(audio);
    }

    if (!audio && pool.length > 0) {
      audio = pool[0];
    }

    if (audio) {
      audio.stop();
      audio.play();
    }
  }
}

export const soundManager = new SoundManager();