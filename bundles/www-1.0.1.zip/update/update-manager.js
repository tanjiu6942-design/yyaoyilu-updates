// 妖异录 更新管理器（普通脚本，通过 window.Capacitor.Plugins 调用原生插件）
// 1) web 内容热更：发现新版静默下载，下次进入生效（玩家无感）
// 2) 整包更新：原生版本落后时弹窗，跳转浏览器下载新 APK
(function () {
  'use strict';

  // 更新清单（GitHub 公开仓库，raw 静态文件，GET）
  var UPDATE_URL = 'https://raw.githubusercontent.com/tanjiu6942-design/yyaoyilu-updates/main/update.json';
  // 内置 web 版本（每次发 APK 由发布脚本同步写入）
  var BUILTIN_WEB_VERSION = '1.0.0';

  var Cap = window.Capacitor;
  if (!Cap || !Cap.Plugins || !Cap.Plugins.CapacitorUpdater) return; // 非真机/无插件：静默退出
  var Updater = Cap.Plugins.CapacitorUpdater;
  var App = Cap.Plugins.App;
  var Browser = Cap.Plugins.Browser;

  // ---------- 简易 toast ----------
  function toast(msg, ms) {
    var t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = 'position:fixed;left:50%;top:16%;transform:translateX(-50%);background:rgba(20,14,10,.92);color:#e8d5a0;border:1px solid #c99a3a;border-radius:8px;padding:10px 16px;font-size:14px;z-index:90001;max-width:82%;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,.5);';
    document.body.appendChild(t);
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, ms || 2600);
  }

  // ---------- semver 简化比较 ----------
  function parseVer(v) { var m = String(v || '').match(/\d+/g); return m ? m.map(Number) : [0]; }
  function gt(a, b) {
    a = parseVer(a); b = parseVer(b);
    for (var i = 0; i < Math.max(a.length, b.length); i++) {
      var x = a[i] || 0, y = b[i] || 0;
      if (x !== y) return x > y;
    }
    return false;
  }

  function openExternal(url) {
    if (Browser && Browser.open) Browser.open({ url: url });
    else window.open(url, '_blank');
  }

  // ---------- 整包更新弹窗（古风） ----------
  function showNativeDialog(info) {
    var mask = document.createElement('div');
    mask.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.66);z-index:90000;display:flex;align-items:center;justify-content:center;';
    var box = document.createElement('div');
    box.style.cssText = 'width:82%;max-width:360px;background:linear-gradient(160deg,#241a12,#160f0a);border:1px solid #c99a3a;border-radius:14px;padding:20px;text-align:center;color:#e8d5a0;box-shadow:0 0 24px rgba(201,154,58,.25);';
    var h = document.createElement('div'); h.textContent = '发现新版本'; h.style.cssText = 'font-size:18px;color:#f0d98a;margin-bottom:10px;';
    var n = document.createElement('div'); n.textContent = info.notes || '修复与优化，建议更新。'; n.style.cssText = 'font-size:14px;line-height:1.6;margin-bottom:18px;color:#cdb98a;white-space:pre-wrap;';
    var btn = document.createElement('button'); btn.textContent = '前往下载更新';
    btn.style.cssText = 'background:#c99a3a;color:#1a1208;border:none;border-radius:8px;padding:10px 22px;font-size:15px;font-weight:600;';
    var later = document.createElement('button'); later.textContent = '稍后';
    later.style.cssText = 'background:transparent;color:#9c8a63;border:1px solid #6b5a39;border-radius:8px;padding:9px 18px;font-size:14px;margin-left:10px;';
    btn.onclick = function () { openExternal(info.apkUrl); if (mask.parentNode) mask.parentNode.removeChild(mask); };
    later.onclick = function () { if (mask.parentNode) mask.parentNode.removeChild(mask); };
    var row = document.createElement('div'); row.appendChild(btn); row.appendChild(later);
    box.appendChild(h); box.appendChild(n); box.appendChild(row);
    mask.appendChild(box);
    document.body.appendChild(mask);
  }

  // ---------- 主检查 ----------
  async function check() {
    var info;
    try {
      var res = await fetch(UPDATE_URL + '?t=' + Date.now(), { cache: 'no-store' });
      info = await res.json();
    } catch (e) { return; } // 无网络/失败：静默

    // 1) web 内容热更
    try {
      var cur = BUILTIN_WEB_VERSION;
      try { var c = await Updater.current(); if (c && c.bundle && c.bundle.version) cur = c.bundle.version; } catch (e) {}
      if (info.webVersion && gt(info.webVersion, cur) && info.webUrl) {
        toast('正在下载更新…', 1500);
        var bundle = await Updater.download({
          url: info.webUrl,
          version: info.webVersion,
          checksum: info.webChecksum || undefined
        });
        await Updater.set({ id: bundle.id });
        toast('更新已就绪，下次进入游戏生效', 3200);
      }
    } catch (e) { if (window.console) console.warn('web 热更失败', e); }

    // 2) 整包更新（原生版本落后）
    try {
      var buildCode = 0;
      if (App && App.getInfo) { var ni = await App.getInfo(); buildCode = parseInt(ni.build || '0', 10) || 0; }
      if (info.forceNative && info.apkUrl && info.nativeVersionCode && info.nativeVersionCode > buildCode) {
        showNativeDialog(info);
      }
    } catch (e) {}
  }

  // 当前 bundle 已正常加载 → 通知插件，防止其判定失败而回滚
  try { Updater.notifyAppReady(); } catch (e) {}
  // 延迟检查，等游戏先加载
  setTimeout(check, 3500);
})();
